# PadSpan HA — BLE Room-Presence Tracking for Home Assistant
# Copyright (C) 2026 Garry Broeckling
# Licensed under the GNU General Public License v3.0
# See LICENSE file or https://www.gnu.org/licenses/gpl-3.0.html
from __future__ import annotations

"""
PadSpan HA — Settings Store
=============================
Persistent UI settings — toggling sample/live mode, tuning BLE parameters
(ref power, path-loss exponent, Kalman Q/R), controlling which
entity types are published, and storing per-scanner RSSI offsets.

All settings live in a single flat dict persisted to
``.storage/padspan_ha.settings``.  Unknown keys from future versions are
preserved on load (merged onto DEFAULT_SETTINGS).
"""


import logging
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from homeassistant.core import HomeAssistant
from homeassistant.helpers.storage import Store

from .build_info import EDITION
from .const import SETTINGS_STORE_KEY

_LOGGER = logging.getLogger(__name__)

# Settings that no longer do anything, dropped from the file at its next save.
# vendor_lookup_enabled: the online maker lookup's switch. Makers now come from
# built-in lists, and nothing is sent, so there is nothing to switch.
RETIRED_SETTINGS: tuple[str, ...] = ("vendor_lookup_enabled",)

DEFAULT_SETTINGS: dict[str, Any] = {
    "data_mode": "sample",  # "sample" | "live"
    "cpu_mode": "shared",  # "shared" | "single" | "dedicated" — see PresenceCoordinator
    "low_memory_mode": False,  # caps for a 2 GB machine — see low_memory.py
    "report_locked_key": "",       # sha256 of a FREE licence key granted from 0.38.181 (trial, tester, free year): the usage report stays on while that key is here and unexpired (report_locked_until)
    "guest_tags_enabled": False,   # guest tags (guest_tags.py): off until chosen in Settings; nothing runs while off
    "guest_retention_days": 30,    # a finished guest stay's report is kept this long: 0, 7, 30 or 90
    "optimize_for_scale": False,  # several wall screens: a slim snapshot for Overview and the 3D people, a longer shared cache, no polls while a page is hidden — snapshot_builder.slim_snapshot
    # Enhanced security (ws_common.require_admin_if_enhanced): off = every
    # command as before; on = only an admin changes the home's shared setup.
    # Only an admin turns it on or off.
    "enhanced_security": False,
    "update_check_enabled": True,  # daily version ping to padspan.traks.ca (see README)
    # Opt-in usage report (telemetry.py). OFF until a person turns it on;
    # the id is minted on first enable and can be replaced from Settings.
    "telemetry_enabled": False,
    "telemetry_asked": False,      # the panel asked once, and got an answer either way
    "telemetry_heard": "",         # where they heard about PadSpan (telemetry.HEARD_WORDS), their own answer; "" = not said
    # The version the what's-new card last reported. Seeded silently the first
    # time the panel sees it, so a FRESH install is never told it "updated".
    "whatsnew_seen_version": "",
    # When this install first ran PadSpan (epoch seconds), stamped once by
    # async_load. The Overview's one-time trial milestone card waits 7 days
    # from it. An install from before the key existed is stamped on its first
    # load of this version, so its 7 days count from the update, not from
    # when it was really installed — nobody is told on update day.
    "first_seen_ts": 0,
    "calibration_points_seen": 0,  # backend-only: calibration points in the last report sent, or after the last clear (telemetry health.calibration_points_vanished)
    "maps_seen": 0,                # backend-only: floor plans in the last report sent, or after the last delete (telemetry health.maps_vanished)
    # The Overview's one-time trial milestone card was answered: "No thanks",
    # its ✕, or a trial started from it. Per install; it never shows again.
    "trial_nudge_done": False,
    "tester_nudge_done": False,     # the Overview "test it, get Pro free" card was shown; never again (views/pro_invite.js)
    "telemetry_install_id": "",
    "telemetry_last_day": "",       # UTC day of the last accepted report (one per day)
    # "Become a tester" (tester.py) — NOT part of the usage report. What the
    # person typed, so they can update it; backend-only (padspan_ha/tester_*),
    # never in settings_get (ws_common._get_settings takes it out). {} = none.
    "tester_signup": {},
    # A free year of Pro the developer invited this install to (pro_invite.py):
    # the token and its last day, or what was answered. Backend-only, like
    # tester_signup; the panel sees pro_invite_open / pro_invite_until.
    "pro_invite": {},
    # The free-Pro offers' on/off switches from the update check's answer
    # (update_check._keep_offers): {"tester": bool, "invite": bool}; {} = all on.
    "server_offers": {},
    "ref_power":      -59.0,   # dBm RSSI at 1 m (distance formula)
    "path_loss_exp":   2.5,    # path-loss exponent n (distance formula)
    "hidden_map_ids":  [],     # map IDs hidden from 3D stack view
    "locate_self_key": "",     # which tracked object's position is "you", for the Locate tab's wayfinding
    "flood_latches": {},       # {binary_sensor entity_id: {triggered_at, expires_at}} — flood_latch.py owns writes
    "scanner_offsets": {},     # {source_name: offset_dBm} — manual per-scanner RSSI trim
    # Sources masked out of positioning (issue #59). A MASK, never a delete:
    # stored calibration samples, positions and registry entries are untouched,
    # so removing a source from this list restores its influence exactly.
    "scanner_min_rssi": {},    # {source: dBm} — opt-in per-receiver minimum signal (presence_rules.scanner_floors)
    "excluded_scanners": [],   # [source_name, ...] — ignored by every matcher
    # Devices masked at INGEST — they never become objects, so they cost no CPU,
    # no cache, no history. A MASK, never a delete: clear the list and the
    # device is back on the next poll with its history intact.
    #
    # excluded_objects is the simple form: stable identity keys, e.g.
    # "ibeacon:<uuid>:<major>:<minor>" — never a MAC, because the devices worth
    # masking are the ones whose MAC changes every second.
    "excluded_objects": [],
    # ingest_rules is the general form, for sites that cannot enumerate devices
    # by hand: [{action: mask|allow, reason: str,
    #            match: {keys: [], uuids: [], ouis: [], addrs: []}}]
    # First match wins, so an allow rule carves an exception out of a broad mask.
    "ingest_rules": [],
    "positioning_algorithm": "knn",    # "knn" | "rf" (Random Forest)
    # Kalman process noise (RSSI responsiveness), per 10 s of time; the poll
    # scales it. 0.125 until November 2026: ESPresense's figure, which its nodes
    # apply to every advert, many a second; at one step per 5 s poll it made a
    # room change take a minute. 3 follows about a third of a change per poll.
    "kalman_q": 3.0,
    "kalman_r": 8.0,               # Kalman measurement noise (smoothing strength)
    # Both OFF by default. hold_last_room_s: the snapshot keeps showing the
    # room a device had through a signal gap this short (display only; the
    # room vote is unchanged). room_reason_attribute: a "why this room"
    # attribute on each area sensor.
    "hold_last_room_s": 0.0,       # 0 = off, else 1-600
    "room_reason_attribute": False,
    # Honest accuracy (0.38.165), all OFF by default; off, rooms and positions
    # are exactly what they were. pick_better: prefer whichever of k-NN and
    # the spatial solve wins the held-out test (heldout.py). unsure: hold and
    # flag a room heard by under 3 scanners or matching no fingerprint well.
    # sensor_fusion: motion/occupancy sensors and usual room-to-room moves
    # break near-ties between rooms the radios already hear.
    "positioning_pick_better": False,
    "positioning_unsure": False,
    "positioning_sensor_fusion": False,
    # Walk a room (0.38.167), OFF by default: a "Walk a room" tab on
    # Calibration (room_walk.py). Off, Calibration is exactly what it was.
    "calibration_room_walk": False,
    "assumed_device_height_m": 1.0,  # carry height above the floor for 3D distance (pocketed phone)
    # GPS bridge (gap #5, best-in-class roadmap): the fabric's own metre
    # plane has no inherent relationship to true north or a real-world
    # location — these three anchor it, so a tracked object's x_m/y_m can
    # become a real latitude/longitude for HA's map. None until a person
    # sets them; a device_tracker with no origin configured reports no GPS
    # rather than fabricating one at (0, 0).
    "fabric_origin_lat": None,   # latitude of the fabric's (x_m=0, y_m=0) point
    "fabric_origin_lon": None,   # longitude of the fabric's (x_m=0, y_m=0) point
    "fabric_bearing_deg": 0.0,   # compass bearing (clockwise from true north) the fabric's +Y axis points toward
    "light_theme": False,   # invert the panel colours (accessibility — dark theme unusable for some)
    "day_theme": False,     # the designed light palette (www/padspan-ha/day_theme.js); wins over light_theme
    "theme_palette": "",    # "" (Night) | "graphite" | "ocean" | "dusk" | "contrast" — day_theme and light_theme win over it
    "theme_follow_sun": False,   # Day (Light without Pro) while sun.sun is up, the Theme picked after sunset
    # Panel chrome skin. "2025" loads the styles-2025.css overlay and the
    # grouped icon nav; "classic" is v0.35.0 chrome byte-for-byte, kept as a
    # first-class option rather than dead code. Anyone who has already chosen a
    # skin keeps it — settings load as {**DEFAULT_SETTINGS, **saved} — so this
    # default only reaches installs that never touched the setting.
    # Reverting is this key (Settings → Appearance), not a redeploy.
    "ui_skin": "2025",   # "2025" | "classic"
    "light_shapes": {},     # entity_id -> marker shape; overrides the shape derived from the entity
    "light_type_overrides": {},  # entity_id -> forced class (wled/partition/plain); Pro-only control, tier-blind storage
    "door_opener_ids": [],  # cover./switch./button. entity_ids marked "this is a door/window opener" (Devices -> Door Openers); Bright+ control, tier-blind storage
    "door_composites": [],  # receipt for Devices -> Door Openers' "build from relays" wizard: [{id, kind, name, entity_id, relays, generated:{scripts,automations,helper_id,template_entry_id}}] — every HA object the wizard created for one composite, so Remove can delete exactly those and nothing else; Bright+ control, tier-blind storage
    "lights_showcase": False,  # Mapping -> Lights: presentation rendering of the same map
    "lights_showcase_seen": False,  # Showcase has been on here: a forested home's first look (ws_settings._forested_home) is only ever the first
    "lights_fit_rooms": False,  # Mapping -> Lights Showcase: never draw a fixture larger than its room
    "lights_isolux": False,  # Mapping -> Lights Showcase: relative-illuminance contours on the metre grid
    "lights_hide_untouched": False,  # Mapping -> Lights: draw only fixtures that have been sized/rotated/coloured/shaped
    "lights_hide_device_codes": False,  # Mapping -> Lights: hide every marker's A01/M08-style code label, everywhere the map renders
    "lights_show_beacons": False,  # Mapping -> Lights: overlay working, identified beacons (read-only, no placement); off by default
    "lights_automorph_enabled": False,  # Mapping -> Lights: room-alignment aura, off = today's rendering exactly
    "lights_automorph_room_pct": 0,     # 0-100: how far each fixture's aura has grown toward its room's own shape
    "lights_automorph_hardness": 0,     # -100..100, centered: negative sharpens/spikes the aura's edges, positive smooths them into a closed spline; 0 = today's straight edge
    "lights_automorph_style": "glow",   # which visual treatment/shape the fixture's aura takes — see AUTOMORPH_STYLE_LABELS in iso_lights.js for the full, single-source-of-truth list
    "lights_automorph_subtlety": 0,     # 0-100: 0 = full opacity/line-weight (today's look), 100 = thinned lines + faded near-invisible
    "lights_showcase_theme": "classic",  # which palette Showcase paints with — "classic" reproduces today's look byte-for-byte; see SHOWCASE_THEMES in iso_lights.js for the full list
    "lights_showcase_presets": [],  # named snapshots of the whole Showcase "look" bundle (theme + automorph + fit/isolux/beacons/codes, plus the optional overview_iso_* layout trio); see the Presets picker in Mapping -> Lights and its sanitizer in ws_settings.py
    "whole_house_presets": [],  # named snapshots of real light/fan DEVICE state, stored in scene.apply shape; see _sanitize_whole_house_presets in ws_settings.py
    "atlas_layout_v2": True,  # Garry, 2026-09-21: shipped as the default Atlas layout after the trial (still a toggle — "▦ Classic layout" reverts it) — see layoutTierFor in views/lights_map.js
    "vacation_mode_enabled": False,       # Garry, 2026-09-21: acts like an average day from real light history until disabled — see vacation_mode.py
    "vacation_mode_intensity": 100,       # 5-100 — scales every light's on-probability, doubling as an energy-saving mode at low settings
    "vacation_mode_pattern": {},          # backend-only: {entity_id: {"weekday:HHMM": on_probability}} built from HA's own recorder history
    "vacation_mode_pattern_built_at": 0,  # backend-only: epoch-s of the last pattern rebuild
    "vacation_mode_pattern_until": 0,     # backend-only: epoch-s the pattern's history window ends at (the vacation's start)
    "vacation_mode_enabled_at": 0,        # backend-only: epoch-s this vacation began; 0 while off — the pattern never learns past it
    "vacation_mode_periods": [],          # backend-only: [[start, end], ...] earlier vacations, left out of every pattern build
    "traceback_house_focus": 0,          # Traceback's Full house activity: the Atlas floor index it opens on (its own key — overview_iso_focus indexes photo floors)
    "wled_teams": [],                     # backend-only (padspan_ha/wled_teams_set): WLED devices that act as one light — see ws_wled.py
    "power_teams": [],                    # backend-only (padspan_ha/power_teams_set): a wall dimmer or switch and the smart bulbs it feeds, as one light — see power_team.py
    "overview_atlas": False,              # Pro: Overview shows the Atlas; Pure Live gets a switch to the classic Overview (Settings → UI Structure)
    "atlas_live_colours": False,          # the working Atlas draws a lit light in the colour it reports (Settings → UI Structure → Atlas); off: amber, as ever
    "atlas_emergency_button": True,       # show the Atlas "Test emergency lighting" button (Settings → UI Structure → Atlas)
    "atlas_heatmap_enabled": False,       # Atlas: offer the ♨ Heatmap chip (temperature / humidity / CO2); off: no chip, the Atlas as ever (Settings → UI Structure → Atlas)
    "atlas_alert_pulse": False,           # Atlas: ring a room's flagged opening (left open, open in the rain); a wall names the worst alert (Settings → UI Structure → Atlas)
    # Atlas outdoor weather (docs/IDEA_ATLAS_WEATHER.md, views/atlas_weather.js) — rain or snow outside the floor
    # plates while it is actually raining or snowing. On by default in both editions (Pro animates, free is still).
    "atlas_weather_enabled": True,        # master on/off; off = nothing drawn at all
    "atlas_weather_rain_entity": "",      # optional binary_sensor (on = wet) or numeric sensor (> 0 = wet); "" = none
    "atlas_weather_condition_entity": "", # weather.* for the fallback trigger and rain vs snow; "" = the first weather.*
    "atlas_weather_warning_entity": "",   # a weather-warning sensor; "" = detect (env_canada, meteoalarm, dwd, nina, meteo_france, weatheralerts, nws_alerts)
    "atlas_weather_strength": 1.0,        # 0.5-1.5 x opacity
    # Wall screens (the sidebar Atlas on ?kiosk=1, lights_panel.js _wallOn): how
    # big to draw for the room. wall_screen_in 0 = size from the screen's
    # resolution; otherwise its diagonal (inches) and how far people stand
    # (m) set the size, text at wall_text_arcmin of visual angle (control-room
    # practice: 16 minimum, 20-22 preferred). A screen's own link can override
    # all three (?wall_in=&wall_m=&wall_text=).
    "wall_screen_in": 0.0,                # 0 or 10-120
    "wall_distance_m": 2.5,               # 0.3-10
    "wall_text_arcmin": 20.0,             # 14-36
    "wall_night_dim": 0.0,                # 0-0.7: how much darker after sunset
    "wall_pixel_shift": False,            # move the picture a few px every few minutes (OLED burn-in)
    "wall_floor_cycle_s": 0,              # 0 or 10-600: show the next floor every N s while nobody touches the wall
    "wall_fully": False,                  # inside Fully Kiosk: night dim by its screen brightness, motion turns the screen on
    # Live Aboard, the 3D house (docs/IDEA_ATLAS_3D_HOUSE.md on the live-aboard branch). NORMALLY OFF:
    # off = no 3D switch, no Furnish tab, no store writes, no AI or library calls, no telemetry.
    "atlas_3d_enabled": False,            # the master switch
    "atlas_3d_quality": "auto",           # auto | low | high
    "atlas_3d_people": False,             # the people layer
    "atlas_3d_tags": False,               # tags and scanners: every placed tag with its name, every scanner at its height
    "atlas_3d_ai_task_entity": "",        # ai_task.* that reads photos; "" = none (the photo button explains)
    "atlas_3d_ai_task_backup_entity": "", # ai_task.* used when the main one can't be reached (ws_house3d_photo.ask_ai); "" = no backup
    "ai_plans_enabled": False,            # Settings → AI: AI map-building research (experimental, 2026-11): hides the stair finder and the Plans tool while off; a home that used the stair finder comes up on (ai_plans_stamp)
    "ai_stairs_enabled": False,           # Settings → AI: stairs read off the floor plans by the AI Task (0.38.188), off until chosen
    "ai_plan_build_enabled": False,       # Settings → AI: Build from plans, advanced plan alignment (Claude, experimental, 2026-11): off for every home, needs ai_plans_enabled and Claude Opus 5.5+
    "ai_map_wizard": {},                  # Let Claude draw your rooms (ai_wizard.py): {dismissed, undone, snooze_until, snoozes, started: {at, ...}, finished_day}; {} = never used; administrators only
    "ai_credit_month_usd": 0,             # Settings → AI: the monthly AI credit typed in (US$, ai_usage.py), 0 = none: the line then says no "of your credit"
    "ai_credit_warn_pct": 0,              # Settings → AI: 0 = off (the default), or 50 / 75 / 90: one notice a month past that share of the credit
    "ai_photos_enabled": True,            # Settings → AI: furniture (tags, receivers, people's figures) from a photo; on as it always was
    "atlas_3d_library": False,            # the shared furniture library
    "atlas_3d_weather": True,             # rain and snow in Live Aboard: follows Outdoor weather (atlas_weather_*), which must be on too
    "atlas_3d_showcase": False,           # older switch (old backups, Bright): kept valid, decides nothing once atlas_3d_look is there
    "atlas_3d_look": "atlas",             # Live Aboard's look: "atlas" = the same as the Atlas (its Showcase theme, or the plain Atlas) | "own" | "studio" (its own colours, soft light and sky)
    "atlas_3d_home_idle_s": 60,           # the sidebar's Live Aboard goes back to its home view after this long untouched: 0 (never) | 30 | 60 | 300
    "atlas_3d_director": [],              # the sidebar's Live Aboard flies to these when they go off: [{"entity": event.*|binary_sensor.*|alarm_control_panel.*, "camera": camera.* or ""}]; [] = off
    "atlas_3d_director_people": [],       # ...and to these people and tags when they go into a room: [{"key": person.x | "beacon:<tracked key>", "rooms": [room names; [] = any room, or a person arriving home]}]; [] = off; personal, kept here only, never sent
    "atlas_3d_carries": {},               # who carries what: {"person.x": [tracked keys]}; personal, kept here only, never sent
    "emergency_entities": [],             # the Atlas emergency lighting test's lights, when set; [] = HA's "emergency" groups, else the default rule — see emergency_test.py
    "vacation_mode_tracked_since": 0,     # backend-only: epoch-s from which every vacation span is in vacation_mode_periods (stamped once on upgrade if Vacation Mode ran before spans were recorded; 0 = always) — vacation_mode.py learned_pattern
    "vacation_mode_pattern_prev": {},     # backend-only: the last pattern learned before a vacation — stands in while a new vacation's build finds nothing (vacation_mode.py learned_pattern)
    "vacation_mode_pattern_attempt": [0, 0],  # backend-only: [enabled_at, epoch-s] of the last build that found nothing usable — retried hourly, not every tick
    "vacation_mode_pattern_for": 0,       # backend-only: the enabled_at a carried-over pattern serves — turned back on within 3 weeks of a trip, it resumes that trip's routine (vacation_mode.resumable)
    "vacation_mode_last_off": {},         # backend-only: {ts, by, via, how} — who last turned Vacation Mode off, for the panel and the turned-off notice
    # Trip options (0.38.172), each off until set — vacation_mode.OPTION_DEFAULTS
    "vacation_mode_dark_only": False,     # lights go on only after sunset (+ offset) and before sunrise
    "vacation_mode_dark_offset_min": 0,   # -60..120 minutes after sunset
    "vacation_mode_end_at": 0,            # epoch-s the trip ends (it turns itself off then); 0 = no end
    "vacation_mode_pause_home": False,    # anyone's person.* at home: nothing is switched until they leave
    "vacation_mode_bedtime": "",          # "HH:MM" (17:00-03:00): lights off from then (±20 min) until 05:00
    "vacation_mode_max_on_min": 0,        # 0 = no limit, else 15-720: a light it turned on goes off after this, and rests as long
    "vacation_mode_max_lights": 0,        # 0 = no limit, else 1-50: at most this many of the pattern's lights on at once
    "vacation_mode_anchors": [],          # up to 10 light entity ids held on over the evening they were really on (last week, or on average); bedtime still ends them
    # Garry, 2026-10-31: where each weekday's routine comes from — vacation_mode.build_routine
    "vacation_mode_source": "last_week",  # "last_week": the same day last week | "month": each weekday's average over the last month; fixed for a trip when it is turned on
    "vacation_mode_trip_source": "",      # backend-only: the source the running (or last) trip was turned on with; "" = before the choice existed (the monthly average)
    "vacation_mode_pattern_source": "",   # backend-only: the source vacation_mode_pattern was built from ("" = month)
    "vacation_mode_pattern_prev_source": "",  # backend-only: the same for vacation_mode_pattern_prev
    "vacation_mode_pattern_end": 0,       # backend-only: a resumed trip whose source was changed is learned again from history ending here; 0 = nothing to redo
    "overview_show_walls": False,   # Overview: draw RF barrier walls over the map
    "overview_show_outdoor": False, # Overview: draw outdoor areas (sheds, driveways) as an overlay
    "overview_show_trails": False,  # Overview/Pure Live: fading movement trail behind each tracked object
    "health_reminder_enabled": False,  # monthly calibration accuracy reminder (off by default)
    "health_reminder_last_ts":  None,  # epoch seconds when reminder was last shown
    "adaptive_learning_enabled": False,  # experimental: passive room fingerprint learning
    "adaptive_floor_detection": False,   # experimental: cross-floor attenuation learning
    "beacon_auto_calibrate": True,       # experimental: auto-inject calibration from pinned beacons
    "overview_persistent_pins": False,   # show away beacons at last known position on overview map
    # 3D isometric view layout (Maps tab)
    "maps_iso_floor_gap":    200,   # px spacing between floors
    "maps_iso_horiz_gap":    0,     # px L/R horizontal offset
    "maps_iso_focus":        None,  # z_level to highlight, or null = all
    # 3D isometric view layout (Overview tab) — also the Atlas builder's own
    # camera (Mapping -> Atlas builder seeds host.view from these same keys).
    "overview_iso_floor_gap": 150,
    "overview_iso_horiz_gap": 0,
    "overview_iso_focus":     None,
    # Atlas's own zoom (Garry, 2026-09-22: "stabilize the zoom in, so when
    # that is locked well, it can stay that way for months if needed" — the
    # sidebar Atlas panel is set up once and left running unattended; an
    # in-memory-only zoom reset to 1.0 on every reboot/reload, which is
    # exactly the kind of drift that made "the map keeps getting smaller"
    # look like a recurring bug rather than a one-time setting never saved).
    "overview_iso_zoom":      1.0,
    # Advanced-mode extra tabs (user picks from Settings → UI Structure)
    "advanced_extra_tabs": [],
    # HA entity publishing controls
    "ha_entity_tracker_enabled":          True,
    "ha_entity_area_enabled":             True,
    "ha_entity_distance_enabled":         True,
    "ha_entity_scanner_distance_enabled": True,
    # MQTT (experimental, off by default)
    "mqtt_publish_enabled": False,
    # ESPresense MQTT ingestion (off by default — requires HA MQTT integration)
    "espresense_mqtt_enabled": False,
    "espresense_topic_prefix": "espresense",
    "tasmota_ble_enabled": False,
    "espresense_room_map": {},              # {"espresense_room": "HA Area Name"}
    # ESPresense Companion import (standalone .NET app / HA add-on)
    "espresense_companion_url": "",         # e.g. "http://espresense:8267" — empty = disabled
    # Aggressive BLE reseed for Shelly/passive proxies (off by default)
    # When enabled, reseeds from HA discovered-service-info every 5s instead of 30s.
    # Helps with HA 2026.4+ where habluetooth dedup suppresses repeat callbacks.
    "aggressive_ble_reseed": False,
    # Presence poll interval (seconds).  How often the smoothing pipeline runs.
    # Lower = faster room transitions but higher CPU.  Default 5 s (installs
    # from before 0.21 may still hold the old 10 s).
    "presence_poll_interval_s": 5,
    # BLE reseed interval (seconds).  How often bluetooth_live re-reads every
    # scanner's list (HA's callbacks carry only one scanner's view of a
    # device).  5 s = every poll, so no scanner's reading is older than one
    # poll; adverts already read are skipped, which keeps it cheap. Was 30 s.
    "ble_reseed_interval_s": 5,
    # One-time (November 2026): an install still on the old kalman_q 0.125 or
    # ble_reseed_interval_s 30 — never changed, as almost nobody had — is
    # moved to the new defaults once; a value someone set stays.
    "room_speed_v1_applied": False,
    # How long an object that was never identified is kept in object history.
    # Tagged/identified objects never expire regardless of this.  The whole
    # cache ships in every live_snapshot (polled every 5s), so longer windows
    # cost payload size and poll time: 7 days measured 16.4k objects / 19.5MB
    # / 2-7s per poll, 1 day 2.8k / 3.8MB / sub-second.  Allowed: 1, 2, 7, 14.
    "object_history_days": 1,
    # The Atlas sidebar panel (panel.py registers it at setup, so a change
    # takes a Home Assistant restart). On by default (Garry, 2026-09-28): off, it
    # was the one place the lighting product lives and almost nobody found it.
    "lights_panel_enabled": True,
    # One-time: installs from before that default had it off only because it
    # WAS the default — nobody chose it. async_load turns it on once for them,
    # records that here, and never touches it again (off stays off after).
    "atlas_default_v1_applied": False,
    "ha_entity_occupancy_enabled": False,  # expose occupancy estimate sensors to HA
    "subzones_enabled": False,             # sub-zones (subzones.py): bed/couch/desk areas with their own sensors
    "bermuda_ignore": False,  # experimental: ignore all Bermuda integration data
    # HA Tags integration
    "tags_room_events_enabled": False,     # emit tag_scanned on room changes
    "tags_nfc_identify_enabled": False,    # NFC tap-to-identify BLE objects
    "tags_phone_autolink_enabled": False,  # auto-track phone on NFC scan
    # Quiet mode — hide unidentified objects everywhere
    "quiet_mode": False,
    # Show lengths in feet and inches (Mapping's measuring and the rooms helper; stored in metres either way)
    "units_feet": False,
    # Experimental: 2D flat map mode (replaces 3D isometric view)
    "overview_2d_mode": False,
    # Followed BLE addresses (uppercase MAC/key strings)
    "followed_addrs": [],
    # Beacon profiling / characteristics
    "beacon_profiling_enabled": True,     # master toggle for beacon profiling feature
    "beacon_tune_disabled": [],           # device_ids excluded from calibration tuning
    "beacon_group_overrides": {},         # device_id → model_key override (ungroup/regroup)
    # Private BLE IRK devices (managed in PadSpan — no separate integration needed)
    "irk_devices": [],                    # [{name: str, irk_hex: str}]
    # Curated room → object map (room name → list of object keys).  Set via the
    # padspan_ha.set_room_tag_map service / Manage UI.  Persisted here so it
    # survives restarts and integration reloads — previously the coordinator's
    # room_tag_map was in-memory only and reset to {} on every restart.
    "room_tag_map": {},                   # {room_name: [object_key, ...]}
    # ── Forensics (off by default — records presence sessions of ALL nearby
    # BLE devices, including neighbours/passers-by, for time-window queries.
    # Privacy-sensitive: user must opt in via Settings → Features.) ──────────
    "forensics_enabled": False,
    "forensics_retention_days": 14,       # allowed: 7, 14, 30, 60, 90
    # PadSpan Pro licence (validated against traks.ca/license, product=padspan).
    # Set only via the padspan_ha/forensics_license_activate command.
    "forensics_license_key": "",
    "forensics_license_expires": "",
    # True only for a key minted by padspan_ha/trial_start (the one-time 3-month
    # PadSpan Pro trial; Bright Pro before 2026-10-27). Display-only — licence.py's tier ladder does not read
    # it, a trial key gates identically to a purchased one.
    "license_is_trial": False,
    # This home among the key's homes (licence_homes.py): the token the
    # licence server rotates at each check, and the name the owner gave it.
    "license_home_token": "",
    "license_home_label": "",
    "license_home_status": "",   # the server's last word on this home, when it refused it
    "license_homes_used": 0,     # how many homes the key is on, as the server last said
    "license_homes_warning": {},  # past two homes with a report off somewhere: licence_homes.homes_warning
    # This install's own id for the licence server, made once, only where Home
    # Assistant's instance id can't be read (licence_homes.machine_id).
    "license_install_id": "",
    # When the update check and the licence recheck last ran (epoch seconds):
    # one within 20 hours makes the next wait, so a restart does not ask again.
    "server_checked_at": 0,
    # ── Enterprise preview features (off by default) ─────────────────────────
    "walk_to_identify_enabled": False,      # spatial correlation device discovery ("who just walked in?")
    "radio_map_enabled": False,             # RSSI heatmap overlay on floor plan maps
    "distortion_map_enabled": False,        # calibration disagreement visualization
    "roomplan_import_enabled": False,       # Rooms tab: also import Apple RoomPlan .json scans
    "vacuum_import_enabled": False,         # Rooms tab: "Import from a robot vacuum" (vacuum_import.py)
    "iphone_irk_guide": False,              # phone setup: iPhones get the IRK steps, not BLE Transmitter (#69)
    # A NEW install's first steps (onboarding.py): when its settings were
    # first made, then how long it took to the first room and the first
    # calibration point, as buckets. {} on every install from before 0.38.165,
    # which is never measured. A brand-new install also starts with
    # iphone_irk_guide on (SettingsStore.async_load).
    "onboarding": {},
    # ── RSSI vector capture (off by default) ─────────────────────────────────
    # Records the full per-scanner RSSI vector for tracked objects, plus the
    # room the pipeline chose, so a trace can be replayed offline against
    # changed code.  Session-scoped: nothing is written until an operator
    # starts a recording, and a session is capped at 60 minutes and 25 MB.
    "rssi_capture_enabled": False,
    "rssi_capture_retention_days": 14,      # allowed: 1, 3, 7, 14, 30
}


def live_first_kept(live: dict[str, Any] | None, other: dict[str, Any] | None,
                    from_bright: bool = False) -> dict[str, Any]:
    """onboarding["live_first"] through a settings restore or a Bright import
    (`other` is the settings coming in). This install's own answer
    ("switched", "chosen") always stays. Otherwise:

    - a restore never leaves "pending": restoring is choosing settings, the
      mode among them, so a new install's switch to Live must not run over it;
    - a Bright import keeps this install's "pending" unless Bright itself was
      Live or had answered: PadSpan Bright never asked (it is never marked),
      so its default "sample" is no one's choice, and a move from Bright
      would otherwise end on the demo house for good.

    Returns {"onboarding": ...} to apply, or {} when there is nothing to change."""
    a, b = live or {}, other or {}
    mine = a.get("onboarding").get("live_first") if isinstance(a.get("onboarding"), dict) else None
    ob = dict(b["onboarding"]) if isinstance(b.get("onboarding"), dict) else None
    if mine in ("switched", "chosen"):
        return {"onboarding": {**(ob or {}), "live_first": mine}}
    if from_bright and mine == "pending" and (ob or {}).get("live_first") not in ("switched", "chosen") \
            and b.get("data_mode") != "live":
        return {"onboarding": {**(ob or {}), "live_first": "pending"}}
    if ob is None:
        return {}
    if ob.get("live_first") == "pending":
        del ob["live_first"]
    return {"onboarding": ob}


def trial_state_kept(live: dict[str, Any] | None, other: dict[str, Any] | None = None) -> dict[str, Any]:
    """The trial milestone's two per-install facts, kept through a settings
    restore, a factory reset and a Bright import (`other` is the settings
    coming in; none for a reset). Like the licence, neither is house
    configuration: an answer given anywhere stays given (trial_nudge_done),
    and the install is as old as its earliest real sighting (first_seen_ts,
    the smaller positive value) — so an older backup can neither bring the
    card back nor restart its week."""
    a, b = live or {}, other or {}
    out: dict[str, Any] = {"trial_nudge_done": bool(a.get("trial_nudge_done") or b.get("trial_nudge_done")),
                           "tester_nudge_done": bool(a.get("tester_nudge_done") or b.get("tester_nudge_done"))}
    seen = [v for v in (a.get("first_seen_ts"), b.get("first_seen_ts"))
            if isinstance(v, (int, float)) and not isinstance(v, bool) and v > 0]
    if seen:
        out["first_seen_ts"] = min(seen)
    # The code running here did not change with a restore, so there is no new
    # update to announce: the later "what's new" version stands, or the update
    # banner (and its one-time trial line) would show again.
    def _ver(v: Any) -> tuple[int, ...] | None:
        try:
            parts = tuple(int(p) for p in str(v).split("."))
        except (TypeError, ValueError):
            return None
        return parts if len(parts) == 3 else None
    versions = [v for v in (a.get("whatsnew_seen_version"), b.get("whatsnew_seen_version")) if _ver(v)]
    if versions:
        out["whatsnew_seen_version"] = max(versions, key=_ver)
    return out


def ai_plans_stamp(data: dict, loaded: Any) -> bool:
    """The AI map-building switch (ai_plans_enabled, 2026-11) on an upgrade:
    a home that had turned the stair finder on comes up with the master
    switch on too, so nobody loses the stair finder (Garry, 2026-11-02:
    "Anyone using the stair find has the switch on by default"); every
    other home, and a fresh install, gets False. Decided once: only while
    the loaded settings have no ai_plans_enabled at all. Called from
    async_load and from a restore (ws_backup), which hot-patches the data
    without a load. Returns whether it set anything."""
    if not isinstance(loaded, dict) or "ai_plans_enabled" in loaded:
        return False
    data["ai_plans_enabled"] = loaded.get("ai_stairs_enabled") is True
    return True


@dataclass
class SettingsStore:
    # The three field annotations below do NOT get their usual @dataclass
    # treatment: this class defines its own __init__ immediately after them,
    # and @dataclass never generates/overrides __init__ when the class
    # already has one. They still document the instance's shape (and drive
    # __repr__/__eq__, which the dataclass machinery does still generate),
    # but SettingsStore(hass=..., store=..., data=...) — the signature these
    # annotations imply — is not how this class is actually constructed;
    # only SettingsStore(hass) is.
    hass: HomeAssistant
    store: Store
    data: dict[str, Any]

    def __init__(self, hass: HomeAssistant) -> None:
        self.hass = hass
        self._raw_store = Store(hass, 1, SETTINGS_STORE_KEY)
        from .safe_store import wrap_store
        self.store = wrap_store(self._raw_store, hass, "settings")
        self.data = dict(DEFAULT_SETTINGS)

    async def async_load(self) -> dict[str, Any]:
        """Load and merge persisted settings onto defaults.

        Merging ensures new keys added in future versions get their defaults
        while preserving the user's existing overrides.
        """
        # Looked at BEFORE the load: the other stores load beside this one
        # and a brand-new install's would be written by the time it returned.
        first_run = await self._first_run()
        loaded = await self.store.async_load()
        if isinstance(loaded, dict):
            self.data = {**DEFAULT_SETTINGS, **loaded}
            # A stored False stays: it does nothing here, and an older version
            # read back with no key would turn the online lookup on again.
            for key in RETIRED_SETTINGS:
                if self.data.get(key) is not False:
                    self.data.pop(key, None)
        else:
            self.data = dict(DEFAULT_SETTINGS)
        # A brand-new install — no settings file and no other PadSpan file in
        # .storage — starts with the iPhone setup steps on and its first steps
        # measured, and opens on its own house as soon as Home Assistant
        # reports a Bluetooth scanner (onboarding.py, "live_first"). Every
        # install from before keeps what it has (the guide off unless someone
        # turned it on, and the mode it is in). Decided once: the file saved
        # below makes every later load an existing install, and a factory
        # reset or a restore writes one too.
        if loaded is None and first_run:
            self.data["iphone_irk_guide"] = True
            self.data["onboarding"] = {"setup_ts": time.time()}
            # PadSpan Bright is the Atlas alone: it has no presence screens to
            # open on, so its mode is left as it always was.
            if EDITION != "bright":
                self.data["onboarding"]["live_first"] = "pending"
        # Normalize followed_addrs: uppercase + dedup (order preserved).
        # Every comparison in the system (frontend followedHas, backend
        # settings_set, tag_integration) is uppercase; historic entries were
        # saved in mixed formats and silently failed to match.
        _normalized = False
        try:
            _fa = self.data.get("followed_addrs") or []
            _seen: set[str] = set()
            _norm: list[str] = []
            for _x in _fa:
                if not isinstance(_x, str):
                    continue
                _u = _x.strip().upper()
                if _u and _u not in _seen:
                    _seen.add(_u)
                    _norm.append(_u)
            if _norm != _fa:
                self.data["followed_addrs"] = _norm
                _normalized = True
        except Exception:
            pass
        # Vacation Mode spans are recorded from this code on. An install
        # that ran Vacation Mode before has unrecorded ones in the recorder
        # until now (vacation_mode.py learned_pattern, round 6).
        if isinstance(loaded, dict) and "vacation_mode_tracked_since" not in loaded:
            # Recorded spans count too: a 0.38.74-75 reset cleared the other
            # three but kept them (round 7).
            ran = bool(loaded.get("vacation_mode_enabled") or loaded.get("vacation_mode_pattern")
                       or loaded.get("vacation_mode_pattern_built_at") or loaded.get("vacation_mode_periods"))
            self.data["vacation_mode_tracked_since"] = time.time() if ran else 0
        # The AI map-building switch, once: on where the stair finder was.
        if ai_plans_stamp(self.data, loaded):
            _normalized = True
        # First sight of this install, once (see first_seen_ts above).
        _fs = self.data.get("first_seen_ts")
        if isinstance(_fs, bool) or not isinstance(_fs, (int, float)) or _fs <= 0:
            self.data["first_seen_ts"] = time.time()
            _normalized = True
        # Atlas on by default, once. Runs before panel.py reads the
        # setting — settings are a critical store, loaded before the panel is
        # registered — so the sidebar entry appears on the restart the update
        # itself needs. A fresh install lands here too and just records it.
        if not self.data.get("atlas_default_v1_applied"):
            self.data["lights_panel_enabled"] = True
            self.data["atlas_default_v1_applied"] = True
            _normalized = True
        # Faster room changes, once (see room_speed_v1_applied above).
        if not self.data.get("room_speed_v1_applied"):
            if self.data.get("kalman_q") == 0.125:
                self.data["kalman_q"] = DEFAULT_SETTINGS["kalman_q"]
            if self.data.get("ble_reseed_interval_s") == 30:
                self.data["ble_reseed_interval_s"] = DEFAULT_SETTINGS["ble_reseed_interval_s"]
            self.data["room_speed_v1_applied"] = True
            _normalized = True
        # Only re-save if new defaults were added (loaded was missing keys)
        if _normalized or not isinstance(loaded, dict) or set(self.data.keys()) != set(loaded.keys()):
            await self.store.async_save(self.data)
        return self.data

    async def _first_run(self) -> bool:
        """No PadSpan file at all in .storage (not even a corrupt settings
        file Home Assistant moved aside). Anything unsure is not a first run."""
        hass = getattr(self, "hass", None)
        if hass is None:
            return False
        prefix = SETTINGS_STORE_KEY.split(".")[0] + "."

        def _scan() -> bool:
            d = Path(hass.config.path(".storage"))
            if not d.exists():
                return True
            return not any(p.name.startswith(prefix) for p in d.iterdir())
        try:
            return (await hass.async_add_executor_job(_scan)) is True
        except Exception:  # noqa: BLE001 - unsure: an existing install
            return False

    async def async_set(self, **kwargs: Any) -> dict[str, Any]:
        self.data = {**self.data, **kwargs}
        await self.store.async_save(self.data)
        return self.data

    def get(self, key: str, default: Any = None) -> Any:
        return self.data.get(key, default)




def licence_key_hash(key: str) -> str:
    import hashlib  # noqa: PLC0415
    return hashlib.sha256(str(key or "").strip().upper().encode()).hexdigest() if str(key or "").strip() else ""


def report_locked_until(data: dict) -> str:
    """The free licence's end ("" when nothing holds the usage report on).
    Every new free licence (the 90-day trial, a tester's two years, a free
    year of Pro) needs the report on, and it stays on until that licence ends
    (Garry, 2026-10-27). The lock is the key it was given with
    (report_locked_key, a hash): a bought key in its place, or the licence's
    end, lets it go; a free licence from before the rule never had one."""
    from datetime import datetime, timezone  # noqa: PLC0415
    locked = str(data.get("report_locked_key") or "")
    if not locked or locked != licence_key_hash(data.get("forensics_license_key") or ""):
        return ""
    end = str(data.get("forensics_license_expires") or "").strip()
    try:
        exp = datetime.fromisoformat(end.replace("Z", "+00:00"))
        if exp.tzinfo is None:
            exp = exp.replace(tzinfo=timezone.utc)
    except ValueError:
        return end or "the end of the free licence"
    return end if exp > datetime.now(timezone.utc) else ""
