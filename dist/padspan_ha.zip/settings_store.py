# PadSpan HA — BLE Room-Presence Tracking for Home Assistant
# Copyright (C) 2026 Garry Broeckling
# Licensed under the GNU General Public License v3.0
# See LICENSE file or https://www.gnu.org/licenses/gpl-3.0.html
from __future__ import annotations

"""
PadSpan HA — Settings Store
=============================
Persistent UI settings — toggling sample/live mode, tuning BLE parameters
(ref power, path-loss exponent, Kalman Q/R), controlling which
entity types are published, and storing per-scanner RSSI offsets.

All settings live in a single flat dict persisted to
``.storage/padspan_ha.settings``.  Unknown keys from future versions are
preserved on load (merged onto DEFAULT_SETTINGS).
"""


import logging
import time
from dataclasses import dataclass
from typing import Any

from homeassistant.core import HomeAssistant
from homeassistant.helpers.storage import Store

from .const import SETTINGS_STORE_KEY

_LOGGER = logging.getLogger(__name__)

DEFAULT_SETTINGS: dict[str, Any] = {
    "data_mode": "sample",  # "sample" | "live"
    "cpu_mode": "shared",  # "shared" | "single" | "dedicated" — see PresenceCoordinator
    "low_memory_mode": False,  # caps for a 2 GB machine — see low_memory.py
    "update_check_enabled": True,  # daily version ping to padspan.traks.ca (see README)
    # Opt-in usage report (telemetry.py). OFF until a person turns it on;
    # the id is minted on first enable and can be replaced from Settings.
    "telemetry_enabled": False,
    "telemetry_asked": False,      # the panel asked once, and got an answer either way
    # The version the what's-new card last reported. Seeded silently the first
    # time the panel sees it, so a FRESH install is never told it "updated".
    "whatsnew_seen_version": "",
    # When this install first ran PadSpan (epoch seconds), stamped once by
    # async_load. The Overview's one-time trial milestone card waits 7 days
    # from it. An install from before the key existed is stamped on its first
    # load of this version, so its 7 days count from the update, not from
    # when it was really installed — nobody is told on update day.
    "first_seen_ts": 0,
    # The Overview's one-time trial milestone card was answered: "No thanks",
    # its ✕, or a trial started from it. Per install; it never shows again.
    "trial_nudge_done": False,
    "tester_nudge_done": False,     # the Overview "test it, get Pro free" card was shown; never again (views/pro_invite.js)
    "telemetry_install_id": "",
    "telemetry_last_day": "",       # UTC day of the last accepted report (one per day)
    # "Become a tester" (tester.py) — NOT part of the usage report. What the
    # person typed, so they can update it; backend-only (padspan_ha/tester_*),
    # never in settings_get (ws_common._get_settings takes it out). {} = none.
    "tester_signup": {},
    # A free year of Pro the developer invited this install to (pro_invite.py):
    # the token and its last day, or what was answered. Backend-only, like
    # tester_signup; the panel sees pro_invite_open / pro_invite_until.
    "pro_invite": {},
    # The free-Pro offers' on/off switches from the update check's answer
    # (update_check._keep_offers): {"tester": bool, "invite": bool}; {} = all on.
    "server_offers": {},
    "vendor_lookup_enabled": True,  # Sends MAC prefixes to vendor lookup APIs when requested from UI
    "ref_power":      -59.0,   # dBm RSSI at 1 m (distance formula)
    "path_loss_exp":   2.5,    # path-loss exponent n (distance formula)
    "hidden_map_ids":  [],     # map IDs hidden from 3D stack view
    "locate_self_key": "",     # which tracked object's position is "you", for the Locate tab's wayfinding
    "flood_latches": {},       # {binary_sensor entity_id: {triggered_at, expires_at}} — flood_latch.py owns writes
    "scanner_offsets": {},     # {source_name: offset_dBm} — manual per-scanner RSSI trim
    # Sources masked out of positioning (issue #59). A MASK, never a delete:
    # stored calibration samples, positions and registry entries are untouched,
    # so removing a source from this list restores its influence exactly.
    "scanner_min_rssi": {},    # {source: dBm} — opt-in per-receiver minimum signal (presence_rules.scanner_floors)
    "excluded_scanners": [],   # [source_name, ...] — ignored by every matcher
    # Devices masked at INGEST — they never become objects, so they cost no CPU,
    # no cache, no history. A MASK, never a delete: clear the list and the
    # device is back on the next poll with its history intact.
    #
    # excluded_objects is the simple form: stable identity keys, e.g.
    # "ibeacon:<uuid>:<major>:<minor>" — never a MAC, because the devices worth
    # masking are the ones whose MAC changes every second.
    "excluded_objects": [],
    # ingest_rules is the general form, for sites that cannot enumerate devices
    # by hand: [{action: mask|allow, reason: str,
    #            match: {keys: [], uuids: [], ouis: [], addrs: []}}]
    # First match wins, so an allow rule carves an exception out of a broad mask.
    "ingest_rules": [],
    "positioning_algorithm": "knn",    # "knn" | "rf" (Random Forest)
    "kalman_q": 0.125,             # Kalman process noise (RSSI responsiveness)
    "kalman_r": 8.0,               # Kalman measurement noise (smoothing strength)
    # Both OFF by default. hold_last_room_s: the snapshot keeps showing the
    # room a device had through a signal gap this short (display only; the
    # room vote is unchanged). room_reason_attribute: a "why this room"
    # attribute on each area sensor.
    "hold_last_room_s": 0.0,       # 0 = off, else 1-600
    "room_reason_attribute": False,
    "assumed_device_height_m": 1.0,  # carry height above the floor for 3D distance (pocketed phone)
    # GPS bridge (gap #5, best-in-class roadmap): the fabric's own metre
    # plane has no inherent relationship to true north or a real-world
    # location — these three anchor it, so a tracked object's x_m/y_m can
    # become a real latitude/longitude for HA's map. None until a person
    # sets them; a device_tracker with no origin configured reports no GPS
    # rather than fabricating one at (0, 0).
    "fabric_origin_lat": None,   # latitude of the fabric's (x_m=0, y_m=0) point
    "fabric_origin_lon": None,   # longitude of the fabric's (x_m=0, y_m=0) point
    "fabric_bearing_deg": 0.0,   # compass bearing (clockwise from true north) the fabric's +Y axis points toward
    "light_theme": False,   # invert the panel colours (accessibility — dark theme unusable for some)
    "day_theme": False,     # the designed light palette (www/padspan-ha/day_theme.js); wins over light_theme
    "theme_palette": "",    # "" (Night) | "graphite" | "ocean" | "dusk" | "contrast" — day_theme and light_theme win over it
    # Panel chrome skin. "2025" loads the styles-2025.css overlay and the
    # grouped icon nav; "classic" is v0.35.0 chrome byte-for-byte, kept as a
    # first-class option rather than dead code. Anyone who has already chosen a
    # skin keeps it — settings load as {**DEFAULT_SETTINGS, **saved} — so this
    # default only reaches installs that never touched the setting.
    # Reverting is this key (Settings → Appearance), not a redeploy.
    "ui_skin": "2025",   # "2025" | "classic"
    "light_shapes": {},     # entity_id -> marker shape; overrides the shape derived from the entity
    "light_type_overrides": {},  # entity_id -> forced class (wled/partition/plain); Pro-only control, tier-blind storage
    "door_opener_ids": [],  # cover./switch./button. entity_ids marked "this is a door/window opener" (Devices -> Door Openers); Bright+ control, tier-blind storage
    "door_composites": [],  # receipt for Devices -> Door Openers' "build from relays" wizard: [{id, kind, name, entity_id, relays, generated:{scripts,automations,helper_id,template_entry_id}}] — every HA object the wizard created for one composite, so Remove can delete exactly those and nothing else; Bright+ control, tier-blind storage
    "lights_showcase": False,  # Mapping -> Lights: presentation rendering of the same map
    "lights_fit_rooms": False,  # Mapping -> Lights Showcase: never draw a fixture larger than its room
    "lights_isolux": False,  # Mapping -> Lights Showcase: relative-illuminance contours on the metre grid
    "lights_hide_untouched": False,  # Mapping -> Lights: draw only fixtures that have been sized/rotated/coloured/shaped
    "lights_hide_device_codes": False,  # Mapping -> Lights: hide every marker's A01/M08-style code label, everywhere the map renders
    "lights_show_beacons": False,  # Mapping -> Lights: overlay working, identified beacons (read-only, no placement); off by default
    "lights_automorph_enabled": False,  # Mapping -> Lights: room-alignment aura, off = today's rendering exactly
    "lights_automorph_room_pct": 0,     # 0-100: how far each fixture's aura has grown toward its room's own shape
    "lights_automorph_hardness": 0,     # -100..100, centered: negative sharpens/spikes the aura's edges, positive smooths them into a closed spline; 0 = today's straight edge
    "lights_automorph_style": "glow",   # which visual treatment/shape the fixture's aura takes — see AUTOMORPH_STYLE_LABELS in iso_lights.js for the full, single-source-of-truth list
    "lights_automorph_subtlety": 0,     # 0-100: 0 = full opacity/line-weight (today's look), 100 = thinned lines + faded near-invisible
    "lights_showcase_theme": "classic",  # which palette Showcase paints with — "classic" reproduces today's look byte-for-byte; see SHOWCASE_THEMES in iso_lights.js for the full list
    "lights_showcase_presets": [],  # named snapshots of the whole Showcase "look" bundle (theme + automorph + fit/isolux/beacons/codes, plus the optional overview_iso_* layout trio); see the Presets picker in Mapping -> Lights and its sanitizer in ws_settings.py
    "whole_house_presets": [],  # named snapshots of real light/fan DEVICE state, stored in scene.apply shape; see _sanitize_whole_house_presets in ws_settings.py
    "atlas_layout_v2": True,  # Garry, 2026-09-21: shipped as the default Atlas layout after the trial (still a toggle — "▦ Classic layout" reverts it) — see layoutTierFor in views/lights_map.js
    "vacation_mode_enabled": False,       # Garry, 2026-09-21: acts like an average day from real light history until disabled — see vacation_mode.py
    "vacation_mode_intensity": 100,       # 5-100 — scales every light's on-probability, doubling as an energy-saving mode at low settings
    "vacation_mode_pattern": {},          # backend-only: {entity_id: {"weekday:HHMM": on_probability}} built from HA's own recorder history
    "vacation_mode_pattern_built_at": 0,  # backend-only: epoch-s of the last pattern rebuild
    "vacation_mode_pattern_until": 0,     # backend-only: epoch-s the pattern's history window ends at (the vacation's start)
    "vacation_mode_enabled_at": 0,        # backend-only: epoch-s this vacation began; 0 while off — the pattern never learns past it
    "vacation_mode_periods": [],          # backend-only: [[start, end], ...] earlier vacations, left out of every pattern build
    "traceback_house_focus": 0,          # Traceback's Full house activity: the Atlas floor index it opens on (its own key — overview_iso_focus indexes photo floors)
    "wled_teams": [],                     # backend-only (padspan_ha/wled_teams_set): WLED devices that act as one light — see ws_wled.py
    "overview_atlas": False,              # Pro: Overview shows the Atlas; Pure Live gets a switch to the classic Overview (Settings → UI Structure)
    "atlas_live_colours": False,          # the working Atlas draws a lit light in the colour it reports (Settings → UI Structure → Atlas); off: amber, as ever
    "atlas_emergency_button": True,       # show the Atlas "Test emergency lighting" button (Settings → UI Structure → Atlas)
    "atlas_heatmap_enabled": False,       # Atlas: offer the ♨ Heatmap chip (temperature / humidity / CO2); off: no chip, the Atlas as ever (Settings → UI Structure → Atlas)
    "atlas_alert_pulse": False,           # Atlas: ring a room's flagged opening (left open, open in the rain); a wall names the worst alert (Settings → UI Structure → Atlas)
    # Atlas outdoor weather (docs/IDEA_ATLAS_WEATHER.md, views/atlas_weather.js) — rain or snow outside the floor
    # plates while it is actually raining or snowing. On by default in both editions (Pro animates, free is still).
    "atlas_weather_enabled": True,        # master on/off; off = nothing drawn at all
    "atlas_weather_rain_entity": "",      # optional binary_sensor (on = wet) or numeric sensor (> 0 = wet); "" = none
    "atlas_weather_condition_entity": "", # weather.* for the fallback trigger and rain vs snow; "" = the first weather.*
    "atlas_weather_warning_entity": "",   # a weather-warning sensor; "" = detect (env_canada, meteoalarm, dwd, nina, meteo_france, weatheralerts, nws_alerts)
    "atlas_weather_strength": 1.0,        # 0.5-1.5 x opacity
    # Wall screens (the sidebar Atlas on ?kiosk=1, lights_panel.js _wallOn): how
    # big to draw for the room. wall_screen_in 0 = size from the screen's
    # resolution; otherwise its diagonal (inches) and how far people stand
    # (m) set the size, text at wall_text_arcmin of visual angle (control-room
    # practice: 16 minimum, 20-22 preferred). A screen's own link can override
    # all three (?wall_in=&wall_m=&wall_text=).
    "wall_screen_in": 0.0,                # 0 or 15-120
    "wall_distance_m": 2.5,               # 0.3-10
    "wall_text_arcmin": 20.0,             # 14-36
    "wall_night_dim": 0.0,                # 0-0.7: how much darker after sunset
    "wall_pixel_shift": False,            # move the picture a few px every few minutes (OLED burn-in)
    "wall_floor_cycle_s": 0,              # 0 or 10-600: show the next floor every N s while nobody touches the wall
    "wall_fully": False,                  # inside Fully Kiosk: night dim by its screen brightness, motion turns the screen on
    # Live Aboard, the 3D house (docs/IDEA_ATLAS_3D_HOUSE.md on the live-aboard branch). NORMALLY OFF:
    # off = no 3D switch, no Furnish tab, no store writes, no AI or library calls, no telemetry.
    "atlas_3d_enabled": False,            # the master switch
    "atlas_3d_quality": "auto",           # auto | low | high
    "atlas_3d_people": False,             # the people layer
    "atlas_3d_tags": False,               # tags and scanners: every placed tag with its name, every scanner at its height
    "atlas_3d_ai_task_entity": "",        # ai_task.* that reads photos; "" = none (the photo button explains)
    "atlas_3d_library": False,            # the shared furniture library
    "atlas_3d_weather": True,             # rain and snow in Live Aboard: follows Outdoor weather (atlas_weather_*), which must be on too
    "atlas_3d_showcase": False,           # older switch (old backups, Bright): kept valid, decides nothing once atlas_3d_look is there
    "atlas_3d_look": "atlas",             # Live Aboard's look: "atlas" = the same as the Atlas (its Showcase theme, or the plain Atlas) | "own"
    "atlas_3d_home_idle_s": 60,           # the sidebar's Live Aboard goes back to its home view after this long untouched: 0 (never) | 30 | 60 | 300
    "atlas_3d_director": [],              # the sidebar's Live Aboard flies to these when they go off: [{"entity": event.*|binary_sensor.*|alarm_control_panel.*, "camera": camera.* or ""}]; [] = off
    "atlas_3d_carries": {},               # who carries what: {"person.x": [tracked keys]}; personal, kept here only, never sent
    "emergency_entities": [],             # the Atlas emergency lighting test's lights, when set; [] = HA's "emergency" groups, else the default rule — see emergency_test.py
    "vacation_mode_tracked_since": 0,     # backend-only: epoch-s from which every vacation span is in vacation_mode_periods (stamped once on upgrade if Vacation Mode ran before spans were recorded; 0 = always) — vacation_mode.py learned_pattern
    "vacation_mode_pattern_prev": {},     # backend-only: the last pattern learned before a vacation — stands in while a new vacation's build finds nothing (vacation_mode.py learned_pattern)
    "vacation_mode_pattern_attempt": [0, 0],  # backend-only: [enabled_at, epoch-s] of the last build that found nothing usable — retried hourly, not every tick
    "overview_show_walls": False,   # Overview: draw RF barrier walls over the map
    "overview_show_outdoor": False, # Overview: draw outdoor areas (sheds, driveways) as an overlay
    "overview_show_trails": False,  # Overview/Pure Live: fading movement trail behind each tracked object
    "health_reminder_enabled": False,  # monthly calibration accuracy reminder (off by default)
    "health_reminder_last_ts":  None,  # epoch seconds when reminder was last shown
    "adaptive_learning_enabled": False,  # experimental: passive room fingerprint learning
    "adaptive_floor_detection": False,   # experimental: cross-floor attenuation learning
    "beacon_auto_calibrate": True,       # experimental: auto-inject calibration from pinned beacons
    "overview_persistent_pins": False,   # show away beacons at last known position on overview map
    # 3D isometric view layout (Maps tab)
    "maps_iso_floor_gap":    200,   # px spacing between floors
    "maps_iso_horiz_gap":    0,     # px L/R horizontal offset
    "maps_iso_focus":        None,  # z_level to highlight, or null = all
    # 3D isometric view layout (Overview tab) — also the Atlas builder's own
    # camera (Mapping -> Atlas seeds host.view from these same keys).
    "overview_iso_floor_gap": 150,
    "overview_iso_horiz_gap": 0,
    "overview_iso_focus":     None,
    # Atlas's own zoom (Garry, 2026-09-22: "stabilize the zoom in, so when
    # that is locked well, it can stay that way for months if needed" — the
    # sidebar Atlas panel is set up once and left running unattended; an
    # in-memory-only zoom reset to 1.0 on every reboot/reload, which is
    # exactly the kind of drift that made "the map keeps getting smaller"
    # look like a recurring bug rather than a one-time setting never saved).
    "overview_iso_zoom":      1.0,
    # Advanced-mode extra tabs (user picks from Settings → UI Structure)
    "advanced_extra_tabs": [],
    # HA entity publishing controls
    "ha_entity_tracker_enabled":          True,
    "ha_entity_area_enabled":             True,
    "ha_entity_distance_enabled":         True,
    "ha_entity_scanner_distance_enabled": True,
    # MQTT (experimental, off by default)
    "mqtt_publish_enabled": False,
    # ESPresense MQTT ingestion (off by default — requires HA MQTT integration)
    "espresense_mqtt_enabled": False,
    "espresense_topic_prefix": "espresense",
    "tasmota_ble_enabled": False,
    "espresense_room_map": {},              # {"espresense_room": "HA Area Name"}
    # ESPresense Companion import (standalone .NET app / HA add-on)
    "espresense_companion_url": "",         # e.g. "http://espresense:8267" — empty = disabled
    # Aggressive BLE reseed for Shelly/passive proxies (off by default)
    # When enabled, reseeds from HA discovered-service-info every 5s instead of 30s.
    # Helps with HA 2026.4+ where habluetooth dedup suppresses repeat callbacks.
    "aggressive_ble_reseed": False,
    # Presence poll interval (seconds).  How often the smoothing pipeline runs.
    # Lower = faster room transitions but higher CPU.  Default 10s.
    "presence_poll_interval_s": 5,
    # BLE reseed interval (seconds).  How often bluetooth_live re-fetches from
    # HA's discovered-service-info API.  Essential for passive proxy scanners
    # (Shelly, etc.).  Overrides aggressive_ble_reseed when set.  Default 30s.
    "ble_reseed_interval_s": 30,
    # How long an object that was never identified is kept in object history.
    # Tagged/identified objects never expire regardless of this.  The whole
    # cache ships in every live_snapshot (polled every 5s), so longer windows
    # cost payload size and poll time: 7 days measured 16.4k objects / 19.5MB
    # / 2-7s per poll, 1 day 2.8k / 3.8MB / sub-second.  Allowed: 1, 2, 7, 14.
    "object_history_days": 1,
    # The Atlas sidebar panel (panel.py registers it at setup, so a change
    # takes a Home Assistant restart). On by default (Garry, 2026-09-28): off, it
    # was the one place the lighting product lives and almost nobody found it.
    "lights_panel_enabled": True,
    # One-time: installs from before that default had it off only because it
    # WAS the default — nobody chose it. async_load turns it on once for them,
    # records that here, and never touches it again (off stays off after).
    "atlas_default_v1_applied": False,
    "ha_entity_occupancy_enabled": False,  # expose occupancy estimate sensors to HA
    "subzones_enabled": False,             # sub-zones (subzones.py): bed/couch/desk areas with their own sensors
    "bermuda_ignore": False,  # experimental: ignore all Bermuda integration data
    # HA Tags integration
    "tags_room_events_enabled": False,     # emit tag_scanned on room changes
    "tags_nfc_identify_enabled": False,    # NFC tap-to-identify BLE objects
    "tags_phone_autolink_enabled": False,  # auto-track phone on NFC scan
    # Quiet mode — hide unidentified objects everywhere
    "quiet_mode": False,
    # Experimental: 2D flat map mode (replaces 3D isometric view)
    "overview_2d_mode": False,
    # Followed BLE addresses (uppercase MAC/key strings)
    "followed_addrs": [],
    # Beacon profiling / characteristics
    "beacon_profiling_enabled": True,     # master toggle for beacon profiling feature
    "beacon_tune_disabled": [],           # device_ids excluded from calibration tuning
    "beacon_group_overrides": {},         # device_id → model_key override (ungroup/regroup)
    # Private BLE IRK devices (managed in PadSpan — no separate integration needed)
    "irk_devices": [],                    # [{name: str, irk_hex: str}]
    # Curated room → object map (room name → list of object keys).  Set via the
    # padspan_ha.set_room_tag_map service / Manage UI.  Persisted here so it
    # survives restarts and integration reloads — previously the coordinator's
    # room_tag_map was in-memory only and reset to {} on every restart.
    "room_tag_map": {},                   # {room_name: [object_key, ...]}
    # ── Forensics (off by default — records presence sessions of ALL nearby
    # BLE devices, including neighbours/passers-by, for time-window queries.
    # Privacy-sensitive: user must opt in via Settings → Features.) ──────────
    "forensics_enabled": False,
    "forensics_retention_days": 14,       # allowed: 7, 14, 30, 60, 90
    # PadSpan Pro licence (validated against traks.ca/license, product=padspan).
    # Set only via the padspan_ha/forensics_license_activate command.
    "forensics_license_key": "",
    "forensics_license_expires": "",
    # True only for a key minted by padspan_ha/trial_start (the one-time 3-month
    # Bright Pro trial). Display-only — licence.py's tier ladder does not read
    # it, a trial key gates identically to a purchased one.
    "license_is_trial": False,
    # This home among the key's homes (licence_homes.py): the token the
    # licence server rotates at each check, and the name the owner gave it.
    "license_home_token": "",
    "license_home_label": "",
    "license_home_status": "",   # the server's last word on this home, when it refused it
    "license_homes_used": 0,     # how many homes the key is on, as the server last said
    # ── Enterprise preview features (off by default) ─────────────────────────
    "walk_to_identify_enabled": False,      # spatial correlation device discovery ("who just walked in?")
    "radio_map_enabled": False,             # RSSI heatmap overlay on floor plan maps
    "distortion_map_enabled": False,        # calibration disagreement visualization
    "roomplan_import_enabled": False,       # Rooms tab: also import Apple RoomPlan .json scans
    # ── RSSI vector capture (off by default) ─────────────────────────────────
    # Records the full per-scanner RSSI vector for tracked objects, plus the
    # room the pipeline chose, so a trace can be replayed offline against
    # changed code.  Session-scoped: nothing is written until an operator
    # starts a recording, and a session is capped at 60 minutes and 25 MB.
    "rssi_capture_enabled": False,
    "rssi_capture_retention_days": 14,      # allowed: 1, 3, 7, 14, 30
}


def trial_state_kept(live: dict[str, Any] | None, other: dict[str, Any] | None = None) -> dict[str, Any]:
    """The trial milestone's two per-install facts, kept through a settings
    restore, a factory reset and a Bright import (`other` is the settings
    coming in; none for a reset). Like the licence, neither is house
    configuration: an answer given anywhere stays given (trial_nudge_done),
    and the install is as old as its earliest real sighting (first_seen_ts,
    the smaller positive value) — so an older backup can neither bring the
    card back nor restart its week."""
    a, b = live or {}, other or {}
    out: dict[str, Any] = {"trial_nudge_done": bool(a.get("trial_nudge_done") or b.get("trial_nudge_done")),
                           "tester_nudge_done": bool(a.get("tester_nudge_done") or b.get("tester_nudge_done"))}
    seen = [v for v in (a.get("first_seen_ts"), b.get("first_seen_ts"))
            if isinstance(v, (int, float)) and not isinstance(v, bool) and v > 0]
    if seen:
        out["first_seen_ts"] = min(seen)
    # The code running here did not change with a restore, so there is no new
    # update to announce: the later "what's new" version stands, or the update
    # banner (and its one-time trial line) would show again.
    def _ver(v: Any) -> tuple[int, ...] | None:
        try:
            parts = tuple(int(p) for p in str(v).split("."))
        except (TypeError, ValueError):
            return None
        return parts if len(parts) == 3 else None
    versions = [v for v in (a.get("whatsnew_seen_version"), b.get("whatsnew_seen_version")) if _ver(v)]
    if versions:
        out["whatsnew_seen_version"] = max(versions, key=_ver)
    return out


@dataclass
class SettingsStore:
    # The three field annotations below do NOT get their usual @dataclass
    # treatment: this class defines its own __init__ immediately after them,
    # and @dataclass never generates/overrides __init__ when the class
    # already has one. They still document the instance's shape (and drive
    # __repr__/__eq__, which the dataclass machinery does still generate),
    # but SettingsStore(hass=..., store=..., data=...) — the signature these
    # annotations imply — is not how this class is actually constructed;
    # only SettingsStore(hass) is.
    hass: HomeAssistant
    store: Store
    data: dict[str, Any]

    def __init__(self, hass: HomeAssistant) -> None:
        self.hass = hass
        self._raw_store = Store(hass, 1, SETTINGS_STORE_KEY)
        from .safe_store import wrap_store
        self.store = wrap_store(self._raw_store, hass, "settings")
        self.data = dict(DEFAULT_SETTINGS)

    async def async_load(self) -> dict[str, Any]:
        """Load and merge persisted settings onto defaults.

        Merging ensures new keys added in future versions get their defaults
        while preserving the user's existing overrides.
        """
        loaded = await self.store.async_load()
        if isinstance(loaded, dict):
            self.data = {**DEFAULT_SETTINGS, **loaded}
        else:
            self.data = dict(DEFAULT_SETTINGS)
        # Normalize followed_addrs: uppercase + dedup (order preserved).
        # Every comparison in the system (frontend followedHas, backend
        # settings_set, tag_integration) is uppercase; historic entries were
        # saved in mixed formats and silently failed to match.
        _normalized = False
        try:
            _fa = self.data.get("followed_addrs") or []
            _seen: set[str] = set()
            _norm: list[str] = []
            for _x in _fa:
                if not isinstance(_x, str):
                    continue
                _u = _x.strip().upper()
                if _u and _u not in _seen:
                    _seen.add(_u)
                    _norm.append(_u)
            if _norm != _fa:
                self.data["followed_addrs"] = _norm
                _normalized = True
        except Exception:
            pass
        # Vacation Mode spans are recorded from this code on. An install
        # that ran Vacation Mode before has unrecorded ones in the recorder
        # until now (vacation_mode.py learned_pattern, round 6).
        if isinstance(loaded, dict) and "vacation_mode_tracked_since" not in loaded:
            # Recorded spans count too: a 0.38.74-75 reset cleared the other
            # three but kept them (round 7).
            ran = bool(loaded.get("vacation_mode_enabled") or loaded.get("vacation_mode_pattern")
                       or loaded.get("vacation_mode_pattern_built_at") or loaded.get("vacation_mode_periods"))
            self.data["vacation_mode_tracked_since"] = time.time() if ran else 0
        # First sight of this install, once (see first_seen_ts above).
        _fs = self.data.get("first_seen_ts")
        if isinstance(_fs, bool) or not isinstance(_fs, (int, float)) or _fs <= 0:
            self.data["first_seen_ts"] = time.time()
            _normalized = True
        # Atlas on by default, once. Runs before panel.py reads the
        # setting — settings are a critical store, loaded before the panel is
        # registered — so the sidebar entry appears on the restart the update
        # itself needs. A fresh install lands here too and just records it.
        if not self.data.get("atlas_default_v1_applied"):
            self.data["lights_panel_enabled"] = True
            self.data["atlas_default_v1_applied"] = True
            _normalized = True
        # Only re-save if new defaults were added (loaded was missing keys)
        if _normalized or not isinstance(loaded, dict) or set(self.data.keys()) != set(loaded.keys()):
            await self.store.async_save(self.data)
        return self.data

    async def async_set(self, **kwargs: Any) -> dict[str, Any]:
        self.data = {**self.data, **kwargs}
        await self.store.async_save(self.data)
        return self.data

    def get(self, key: str, default: Any = None) -> Any:
        return self.data.get(key, default)
