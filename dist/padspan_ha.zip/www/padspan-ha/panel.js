// PadSpan HA — BLE Room-Presence Tracking for Home Assistant
// Copyright (C) 2026 Garry Broeckling
// Licensed under the GNU General Public License v3.0
// See LICENSE file or https://www.gnu.org/licenses/gpl-3.0.html
/*
REPO LOGIC NOTES

PadSpan HA Panel (single sidebar entry).
- All backend calls go through hass.callWS (websocket_api).
- The UI supports Sample vs Live data (toggle top-right).
- Internal navigation renders feature pages. Each page module exports render(ctx).
- A build stamp is shown in the UI so you can *prove* what code HA is serving (avoids cache confusion).

If UI changes don't show:
  - Hard refresh browser (Ctrl+F5)
  - Clear cache for your HA URL
  - Confirm build stamp in Diagnostics page
*/

// ── Version & Build Constants ────────────────────────────────────────────────
// APP_VERSION is the semver shown in the sidebar and Diagnostics.
// BUILD_ID (YYYYMMDDTHHMMSSZ) is appended to all JS import URLs as a cache-buster
// so browsers always load the latest code after a release.
// CHANNEL controls the sidebar badge and maps to GitHub release types (beta=pre-release).
const APP_VERSION = "0.38.265";
const RELEASE_BUILD_ID = "20261119T182506Z";
// The stamp the views are actually loaded with.
//
// This was the release literal above, so every view URL stayed frozen between
// releases — a browser kept serving `overview.js?b=<last release>` however
// many times that file changed on disk. panel.py now stamps OUR url with a
// digest of the frontend tree (build_info.ASSET_ID), so reading it back here
// makes every view inherit a stamp that moves whenever a file does. The
// literal remains the fallback for anything that loads this module directly.
const BUILD_ID = (() => {
  try {
    return new URL(import.meta.url).searchParams.get("b") || RELEASE_BUILD_ID;
  } catch (e) {
    return RELEASE_BUILD_ID;
  }
})();
const CHANNEL = "beta";

// ── Editions and tiers ───────────────────────────────────────────────────────
// Which surfaces this build shows (views/editions.js). Loaded with the same
// cache-buster as everything else; a failure here must not take the panel
// down, so the fallback is "show everything" — the full edition's answer.
let EDITIONS = null;
// What to do when the backend isn't the build this page loaded. An open
// panel keeps running the JS it loaded, so a wall screen left on through an
// update ran the old UI against the new backend until someone reloaded it.
// Build ids are YYYYMMDDTHHMMSSZ, so they compare as times. A newer backend
// is an update: a kiosk screen reloads itself, once per build (a reload that
// didn't help must not loop). An older one is a page newer than the running
// backend: files updated, HA not restarted yet (or a downgrade).
function staleBuildAction(pageBuild, backendBuild, kiosk, reloadedFor){
  if(!pageBuild || !backendBuild || pageBuild === backendBuild) return null;
  const newer = backendBuild > pageBuild;
  return { newer, reload: newer && !!kiosk && reloadedFor !== backendBuild };
}
// A wall screen: ?kiosk=1, or a window that fills the screen (Chrome
// --kiosk, a full-screen tablet), which nobody is there to press Reload on.
// The same test trial_offer.js newTabOk makes, the other way round.
function wallScreen(kiosk, win = globalThis){
  if(kiosk) return true;
  try {
    const s = win.screen;
    return !!(s && win.innerWidth >= s.width - 1 && win.innerHeight >= s.height - 1);
  } catch(e) { return false; }
}
// The last time anybody touched this screen. A full-screen window may be a
// tablet somebody is using (or a desktop at F11), so it reloads itself only
// after two minutes with nobody at it; ?kiosk=1 reloads straight away.
let _lastInputAt = Date.now();
for (const ev of ["pointerdown", "keydown", "wheel", "touchstart"]) {
  try { globalThis.addEventListener(ev, () => { _lastInputAt = Date.now(); }, { capture: true, passive: true }); } catch(e) {}
}
function untouchedFor(ms){
  return Date.now() - _lastInputAt >= ms;
}
// What kind of screen this is, for the opt-in report (wall_screen:*): does
// the full-screen rule above find real wall screens, or desktops at F11?
function screenKind(kiosk, win = globalThis){
  if(kiosk) return "kiosk";
  if(!wallScreen(false, win)) return "windowed";
  return untouchedFor(120000) ? "fullscreen_idle" : "fullscreen_used";
}
// How a self-reload went, for the opt-in report (wall_reload:*). The page
// that reloaded wrote "<panel>:<kiosk|fullscreen>" beside padspan_reloaded_for;
// the page that comes back is the build it went for, or still the old one.
function reloadOutcome(panel, pageBuild, reloadedFor, how){
  if(!how || !reloadedFor || !how.startsWith(panel + ":")) return null;
  if(reloadedFor === pageBuild) return how.slice(panel.length + 1);
  return reloadedFor > pageBuild ? "stuck" : null;
}
// Read once per page load: this panel's self-reload, if it just made one.
const _PAGE_START = Date.now();
let _reloadNote = null, _screenReported = false;
try {
  const how = sessionStorage.getItem("padspan_reload_how") || "";
  _reloadNote = reloadOutcome("panel", RELEASE_BUILD_ID, sessionStorage.getItem("padspan_reloaded_for") || "", how);
  if (_reloadNote) sessionStorage.removeItem("padspan_reload_how");
} catch(e) {}

const _editionsPromise = import(`./views/editions.js?b=${BUILD_ID}`)
  .then(m => { EDITIONS = m; })
  .catch(err => console.warn("PadSpan: editions module failed to load", err));
// The 90-day trial card (views/trial_offer.js), offered from the Getting
// started card, the update banner, the milestone card and the sidebar entry.
// Optional in the same way: if it fails to load, those lines simply are not
// there. The sidebar is built before it lands, so it waits on the promise.
let TRIAL = null;
const _trialPromise = import(`./views/trial_offer.js?b=${BUILD_ID}`)
  .then(m => { TRIAL = m; })
  .catch(err => console.warn("PadSpan: trial_offer module failed to load", err));
// Free Pro (views/pro_invite.js): an invite the developer sent this install,
// and the one-time "test it, get Pro free" card. Optional like the trial.
let PRO_INVITE = null;
import(`./views/pro_invite.js?b=${BUILD_ID}`)
  .then(m => { PRO_INVITE = m; })
  .catch(err => console.warn("PadSpan: pro_invite module failed to load", err));
// Where "Let Claude draw your rooms" is offered (views/ai_wizard_offer.js):
// a Getting started row and an Overview card. Optional like the trial.
let AIW = null;
import(`./views/ai_wizard_offer.js?b=${BUILD_ID}`)
  .then(m => { AIW = m; })
  .catch(err => console.warn("PadSpan: ai_wizard_offer module failed to load", err));
// "Is this setup step done?": views/setup_status.js, the one rule Setup, the
// Setup Wizard and Mapping read; the Getting started card waits for it.
let SETUP_STATUS = null;
import(`./views/setup_status.js?b=${BUILD_ID}`)
  .then(m => { SETUP_STATUS = m; })
  .catch(err => console.warn("PadSpan: setup_status module failed to load", err));
// Basic's focused views (views/focus.js): a link from Basic opens just the
// part it is about. Settings and Mapping load it too; the panel's own links
// (an Overview tip, the tester card) wait for it.
const _focusPromise = import(`./views/focus.js?b=${BUILD_ID}`)
  .catch(err => { console.warn("PadSpan: focus module failed to load", err); return null; });

// Hide HA / Show HA (ha_sidebar.js), shared with the sidebar Atlas. Until it
// lands the button keeps its first word and a press does nothing; panels that
// tried to paint it before then are repainted when it does.
let HA_SIDEBAR = null;
const _haSideWaiting = new Set();
import(`./ha_sidebar.js?b=${BUILD_ID}`)
  .then(m => { HA_SIDEBAR = m; _haSideWaiting.forEach(p => p._paintHaSide()); _haSideWaiting.clear(); })
  .catch(err => console.warn("PadSpan: ha_sidebar module failed to load", err));

// Which PadSpan module an uncaught error came from (views/ui_error.js). Until
// it lands, or if it never does, uncaught errors simply go uncounted.
let UI_ERROR = null;
// The day theme (day_theme.js), imported the first time it is turned on.
let DAY_THEME = null;
import(`./views/ui_error.js?b=${BUILD_ID}`)
  .then(m => { UI_ERROR = m; })
  .catch(err => console.warn("PadSpan: ui_error module failed to load", err));
// The top bar's status dot (views/status_dot.js): what is wrong, from the
// live poll. Optional like the rest: until it lands, or if it never does,
// there is simply no dot.
let STATUS_DOT = null;
import(`./views/status_dot.js?b=${BUILD_ID}`)
  .then(m => { STATUS_DOT = m; })
  .catch(err => console.warn("PadSpan: status_dot module failed to load", err));

// One name per device, on the server's word (views/device_name.js). Used here by
// the device window; until it lands, the window reads the fields itself.
let DEVICE_NAME = null;
import(`./views/device_name.js?b=${BUILD_ID}`)
  .then(m => { DEVICE_NAME = m; })
  .catch(err => console.warn("PadSpan: device_name module failed to load", err));

// The map as text for screen readers (views/map_text.js). Until it lands, or
// if it never does, the Overview simply has no hidden text.
let MAP_TEXT = null;
import(`./views/map_text.js?b=${BUILD_ID}`)
  .then(m => { MAP_TEXT = m; })
  .catch(err => console.warn("PadSpan: map_text module failed to load", err));

// ── Dynamic view imports ─────────────────────────────────────────────────────
// Two-phase loading for fast first paint:
//   Phase 1 (critical): sample_data, help_content, overview, follow — enough to
//                        render the default view immediately.
//   Phase 2 (deferred): remaining views load in background after first render.
// On-demand: if the user navigates to a view that hasn't loaded yet,
// _loadView() fetches it immediately and re-renders.
let SAMPLE_SNAPSHOT = null;
let HELP = {};
let HELP_MOD = null;   // help_content.js itself: helpTexts() rebuilds HELP in a shipped language
const VIEWS = {};
// Expose VIEWS globally so the Preact bridge can access loaded view modules
window.__PADSPAN_VIEWS = VIEWS;

// Map of view id → module path for on-demand loading
const _VIEW_PATHS = {
  follow:       "./views/follow.js",
  overview:     "./views/overview.js",
  purelive: "./views/purelive.js",
  objects:      "./views/objects.js",
  devices:      "./views/devices.js",
  bluetooth:    "./views/bluetooth.js",
  presence:     "./views/presence.js",
  history:      "./views/history.js",
  monitor:      "./views/monitor.js",
  maps:         "./views/maps.js",
  rooms:        "./views/rooms.js",
  events:       "./views/events.js",
  health:       "./views/health.js",
  settings:     "./views/settings.js",
  manage:       "./views/manage.js",
  debug:        "./views/debug.js",
  diagnostics:  "./views/diagnostics.js",
  qa:           "./views/qa.js",
  training:     "./views/training.js",
  calibration:  "./views/calibration.js",
  receivers:    "./views/receivers.js",
  traceback:    "./views/traceback.js",
  forensics:    "./views/forensics.js",
  sandbox:      "./views/sandbox.js",
  occupancy:    "./views/occupancy.js",
  guests:       "./views/guests.js",
  installbase:  "./views/installbase.js",
  // The guided Setup (plan → … → calibration): a menu tab at the top of the
  // build group until every step is done (owner's D4, 2026-11-13, _setupInMenu),
  // and always reached from the Overview's Getting started and from Mapping.
  setup:        "./views/setup.js",
  // Let Claude draw your rooms (experimental): opened from its offers
  // (views/ai_wizard_offer.js), never a menu tab.
  ai_wizard:    "./views/ai_wizard.js",
};

// Views reachable by internal navigation but never listed in MENU. Being
// current while not in the visible menu set is legitimate for these.
// qa and devices are Development-mode menu tabs that Advanced mode reaches by
// link (the calibration wizard's "See detailed quality report →", the Atlas's
// "Build from relays"): without them here the next nav rebuild bounced the
// user back to the first menu view, the same silent no-op as Mapping's Open
// in Basic mode. (Since More tools, 2026-10-30, every mode lists qa and
// devices; they stay here harmlessly.)
const _VIEW_PATHS_HIDDEN_OK = new Set(["objects", "history", "events", "debug", "diagnostics", "qa", "devices", "setup"]);
_VIEW_PATHS_HIDDEN_OK.add("ai_wizard");   // Let Claude draw your rooms: reached from its offers only

// Track in-flight imports to avoid duplicate fetches
const _viewLoading = {};

/** Load a single view on demand. Returns a promise that resolves when ready. */
function _loadView(id) {
  if (VIEWS[id]) return Promise.resolve(VIEWS[id]);
  if (_viewLoading[id]) return _viewLoading[id];
  const path = _VIEW_PATHS[id];
  if (!path) return Promise.resolve(null);
  _viewLoading[id] = import(`${path}?b=${BUILD_ID}`)
    .then(m => { VIEWS[id] = m; delete _viewLoading[id]; return m; })
    .catch(err => { console.warn("PadSpan: failed to load view", id, err); delete _viewLoading[id]; return null; });
  return _viewLoading[id];
}

// Phase 1: critical modules — just enough for the default view
const _criticalPromise = Promise.allSettled([
  import(`./sample_data.js?b=${BUILD_ID}`).then(m => { SAMPLE_SNAPSHOT = m.SAMPLE_SNAPSHOT || null; }),
  import(`./help_content.js?b=${BUILD_ID}`).then(m => { HELP = m.HELP || {}; HELP_MOD = m; }),
  import(`./views/overview.js?b=${BUILD_ID}`).then(m => { VIEWS.overview = m; }),
  import(`./views/follow.js?b=${BUILD_ID}`).then(m => { VIEWS.follow = m; }),
]).then(results => {
  results.forEach((r, i) => {
    if(r.status === "rejected") console.warn("PadSpan: critical module [" + i + "] failed to load:", r.reason);
  });
});

// Phase 2: remaining views — loaded in background after first paint
const _deferredViewIds = Object.keys(_VIEW_PATHS).filter(id => id !== "overview" && id !== "follow");
let _deferredStarted = false;
function _startDeferredLoads() {
  if (_deferredStarted) return;
  _deferredStarted = true;
  // Stagger slightly to avoid hammering the network on slow hardware
  Promise.allSettled(
    _deferredViewIds.map(id =>
      import(`${_VIEW_PATHS[id]}?b=${BUILD_ID}`)
        .then(m => { VIEWS[id] = m; })
        .catch(err => console.warn("PadSpan: deferred view", id, "failed:", err))
    )
  );
}

// Backwards compat: anything that awaits _viewsPromise still works
const _viewsPromise = _criticalPromise;

// ── Sample mode: the sample house, and nothing written ─────────────────────
// Sample mode ("Preview a finished house") shows the estate (sample_house.js,
// loaded only then). Every message the panel, a view or the embedded Atlas
// sends while it is on goes through _sampleCall, which sorts it here:
//   "pass"  - to the real Home Assistant, as Sample mode always sent them:
//             the settings read, the version, the opt-in report's preview,
//             and a settings save that only switches the data mode back to
//             Live, records the release notes seen, answers the report's
//             question or changes how the panel looks (theme, palette, Day /
//             Light, follow the sun, the 2025 look: display preferences, not
//             the house). Nothing about the house.
//   "drop"  - the opt-in report's counts: answered at once, never sent. The
//             sample house's stairs, 3D and screens are never counted as the
//             real one's (nothing is counted from Sample mode).
//   "read"  - answered from the sample house (or an empty answer); never
//             sent to Home Assistant.
//   "write" - anything else: refused with SAMPLE_READONLY_MSG. Something new
//             is a write until it is listed, so it can only ever be refused.
const SAMPLE_READONLY_MSG = "Sample mode shows a sample house, so nothing can be changed. Switch to Live mode to change your own.";
// This browser's Sample / Live choice (_applyDataMode), and the real follow
// choices kept aside while Sample mode shows (_keepLiveFollow).
const _DATA_MODE_KEY = "padspan_data_mode";
const _FOLLOW_ASIDE = "padspan_follow_live";
let _dataModeMem = null;   // the choice when this browser keeps no storage: it lasts the page
function _localDataMode(){
  try { const v = localStorage.getItem(_DATA_MODE_KEY); if (v === "live" || v === "sample") return v; } catch (_) { /* no storage */ }
  return _dataModeMem;
}
function _saveLocalDataMode(mode){
  _dataModeMem = mode;
  try { localStorage.setItem(_DATA_MODE_KEY, mode); } catch (_) { /* no storage: _dataModeMem */ }
}
function _sampleKind(payload){
  const type = String((payload && payload.type) || "");
  const PASS = ["padspan_ha/settings_get", "padspan_ha/version", "padspan_ha/telemetry_preview"];
  if (PASS.includes(type)) return "pass";
  if (type === "padspan_ha/telemetry_event") return "drop";
  if (type === "padspan_ha/settings_set") {
    const keys = Object.keys(payload).filter(k => k !== "type" && k !== "id");
    const ok = ["data_mode", "whatsnew_seen_version", "telemetry_enabled", "telemetry_asked",
                "telemetry_heard", "telemetry_heard_ask", "theme_palette", "light_theme", "day_theme", "theme_follow_sun", "ui_skin"];
    // Only ever back to Live (_setDataMode): Sample is this browser's own choice, never the server's.
    if ("data_mode" in payload && payload.data_mode !== "live") return "write";
    return keys.length && keys.every(k => ok.includes(k)) ? "pass" : "write";
  }
  // A photo-to-3D status check (no photo sent) is a read; with a photo it is work done for the real house.
  if (type === "padspan_ha/house3d_from_photo") return payload.photo ? "write" : "read";
  const READS = new Set(("adaptive_fingerprints_get adaptive_status_get auto_diagnostics bright_import_status calibration_beacon_profiles "
    + "calibration_get calibration_health_check calibration_room_walk_preview capture_get capture_list capture_status device_registry_list "
    + "emergency_status fabric_health fabric_truth_candidates follow_alert_get forensics_query forensics_stats guests_get ha_entities_audit "
    + "house3d_get house3d_import_preview house3d_library_get house3d_library_search house3d_stairs_plans house3d_stairs_read plan_ai_plans plan_ai_status plan_ai_sessions_get plan_build_info plan_build_status plan_build_rooms_status plan_build_rooms_check ai_usage_get insights_get "
    + "install_base licence_homes live_snapshot logs_get lost_and_found_get maps_image_urls maps_list model_get movement_history_get "
    + "notify_services_list object_label_list occupancy_estimate positioning_diag private_ble_status propagation_health radio_audit "
    + "room_tags rooms_overlap setup_tips status store_backup_list subzones_list system_critics tags_status tester_preview tester_status traceback_get "
    + "traceback_objects vacation_log_get vacation_preview vacuum_cal_pending_list vacuum_status wled_backups wled_devices "
    + "wled_exact_list wled_get wled_look_get wled_teams_get power_teams_get motion_reconnects vacuum_import_preview irk_validate "
    + "companion_discover").split(" ").map(t => "padspan_ha/" + t));
  for (const t of ["config/entity_registry/list", "config/entity_registry/list_for_display", "config/entity_registry/get",
                   "config/device_registry/list", "config/area_registry/list", "config/floor_registry/list",
                   "history/history_during_period"]) READS.add(t);
  return READS.has(type) ? "read" : "write";
}

// ── Sidebar Menu Definition ──────────────────────────────────────────────────
// Each entry: [route_id, display_label, mdi_icon].
// Order here determines sidebar rendering order. Visibility is filtered
// at render time based on the current complexity mode (Basic/Advanced/Dev).
const MENU = [
  ["overview","Overview","mdi:view-dashboard-outline"],
  ["purelive","Live Tracker","mdi:lightning-bolt-outline"],
  ["follow","Follow","mdi:crosshairs-gps"],
  ["devices","Devices","mdi:devices"],
  ["bluetooth","Bluetooth","mdi:bluetooth"],
  ["presence","Presence","mdi:map-marker-radius-outline"],
  ["monitor","Monitor","mdi:monitor-dashboard"],
  ["setup","Setup","mdi:format-list-checks"],
  ["maps","Mapping","mdi:map"],
  ["rooms","Rooms","mdi:floor-plan"],
  ["receivers","Receivers","mdi:access-point"],
  ["settings","Settings","mdi:cog-outline"],
  ["manage","Manage","mdi:cog-wrench"],
  ["training","Training","mdi:school-outline"],
  ["calibration","Calibration","mdi:crosshairs"],
  ["traceback","Traceback","mdi:history"],
  ["forensics","Forensics","mdi:magnify-scan"],
  ["occupancy","Occupancy","mdi:account-group-outline"],
  ["guests","Guests","mdi:account-clock-outline"],
  ["health","Health","mdi:heart-pulse"],
  ["qa","QA","mdi:clipboard-check-outline"],
  ["sandbox","Sandbox","mdi:flask-outline"],
  ["installbase","Install Base","mdi:chart-box-outline"],
];

// Screens reached by a link, never listed in MENU: what the phone's top bar calls them.
const UNLISTED_VIEW_TITLES = { objects: "Devices", history: "History", events: "Events", debug: "Debug", diagnostics: "Diagnostics", ai_wizard: "Claude draws rooms" };   // the phone's title bar: the card says "Let Claude draw your rooms"

// ── Complexity Mode Tab Sets ─────────────────────────────────────────────────
// Modes no longer hide screens (2026-10-30): every screen is in the menu in
// every mode. These sets only decide which screens sit in the main groups;
// the rest go in one "More tools" group, closed until opened (remembered).
//   Basic     — a short main list for non-technical users (follow + overview +
//               essentials, Calibration among them: every home needs it; Rooms
//               too: Basic's Mapping has no Edit or Rooms tab, so it is Basic's
//               only room-by-room screen, its colours included; and Receivers:
//               every home has them, and a silent one is the commonest cause
//               of wrong rooms)
//   Advanced  — default set plus user-chosen extras from Settings -> UI Structure
//   Dev       — the same menu as Advanced; it changes detail inside screens
// DEV_ONLY_TABS: the screens only Development used to list.
// Setup is a main tab in every mode while it is in the menu at all (_setupInMenu).
const BASIC_TABS = new Set(["follow", "overview", "setup", "maps", "rooms", "receivers", "calibration", "settings", "training"]);
const ADVANCED_DEFAULT = new Set(["follow","overview","purelive","setup","maps","rooms","receivers","settings","training","manage","calibration","traceback","occupancy","health"]);
const DEV_ONLY_TABS = ["devices","bluetooth","presence","monitor","qa","sandbox","installbase"];

// Accent color per tab — used for the sidebar dot, mobile nav, and active highlights
const MENU_COLORS = {
  follow: "#5eead4",
  overview: "#52b788",
  objects: "#ff8a65",
  devices: "#4db6ac",
  bluetooth: "#43a047",
  presence: "#ba68c8",
  zones: "#81c784",
  history: "#90a4ae",
  monitor: "#f06292",
  setup: "#5eead4",
  maps: "#4caf50",
  rooms: "#66bb6a",
  events: "#ffb74d",
  health: "#e57373",
  settings: "#b0bec5",
  manage: "#78909c",
  training: "#4dd0e1",
  calibration: "#26a69a",
  receivers: "#86efac",
  occupancy: "#a78bfa",
  guests: "#fbbf24",
  diagnostics: "#9575cd",
  debug: "#ef5350",
  traceback: "#fbbf24",
  forensics: "#f87171",
  qa: "#26c6da",
  sandbox: "#9ccc65",
  purelive: "#7c3aed",
  installbase: "#38bdf8",
};

// ── 2025 skin: nav icons and groups ──────────────────────────────────────────
// MENU already carries an mdi name per entry, but nothing ever rendered it —
// which is also why the collapsed rail (.app.mini) had nothing to fall back to
// and clipped its labels mid-word. These are inline SVG bodies rather than
// <ha-icon>: ha-icon is used nowhere else in this panel, and a missing
// registration inside a shadow root renders as a blank box. Inline SVG also
// inherits currentColor, which is what drives the active-state tint.
// Only consulted when settings.ui_skin === "2025".
const MENU_ICONS = {
  overview:    '<rect x="3" y="3" width="7" height="7" rx="1.6"/><rect x="14" y="3" width="7" height="7" rx="1.6"/><rect x="3" y="14" width="7" height="7" rx="1.6"/><rect x="14" y="14" width="7" height="7" rx="1.6"/>',
  purelive:    '<path d="M13 2 4 14h7l-1 8 9-12h-7z"/>',
  follow:      '<path d="M21 3 3 10.5l7.5 3L14 21l7-18z"/>',
  guests:      '<circle cx="9" cy="8" r="3.2"/><path d="M3 20c0-3.3 2.7-5 6-5s6 1.7 6 5"/><circle cx="17.5" cy="16.5" r="4"/><path d="M17.5 14.6v2l1.3 1"/>',
  occupancy:   '<circle cx="9" cy="8" r="3.2"/><path d="M3 20c0-3.3 2.7-5 6-5s6 1.7 6 5"/><path d="M16 5.6a3.2 3.2 0 0 1 0 6.1M17.2 20c0-2.6-.9-4.2-2.4-5"/>',
  setup:       '<path d="M9 6h11M9 12h11M9 18h11"/><path d="M3.5 6l1.5 1.5L7.5 5M3.5 12l1.5 1.5L7.5 11"/><circle cx="5" cy="18" r="1.4"/>',
  maps:        '<path d="M9 4 3 6.5v14L9 18l6 2.5 6-2.5v-14L15 6.5 9 4z"/><path d="M9 4v14M15 6.5v14"/>',
  rooms:       '<rect x="3" y="3" width="18" height="18" rx="1.6"/><path d="M3 12h7M14 12h7M12 3v6M12 15v6"/>',
  calibration: '<circle cx="12" cy="12" r="8.4"/><circle cx="12" cy="12" r="3.6"/><path d="M12 1.5v3M12 19.5v3M1.5 12h3M19.5 12h3"/>',
  receivers:   '<circle cx="12" cy="11" r="1.8"/><path d="M12 12.8V21"/><path d="M8.3 7.3a5.2 5.2 0 0 0 0 7.4M15.7 7.3a5.2 5.2 0 0 1 0 7.4M5.5 4.5a9.2 9.2 0 0 0 0 13M18.5 4.5a9.2 9.2 0 0 1 0 13"/>',
  training:    '<path d="M12 4 2 9l10 5 10-5-10-5z"/><path d="M6 11.5V17c0 1.7 2.7 3 6 3s6-1.3 6-3v-5.5"/>',
  manage:      '<path d="M4 6h9M19 6h1M4 12h4M13 12h7M4 18h9M19 18h1"/><circle cx="16" cy="6" r="2.1"/><circle cx="10.5" cy="12" r="2.1"/><circle cx="16" cy="18" r="2.1"/>',
  settings:    '<circle cx="12" cy="12" r="3.1"/><path d="M12 2.2v2.6M12 19.2v2.6M4.4 4.4l1.9 1.9M17.7 17.7l1.9 1.9M2.2 12h2.6M19.2 12h2.6M4.4 19.6l1.9-1.9M17.7 6.3l1.9-1.9"/>',
  traceback:   '<path d="M3.2 12a8.8 8.8 0 1 0 2.9-6.5L3 8"/><path d="M3 3v5h5"/><path d="M12 7.4V12l3 2"/>',
  health:      '<path d="M12 20s-7.4-4.9-7.4-9.4A4.1 4.1 0 0 1 12 7.5a4.1 4.1 0 0 1 7.4 3.1c0 4.5-7.4 9.4-7.4 9.4z"/><path d="M4.8 12.1h2.9l1.4-2.1 1.8 3.9 1.6-2.9 1.1 1.1h4.6"/>',
  forensics:   '<circle cx="11" cy="11" r="6.2"/><path d="M20 20l-4.6-4.6"/><path d="M8.2 11h5.6"/>',
  monitor:     '<rect x="2.5" y="4" width="19" height="12.4" rx="2"/><path d="M9 20h6M12 16.4V20"/>',
  devices:     '<rect x="2" y="5" width="13" height="10" rx="1.8"/><path d="M5.5 19h6"/><rect x="17" y="9" width="5" height="10" rx="1.6"/>',
  bluetooth:   '<path d="M7 7.5 17 16.5 12 21V3l5 4.5L7 16.5"/>',
  presence:    '<circle cx="12" cy="10" r="2.5"/><path d="M12 21s6-5.4 6-10a6 6 0 1 0-12 0c0 4.6 6 10 6 10z"/>',
  qa:          '<rect x="5" y="4.5" width="14" height="16" rx="2"/><path d="M9 4.5V3.6a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v.9"/><path d="M9 13l2.2 2.2L15.5 11"/>',
  sandbox:     '<path d="M10 3v6.2L4.6 18a2 2 0 0 0 1.7 3h11.4a2 2 0 0 0 1.7-3L14 9.2V3"/><path d="M9 3h6"/><path d="M7.4 14.5h9.2"/>',
  installbase: '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="M7 16v-5M12 16V8M17 16v-3"/>',
};

// Sidebar grouping for the 2025 skin. Order here drives render order; any MENU
// id missing from this table still renders, under a trailing "More" heading, so
// adding a tab without touching this file can never make it disappear.
const MENU_GROUPS = [
  ["Live",      ["overview","purelive","follow","occupancy","guests"]],
  ["Build",     ["setup","maps","rooms","receivers","calibration","training","manage","settings"]],
  ["Diagnose",  ["traceback","health","forensics","monitor"]],
  ["Internals", ["devices","bluetooth","presence","qa","sandbox","installbase"]],
];


// ── DOM Utility Functions ────────────────────────────────────────────────────
// Shared helpers used by panel.js and all view modules (passed via ctx.helpers).

/** HTML-escape a string to prevent XSS when inserting into innerHTML. */
function esc(s){
  return String(s ?? "").replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;");
}

/** Convenience DOM builder: el("div", {class:"foo", onclick:fn}, ["text", childNode]) */
/**
 * Human-readable age, e.g. "42s", "3m 10s", "2d 4h".
 *
 * This was a local of _showObjectDetail while _showRoomDetail called it as if
 * it were shared — a ReferenceError on every click of an occupied room, and
 * invisible because the modal simply never opened. It is shared now, which is
 * what both callers always assumed.
 */
function fmtAgo(age_s){
  const s = Number(age_s);
  if(!isFinite(s)) return "—";
  if(s < 1) return "<1s";
  if(s < 60) return `${Math.round(s)}s`;
  const m = Math.floor(s/60), rs = Math.round(s - m*60);
  if(m < 60) return `${m}m ${rs}s`;
  const h = Math.floor(m/60), rm = m - h*60;
  if(h < 24) return `${h}h ${rm}m`;
  const d = Math.floor(h/24), rh = h - d*24;
  return `${d}d ${rh}h`;
}

function el(tag, attrs={}, children=[]){
  const n=document.createElement(tag);
  for(const [k,v] of Object.entries(attrs||{})) {
    if(k==="class") n.className=v;
    else if(k==="id") n.id=v;
    else if(k==="style") n.setAttribute("style", v);
    else if(k.startsWith("on") && typeof v==="function") n.addEventListener(k.slice(2), v);
    else if(v!==undefined && v!==null) n.setAttribute(k, String(v));
  }
  if(!Array.isArray(children)) children=[children];
  for(const c of children) {
    if(c===null || c===undefined) continue;
    if(typeof c==="string" || typeof c==="number") n.appendChild(document.createTextNode(String(c)));
    else n.appendChild(c);
  }
  return n;
}

/**
 * URL for a map's image: the signed link maps_list handed out for it.
 *
 * Floor plans are served only to a logged-in user (map_image_view.py), and an
 * <img> cannot send a login header, so each map gets a link signed for this
 * user. The backend versions it on the picture, so a trimmed or rotated map
 * never shows its stale pre-edit image (issue #62).
 *
 * The links are kept here, not on the map objects: Diagnostics and the Maps
 * backup write those out whole, and a working link has no business in a file
 * somebody may attach to an issue.
 * Every map image URL must be built here; tests/test_map_image_url.py fails
 * the build if a hand-built path reappears.
 */
let _mapImageUrls = {};
function mapImageUrl(map){
  const fn = map && map.image && map.image.filename;
  if(!fn) return null;
  return _mapImageUrls[map.id] || null;
}

/**
 * Away timeout in SECONDS, from settings (default 5 min), and the presence
 * test that goes with it. Mirrors presence_rules.py exactly.
 *
 * This one rule had been hand-rolled in nine places across the backend and
 * frontend. Copies drift: the server-side room-occupancy rebuild never
 * implemented it at all, so a car gone for an hour stayed listed in the Garage
 * beside devices seen 20 seconds ago. Every consumer must come through here;
 * tests/test_presence_away_rule.py fails the build if a tenth copy appears.
 */
const AWAY_RADIO_KINDS = ["ble", "private_ble", "ibeacon"];
function awayTimeoutS(settings){
  const v = settings && settings.away_timeout_m != null ? Number(settings.away_timeout_m) : 5;
  if(!isFinite(v)) return 300;
  return Math.max(1, Math.min(1440, v)) * 60;
}
/** Only radio-backed objects go away; an object with no usable age never has. */
function isAway(obj, timeoutS){
  if(!obj || AWAY_RADIO_KINDS.indexOf(obj.kind) === -1) return false;
  const a = obj.age_s;
  return typeof a === "number" && isFinite(a) && a > timeoutS;
}

/**
 * RSSI (dBm) to a 0-100 signal-bar percentage: -100dBm=0%, -40dBm=100%,
 * clamped at both ends. A missing/undefined rssi is treated as -100 (empty
 * bar). This formula was duplicated verbatim at three call sites in this
 * file (a fourth, separate copy lives in views/calibration.js); route all
 * local signal-bar rendering through here instead of re-deriving it.
 */
function rssiToPercent(rssi){
  return Math.max(0, Math.min(100, (((rssi ?? -100) + 100) / 60) * 100));
}

/**
 * Deterministic short ID for a BLE radio: letter-number-letter (e.g. "A3B").
 * Derived from a djb2 hash of the source string so it's stable across sessions
 * and compact enough to display as a visual badge in scanner lists.
 */
function radioShortId(source){
  let h = 5381;
  const s = String(source || "");
  for(let i = 0; i < s.length; i++) h = (((h * 33) >>> 0) ^ s.charCodeAt(i)) >>> 0;
  const L1 = String.fromCharCode(65 + (h % 26));
  const N  = (h >>> 5) % 10;
  const L2 = String.fromCharCode(65 + ((h >>> 9) % 26));
  return `${L1}${N}${L2}`;
}

/**
 * Determine scanner status: "scanning", "listening", or "idle".
 * @param {object} radio  — radio object with .scanning, .source
 * @param {Array}  ads    — snapshot advertisements array (optional)
 * @returns {{label:string, cls:string, title:string}}
 */
function scannerStatus(radio, ads){
  if(radio.scanning === true)
    return { label:"scanning", cls:"badge", title:"Actively requesting BLE advertisements from nearby devices" };
  // Use last_heard_s (seconds since last ad received, independent of age filter) if available
  const lh = radio.last_heard_s;
  if(typeof lh === "number" && lh < 120)
    return { label:"listening", cls:"badge", style:"background:rgba(56,189,248,.14);color:#38bdf8", title:`Last heard ${Math.round(lh)}s ago — online and receiving BLE broadcasts` };
  const src = radio.source || "";
  const hasAds = Array.isArray(ads) && ads.some(a => a.source === src);
  if(hasAds)
    return { label:"listening", cls:"badge", style:"background:rgba(56,189,248,.14);color:#38bdf8", title:"Online and receiving BLE broadcasts (passive mode)" };
  if(typeof lh === "number" && lh < 600)
    return { label:`heard ${Math.round(lh)}s ago`, cls:"badge warn", title:`Last advertisement received ${Math.round(lh)}s ago — may be in a quiet area` };
  return { label:"idle", cls:"badge warn", title:"No recent BLE data — may be offline, rebooting, or in a quiet area" };
}

// Room colour lives in views/room_color.js — ONE implementation, shared with
// the lights renderer. panel.js hands it to every view as ctx.helpers.roomColor.
const { roomColor, roomColorAlpha } =
  await import(`./views/room_color.js${new URL(import.meta.url).search}`);
// The object detail modal's "why is it here" evidence diagram (gap #2,
// best-in-class roadmap) — a pure string builder, see its own header.
const { buildEvidenceSvg, roomScoreBars } =
  await import(`./views/evidence_diagram.js${new URL(import.meta.url).search}`);
// A push subscription kept across HA restarts (motion_reconnects, below).
const { keepSubscribed } =
  await import(`./views/push_subscription.js${new URL(import.meta.url).search}`);
// The panel's translations (views/i18n.js), the same module help_content.js
// imports. English, or a language not shipped, loads nothing. Not awaited:
// if it fails to load, the help simply stays English.
const _i18nPromise = import(`./views/i18n.js?b=${BUILD_ID}`)
  .catch(err => { console.warn("PadSpan: i18n module failed to load", err); return null; });

function pill(text){ return el("span",{class:"pill"}, text); }

// ── Main Application Element ─────────────────────────────────────────────────
// PadSpanHaApp is registered as a custom element ("padspan-ha-app") and mounted
// by Home Assistant as a panel. HA drives the lifecycle:
//   1. constructor()        — initializes state (no DOM yet)
//   2. connectedCallback()  — builds shadow DOM, starts polling & keep-alive
//   3. set hass(hass)       — called by HA on every state change (very frequent);
//                             used for first boot, WS reconnect detection, and
//                             sidebar re-entry recovery
//   4. disconnectedCallback() — tears down timers & listeners when HA detaches
//
// State management: all UI state lives in this.state (a plain object).
// Views receive a "ctx" object (_ctx()) with state, helpers, and actions.
// Views are pure render functions: ctx => HTMLElement. They never mutate state
// directly — all mutations go through ctx.actions which call back into this class.
class PadSpanHaApp extends HTMLElement {
  constructor(){
    super();
    // _hass is what the panel and its views talk to: Home Assistant itself,
    // or in Sample mode the sample house in front of it (_viewHass).
    // _realHass is always Home Assistant's own.
    this._hass = null;
    this._realHass = null;
    this._sampleHouse = null;

    // ── Centralized application state ──────────────────────────────────────
    // All UI state is kept here so views can read it through ctx.state.
    // Mutations happen through actions (ctx.actions) which update state
    // and trigger re-renders via _renderCurrentView().
    this.state = {
      version: APP_VERSION,
      buildId: BUILD_ID,
      view: "overview",
      dataMode: "sample",          // sample | live
      _dataModeKnown: false,       // true once the server has said which (see _applyDataMode)
      complexity: "advanced",      // basic | advanced | development
      status: {},
      roomTagMap: {},
      savedRoomTagMap: {},
      model: { floors: [], room_meta: {}, scanners: {}, room_adjacency: {}, fabric_sync_mode: "auto", scanner_positions_m: {}, room_geometry_m: {}, rf_barriers_m: [], map_transforms: {}, beacon_positions_m: {}, fabric_floors: {} },
      live: { snapshot: null, sources: null, error: null },
      maps: { list: [], lastError: null },
      // "no maps yet" and "maps have not arrived yet" are different facts. The
      // onboarding card asks whether setup is done; before these fetches settle the
      // honest answer is "unknown", and rendering unknown as "not done" told an
      // established install it had never uploaded a floor plan. See _setupKnown.
      _mapsLoaded: false,
      _modelLoaded: false,
      mapsTab: "library",
      activeMapId: null,
      diag: null,
      selectedRooms: [],
      _roomsInit: false,
      mode: "live",
      tagFilter: "",
      wsCounts: {},
      timing: { lastRefreshMs: null, lastDiagMs: null },
      _sessionEvents: [],
      _sessionStart: Date.now(),
      lastToast: null,
      versionInfo: null,
      settings: {},               // full settings dict from settings_get
      // Followed beacons — persisted to localStorage
      // Read guarded: a browser that blocks storage threw here and left a blank panel.
      followedAddrs: new Set((() => { try { return JSON.parse(localStorage.getItem("padspan_followed") || "[]"); } catch (e) { return []; } })()),
      followAddr: (() => { try { return localStorage.getItem("padspan_followAddr") || ""; } catch (e) { return ""; } })(),
    };

    // ── Shadow DOM references (set in connectedCallback) ─────────────────
    this.$ = null;          // querySelector shorthand for shadow DOM
    this.$nav = null;       // sidebar nav container
    this.$content = null;   // main content area where views render

    // ── Polling & Keep-Alive Timers ────────────────────────────────────────
    // _pollTimer: 5s interval that fetches live_snapshot + status (data freshness)
    // _pollInFlight: prevents overlapping WS calls if previous poll is still running
    this._pollTimer = null;
    this._pollInFlight = false;
    // _activityTimer: 25s synthetic pointer events to prevent HA idle overlay
    // _watchdogTimer: 5s DOM integrity checks to recover from blank screens
    this._activityTimer = null;
    this._watchdogTimer = null;
    // Render health tracking — watchdog uses these to detect persistent blank screens
    // and escalate from soft re-render to full connectedCallback rebuild
    this._lastGoodRender = performance.now();
    this._renderFailCount = 0;
    // Track last user interaction to suppress poll re-renders during active use
    // (prevents form inputs from being destroyed while the user is typing)
    this._lastUserInteraction = 0;

    // Custom-element upgrade race: HA can set .hass on this element before
    // the browser finishes upgrading it to this class (the defining module
    // loads async over the network), which creates a plain instance
    // property that permanently shadows the `hass` accessor below — set
    // hass() would then never fire on its own. The _watchdogTimer above
    // already recovers from this within ~5s, but reclaiming any pre-upgrade
    // value here through the accessor avoids that delay/blank flash entirely.
    if (Object.prototype.hasOwnProperty.call(this, "hass")) {
      const preUpgradeHass = this.hass;
      delete this.hass;
      this.hass = preUpgradeHass;
    }
  }

  // ── HA Property Setter ──────────────────────────────────────────────────────
  // HA calls `set hass()` on EVERY state change (entity updates, etc.) — potentially
  // dozens of times per second. We must NOT do expensive work on every call.
  // Three cases are handled:
  //   1. First boot (_booted === false): wait for view modules, then full refresh
  //   2. WS reconnect (connection object changed): re-bootstrap everything
  //   3. Sidebar re-entry: restart timers/listeners if they were cleared by disconnect
  set hass(hass){
    // prevHass: Home Assistant's own, as before (the reconnect test below
    // compares its connections); the views get _viewHass's answer.
    const prevHass = this._realHass;
    this._realHass = hass;
    this._hass = this._viewHass(hass);
    if (hass && (!prevHass || prevHass.dockedSidebar !== hass.dockedSidebar)) this._paintHaSide();
    // The Atlas as Overview (views/overview.js) is the sidebar Atlas page,
    // which reads states off its own hass: hand it each new one.
    if(this.state && this.state._overviewAtlas) this.state._overviewAtlas.hass = this._hass;
    // Follow the sun (_sunLook): the look changes at sunrise and sunset.
    // The help in the HA profile's language: fetched on first need (a "?" or
    // Training, see _loadHelpLanguage), asked again only when it changes.
    const langSeen = hass ? ((hass.locale && hass.locale.language) || hass.language || "") : "";
    if(hass && langSeen !== this._langSeen){ this._langSeen = langSeen; if(this._helpLoad) this._loadHelpLanguage(); }
    if(this.state?.settings?.theme_follow_sun === true && (hass?.states?.["sun.sun"]?.state || null) !== (this._sunSeen ?? null)) this._applyTheme();
    // Motion sensors back from an offline blip (motion_reconnects.py), pushed
    // on every change — one subscription per connection (a new connection,
    // or a re-entry after disconnectedCallback, subscribes afresh), kept
    // across HA restarts on the same connection (push_subscription.js).
    if(hass && hass.connection && this._reconnectsConn !== hass.connection){
      if(this._reconnectsStop) this._reconnectsStop();
      this._reconnectsConn = hass.connection;
      this._reconnectsStop = keepSubscribed(hass.connection, { type: "padspan_ha/motion_reconnects" },
        m => { this.state._motionReconnects = m || {}; });
    }
    if(!this._booted){
      this._booted = true;
      // Wait for critical view modules (overview + follow), then render immediately.
      // Deferred views load in background after first paint.
      _criticalPromise.then(() => {
        _startDeferredLoads();
        // Keep-alive/watchdog starts immediately so recovery works even if
        // the first refresh hangs on a dead WS connection.
        this._startKeepAlive();
        // Start polling AFTER the first refresh resolves: dataMode comes from
        // settings fetched inside _refreshAll, so checking it synchronously
        // here always saw the "sample" default and never started the poll on
        // first boot (live data only began after a later set-hass re-entry).
        this._refreshAll(false).finally(() => {
          if(this.state.dataMode === "live") this._startDataPoll();
        });
      });
    } else if(hass && prevHass && hass !== prevHass && hass.connection !== prevHass.connection){
      // HA reconnected with a new WS connection (e.g. after network blip) — re-bootstrap
      this._pollInFlight = false;
      _criticalPromise.then(() => {
        this._ensureShadowDom();
        this._refreshAll(false);
        if(this.state.dataMode === "live") this._startDataPoll();
      });
    }
    // ── Sidebar re-entry recovery ────────────────────────────────────────────
    // HA calls set hass() when the user navigates back to PadSpan in the sidebar.
    // If disconnectedCallback ran (cleared timers/listeners), re-start them here.
    // This catches the case where HA re-attaches without calling connectedCallback.
    if(hass && this._booted && this.isConnected){
      if(!this._watchdogTimer || !this._activityTimer){
        this._startKeepAlive();
      }
      if(this.state.dataMode === "live" && !this._pollTimer){
        this._startDataPoll();
      }
      // If content is blank, rebuild + refresh (user just navigated back)
      if(this.$content && !this.$content.children.length){
        this._renderNav();
        this._scheduleRender();
        if(!this._sidebarRefreshing){
          this._sidebarRefreshing = true;
          this._refreshAll(false).finally(()=>{ this._sidebarRefreshing = false; });
        }
      }
    }
  }

  // ── connectedCallback ───────────────────────────────────────────────────────
  // Called when HA inserts the element into the DOM. Builds the entire shadow DOM
  // (sidebar, topbar, content area, modal/toast containers), wires up event
  // listeners, and kicks off the initial data load. Also called as a "nuclear
  // recovery" path by the watchdog when the DOM is irrecoverably corrupted.
  connectedCallback(){
    if(!this.shadowRoot) this.attachShadow({mode:"open"});
    // The rebuild below drops the theme's stylesheets and the skin link:
    // forget them, so _applyTheme and _applySkin put them back on the new page.
    if (this._dayOff) { this._dayOff(); this._dayOff = null; }
    this._dayKey = ""; this._skin = null;
    this.shadowRoot.innerHTML = `
      <link rel="stylesheet" href="/padspan_ha_static/padspan-ha/styles.css?v=${APP_VERSION}&b=${BUILD_ID}">
      <!-- 2025 skin overlay. Deliberately href-less until _applySkin() decides:
           styles.css above is always the base, so a failed or disabled skin
           leaves the classic panel fully intact rather than unstyled. -->
      <link rel="stylesheet" id="skinLink">
      <style>
        /* Only :host fallback — do not override layout classes that styles.css already handles */
        :host{display:block;background:#0a150e;color:#e2e8f0;font-family:Inter,system-ui,Arial,sans-serif;box-sizing:border-box}
      </style>
      <div id="app" class="app">
        <div class="side-backdrop" id="sideBackdrop"></div>
        <aside class="left">
          <div class="sidebar-mobile-header" id="sidebarMobileHeader">
            <span style="font-weight:700;font-size:15px;flex:1">PadSpan HA</span>
            <button class="btn inline" id="sidebarClose" style="width:auto;font-size:18px;padding:4px 10px">&times;</button>
          </div>
          <div class="brand">
            <img src="/padspan_ha_static/padspan-ha/assets/padspan-mark.svg?b=${BUILD_ID}" alt="PadSpan" onerror="this.style.display='none'">
            <div>
              <div class="label">PadSpan™ HA</div>
              <div class="muted" style="margin-top:2px">v${APP_VERSION}${CHANNEL==='stable'?` <span style="font-size:10px;padding:1px 5px;border-radius:3px;background:#2e7d32;color:#fff;vertical-align:middle">${CHANNEL}</span>`:''}</div>
            </div>
          </div>

          <div class="toolbar" style="margin-top:10px">
            <button class="btn inline" id="refresh">Refresh</button>
            <button class="btn inline" id="autodiag">Auto Diagnostics</button>
            <button class="btn inline" id="toggleSide">Toggle</button>
            <button class="btn inline" id="haSide" title="Hide or show Home Assistant's sidebar, on this browser only">Hide HA</button>
          </div>

          <!-- Flood alarm latches (flood_latch.py) — always visible off to
               the side, whichever tab is open, not buried in a device row.
               Hidden entirely when nothing is latched. -->
          <div id="emergencyBanner" class="emergency-banner hidden">
            <div class="emergency-banner-head" id="emergencyBannerHead">
              <span>🚨</span><span id="emergencyBannerCount">0 active</span>
            </div>
            <div id="emergencyBannerList"></div>
          </div>

          <div style="margin-top:12px;margin-bottom:8px" class="muted" id="navLabel">Menu</div>
          <div class="nav" id="nav"></div>
          <div id="navTrial" style="margin-top:10px"></div>
        </aside>

        <main class="main">
          <div class="mobile-topbar" id="mobileTopbar">
            <button class="mobile-topbar-btn" id="mobileBackBtn" title="Back to Home Assistant" style="font-size:18px;padding:4px 6px">&#x2190;</button>
            <button class="mobile-topbar-btn" id="mobileMenuBtn">&#9776;</button>
            <span class="mobile-topbar-title" id="mobileTitle">Overview</span>
            <button class="status-dot hidden" type="button" data-status-dot="mobile"></button>
            <button class="mobile-topbar-pill" id="mobileDataPill">…</button>
            <button class="mobile-topbar-pill" id="mobileModePill">Advanced</button>
            <button class="mobile-topbar-pill hidden" id="mobileEmergencyPill" style="background:#7f1d1d;border-color:#dc2626;color:#fecaca">🚨 0</button>
          </div>
          <div class="row desktop-topbar" style="margin-bottom:10px;align-items:center">
            <span class="pill" id="cloudBadge">Cloud disabled</span>
            <span class="pill" id="scanBadge">Scan: —</span>
            <span class="pill" id="statusBadge">Status: —</span>
            <button class="status-dot hidden" type="button" data-status-dot="desktop"></button>

            <span style="margin-left:auto;display:flex;align-items:center;gap:8px">
              <span class="muted" style="font-size:12px">Data</span>
              <button class="btn inline" id="dataModeToggle" title="Toggle sample vs live data">…</button>
              <button class="btn-help" id="dataModeHelp" title="Help: Live and Sample">?</button>
              <button class="btn inline" id="complexityToggle" title="Cycle between Basic, Advanced, and Development modes">Advanced</button>
              <button class="btn-help" id="complexityHelp" title="Help: Basic, Advanced and Development">?</button>
            </span>
          </div>
          <!-- ?kiosk=1 hides both top bars: there, red only, in the bottom corner (the top right is the Overview's Quiet tick). -->
          <div class="status-dot status-dot-wall hidden" role="status" data-status-dot="wall"></div>
          <div id="toast" class="toast hidden"></div>
          <div id="staleBuild" class="stale-build hidden"></div>
          <div id="modal" class="modal hidden"></div>
          <div id="content"></div>
        </main>

        <div class="mobile-bottom-nav" id="mobileBottomNav"></div>
      </div>
    `;

    this.$ = (q)=>this.shadowRoot.querySelector(q);
    this.$nav = this.$("#nav");
    this.$content = this.$("#content");
    this.$modal = this.$("#modal");
    // A re-entry with the settings already read: the 2025 skin goes back on
    // the new page at once, not at the next settings read (a flash of classic).
    if (this.state?.settings) this._applySkin();

    // Kiosk chrome hiding runs after state init (URL parsed later in this
    // method) — schedule for after the constructor body completes.
    queueMicrotask(() => {
      if (!this.state?.kioskMode) return;
      try {
        const style = document.createElement("style");
        style.textContent = `
          .left, .desktop-topbar, .mobile-topbar, .mobile-bottom-nav { display: none !important; }
          .app { grid-template-columns: 1fr !important; }
          .main { padding: 0 !important; --sticky-top: 0px !important; }
        `;
        this.shadowRoot.appendChild(style);
      } catch(e) { /* ignore */ }
    });

    // Measure actual available height — HA's toolbar offsets the panel
    // from the top of the viewport.  --header-height may not propagate
    // through shadow DOM, so measure directly and set on the app element.
    this._fitHeight = () => {
      try {
        const appEl = this.$("#app");
        if (appEl) {
          const rect = appEl.getBoundingClientRect();
          const avail = window.innerHeight - rect.top;
          if (avail > 100) appEl.style.height = avail + "px";
        }
      } catch(e) {}
    };
    requestAnimationFrame(() => this._fitHeight());
    // One listener: connectedCallback runs again on every sidebar re-entry
    // and watchdog rebuild, and each run added another that nothing removed.
    if(this._resizeHandler) window.removeEventListener("resize", this._resizeHandler);
    this._resizeHandler = () => this._fitHeight();
    window.addEventListener("resize", this._resizeHandler);

    this.$("#refresh").addEventListener("click", ()=>this._refreshAll(true));
    this.$("#autodiag").addEventListener("click", ()=>this._runAutoDiag(true));
    this.$("#toggleSide").addEventListener("click", ()=>this.$("#app").classList.toggle("mini"));
    this.$("#haSide").addEventListener("click", ()=>this._toggleHaSidebar());
    this._paintHaSide();
    for (const b of this.shadowRoot.querySelectorAll('button[data-status-dot]')) {
      b.addEventListener("click", () => this._openHealthFromDot());
    }
    this._paintStatusDot();

    // Mobile navigation wiring
    const _openDrawer = () => {
      this.$("#app").classList.add("mobile-open");
      this.$("#sideBackdrop").classList.add("active");
    };
    const _closeDrawer = () => {
      this.$("#app").classList.remove("mobile-open");
      this.$("#sideBackdrop").classList.remove("active");
    };
    this.$("#mobileBackBtn").addEventListener("click", () => {
      // Navigate back to HA dashboard — works in Companion App on iPhone
      if (window.history.length > 1) {
        window.history.back();
      } else {
        window.location.href = "/";
      }
    });
    this.$("#mobileMenuBtn").addEventListener("click", _openDrawer);
    this.$("#sidebarClose").addEventListener("click", _closeDrawer);
    this.$("#sideBackdrop").addEventListener("click", _closeDrawer);
    this._closeDrawer = _closeDrawer;

    // Mobile topbar pills mirror the desktop toggles
    this.$("#mobileDataPill").addEventListener("click", () => this._onDataModeClick());
    this.$("#mobileDataPill").addEventListener("keydown", (e) => { if(e.repeat && e.key === "Enter") e.preventDefault(); });
    this.$("#mobileModePill").addEventListener("click", () => {
      // Re-use the same complexity toggle logic
      this.$("#complexityToggle").click();
    });

    // ── User interaction tracking ──────────────────────────────────────────
    // Records the timestamp of the last user interaction on the content area.
    // _renderCurrentView(fromPoll=true) checks this and skips re-renders within
    // 3 seconds of interaction, preventing form inputs / scroll positions from
    // being destroyed while the user is actively working.
    //
    // "pointerdown" is the important one (2026-09-11: dragging on the
    // Lights map "works only sometimes, other times it brings me to the
    // list" mid-drag). This list used to be click/input/change/focusin/
    // scroll only — every one of those fires at the END of a gesture (a
    // "click" doesn't even fire for a real drag), so a press-and-hold or a
    // slow drag had NO protection for however long it took to complete: if
    // the 5s poll landed anywhere in that window, it tore down and rebuilt
    // the whole view mid-gesture, which forces a pointercancel on whatever
    // was being pressed. _editDragging (maps.js) covers a drag once it's
    // past its own 8px arm threshold, but nothing covered the gap from the
    // initial press to that point, or a long-press that never moves at
    // all — exactly the gap the reported flakiness lived in.
    const _markInteraction = () => { this._lastUserInteraction = performance.now(); };
    this.$content.addEventListener("pointerdown", _markInteraction, true);
    this.$content.addEventListener("input", _markInteraction, true);
    this.$content.addEventListener("change", _markInteraction, true);
    this.$content.addEventListener("click", _markInteraction, true);
    this.$content.addEventListener("focusin", _markInteraction, true);
    this.$content.addEventListener("scroll", _markInteraction, true);

    this.$("#dataModeToggle").addEventListener("click", () => this._onDataModeClick());
    this.$("#dataModeHelp").addEventListener("click", () => this._showHelp("data_mode"));
    this.$("#complexityHelp").addEventListener("click", () => this._showHelp("complexity_mode"));
    // A held Enter clicks a button once per key repeat: one press, one click
    // (see _onDataModeClick). Same on the mobile pill above.
    this.$("#dataModeToggle").addEventListener("keydown", (e) => { if(e.repeat && e.key === "Enter") e.preventDefault(); });

    // Restore persisted complexity preference (Basic/Advanced/Dev survives page reloads)
    try {
      const saved = localStorage.getItem("padspan_complexity");
      if (saved === "basic" || saved === "advanced" || saved === "development") this.state.complexity = saved;
    } catch(e) { /* ignore */ }

    // ── URL deep-link: ?view=<id> and ?kiosk=1 ──
    // /padspan-ha?view=purelive opens that view regardless of the browser's
    // complexity mode (wall monitors have fresh localStorage); kiosk=1 also
    // hides the panel chrome for a clean always-on display.
    try {
      const q = new URLSearchParams(window.location.search);
      const reqView = q.get("view");
      // Insights / Busy Times became Traceback modes and Locate a Follow option
      // (2026-09-23); an old ?view= link still lands on them.
      if (reqView === "insights" || reqView === "busytimes") {
        this.state._tracebackInitialMode = reqView;
        this.state.view = "traceback";
        this._urlPinnedView = "traceback";
      } else if (reqView === "locate") {        // Locate became a Follow option
        this.state._followLocateOn = true;
        this.state.view = "follow";
        this._urlPinnedView = "follow";
      } else if (reqView && _VIEW_PATHS[reqView]) {
        this.state.view = reqView;
        this._urlPinnedView = reqView;   // exempt from complexity-fallback
      }
      // ?tab=lights lands on a Mapping sub-tab; ?light=<entity_id> arrives
      // with that light selected — the Lights sidebar's pencil deep-links
      // here so "edit this light" is one tap from the map you are using.
      const reqTab = q.get("tab");
      if (reqView === "maps" && reqTab && /^[a-z]+$/.test(reqTab)) this.state.mapsTab = reqTab;
      // ?view=maps&guide=scan: the phone's walk-through of a room scan (views/rough_plan.js), for the person holding the phone.
      if (reqView === "maps" && q.get("guide") === "scan") this.state._roughPlan = { open: false, kind: null, across: "", down: "", busy: false, msg: "", walk: 0, linked: true };
      // ?view=calibration&tab=tune opens that Calibration tab (Results otherwise).
      if (reqView === "calibration" && reqTab && /^[a-z]+$/.test(reqTab)) this.state._calibTabRequest = reqTab;
      // ?view=settings&tab=atlas&part=atlas_weather (Live Aboard's ⋯ list):
      // that Settings tab, scrolled to the card marked data-focus-part.
      if (reqView === "settings" && reqTab && /^[a-z]+$/.test(reqTab)) this.state._settingsTab = reqTab;
      const reqPart = q.get("part");
      if (reqView === "settings" && reqPart && /^[a-z0-9_]+$/.test(reqPart)) this.state._settingsPart = reqPart;
      const reqLight = q.get("light");
      if (reqLight && /^(light|fan|binary_sensor|sensor)\.[a-z0-9_]+$/.test(reqLight)) {
        this.state.maps._selLight = { eid: reqLight, mapId: null };
        this.state.maps._focusRow = reqLight;
      }
      this.state.kioskMode = q.get("kiosk") === "1";
    } catch(e) { /* ignore */ }

    this.$("#complexityToggle").addEventListener("click", ()=>{
      const cur = this.state.complexity;
      this._setComplexity(cur === "basic" ? "advanced" : cur === "advanced" ? "development" : "basic");
    });

    this._renderNav();
    // Load persisted mode (sample/live) even before hass is set.
    // When hass arrives we refresh.
    this._loadSettings();
    // Once per page load, after the two idle minutes a full-screen window
    // needs to count as a wall (_screenReport).
    if (!this._screenTimer) this._screenTimer = setTimeout(() => this._screenReport(), Math.max(0, 150000 - (Date.now() - _PAGE_START)));

    // Always start keep-alive (activity ping + watchdog) regardless of data mode.
    this._startKeepAlive();

    // If views are already populated (reconnect after detach), render immediately.
    // Otherwise show a loading placeholder then render once dynamic imports settle.
    if(Object.keys(VIEWS).length > 0){
      this._scheduleRender();
      this._startPolling();
      // On reconnect (not first boot), refresh data to recover from stale state
      if(this._booted && this._hass){
        this._pollInFlight = false;
        this._refreshAll(false);
      }
    } else {
      // Show loading placeholder with progress — purely inline so it works with no CSS loaded yet
      if(this.$content){
        const lo = document.createElement("div");
        lo.style.cssText = "padding:40px;text-align:center;font-family:system-ui,sans-serif";
        lo.innerHTML = `<div style="margin-bottom:16px"><svg width="48" height="48" viewBox="0 0 48 48"><circle cx="24" cy="24" r="20" fill="none" stroke="#1b3526" stroke-width="4"/><circle cx="24" cy="24" r="20" fill="none" stroke="#52b788" stroke-width="4" stroke-linecap="round" stroke-dasharray="80 45"><animateTransform attributeName="transform" type="rotate" from="0 24 24" to="360 24 24" dur="1s" repeatCount="indefinite"/></circle></svg></div>`
          + `<div style="color:#52b788;font-size:16px;font-weight:700;margin-bottom:6px">PadSpan HA v${APP_VERSION}</div>`
          + `<div style="color:#64748b;font-size:12px" id="padspan-load-status">Loading modules\u2026</div>`;
        this.$content.appendChild(lo);
      }
      _criticalPromise.then(() => {
        _startDeferredLoads();
        const statusEl = this.$content?.querySelector("#padspan-load-status");
        if(statusEl) statusEl.textContent = "Connecting\u2026";
        this._renderNav();       // rebuild nav after complexity may have been restored
        this._scheduleRender();
        this._startPolling();
      });
    }
  }


  // ── The one-time ask for the usage report ───────────────────────────────
  // The switch has lived in Settings → Presence since 0.35.0 and nothing ever
  // pointed at it: every install that opted in was one whose owner was
  // already describing bugs on GitHub — the people the report needs least.
  // So it is asked for, ONCE, in the two places a person is actually
  // looking: inside the setup checklist for a new install, and as a card on
  // Overview for an install that finished setup before the switch existed.
  // Any answer sets telemetry_asked and the card never comes back; the
  // switch itself stays in Settings either way. Off until someone says yes.
  // ── What's new, once per version ────────────────────────────────────────
  // An update lands silently. Home Assistant's persistent notification is easy
  // to miss and easy to dismiss without reading, and the release notes live
  // somewhere the person is not. This says what happened where they already
  // are, once, and then never again for that version.
  //
  // It is SEEDED, not shown, the first time the panel sees an install: with no
  // stored version there is no way to tell a genuine update from a fresh
  // install, and telling somebody who just installed PadSpan that it "updated"
  // is worse than saying nothing. So the first sight records the version
  // quietly and the card appears only on a real change.
  _whatsNewCard(){
    const st = this.state.settings;
    if (!st || !("whatsnew_seen_version" in st)) return null;
    const seen = String(st.whatsnew_seen_version || "");
    if (seen === APP_VERSION) return null;

    const remember = (toast) => {
      this._callWS({ type: "padspan_ha/settings_set", whatsnew_seen_version: APP_VERSION })
        .then(res => { if (res && res.settings) this.state.settings = res.settings; })
        .catch(() => {})
        .finally(() => { if (toast) this._toast(toast); this._scheduleRender(); });
    };

    if (!seen) { remember(null); return null; }   // first sight: record, show nothing

    const card = el("div", { style: "background:#0a1f14;border:1px solid #1a4228;border-radius:8px;padding:10px 14px;margin-bottom:12px" });
    card.appendChild(el("div", { style: "font-weight:700;font-size:13px;color:#52b788;margin-bottom:4px" },
      `PadSpan HA updated to v${APP_VERSION}`));
    card.appendChild(el("div", { style: "font-size:12px;color:#cbd5e1;line-height:1.55;margin-bottom:8px" },
      // `seen` is the last version somebody here opened or dismissed this card
      // for, not necessarily the one installed before (issue #94): an update
      // nobody looked at leaves it behind. The notes cover everything since.
      `The last update anyone here looked at was v${seen}. The release notes cover everything since then, and why, in plain terms.`));

    // The paid half, once per version, and only to someone it could be news to.
    // The rule lives in editions.js next to the tier vocabulary and is pure, so
    // it is tested without a browser; if editions failed to load there is simply
    // no pitch, which is the right way to fail.
    // The import above is deliberately allowed to fail, and this call site has
    // to honour that same contract: editions.js is optional, so neither its
    // absence NOR a throw inside it may cost the reader the Overview tab.
    // One offer per banner: when the trial line below will show, it is the
    // offer, and the older Pro pitch steps aside (two sales lines in a "what
    // changed" note reads as nagging). The trial line is news once — only in
    // the banner for the update that brought it (trialNewsDue) — so every
    // later banner has the Pro pitch exactly as before.
    let trialLine = false;
    try {
      trialLine = !!(TRIAL && (this.state._bannerTrialOpen || TRIAL.trialNewsDue(st, seen, this.state.kioskMode)));
    } catch (_) { trialLine = false; }
    let pitch = null;
    try { if (!trialLine && EDITIONS && EDITIONS.proPitch) pitch = EDITIONS.proPitch(st); }
    catch (e) { console.warn("PadSpan: proPitch failed", e); }
    if (pitch) {
      const line = el("div", { style: "font-size:12px;color:#94a3b8;line-height:1.55;margin-bottom:8px" });
      line.appendChild(document.createTextNode(pitch.text));
      // A wall screen (kiosk / full screen) can't close the tab a link
      // opens, so there it names the site instead of linking to it.
      let tabOk = true;
      try { tabOk = !TRIAL || !TRIAL.newTabOk || TRIAL.newTabOk(this.state.kioskMode); } catch (_) { tabOk = true; }
      line.appendChild(tabOk
        ? el("a", { href: pitch.url, target: "_blank", rel: "noopener",
            style: "color:#52b788;font-weight:600;text-decoration:none" }, pitch.cta)
        : el("span", { style: "color:#52b788;font-weight:600" }, `${pitch.cta} (padspan.traks.ca)`));
      card.appendChild(line);
    }

    // The 90-day trial (views/trial_offer.js): one line, in the one banner
    // trialNewsDue picks (the update from before the trial, no key, below
    // bright, not answered, not a kiosk). It is part of this banner, and
    // dismissing the banner dismisses it. "Try it" opens the shared card
    // inline; after a start it stays open to say it worked. Optional like
    // editions: a missing or throwing trial module costs this line, never
    // the banner.
    try {
      const open = !!this.state._bannerTrialOpen;
      if (trialLine) {
        const row = el("div", { "data-trial-line": "update_banner",
          style: "display:flex;align-items:center;gap:8px;flex-wrap:wrap;font-size:12px;color:#8ee5b4;line-height:1.55;margin-bottom:8px" });
        row.appendChild(el("span", {}, TRIAL.TRIAL_NEWS_LINE + " "));
        row.appendChild(el("span", { style: "color:#94a3b8" }, TRIAL.TRIAL_HONESTY));
        const tryIt = el("button", { class: "btn inline", "data-trial-open": "update_banner",
          style: "font-size:11px;padding:2px 8px;border-color:#52b788;color:#52b788" }, open ? "Hide" : "Try it");
        tryIt.addEventListener("click", () => { this.state._bannerTrialOpen = !open; this._scheduleRender(); });
        row.appendChild(tryIt);
        card.appendChild(row);
        TRIAL.trialOfferSeen("update_banner", (n) => this._telemetryEvent(n));
        if (open) {
          const offer = TRIAL.trialOfferFromCtx(this._ctx(), "update_banner", { honesty: false });
          if (offer) card.appendChild(offer);
        }
      }
    } catch (e) { console.warn("PadSpan: trial line failed", e); }

    // The notes open over the panel (_openReleaseNotes). This was a link to
    // padspan.traks.ca in a new tab, and a wall screen (Chrome --kiosk, touch
    // only) has no way to close one: the screen was stuck on the website.
    const notes = el("button", { class: "btn inline", "data-whatsnew-notes": "open",
      style: "background:#0a2a1a;border-color:#52b788;color:#52b788;font-weight:700" },
      "See what changed");
    notes.addEventListener("click", () => { remember(null); this._openReleaseNotes(); });
    const dismiss = el("button", { class: "btn inline", style: "color:#94a3b8" }, "Dismiss");
    dismiss.addEventListener("click", () => remember(`Hidden until the next update.`));
    card.appendChild(el("div", { style: "display:flex;gap:8px;flex-wrap:wrap" }, [notes, dismiss]));
    return card;
  }

  // ── Release notes, over the panel ───────────────────────────────────────
  // views/release_notes.js shows assets/whatsnew.json (written from
  // CHANGELOG.md by release.py, shipped with the integration) in #modal, so
  // the notes work offline and close with ✕, Close, a tap outside or Escape.
  // Loaded on first use; if it can't load, a toast says so.
  _openReleaseNotes(){
    // Read at call time, not import time: editions.js is allowed to fail.
    // The literal is the same URL release.py writes into the update manifest.
    const historyUrl = (EDITIONS && EDITIONS.WHATSNEW_URL) || "https://padspan.traks.ca/?hl=en#whatsnew";
    import(`./views/release_notes.js?b=${BUILD_ID}`)
      .then(m => m.openReleaseNotes(this.$modal, {
        url: `/padspan_ha_static/padspan-ha/assets/whatsnew.json?v=${APP_VERSION}&b=${BUILD_ID}`,
        history: m.notesHistoryLink(historyUrl, this.state.kioskMode),
      }))
      .catch(err => {
        console.warn("PadSpan: release notes failed to open", err);
        this._toast("The release notes couldn't be opened. Refresh the page and try again.", true);
      });
  }

  // ── Free Pro: the invite and the tester card (views/pro_invite.js) ─────
  // The trial milestone's rules: an administrator, live data, no kiosk, and
  // one Overview card per page load (the caller, _overviewCardShown). The
  // invite stays until it is answered ("Later" puts it off for a week in
  // this browser). The tester card shows once per install and takes the
  // trial milestone's place: both flags are saved the moment it shows.
  _proOffersAllowed(){
    if (!PRO_INVITE || !this.state.settings || this.state.kioskMode) return false;
    if (!this.state._dataModeKnown || this.state.dataMode !== "live") return false;
    return !!(this._hass && this._hass.user && this._hass.user.is_admin);
  }

  // ── Accuracy tips (setup_checks.py, 0.38.193) ─────────────────────────
  // The opt-in reports found most multi-floor homes skip three setup steps:
  // every floor at the default height, every receiver at one height, no plan
  // with a real-world scale. Once setup is done or skipped, the Overview says
  // so in one small card, to an administrator, never on a wall screen; the
  // server decides which apply (padspan_ha/setup_tips, the report's own
  // rules), each line goes to its fix or is hidden, and the card can go for good.
  _accuracyTipsCard(){
    if (!this.state.settings || this.state.kioskMode || wallScreen(false)) return null;
    if (!this.state._dataModeKnown || this.state.dataMode !== "live") return null;
    if (!(this._hass && this._hass.user && this._hass.user.is_admin)) return null;
    const hidden = new Set(this.state.settings.accuracy_tips_hidden || []);
    if (hidden.has("all")) return null;
    const T = this._tips || (this._tips = { at: 0, list: null, busy: false, shown: new Set() });
    if (!T.busy && Date.now() - T.at > 600000) {
      T.busy = true;
      this._callWS({ type: "padspan_ha/setup_tips" })
        .then(r => { T.list = Array.isArray(r && r.tips) ? r.tips : []; T.shape = Array.isArray(r && r.plan_shape) ? r.plan_shape : []; })
        .catch(() => { T.list = T.list || []; })
        .finally(() => { T.at = Date.now(); T.busy = false; this._scheduleRender(); });
    }
    const WORDS = {
      floor_heights: ["Give your floors their real heights",
        "Every floor is at the default height, so PadSpan tells floors apart less well than it could.", "Floor Heights"],
      receiver_heights: ["Say how high each receiver is mounted",
        "They're all at one height, which makes it harder to tell which floor someone is on.", "Receiver heights"],
      scale: ["Measure one distance on a floor plan",
        "With no real-world scale, positions and distances on the map are guesses.", "Measure"],
    };
    // A plan placed out of shape (setup_checks.plans_out_of_shape): named, with how far off, and Measure on that plan.
    const shape = (T.shape || [])[0];
    if (shape) {
      const more = T.shape.length - 1, pct = Math.abs(shape.off);
      WORDS.plan_shape = [`Check the shape of "${shape.name}"` + (more > 0 ? ` and ${more} more` : ""),
        `It is placed ${pct}% ${shape.off < 0 ? "narrower" : "wider"} than its picture, so rooms and receivers on it can be off. Measure a distance each way on it.`, "Measure"];
    }
    const tips = (T.list || []).filter(t => WORDS[t] && !hidden.has(t));
    if (!tips.length) return null;
    const save = (list) => {
      if (this.state.settings) this.state.settings.accuracy_tips_hidden = list;
      this._callWS({ type: "padspan_ha/settings_set", accuracy_tips_hidden: list })
        .then(res => { if (res && res.settings) this.state.settings = res.settings; }).catch(() => {});
      this._scheduleRender();
    };
    const go = (t) => {
      this._telemetryEvent("tip_opened:" + t);
      if (t === "plan_shape") {
        this.state.view = "maps";
        this.state._mapsWizard = { step: 2, mapId: shape.id };
      } else if (t === "scale") {
        const maps = (this.state.maps && this.state.maps.list) || [];
        const id = (this.state.activeMapId && maps.some(m => m.id === this.state.activeMapId)) ? this.state.activeMapId : ((maps[0] && maps[0].id) || null);
        this.state.view = "maps";
        this.state._mapsWizard = { step: 2, mapId: id };
      } else if (t === "floor_heights") {
        // Mapping → 3D Stack's Floor Heights; in Basic only that card, with
        // a way back here (views/focus.js). Advanced: the whole tab.
        _focusPromise.then(F => {
          if (F) { F.openFocus(this._ctx(), F.part("floorHeights")); return; }
          this.state.view = "maps"; this.state.mapsTab = "stack"; this._renderNav(); this._scheduleRender();
        });
        return;
      } else {
        this.state.view = "calibration";
        this.state._calibTabRequest = "tune";
      }
      this._renderNav();
      if (!VIEWS[this.state.view] && _VIEW_PATHS[this.state.view]) _loadView(this.state.view).then(() => this._scheduleRender());
      if (this.actions?.renderRooms) this.actions.renderRooms(); else this._scheduleRender();
    };
    const card = el("div", { "data-accuracy-tips": "card", style: "background:#0a1f14;border:1px solid #1a4228;border-radius:8px;padding:8px 12px;margin-bottom:12px" });
    const hdr = el("div", { style: "display:flex;align-items:center;justify-content:space-between;margin-bottom:4px" });
    hdr.appendChild(el("div", { style: "font-weight:700;font-size:12px;color:#52b788" }, "Improve accuracy"));
    const off = el("span", { "data-accuracy-tips": "off", style: "cursor:pointer;font-size:10px;color:#64748b;text-decoration:underline" }, "Hide these tips");
    off.addEventListener("click", () => { this._telemetryEvent("tip_hidden:all"); save([...hidden, "all"]); });
    hdr.appendChild(off);
    card.appendChild(hdr);
    for (const t of tips) {
      if (!T.shown.has(t)) { T.shown.add(t); this._telemetryEvent("tip_shown:" + t); }
      const [title, why, btnText] = WORDS[t];
      const row = el("div", { "data-accuracy-tips": "tip-" + t, style: "display:flex;align-items:center;gap:8px;padding:4px 0;font-size:12px;border-top:1px solid #12301f" });
      row.appendChild(el("div", { style: "flex:1;min-width:0" }, [
        el("span", { style: "color:#e2e8f0;font-weight:600" }, title + ". "),
        el("span", { style: "color:#94a3b8" }, why),
      ]));
      const fix = el("button", { class: "btn inline", style: "font-size:11px;padding:2px 10px", title: "Go there" }, btnText);
      fix.addEventListener("click", () => go(t));
      const x = el("span", { style: "cursor:pointer;color:#64748b;font-size:13px;padding:0 4px", title: "Hide this tip", "aria-label": "Hide this tip", role: "button" }, "\u00d7");
      x.addEventListener("click", () => { this._telemetryEvent("tip_hidden:" + t); save([...hidden, t]); });
      row.appendChild(fix);
      row.appendChild(x);
      card.appendChild(row);
    }
    return card;
  }

  _proInviteOverviewCard(){
    if (!this._proOffersAllowed()) return null;
    const v = this._proInviteView || (this._proInviteView = { visible: false, hidden: false });
    if (v.hidden) return null;
    if (!v.visible) {
      if (this._overviewCardShown || !PRO_INVITE.inviteDue(this.state.settings)) return null;
      v.visible = true;
      this._overviewCardShown = true;   // it holds the slot for this page load
    }
    const host = PRO_INVITE.inviteHostFromCtx(this._ctx());
    host.rerender = () => this._scheduleRender();
    host.telemetry = (n) => this._telemetryEvent(n);
    return PRO_INVITE.inviteCard(host, {
      onLater: () => { PRO_INVITE.inviteLater(); v.hidden = true; this._scheduleRender(); },
      onDeclined: () => { v.hidden = true; },
      onClose: () => { v.hidden = true; this._scheduleRender(); },
    });
  }

  _testerOverviewCard(positioned){
    if (!this._proOffersAllowed()) return null;
    const st = this.state.settings;
    const v = this._testerView || (this._testerView = { visible: false, hidden: false, saved: false });
    if (v.hidden) return null;
    if (!v.visible) {
      if (this._overviewCardShown || !PRO_INVITE.testerCardDue(st, positioned)) return null;
      v.visible = true;
      this._overviewCardShown = true;
    }
    if (!v.saved) {
      v.saved = true;
      this._callWS({ type: "padspan_ha/settings_set", tester_nudge_done: true, trial_nudge_done: true })
        .then(res => { if (res && res.settings) this.state.settings = res.settings; })
        .catch(() => {});
    }
    const hide = () => { v.hidden = true; this._scheduleRender(); };
    return PRO_INVITE.testerCard({ el, settings: st, telemetry: (n) => this._telemetryEvent(n) }, {
      onClose: hide,
      onNo: hide,
      onSignUp: () => { v.hidden = true; this._openTesterSignup(); },
    });
  }

  // Settings → Tracking, where the report switch and the tester sign-up are;
  // the sign-up opens itself there (tester_signup.js, state._testerFocus).
  // In Basic just the report's card, with a way back (views/focus.js).
  _openTesterSignup(){
    this.state._testerScrolled = null;
    this.state._testerFocus = true;
    _focusPromise.then(F => {
      if (F) { F.openFocus(this._ctx(), F.part("usageReport")); return; }
      this.state.view = "settings";
      this.state._settingsTab = "presence";
      this._renderNav();
      if (!VIEWS.settings && _VIEW_PATHS.settings) _loadView("settings").then(() => this._scheduleRender());
      this._scheduleRender();
    });
  }

  // ── The trial's milestone card, once per install ─────────────────────────
  // A free install that never meets a paid wall never meets the trial either.
  // This tells it once, at a moment the free product has just proved itself:
  // the first time someone real is on the map in live data (Getting started's
  // own "positioned" rule, passed in), or after a week of PadSpan running here
  // (first_seen_ts — an install from before that key is stamped on its first
  // load of this version, so its week counts from the update).
  //
  // ONCE means once: the per-install flag (trial_nudge_done) is saved the
  // moment the card first appears, so a reload never brings it back whether
  // or not anyone answered; "No thanks" / ✕ just take it away for this page.
  // For that reason it is shown only to an administrator — the one person who
  // can start the trial — and never on a kiosk or in sample mode. Never
  // beside the Getting started card or another Overview card (the caller).
  // Let Claude draw your rooms (views/ai_wizard_offer.js): the Overview's own
  // card when Getting started isn't showing, one card at a time.
  _aiWizardOverviewCard(){
    if (!AIW || this.state.kioskMode) return null;
    if (!this._aiwCardVisible && this._overviewCardShown) return null;   // another card has this page load
    let card = null;
    try { card = AIW.overviewCard(this._ctx()); } catch(e) { card = null; }
    if (card) { this._aiwCardVisible = true; this._overviewCardShown = true; }
    return card;
  }

  // ── The launch price's card, once per install ───────────────────────────
  // Pro for life is $89 until November 30, then $168 (editions.js: one date).
  // One card says so, with where to buy, the way the trial's milestone card
  // works: to an administrator (the one who buys), in live data, never on a
  // wall; once means once (launch_card_done is saved the moment it first
  // shows, so a reload never brings it back); No thanks only takes it away
  // for this page. It goes by itself when the launch price ends.
  _launchPriceCard(){
    const st = this.state.settings;
    if (!EDITIONS || typeof EDITIONS.launchCardDue !== "function" || !st || this.state.kioskMode) return null;
    if (!this.state._dataModeKnown || this.state.dataMode !== "live") return null;
    if (!(this._hass && this._hass.user && this._hass.user.is_admin)) return null;
    const v = this._launchCard || (this._launchCard = { visible: false, hidden: false, saved: false });
    if (v.hidden || !EDITIONS.proLifetimeLaunch()) return null;
    if (!v.visible) {
      if (this._overviewCardShown || !EDITIONS.launchCardDue(st)) return null;
      v.visible = true;
      this._overviewCardShown = true;   // one card per page load
    }
    if (!v.saved) {
      v.saved = true;
      this._callWS({ type: "padspan_ha/settings_set", launch_card_done: true })
        .then(res => { if (res && res.settings) this.state.settings = res.settings; })
        .catch(() => {});
    }
    const card = el("div", { "data-launch-card": "card",
      style: "background:#0a1f14;border:1px solid #1a4228;border-radius:8px;padding:10px 14px;margin-bottom:12px" });
    card.appendChild(el("div", { style: "font-weight:700;font-size:13px;color:#52b788;margin-bottom:4px" }, EDITIONS.LAUNCH_CARD_TITLE));
    const annual = typeof EDITIONS.launchCardAnnual === "function" && EDITIONS.launchCardAnnual(st);
    card.appendChild(el("div", { style: "font-size:12px;color:#cbd5e1;line-height:1.55;margin-bottom:8px" },
      "PadSpan Pro for life is " + EDITIONS.proLifetimeWords() + "."
      + (annual ? " Pay with the email your key was sent to and this key becomes Pro for life." : "")));
    // A page that fills the screen can't close the tab a link opens: say where instead.
    let tabOk = true;
    try { tabOk = !TRIAL || !TRIAL.newTabOk || TRIAL.newTabOk(this.state.kioskMode); } catch (_) { tabOk = true; }
    const buy = tabOk
      ? el("a", { class: "btn inline", "data-launch-card": "buy", href: EDITIONS.BUY_URL, target: "_blank", rel: "noopener",
          style: "background:#0a2a1a;border-color:#52b788;color:#52b788;font-weight:700;text-decoration:none" }, "Buy at padspan.traks.ca")
      : el("span", { "data-launch-card": "buy-text", style: "font-size:12px;color:#52b788;font-weight:600;align-self:center" }, "At padspan.traks.ca");
    const no = el("button", { class: "btn inline", "data-launch-card": "no", style: "color:#94a3b8" }, "No thanks");
    no.addEventListener("click", () => { v.hidden = true; this._scheduleRender(); });
    card.appendChild(el("div", { style: "display:flex;gap:8px;flex-wrap:wrap" }, [buy, no]));
    return card;
  }

  _trialMilestoneCard(positioned){
    const st = this.state.settings;
    if (!TRIAL || !st || this.state.kioskMode) return null;
    if (!this.state._dataModeKnown || this.state.dataMode !== "live") return null;
    if (!(this._hass && this._hass.user && this._hass.user.is_admin)) return null;
    const m = this._trialMilestone || (this._trialMilestone = { visible: false, hidden: false, open: false, saved: false });
    if (m.hidden) return null;
    if (!m.visible) {
      // One offer per page load: after the update banner, the usage-report
      // ask or Getting started showed on this load, the card waits for the
      // next one rather than following them onto the screen (_overviewCardShown).
      if (this._overviewCardShown) return null;
      if (!TRIAL.trialMilestoneDue(st, positioned)) return null;
      m.visible = true;
      this._overviewCardShown = true;   // so a Pro card cannot take its place this load
    }
    // A key that arrives from elsewhere (Settings) takes the card away; a
    // trial started from it keeps it open to say so.
    if (!m.open && !TRIAL.trialOfferable(st)) return null;
    const markDone = () => {
      this._callWS({ type: "padspan_ha/settings_set", trial_nudge_done: true })
        .then(res => { if (res && res.settings) this.state.settings = res.settings; })
        .catch(() => {});
    };
    if (!m.saved) { m.saved = true; markDone(); }
    TRIAL.trialOfferSeen("milestone", (n) => this._telemetryEvent(n));
    const hide = () => {
      m.hidden = true;
      // ✕ after a trial was started here closes a "started" note: nothing
      // was dismissed, and the flag was saved when the card first showed.
      if (!TRIAL.trialStartedHere("milestone")) {
        this._telemetryEvent("trial_nudge_dismissed");
        markDone();
      }
      this._scheduleRender();
    };

    const card = el("div", { "data-trial-milestone": "card",
      style: "background:#0a1f14;border:1px solid #1a4228;border-radius:8px;padding:10px 14px;margin-bottom:12px" });
    const close = el("button", { class: "btn inline", "data-trial-milestone": "close", title: "Hide this",
      style: "margin-left:auto;font-size:12px;padding:0 8px;color:#94a3b8" }, "✕");
    close.addEventListener("click", hide);
    card.appendChild(el("div", { style: "display:flex;align-items:center;gap:8px;margin-bottom:4px" }, [
      el("div", { style: "font-weight:700;font-size:13px;color:#52b788" }, TRIAL.TRIAL_MILESTONE_TITLE), close]));
    card.appendChild(el("div", { style: "font-size:12px;color:#cbd5e1;line-height:1.55" }, TRIAL.TRIAL_MILESTONE_BODY));
    card.appendChild(el("div", { style: "font-size:12px;color:#94a3b8;line-height:1.55;margin-bottom:8px" }, TRIAL.TRIAL_HONESTY));
    if (m.open) {
      const offer = TRIAL.trialOfferFromCtx(this._ctx(), "milestone", { honesty: false });
      if (offer) card.appendChild(offer);
    } else {
      const tryIt = el("button", { class: "btn inline", "data-trial-milestone": "try",
        style: "background:#0a2a1a;border-color:#52b788;color:#52b788;font-weight:700" }, "Try it");
      tryIt.addEventListener("click", () => { m.open = true; this._scheduleRender(); });
      const no = el("button", { class: "btn inline", "data-trial-milestone": "no", style: "color:#94a3b8" }, "No thanks");
      no.addEventListener("click", hide);
      card.appendChild(el("div", { style: "display:flex;gap:8px;flex-wrap:wrap" }, [tryIt, no]));
    }
    return card;
  }

  // ── The trial's quiet sidebar entry ──────────────────────────────────────
  // Muted text under the PadSpan menu while the install could be offered the
  // trial (no key, below bright); a tap opens the shared card right there.
  // No badge, no count, no animation. It is the one placement a Bright build
  // keeps (its Overview does not exist). Administrators only (the one person
  // who can start it), and gone once the milestone card has been SHOWN
  // (trial_nudge_done is saved when it first appears, answered or not): the
  // offer has been made once, and that is enough. Built by _renderNav; the
  // trial module may land after the first nav, so that waits for it once.
  _renderSidebarTrial(){
    const box = this.$ && this.$("#navTrial");
    if (!box) return;
    box.innerHTML = "";
    if (!TRIAL) {
      if (!this._sidebarTrialWaiting) {
        this._sidebarTrialWaiting = true;
        _trialPromise.then(() => { if (TRIAL) this._renderSidebarTrial(); });
      }
      return;
    }
    try {
      const open = !!this._sidebarTrialOpen;
      const st = this.state.settings;
      const admin = !!(this._hass && this._hass.user && this._hass.user.is_admin);
      if (!open && (!admin || (st && st.trial_nudge_done === true) || !TRIAL.trialOfferable(st))) return;
      // #8391a7: still quieter than the menu above it, but readable — at
      // least 5:1 on either skin's sidebar (#64748b was 3.9:1).
      const link = el("div", { "data-trial-sidebar": "entry", role: "button", tabindex: "0",
        style: "cursor:pointer;font-size:11px;color:#8391a7;padding:4px 8px" }, TRIAL.TRIAL_SIDEBAR_LABEL);
      const toggle = () => { this._sidebarTrialOpen = !open; this._renderSidebarTrial(); };
      link.addEventListener("click", toggle);
      link.addEventListener("keydown", (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); toggle(); } });
      box.appendChild(link);
      if (open) {
        const host = TRIAL.trialHostFromCtx(this._ctx());
        host.rerender = () => this._renderSidebarTrial();
        const offer = TRIAL.trialOfferCard(host, "sidebar");
        if (offer) box.appendChild(offer);
      }
    } catch (e) { console.warn("PadSpan: sidebar trial entry failed", e); }
  }

  _telemetryAskCard(compact){
    const st = this.state.settings;
    const cardStyle = compact
      ? "margin-top:8px;padding:8px 10px;border-top:1px solid #1a4228"
      : "background:#0a1f14;border:1px solid #1a4228;border-radius:8px;padding:10px 14px;margin-bottom:12px";
    // One optional question, once per install: where they heard about
    // PadSpan. The backend makes it due when the report is turned on (this
    // card, Settings, a trial's tick box) or a free licence starts (trial,
    // tester, free year): telemetry.heard_ask_due. An answer or Skip ends it
    // for good; the same choice stays in Settings → Tracking beside the
    // switch. Not on a wall screen, and only for someone who can answer. The
    // words are telemetry.HEARD_WORDS (tests/test_telemetry.py holds them equal).
    if (st && st.telemetry_enabled && st.telemetry_heard_ask === "due" && !st.telemetry_heard) {
      if (this.state.kioskMode || !(this._hass && this._hass.user && this._hass.user.is_admin)) return null;
      const done = async (word) => {
        try {
          const res = await this._callWS(Object.assign({ type: "padspan_ha/settings_set" },
            word ? { telemetry_heard: word } : { telemetry_heard_ask: "done" }));
          this.state.settings = res?.settings || this.state.settings;
          if (word) this._toast("Thank you.");
        } catch(e) { this._toast("Failed to save setting", true); }
        this._scheduleRender();
      };
      const q = el("div", { "data-heard-ask": "1", style: cardStyle });
      q.appendChild(el("div", { style: "font-weight:700;font-size:13px;color:#52b788;margin-bottom:4px" }, "Thank you. One optional question"));
      q.appendChild(el("div", { style: "font-size:12px;color:#cbd5e1;line-height:1.55;margin-bottom:8px" },
        "Where did you hear about PadSpan? One tap, and it goes with the report as one word. Skip it if you'd rather not say."));
      const row = el("div", { style: "display:flex;gap:6px;flex-wrap:wrap" });
      for (const [word, label] of [["reddit", "Reddit"], ["youtube", "YouTube"], ["ha_forum", "Home Assistant forum"], ["forum", "Another forum"],
                                   ["marketplace", "Marketplace or HACS"], ["github", "GitHub"], ["discord", "Discord"], ["search", "A web search"],
                                   ["friend", "A friend"], ["other", "Somewhere else"]]) {
        const b = el("button", { class: "btn inline", "data-heard": word }, label);
        b.addEventListener("click", () => done(word));
        row.appendChild(b);
      }
      const skip = el("button", { class: "btn inline", "data-heard-skip": "1", style: "color:#94a3b8" }, "Skip");
      skip.addEventListener("click", () => done(""));
      row.appendChild(skip);
      q.appendChild(row);
      return q;
    }
    // Settings not loaded yet ({} at start) is not "never asked": no flash of
    // the question before the answer arrives.
    if (!st || !("telemetry_enabled" in st) || st.telemetry_enabled || st.telemetry_asked) return null;
    const decide = async (on) => {
      try {
        // Straight to the wire: `this.actions` is never assigned on the
        // element (the onboarding block above optional-chains it, which
        // means its "Skip setup" save is a silent no-op — not touched here).
        const res = await this._callWS(Object.assign({ type: "padspan_ha/settings_set" },
          on ? { telemetry_enabled: true, telemetry_asked: true } : { telemetry_asked: true }));
        this.state.settings = res?.settings || this.state.settings;
        this._toast(on ? "Thank you — usage report on. Settings → Tracking shows exactly what goes." : "Okay — it stays off. Settings → Tracking if you change your mind.");
      } catch(e) { this._toast("Failed to save setting", true); }
      this._scheduleRender();
    };
    const card = el("div", { style: cardStyle });
    card.appendChild(el("div", { style: "font-weight:700;font-size:13px;color:#52b788;margin-bottom:4px" }, "Help improve PadSpan"));
    card.appendChild(el("div", { style: "font-size:12px;color:#cbd5e1;line-height:1.55;margin-bottom:8px" },
      "PadSpan is bleeding edge. Metre-level BLE positioning in an ordinary house is not a solved problem, and this one is developed against exactly one house. " +
      "It needs all the help it can find, and the biggest help is being able to see what other houses look like. " +
      "Opt in and once a day it sends counts only: scanners, floors, rooms, calibration points, which features are on, whether positioning and identity resolution are actually working, how hard the machine works and what class of machine it is, and how many warnings each part logged. " +
      "Never addresses, keys, names, coordinates or timestamps. Off until you say yes, and Settings → Tracking turns it off again any time. " +
      "Now and then the developer invites houses that report to try something, like a free year of Pro. You can say no."));
    const out = el("pre", { class: "pre", style: "display:none;margin:0 0 8px;max-height:260px;overflow:auto;font-size:11px" });
    const yes = el("button", { class: "btn inline", "data-ask": "yes", style: "background:#0a2a1a;border-color:#52b788;color:#52b788;font-weight:700" }, "Share usage report");
    yes.addEventListener("click", () => decide(true));
    const prev = el("button", { class: "btn inline" }, "Preview what would be sent");
    prev.addEventListener("click", async () => {
      prev.disabled = true;
      try {
        const r = await this._callWS({ type: "padspan_ha/telemetry_preview" });
        out.textContent = JSON.stringify(r.payload, null, 2);
        out.style.display = "block";
      } catch(e) { this._toast("Preview failed: " + (e.message || e), true); }
      prev.disabled = false;
    });
    const no = el("button", { class: "btn inline", "data-ask": "no", style: "color:#94a3b8" }, "No thanks");
    no.addEventListener("click", () => decide(false));
    card.appendChild(out);
    card.appendChild(el("div", { style: "display:flex;gap:8px;flex-wrap:wrap" }, [yes, prev, no]));
    return card;
  }

  // ── disconnectedCallback ────────────────────────────────────────────────────
  // Called when HA removes the element from the DOM (e.g. user navigates away).
  // Full cleanup: clear ALL timers and event listeners to prevent zombie timers
  // if HA creates a new element instance. connectedCallback will recreate them.
  disconnectedCallback(){
    this._stopDataPoll();
    this._stopClientPerf();
    this._pollInFlight = false;
    if(this._reconnectsStop) this._reconnectsStop();
    this._reconnectsStop = null; this._reconnectsConn = null;
    if(this._activityTimer){ clearInterval(this._activityTimer); this._activityTimer = null; }
    if(this._watchdogTimer){ clearInterval(this._watchdogTimer); this._watchdogTimer = null; }
    if(this._visibilityHandler){
      document.removeEventListener("visibilitychange", this._visibilityHandler);
      this._visibilityHandler = null;
    }
    if(this._focusHandler){
      window.removeEventListener("focus", this._focusHandler);
      this._focusHandler = null;
    }
    if(this._pageshowHandler){
      window.removeEventListener("pageshow", this._pageshowHandler);
      this._pageshowHandler = null;
    }
    if(this._haLocationHandler){
      window.removeEventListener("location-changed", this._haLocationHandler);
      this._haLocationHandler = null;
    }
    if(this._uiErrorHandler){
      window.removeEventListener("error", this._uiErrorHandler);
      this._uiErrorHandler = null;
    }
    if(this._uiRejectionHandler){
      window.removeEventListener("unhandledrejection", this._uiRejectionHandler);
      this._uiRejectionHandler = null;
    }
    if(this._interactionHandler){
      this.removeEventListener("pointerdown", this._interactionHandler);
      this._interactionHandler = null;
    }
    if(this._modalEsc){
      window.removeEventListener("keydown", this._modalEsc);
      this._modalEsc = null;
    }
    if(this._resizeHandler){
      window.removeEventListener("resize", this._resizeHandler);
      this._resizeHandler = null;
    }
  }

  // ── Anti-blank system ─────────────────────────────────────────────────────
  // Four independent mechanisms prevent the panel from going blank:
  // 1. Activity ping — synthetic pointer events keep HA's idle overlay away
  // 2. Watchdog — detects empty/stale content and forces a full rebuild
  // 3. Visibility handler — immediate recovery when tab regains focus
  // 4. hass reconnect detection — re-bootstraps on WS connection change

  _ensureShadowDom(){
    // Verify shadowRoot has the expected structure. If not, rebuild entirely.
    if(!this.shadowRoot) return false;
    const liveContent = this.shadowRoot.querySelector("#content");
    if(!liveContent || !this.shadowRoot.querySelector("#app")){
      // Shadow DOM was cleared externally — full rebuild
      this.connectedCallback();
      return true;
    }
    // Fix stale references: this.$content might point at a detached node
    if(this.$content !== liveContent){
      this.$ = (q)=>this.shadowRoot.querySelector(q);
      this.$content = liveContent;
      this.$nav = this.$("#nav");
      this.$modal = this.$("#modal");
      return true;
    }
    return false;
  }

  _startKeepAlive(){
    // ── Activity ping (30s) ─────────────────────────────────────────────────
    // Synthetic pointer events keep HA's idle overlay away. Dispatches on
    // document, window, AND the HA root element with both trusted event types.
    if(!this._activityTimer){
      const ping = ()=>{
        try {
          for(const EvType of [PointerEvent, MouseEvent]){
            for(const name of ["pointermove","mousemove"]){
              try {
                const ev = new EvType(name, {bubbles:true, composed:true, cancelable:true});
                document.dispatchEvent(ev);
                window.dispatchEvent(ev);
              } catch(e){}
            }
          }
          const haRoot = document.querySelector("home-assistant");
          if(haRoot) haRoot.dispatchEvent(new Event("mousemove", {bubbles:true}));
        } catch(e){}
      };
      ping();
      this._activityTimer = setInterval(ping, 25_000);
    }

    // ── Watchdog (8s) ───────────────────────────────────────────────────────
    // Checks DOM integrity, content visibility, stuck polls, and poll liveness.
    // This is the last line of defense against blank screens.
    if(!this._watchdogTimer){
      this._watchdogTimer = setInterval(()=>{
        try {
          if(!this.isConnected) return;

          // 0. Floor-plan links, every 10 minutes. Here and not in the data
          // poll because this timer runs in sample mode too, which shows real
          // maps. Timed from the last attempt as well, so a failing re-read
          // waits its 10 minutes instead of retrying every tick.
          if(this._hass && this._mapUrlsAt && !this._mapUrlsBusy
             && Date.now() - Math.max(this._mapUrlsAt, this._mapUrlsTry || 0) > 600000){
            this._mapUrlsBusy = true;
            this._mapUrlsTry = Date.now();
            this._renewMapImageUrls().catch(() => {}).finally(() => { this._mapUrlsBusy = false; });
          }

          // 1. Stale shadow DOM references — fix before anything else
          const rebuilt = this._ensureShadowDom();
          if(rebuilt){ this._scheduleRender(); return; }

          // 2. Verify $content exists and is live
          if(!this.$content || !this.$content.isConnected){
            console.warn("PadSpan watchdog: $content missing/disconnected — full rebuild");
            this.connectedCallback();
            return;
          }

          // 3. Content area empty OR visually zero-height
          const empty = !this.$content.children.length;
          let zeroHeight = false;
          try { zeroHeight = this.$content.getBoundingClientRect().height < 2; } catch(e){}
          if(empty || zeroHeight){
            console.warn("PadSpan watchdog: content blank (empty=%s, zeroH=%s) — forcing render", empty, zeroHeight);
            // Force render: bypass all guards by not passing fromPoll
            this._scheduleRender();
            // If still empty after sync render, escalate to full refresh
            if(!this.$content.children.length){
              this._pollInFlight = false;
              this._refreshAll(false);
            }
          }

          // 4. Unstick deadlocked poll (hung > 20s)
          if(this._pollInFlight && this._pollStartedAt){
            if(performance.now() - this._pollStartedAt > 20_000){
              console.warn("PadSpan watchdog: poll stuck for >20s — unsticking");
              this._pollInFlight = false;
              this._scheduleRender();
            }
          }

          // 5. Ensure data poll is alive in live mode
          if(this.state.dataMode === "live" && !this._pollTimer){
            this._startDataPoll();
          }
          // 5b. Data mode still unknown (every settings_get failed): ask again
          this._retryDataMode();
          // 5c. Sample mode has no data poll: its settings re-read
          this._sampleSettingsTick();

          // 6. Escalation: no successful render in 20s → full rebuild
          // Skip for non-live views (calibration, maps, etc.) — they don't poll-render,
          // so _lastGoodRender goes stale naturally. Forcing a render mid-drag breaks things.
          const _liveSet = new Set(["overview","follow","monitor"]);
          // Sample mode has no poll that stamps a render, so the time since one
          // says nothing there: a forced render would only close what is open.
          // One that failed still gets the recovery below.
          const _noPollToWatch = !!this.state?._dataModeKnown && this.state?.dataMode !== "live" && !this._renderFailCount;
          const _isLiveView = _liveSet.has(this.state?.view) && !_noPollToWatch;
          const sinceGoodRender = this._lastGoodRender ? performance.now() - this._lastGoodRender : 0;
          // Follow/Monitor re-render from the poll every 20 s (_SLOW_INTERVAL),
          // through its focus guard. The watchdog stays above that, so it only
          // steps in on a real stall — it used to beat the poll to it and
          // rebuild outside the guard, snapping an open picker shut.
          const _stallMs = (this.state?.view === "follow" || this.state?.view === "monitor") ? 30_000 : 20_000;
          if(sinceGoodRender > _stallMs){
            if(!_isLiveView){
              // Non-live view: just reset the timer, don't force render
              this._lastGoodRender = performance.now();
            } else if((this._renderFailCount || 0) >= 2){
              console.warn("PadSpan watchdog: no successful render in 20s + %d failures — full rebuild", this._renderFailCount);
              this._renderFailCount = 0;
              this._lastGoodRender = performance.now();
              this._pollInFlight = false;
              this.connectedCallback();
            } else {
              // Try a non-poll render first before escalating
              console.warn("PadSpan watchdog: no successful render in 20s — forcing render");
              this._scheduleRender();
            }
          }
        } catch(e){
          // Even the watchdog crashed — nuclear recovery
          console.error("PadSpan watchdog error — rebuilding:", e);
          try { this.connectedCallback(); } catch(e2){}
        }
      }, 5_000);
    }

    // ── Visibility change (browser tab show/hide) ───────────────────────────
    if(!this._visibilityHandler){
      this._visibilityHandler = ()=>{
        if(document.visibilityState === "visible") this._wakeUp("visibilitychange");
      };
      document.addEventListener("visibilitychange", this._visibilityHandler);
    }

    // ── Window focus (browser window regains focus) ─────────────────────────
    // Fires on Alt-Tab back, clicking the browser from taskbar, etc.
    // visibilitychange does NOT fire for these on all browsers.
    if(!this._focusHandler){
      this._focusHandler = ()=> this._wakeUp("focus");
      window.addEventListener("focus", this._focusHandler);
    }

    // ── Page show (bfcache restore, navigation) ─────────────────────────────
    if(!this._pageshowHandler){
      this._pageshowHandler = (ev)=>{
        if(ev.persisted) this._wakeUp("pageshow");
      };
      window.addEventListener("pageshow", this._pageshowHandler);
    }

    // ── Uncaught panel errors ───────────────────────────────────────────────
    // Counted, never described. v0.35.0 shipped a Mapping tab that threw
    // before it re-rendered: the previous tab stayed on screen, the panel read
    // as a hang, and nothing anywhere recorded that anything had happened —
    // the Python log cannot see a throw in the browser.
    //
    // A window listener hears every error on the page, Home Assistant's and
    // other cards' included, so views/ui_error.js counts only a throw with
    // PadSpan's own code on its stack, and names the module that threw
    // (ui_error:<module>) plus, separately, the tab that was open
    // (ui_error_while:<view>) — names from the closed lists in telemetry.py.
    // The message and the stack stay here, in the console, where they can
    // name rooms and entities freely. At most once a minute per module;
    // nothing is sent unless the report is switched on.
    if(!this._uiErrorHandler){
      const _report = (ev)=>{
        try{
          if(!UI_ERROR) return;
          UI_ERROR.reportUiError(ev, this.state.view, (name)=>this._telemetryEvent(name));
        }catch(_e){ /* the error reporter must never be the error */ }
      };
      this._uiErrorHandler = _report;
      this._uiRejectionHandler = _report;
      window.addEventListener("error", this._uiErrorHandler);
      window.addEventListener("unhandledrejection", this._uiRejectionHandler);
    }

    // ── HA location-changed (sidebar navigation within HA) ──────────────────
    // HA fires this custom event on every route change. When the user clicks
    // PadSpan in the sidebar after visiting another panel, this wakes us up
    // even though visibilitychange won't fire (page was never hidden).
    if(!this._haLocationHandler){
      this._haLocationHandler = ()=>{
        // Only wake if we're actually connected (HA re-attached our element)
        if(this.isConnected) this._wakeUp("ha-location");
      };
      window.addEventListener("location-changed", this._haLocationHandler);
    }

    // ── Interaction recovery (user clicks on panel) ─────────────────────────
    // If the panel looks blank and the user clicks anywhere inside it,
    // immediately check health and rebuild if needed.
    if(!this._interactionHandler){
      this._interactionHandler = ()=>{
        if(!this.$content) return;
        if(!this.$content.children.length){
          console.warn("PadSpan: user click on blank panel — recovering");
          this._scheduleRender();
          this._refreshAll(false);
        }
      };
      this.addEventListener("pointerdown", this._interactionHandler);
    }
  }

  // ── Render Scheduler ──────────────────────────────────────────────────────
  // User-triggered renders (tab clicks, actions): execute IMMEDIATELY.
  // Background renders (poll, wakeUp, refreshAll): batch via rAF to prevent
  // multiple DOM rebuilds within the same frame.
  // Who is in which room on the Overview's map, as text in a box no one sees
  // (views/map_text.js: a screen reader hears a room's line when it changes,
  // at most every 10 s). Elsewhere, or with the Atlas as Overview (it has its
  // own), the box is empty.
  _updateMapText(){
    const main = MAP_TEXT && this.shadowRoot ? this.shadowRoot.querySelector("main.main") : null;
    if (!main) return;
    if (!this._mapTextBox) this._mapTextBox = MAP_TEXT.createMapText("psMapText", "Who is in which room");
    const mt = this._mapTextBox;
    if (mt.el.parentNode !== main) main.appendChild(mt.el);
    const list = this.state.live?.snapshot?.objects?.list;
    const atlasHome = !!(VIEWS.overview && VIEWS.overview.atlasHomeOn && VIEWS.overview.atlasHomeOn({ state: this.state }));
    if (this.state.view !== "overview" || atlasHome || !Array.isArray(list)) { mt.clear(); return; }
    const t = awayTimeoutS(this.state.settings), fa = this.state.followedAddrs, isScanner = this._ctx().helpers.isScanner;
    const followed = (o) => !!fa && [o.address, o.entity_id, o.key].some(a => !!a && fa.has(String(a).toUpperCase()));
    mt.update(MAP_TEXT.roomLines(MAP_TEXT.overviewEntries(list, { followed, away: (o) => isAway(o, t), isScanner }),
      MAP_TEXT.mapRooms(this.state.model)));
  }

  _scheduleRender(fromPoll = false) {
    // The screen-reader text must never stop the Overview from drawing.
    try { this._updateMapText(); } catch (e) { console.debug("PadSpan: map text skipped", e); }
    if (!fromPoll) {
      // User action — render immediately, no delay
      this._renderCurrentView(false);
      return;
    }
    // Background/poll — batch via requestAnimationFrame
    if (this._renderRAF) return; // already batched
    this._renderRAF = requestAnimationFrame(() => {
      this._renderRAF = null;
      this._renderCurrentView(true);
    });
  }

  // Unified wake-up handler — called by all recovery triggers
  _wakeUp(source){
    if(!this._hass || !this.isConnected) return;
    this._pollInFlight = false;
    this._ensureShadowDom();
    this._scheduleRender();
    this._refreshAll(false);
    if(this.state.dataMode === "live" && !this._pollTimer) this._startDataPoll();
  }

  // ── Data Polling ────────────────────────────────────────────────────────────
  // The 5-second poll loop keeps "Live" mode actually live by periodically
  // fetching fresh snapshot + status data from the backend via WebSocket.
  // Polling is ONLY active in live mode — sample mode uses static demo data.
  // The poll loop is separate from the keep-alive system (activity ping + watchdog)
  // which runs regardless of data mode to prevent blank screens.

  _startDataPoll(){
    if(this._pollTimer) return;
    // Match UI refresh rate to the presence poll interval setting (default 5s, min 1s)
    const pollS = (this.state.settings && this.state.settings.presence_poll_interval_s) || 5;
    const pollMs = Math.max(1000, Math.min(10000, pollS * 1000));
    this._pollTimer = setInterval(()=>this._pollTick(), pollMs);
  }

  _startPolling(){
    this._startDataPoll();
    this._startKeepAlive();
    this._startClientPerf();
  }

  // The opt-in report's look at this screen (client_perf.js): frame rate and
  // heap by view once a minute, the device class once per page load. Nothing
  // is measured while the report is off; events go through _telemetryEvent.
  _startClientPerf(){
    if (this._clientPerf || this._clientPerfLoading) return;
    this._clientPerfLoading = import(`./client_perf.js?b=${BUILD_ID}`).then((m) => {
      this._clientPerfLoading = null;
      if (!this.isConnected || this._clientPerf) return;
      this._clientPerf = m.startClientPerf({
        root: this.shadowRoot || this,
        viewClass: () => (this.state.view === "maps" && this.state.mapsTab === "lights") ? "atlas" : "other",
        enabled: () => !!this.state.settings?.telemetry_enabled,
        send: (name, extra) => this._telemetryEvent(name, extra),
        states: () => this._hass && this._hass.states,
      });
    }).catch(() => { this._clientPerfLoading = null; });
  }

  _stopClientPerf(){
    if (this._clientPerf){ this._clientPerf.stop(); this._clientPerf = null; }
  }

  _stopDataPoll(){
    if(this._pollTimer){
      clearInterval(this._pollTimer);
      this._pollTimer = null;
    }
  }

  _stopPolling(){
    this._stopDataPoll();
    // Keep-alive timers + event handlers are NOT stopped here —
    // they protect against blank screens regardless of data mode.
  }

  /**
   * Mapping has no poll: a rebuild would break what is being drawn. Only the
   * alarm state goes on. The banner reads the latches as on the other tabs,
   * every 30 s, and while the Plans map is open (the tool can hold someone
   * here a long while) every tick, for its alarm word and marks. Nothing here
   * renders, and of the settings read only the latches are kept.
   */
  async _mappingAlarmTick(){
    const say = (latches) => {
      const detail = { states: this._hass && this._hass.states, latches, plansOpen: false };
      window.dispatchEvent(new CustomEvent("padspan-ha-alarms-now", { detail }));
      return detail.plansOpen;
    };
    const plansOpen = say(this.state.settings && this.state.settings.flood_latches);
    if(!plansOpen && Date.now() - (this._settingsPollTs || 0) <= 30000) return;
    this._settingsPollTs = Date.now();
    this._pollInFlight = true;
    this._pollStartedAt = performance.now();
    try{
      const timeout = new Promise((_, reject) => setTimeout(() => reject(new Error("poll_timeout")), 15_000));
      const res = await Promise.race([this._callWS({ type: "padspan_ha/settings_get" }), timeout]);
      const latches = res && res.settings && res.settings.flood_latches;
      if(latches && this.state.settings){
        this.state.settings.flood_latches = latches;
        this._updateEmergencyBanner();
        if(plansOpen) say(latches);
      }
    } catch(e){
      // The next tick asks again.
    } finally {
      this._pollInFlight = false;
      this._pollStartedAt = null;
    }
  }

  /**
   * Single poll iteration — called every 5s by _pollTimer.
   * Guards prevent overlapping calls, polling in sample mode, and interrupting
   * the maps view (where drawing/dragging would break on DOM rebuild).
   * After fetching data, triggers a "from poll" re-render which respects
   * interaction guards (_dragging, _confirming, focused inputs, recent clicks).
   */
  async _pollTick(){
    if(!this._hass) return;
    if(this.state.dataMode !== "live"){
      // A new install still on the demo house turns to its own house once
      // Home Assistant reports a Bluetooth scanner. The server decides
      // (onboarding.py, live_first); this only notices: every 10 s for the
      // first five minutes on the page, then every two (a house with no
      // scanner yet isn't asked forever), and never mid-task in Mapping.
      const _mapsBusy = this.state.view === "maps" && (!!this.state._mapsWizard || ["upload", "stack", "edit"].includes(this.state.mapsTab));
      if(this.state.settings?.onboarding?.live_first === "pending" && !_mapsBusy){
        this._liveFirstSince = this._liveFirstSince || Date.now();
        const _every = (Date.now() - this._liveFirstSince) < 300000 ? 10000 : 120000;
        if(Date.now() - (this._liveFirstTs || 0) > _every){
          this._liveFirstTs = Date.now();
          await this._liveFirstCheck();
        }
      }
      return;
    }
    if(this._pollInFlight) return;
    // Optimize for scale: a page nobody can see (display off, tab in the
    // background) asks for nothing; it catches up when it is shown again.
    if(this.state.settings && this.state.settings.optimize_for_scale && document.visibilityState === "hidden") return;
    if(this.state.view === "maps"){ await this._mappingAlarmTick(); return; }

    this._pollInFlight = true;
    this._pollStartedAt = performance.now();
    const t0 = this._pollStartedAt;
    let _pollOk = false;
    try{
      // Race WS calls against a 15s timeout to prevent indefinite hangs
      const timeout = new Promise((_, reject) => setTimeout(() => reject(new Error("poll_timeout")), 15_000));
      await Promise.race([
        (async ()=>{
          // Heal path: if the boot fetch of the map geometry failed (e.g. the
          // WS connection died mid-batch), nothing else ever re-fetched it and
          // the floor plan stayed blank until a manual refresh. Both calls are
          // tiny; re-fetch whenever the state is still empty.
          if(!(this.state.maps.list || []).length){
            await this._getMapsList(false).catch(()=>{});
          }
          if(!((this.state.model || {}).floors || []).length){
            await this._getModel();
          }
          await this._getLiveSnapshot();
          await this._getStatus();
          // Settings (flood_latches among them) otherwise only refresh on
          // boot, manual Refresh, or a tab-focus/visibility wake-up — a
          // kiosk display that's simply being watched, never losing focus,
          // could miss a newly-tripped flood alarm on the emergency banner
          // indefinitely (found in the week-review workflow, 2026-09-19).
          // Same 30s-inside-the-fast-tick throttle lights_panel.js already
          // uses for its own settings repoll.
          if(Date.now() - (this._settingsPollTs || 0) > 30000){
            this._settingsPollTs = Date.now();
            await this._fetchSettings();
          }
          // The build check also runs every 10 minutes: a wall screen never
          // refreshes in full, and across an HA restart the panel can keep
          // its connection object, so the refresh that carries it never ran.
          if(Date.now() - (this._versionPollTs || 0) > 600000){
            this._versionPollTs = Date.now();
            await this._getVersionInfo();
            try { this._checkBuild(); } catch(e){}
          }
        })(),
        timeout,
      ]);
      this.state.timing.lastRefreshMs = Math.round(performance.now() - t0);
      _pollOk = true;
      this._updateBadges();

      // Re-render views that show live data.
      // Overview uses its own efficient _isoUpdateObjects() path (no full rebuild)
      // so it can safely update every 5s.  Other live views (follow, monitor) do
      // a full DOM rebuild which causes flicker — throttle those to every 35s.
      const _view = this.state.view;
      const _fastViews = new Set(["overview","purelive"]);  // efficient partial update
      const _slowViews = new Set(["follow","monitor","receivers"]);     // full rebuild — throttle
      const _SLOW_INTERVAL = 20_000;   // the ~20 s cadence Follow/Monitor have always had in practice

      if(_fastViews.has(_view)){
        // Overview: always re-render (uses _isoUpdateObjects or Preact diffing)
        const stale = this._lastGoodRender && (performance.now() - this._lastGoodRender > 10_000);
        const usePollMode = !stale || _view === "overview";
        this._scheduleRender(usePollMode);
      } else if(_slowViews.has(_view)){
        // Follow/Monitor: only re-render every 35s to avoid flicker
        const sinceLastRender = this._lastGoodRender ? (performance.now() - this._lastGoodRender) : _SLOW_INTERVAL;
        // Receivers has inline height/offset fields: never rebuild under a
        // half-typed value (the next slow tick catches up).
        const _typing = _view === "receivers" && /^(INPUT|SELECT|TEXTAREA)$/.test((this.shadowRoot && this.shadowRoot.activeElement && this.shadowRoot.activeElement.tagName) || "");
        if(sinceLastRender >= _SLOW_INTERVAL && !_typing){
          this._scheduleRender(true);
        } else if(_view === "follow" && this.state._followLocateRefresh){
          // Follow's 📍 Locate card follows every poll without the full
          // rebuild — walking directions a room behind are no directions.
          try { this.state._followLocateRefresh(); } catch(e){ console.warn("PadSpan: Locate refresh failed", e); }
        }
      } else if(_view === "calibration" && typeof this.state._calibLiveChanged === "function"){
        // Guided Calibration's steps 1 and 2 (the Tune and Setup tabs) draw
        // HA's radios and devices once and are otherwise left alone by the
        // poll. They kept saying "no scanners" after HA's Bluetooth came up a
        // minute into a restart (#88): rebuild once when what the view drew
        // has changed. The view's hook says no while it holds something not
        // yet saved (a radio waiting to be placed, a typed MAC); the poll
        // render's own guards hold it back mid-drag, mid-confirm, in a
        // focused field, or just after a click.
        let changed = false;
        try { changed = this.state._calibLiveChanged(); } catch(e){}
        if(changed) this._scheduleRender(true);
      }
    } catch(e){
      // Non-fatal — snapshot is preserved from last good fetch.
      // Only re-render if screen might be stale (> 10s since last good render).
      if(!this._lastGoodRender || (performance.now() - this._lastGoodRender > 10_000)){
        try { this._scheduleRender(); } catch(e2){}
      }
    } finally {
      this._pollInFlight = false;
      this._pollStartedAt = null;
      // The status dot counts polls (views/status_dot.js PERSIST): once per
      // poll, here, whether it answered or not.
      try { this._updateStatusDot(!_pollOk || !!this.state.live.error); } catch(e){}
    }
  }

  // ── WebSocket Helpers ───────────────────────────────────────────────────────
  // All backend communication goes through hass.callWS (HA's WS API).
  // _callWS wraps it with call counting (for Diagnostics) and event logging
  // (for the session Events tab). Views never call hass.callWS directly —
  // they use ctx.actions.callWS or the typed action methods.

  _wsCount(type){
    this.state.wsCounts[type] = (this.state.wsCounts[type]||0)+1;
  }

  _logEvent(type, detail){
    this.state._sessionEvents.push({ ts: Date.now(), type, detail: detail || "" });
    if(this.state._sessionEvents.length > 500) this.state._sessionEvents.shift();
  }

  async _callWS(payload){
    if(!this._hass) throw new Error("hass not ready");
    this._wsCount(payload.type);
    this._logEvent("ws_call", payload.type);
    try {
      return await this._hass.callWS(payload);
    } catch (err) {
      // Enhanced security is on and this person is not an admin
      // (ws_common.require_admin_if_enhanced): say so plainly, and keep that
      // message up over the view's own "failed" toast that follows it.
      if (err && err.code === "admin_only") {
        this._toast(err.message || "Only an admin can change this while Enhanced security is on");
        this._adminOnlyToastUntil = Date.now() + 4500;
      }
      throw err;
    }
  }

  // ── Sample mode: the sample house in front of Home Assistant ──────────────
  // While this browser is in Sample mode (_applyDataMode), _hass is a copy of
  // Home Assistant's hass whose states are the sample house's and whose
  // every call goes through _sampleCall (_sampleKind above): reads are
  // answered from the house, writes refused, and only the "pass" messages
  // reach Home Assistant. The website demo's fake Home Assistant
  // (hass.padspan_demo) is its own in-memory sample house, so it is asked
  // directly.

  /** Sample mode is on (_applyDataMode) and Home Assistant is a real one. */
  _sampleGateOn(){
    return this.state.dataMode === "sample" && !!this.state._dataModeKnown
      && !(this._realHass && this._realHass.padspan_demo === true);
  }

  /** The sample house, loaded the first time Sample mode needs it (never in Live mode). null if it could not load. */
  _ensureSampleHouse(){
    if (this._sampleHouse) return Promise.resolve(this._sampleHouse);
    // Failed a moment ago: not asked again yet (every read comes through here).
    if (Date.now() < (this._sampleHouseRetryAt || 0)) return Promise.resolve(null);
    if (!this._sampleHouseP) {
      // A browser remembers a module that failed to load as failed, so another
      // try has to ask for it under a new address.
      const fails = this._sampleHouseFails || 0;
      this._sampleHouseP = import(`./sample_house.js?b=${BUILD_ID}${fails ? "&retry=" + fails : ""}`)
        .then(m => {
          if (this._sampleGateOn() && !this._sampleHouse) {
            this._sampleHouse = m.createSampleHouse();
            this._houseGen = (this._houseGen || 0) + 1;
            // The settings already read are the real house's: its Vacation
            // Mode, flood latches and so on are not the sample house's.
            if (this.state.settings) { this._realSettings = this.state.settings; this.state.settings = this._sampleHouse.settingsFor(this.state.settings); }
            this._syncSampleHass();
            // It loaded on a later try: what is on screen came without it.
            if (this._sampleHouseMissed) {
              this._sampleHouseMissed = false;
              this._dropHouseCaches();
              this._refreshAll(false).finally(() => this._scheduleRender());
            }
          }
          return this._sampleHouse;
        })
        .catch(err => {
          // Sample mode shows the small demo house (sample_data.js) until a later try loads it.
          console.warn("PadSpan: the sample house failed to load", err);
          this._sampleHouseFails = fails + 1;
          this._sampleHouseMissed = true;
          this._sampleHouseRetryAt = Date.now() + 10000;
          return null;
        })
        .finally(() => { this._sampleHouseP = null; });
    }
    return this._sampleHouseP;
  }

  /** A write refused in Sample mode: said once (not again within 3 s, and
   *  kept over the view's own "failed" toast that follows), and the error
   *  the caller gets. */
  _sampleBlocked(){
    const now = Date.now();
    if (!(this._sampleToastAt && now - this._sampleToastAt < 3000)) this._toast(SAMPLE_READONLY_MSG);
    this._sampleToastAt = now;
    this._adminOnlyToastUntil = now + 4500;
    const err = new Error(SAMPLE_READONLY_MSG);
    err.code = "sample_mode";
    return err;
  }

  /** No settings answer yet, so nobody knows which house this screen is on
   *  ("sample" in state.dataMode is only the default until then). */
  _modeUnknown(){
    return !this.state._dataModeKnown && !(this._realHass && this._realHass.padspan_demo === true);
  }

  /** Resolves when the mode is known (_applyDataMode; the watchdog's
   *  _retryDataMode keeps asking). One promise for every change held, so they
   *  leave in the order they were made. No answer within 20 s of the first
   *  one held: they are refused together, not sent blind (_sampleCall has the
   *  one exception). */
  _modeAnswered(){
    if (!this._modeGate) {
      const gate = this._modeGate = {};
      gate.promise = new Promise((resolve, reject) => {
        const timer = setTimeout(() => {
          this._modeGate = null;
          reject(new Error("Home Assistant hasn't answered yet, so nothing was changed. Try again in a moment."));
        }, 20000);
        gate.release = () => { clearTimeout(timer); this._modeGate = null; resolve(); };
      });
    }
    return this._modeGate.promise;
  }

  /** Every message sent while Sample mode is on (_sampleKind), or while the
   *  mode is unknown: reads as ever, but a change waits to hear which house
   *  this is, and then goes where that house sends it. */
  async _sampleCall(payload){
    const real = this._realHass;
    if (this._modeUnknown()) {
      const unknownKind = _sampleKind(payload);
      if (unknownKind === "read" || unknownKind === "pass") return real.callWS(payload);
      try {
        await this._modeAnswered();
      } catch (err) {
        // The way out when the settings never answer: the repair tools still
        // reach the server, as they always have before the mode is known.
        // An answer in time decides as for any change: Sample refuses them.
        if (!["padspan_ha/factory_reset", "padspan_ha/store_backup_restore"].includes(payload.type)) throw err;
        return this._realHass.callWS(payload);
      }
      return this._sampleCall(payload);
    }
    // Switched back to Live while a view still held the sample hass.
    if (!this._sampleGateOn()) return real.callWS(payload);
    const kind = _sampleKind(payload);
    if (kind === "drop") return {};
    if (kind === "write") throw this._sampleBlocked();
    if (kind === "pass") {
      const res = await real.callWS(payload);
      // A settings answer as the sample house has it (no real Vacation Mode, receiver offsets or
      // hidden plans); the real one kept for the switch back (_syncSampleHass).
      if (!(this._sampleHouse && res && res.settings)) return res;
      this._realSettings = res.settings;
      return { ...res, settings: this._sampleHouse.settingsFor(res.settings) };
    }
    const house = await this._ensureSampleHouse();
    // The house could not load: reads go to Home Assistant, as Sample mode always sent them.
    if (!house) return real.callWS(payload);
    const res = house.route(payload);
    return res === undefined ? {} : res;
  }

  /** What the views talk to: real, or in Sample mode the sample house in
   *  front of it. The same object until either changes, and one connection
   *  object for the whole Sample session (set hass's reconnect test). While
   *  the mode is unknown the same copy holds changes back (_sampleCall). */
  _viewHass(real){
    if (!real || !(this._sampleGateOn() || this._modeUnknown())) return real;
    const house = this._sampleHouse;
    const w0 = this._sampleWrap;
    if (w0 && w0._real === real && w0._house === house) return w0;
    const self = this;
    // Nothing is pushed from a sample house; with the mode unknown it may be the real one.
    const push = (how) => async (...a) => self._modeUnknown() ? self._realHass.connection[how](...a) : () => {};
    const conn = this._sampleConn || (this._sampleConn = {
      connected: true, addEventListener(){}, removeEventListener(){},
      sendMessagePromise: (m) => self._sampleCall(m),
      subscribeMessage: push("subscribeMessage"), subscribeEvents: push("subscribeEvents"),
    });
    const held = (fn) => (...a) => self._modeUnknown() ? self._modeAnswered().then(() => fn(...a)) : fn(...a);
    const w = Object.assign({}, real, {
      callWS: (m) => self._sampleCall(m),
      sendWS: (m) => { self._sampleCall(m).catch(() => {}); },
      // Refused only while Sample mode is on: a view still holding this copy
      // after the switch back to Live is talking to the real house again.
      callService: held((...a) => self._sampleGateOn() ? Promise.reject(self._sampleBlocked()) : self._realHass.callService(...a)),
      // A history read gets nothing; anything else is a change.
      callApi: held((method, ...a) => !self._sampleGateOn() ? self._realHass.callApi(method, ...a)
        : String(method).toUpperCase() === "GET" ? Promise.resolve([]) : Promise.reject(self._sampleBlocked())),
      connection: conn,
      padspan_sample: true,
    });
    if (house) {
      // The sample house's own lights and sensors; the real sun, so a theme
      // that follows it does not jump at the switch.
      w.states = Object.assign({}, house.states, real.states && real.states["sun.sun"] ? { "sun.sun": real.states["sun.sun"] } : {});
      w.entities = house.entities;
      w.devices = {};
      w.areas = Object.fromEntries(house.model.areas.map(a => [a.id, { area_id: a.id, name: a.name, floor_id: a.floor_id }]));
      w.floors = Object.fromEntries(house.model.floors.map(f => [f.id, { floor_id: f.id, name: f.name, level: f.level }]));
    }
    Object.defineProperty(w, "_real", { value: real });
    Object.defineProperty(w, "_house", { value: house });
    this._sampleWrap = w;
    return w;
  }

  /**
   * After every data-mode answer (_applyDataMode): which hass the views get,
   * and on a change of mode, nothing of the other house kept. Entering
   * Sample mode starts loading the sample house and puts the real follow
   * choices aside; leaving it drops the house, gives them back, and the
   * refresh that follows the switch reloads the real model.
   */
  _syncSampleHass(){
    const on = this._sampleGateOn();
    if (on !== !!this._sampleOn) {
      this._sampleOn = on;
      this._houseGen = (this._houseGen || 0) + 1;
      this._dropHouseCaches();
      if (!on) {
        this._sampleHouse = null; this._sampleWrap = null;
        // The real settings back, not the sample copy, even if the next read fails: a Live
        // save must never send the copy's blanks (hidden plans, receiver offsets).
        if (this._realSettings) this.state.settings = this._realSettings;
      }
      this._realSettings = null;
    }
    if (on) this._keepLiveFollow();
    else this._restoreLiveFollow();
    if (on && !this._sampleHouse) this._ensureSampleHouse();
    const h = this._viewHass(this._realHass);
    if (h !== this._hass) {
      this._hass = h;
      if (this.state._overviewAtlas) this.state._overviewAtlas.hass = h;
    }
  }

  /** What the panel and its views hold of one house, dropped when the
   *  data mode changes; the refresh after the switch reads the other's. */
  _dropHouseCaches(){
    const st = this.state;
    const atlas = st._overviewAtlas;
    if (atlas && atlas.parentNode) atlas.parentNode.removeChild(atlas);
    st._overviewAtlas = null;
    if (st.live) { st.live.snapshot = null; st.live.fromSample = false; }
    // The model too: a failed model_get after the switch must not leave the
    // other house's rooms under a Live edit. Views wait for _modelLoaded.
    st.model = { floors: [], areas: [], room_meta: {}, scanners: {}, room_adjacency: {}, scanner_positions_m: {},
                 room_geometry_m: {}, rf_barriers_m: [], map_transforms: {}, beacon_positions_m: {},
                 light_positions_m: {}, floor_elevations: {}, fabric_floors: {} };
    st._modelLoaded = false;
    // The plans and everything Mapping keeps about them (drafts, alignments).
    st.maps = { list: [], lastError: null };
    st._mapsLoaded = false;
    st.activeMapId = null;
    st._mapsWizard = null;
    st.calibration = null;
    st._setupCalAsked = false;
    st._lightsRegStore = null;
    st._settingsDraft = null;
    st.diag = null;
    st.status = null;
    st.savedRoomTagMap = {};
    st.roomTagMap = {};
    if (st._calib) st._calib._resultsTips = null;
  }

  /**
   * Sample mode has no data poll, so its settings are re-read here every
   * 30 s (from the watchdog): a real flood alarm still shows on a screen
   * left in Sample mode (a wall display), and a screen with no choice of
   * its own follows another screen's "Back to my house" (_applyDataMode).
   */
  _sampleSettingsTick(){
    if (this._sampleGateOn() && !this._sampleHouse) this._ensureSampleHouse();
    if (this.state.dataMode === "live" || !this.state._dataModeKnown || this._sampleTickBusy) return;
    if (Date.now() - (this._settingsPollTs || 0) < 30000) return;
    this._settingsPollTs = Date.now();
    this._sampleTickBusy = true;
    return this._fetchSettings()
      .then(async () => {
        this._updateEmergencyBanner();
        if (this.state.dataMode === "live") { await this._refreshAll(false); this._startPolling(); this._scheduleRender(); }
      })
      .catch(() => {})
      .finally(() => { this._sampleTickBusy = false; });
  }

  /**
   * Following in Sample mode (M2): the Follow view, the Overview and the
   * device sheet change state.followedAddrs / followAddr and their
   * localStorage copies (padspan_followed, padspan_followAddr) as they
   * always did, so following the sample house's people works; the server's
   * list is never written (_sampleKind). The real choices are put aside
   * here on entering Sample mode, in localStorage too so a reload or a
   * closed tab in between keeps them, and given back on leaving it.
   */
  _keepLiveFollow(){
    try {
      if (localStorage.getItem(_FOLLOW_ASIDE) !== null) return;
      localStorage.setItem(_FOLLOW_ASIDE, JSON.stringify({ followed: localStorage.getItem("padspan_followed"),
                                                           addr: localStorage.getItem("padspan_followAddr") }));
    } catch (_) { /* no storage: nothing kept, nothing to give back */ }
  }

  _restoreLiveFollow(){
    let kept = null;
    try { kept = JSON.parse(localStorage.getItem(_FOLLOW_ASIDE) || "null"); } catch (_) { kept = null; }
    if (!kept || typeof kept !== "object") return;
    try {
      for (const [key, v] of [["padspan_followed", kept.followed], ["padspan_followAddr", kept.addr]]) {
        if (v === null || v === undefined) localStorage.removeItem(key); else localStorage.setItem(key, v);
      }
      localStorage.removeItem(_FOLLOW_ASIDE);
    } catch (_) { /* storage went away */ }
    let list = [];
    try { list = JSON.parse(kept.followed || "[]"); } catch (_) { list = []; }
    this.state.followedAddrs = new Set(Array.isArray(list) ? list : []);
    this.state.followAddr = kept.addr || "";
    // The server's list is read again with the next settings (Live).
    this._followedLoadedFromServer = false;
  }

  // Fetch settings and store quietly (no re-render, no toast) — called from _refreshAll
  async _fetchSettings(){
    const attempt = async () => {
      const res = await this._callWS({ type: "padspan_ha/settings_get" });
      if(res?.settings){
        this.state.settings = res.settings;
        // Skin and theme follow every settings read, not only _loadSettings
        // (both return at once when nothing changed).
        this._applySkin();
        this._applyTheme();
        const first = !this._settingsLoaded;
        this._settingsLoaded = true;
        // The first settings decide what the menu shows (Forensics, Bright):
        // a ?view= link kept until now is checked against them (issue #93).
        if (first && this.$nav) this._renderNav();
        if ("cpu_pinning_supported" in res) this.state.cpuPinningSupported = !!res.cpu_pinning_supported;
        // The mode first, then the counts queued before it was known: a page
        // that opens in Sample mode sends none of them (_sampleKind "drop").
        this._applyDataMode(res.settings.data_mode);
        this._telemetryFlush();
        // Load followed addrs from server ONCE on boot (not on every poll,
        // which would race with local toggles and revert user clicks); in
        // Live mode only (Sample mode keeps the real ones aside, _keepLiveFollow).
        if(!this._followedLoadedFromServer && this.state.dataMode === "live" && Array.isArray(res.settings.followed_addrs)){
          this.state.followedAddrs = new Set(res.settings.followed_addrs);
          this._followedLoadedFromServer = true;
        }
      }
    };
    try{
      await attempt();
    }catch(e){
      // The data mode stays unknown until this succeeds, so a swallowed
      // failure here strands the user with no data at all (it used to be the
      // demo data — issues #68, #88). Most failures here are a transient WS hiccup on
      // a fresh/first setup, so retry once after a short delay before giving up.
      console.warn("PadSpan refresh: fetchSettings failed, retrying:", e);
      try{
        await new Promise(r => setTimeout(r, 750));
        await attempt();
      }catch(e2){
        console.warn("PadSpan refresh: fetchSettings retry failed:", e2);
      }
    }
  }
  async _loadAlertConfigs(){
    try{
      const res = await this._callWS({ type: "padspan_ha/follow_alert_get" });
      if(res?.configs) this.state.followAlertConfig = res.configs;
    }catch(e){}
  }

  // ── Data Loading ────────────────────────────────────────────────────────────
  // These methods fetch data from the backend and update this.state.
  // They are called from _refreshAll (full bootstrap) and individually
  // from specific actions (e.g. after tagging an object, after map upload).

  // Three themes (Settings → Appearance → Theme). Night is the panel as
  // drawn. Light (settings.light_theme) is a full colour inversion of the
  // host (accessibility: the dark theme is unusable for some eye
  // conditions); styles.css counter-inverts photos/map images via the
  // data-invert attribute so they don't render as negatives. Day
  // (settings.day_theme, which wins over light_theme) is a designed light
  // palette made from the night colours by day_theme.js, loaded only when
  // someone picks it; Pure Live is never touched. Day re-applies when the
  // skin changes, since the skin's stylesheet changes.
  async _applyTheme(){
    // Day wins, then Light (the inversion), then a palette (day_theme.js
    // PALETTES); none of them is Night.
    // Day and three palettes are PadSpan Pro's: without Pro (a lapsed key
    // too) they are Night. Light, the accessibility inversion, and High
    // contrast are everyone's.
    const pro = String(this.state.settings?.tier || "").toLowerCase() === "pro";
    const look = this._sunLook(pro);
    const day = pro && !!look.day_theme;
    const named = String(look.theme_palette || "");
    const pal = !day && !look.light_theme && (pro ? ["graphite", "ocean", "dusk", "contrast"] : ["contrast"]).includes(named) ? named : "";
    const on = day || !!pal;
    const invert = !on && !!look.light_theme;
    this.style.filter = invert ? "invert(1) hue-rotate(180deg)" : "";
    if (invert) this.setAttribute("data-invert", ""); else this.removeAttribute("data-invert");
    const want = on ? (day ? "day" : pal) + ":" + (this._skin || "classic") : "";
    if ((this._dayKey || "") === want) return;
    this._dayKey = want;
    if (this._dayOff) { this._dayOff(); this._dayOff = null; }
    this.removeAttribute("data-theme");
    if (!on) return;
    try {
      if (!DAY_THEME) DAY_THEME = await import(`./day_theme.js?b=${BUILD_ID}`);
      const urls = Array.from(this.shadowRoot.querySelectorAll('link[rel="stylesheet"][href]')).map(l => l.href);
      const css = await Promise.all(urls.map(u => fetch(u).then(r => r.ok ? r.text() : "").catch(() => "")));
      if (this._dayKey !== want) return;   // switched again while loading
      this._dayOff = DAY_THEME.attachDayTheme(this.shadowRoot, {
        extraCss: css.filter(Boolean),
        color: day ? DAY_THEME.dayColor : DAY_THEME.paletteColor(pal),
        frozen: (n) => { const content = this.shadowRoot.querySelector("#content"); return this.state.view === "purelive" && !!content && content.contains(n); },
      });
      this.setAttribute("data-theme", day ? "day" : pal);
    } catch (e) {
      this._dayKey = "";
      console.warn("PadSpan: day theme failed to load", e);
    }
  }

  // Follow the sun (settings.theme_follow_sun, off by default): while the sun
  // is up (sun.sun above_horizon) the panel is Day, or Light (inverted)
  // without PadSpan Pro; once it sets, the Theme picked, unless that is Day
  // or Light itself, which give Night. Off, or with no sun.sun, the Theme
  // picked as it always was. set hass() asks again only when the sun's state
  // changes.
  _sunLook(pro){
    const s = this.state.settings || {};
    const sun = s.theme_follow_sun === true ? this._hass?.states?.["sun.sun"]?.state : null;
    this._sunSeen = sun || null;
    if (sun === "above_horizon") return pro ? { day_theme: true } : { light_theme: true };
    if (sun === "below_horizon") return { theme_palette: s.theme_palette };
    return s;
  }

  // Chrome skin. "classic" is v0.35.0 untouched; "2025" links styles-2025.css
  // on top of styles.css and switches _renderNav to the grouped icon list.
  // Anything other than the exact string "2025" means classic, so a bad or
  // missing setting can never strand someone on a skin that failed to load.
  //
  // Independent of the theme (_applyTheme): both skins still invert the host
  // for the Light theme, and the Day theme re-applies itself to the skin's
  // stylesheet as well.
  _applySkin(){
    const skin = (this.state.settings?.ui_skin === "2025") ? "2025" : "classic";
    if (this._skin === skin) return false;
    this._skin = skin;
    this.setAttribute("data-skin", skin);
    const link = this.shadowRoot?.querySelector("#skinLink");
    if (link) {
      if (skin === "2025") {
        link.href = `/padspan_ha_static/padspan-ha/styles-2025.css?v=${APP_VERSION}&b=${BUILD_ID}`;
      } else {
        link.removeAttribute("href");
      }
    }
    return true;
  }

  // ── Opt-in usage report: the one door its events go through ──────────────
  // Settings arrive after the first render, and the landing view, a deep
  // link and a throw during that first render all happen before them. An
  // event that checked the switch at that moment was dropped, which is why
  // the report could never count the landing tab and could never see the one
  // class of error it was added for (v0.35.0's first-render throw). Events
  // wait here until the switch is KNOWN, then go or are discarded; the
  // backend checks the switch again and is the authority. Nothing leaves the
  // browser while the report is off or unknown.
  // Home Assistant's own sidebar, hidden or shown from PadSpan's toolbar
  // (ha_sidebar.js). The button stays on the collapsed rail too: with HA's
  // sidebar gone it is the way back.
  _paintHaSide(){
    const b = this.shadowRoot && this.shadowRoot.querySelector("#haSide");
    if (!HA_SIDEBAR) { _haSideWaiting.add(this); return; }
    if (!b) return;
    b.textContent = HA_SIDEBAR.haLabel(this._hass);
    b.setAttribute("aria-pressed", String(HA_SIDEBAR.haHidden(this._hass)));
  }
  _toggleHaSidebar(){
    if (!HA_SIDEBAR) return;
    this._telemetryEvent(HA_SIDEBAR.toggleHaSidebar(this, this._hass));
  }
  _telemetryEvent(name, extra){
    const s = this.state.settings;
    if (!s || !("telemetry_enabled" in s)) {
      const q = this._telemetryQueue || (this._telemetryQueue = []);
      // Screen-counted events need their id, so they wait for the next tick;
      // anything else is kept by name (a wall_screen word just loses its id).
      if (q.length < 50 && !(extra && /^(client_screen|overview_shown)/.test(String(name)))) q.push(String(name));
      return;
    }
    if (!s.telemetry_enabled) { this._telemetryQueue = null; return; }
    // `extra` only ever carries this browser's screen id (client_perf.js).
    const screen = extra && typeof extra.screen === "string" ? { screen: extra.screen } : {};
    this._callWS({ type: "padspan_ha/telemetry_event", event: String(name), ...screen }).catch(() => {});
  }
  // Called whenever settings land. Counts the view that was already open
  // once — it was set directly, never through setView — then releases
  // whatever waited. Idempotent: a later settings refresh finds nothing.
  // What kind of screen this is and how a self-reload went (screenKind,
  // reloadOutcome), once per page load.
  _screenReport(){
    if (_screenReported) return;
    _screenReported = true;
    // With the screen id (read, never made): its word in the report's list of screens.
    let sid = null;
    try { sid = localStorage.getItem("padspan_screen_id"); } catch (_) {}
    this._telemetryEvent("wall_screen:panel:" + screenKind(this.state.kioskMode),
      /^[0-9a-f]{16}$/.test(sid || "") ? { screen: sid } : undefined);
    if (_reloadNote) this._telemetryEvent("wall_reload:panel:" + _reloadNote);
  }
  // A ?view= link (#93), once settings say whether it stays open.
  _countViewLink(){
    const v = this._urlPinnedView;
    if (this._viewLinkCounted || !v || !this._settingsLoaded) return;
    this._viewLinkCounted = true;
    const off = v === "forensics" && (this.state.settings || {}).forensics_enabled !== true;
    this._telemetryEvent("view_link:" + (this._keepsLinkedView(v) ? "kept" : off ? "forensics_off" : "edition"));
  }
  _telemetryFlush(){
    const s = this.state.settings;
    if (!s || !("telemetry_enabled" in s)) return;
    const q = this._telemetryQueue || [];
    this._telemetryQueue = null;
    if (!this._telemetryLanded) {
      this._telemetryLanded = true;
      if (this.state.view) q.unshift("tab:" + this.state.view);
    }
    for (const e of q) this._telemetryEvent(e);
  }

  async _loadSettings(){
    try {
      if(!this._hass) return;
      const res = await this._callWS({ type: "padspan_ha/settings_get" });
      this.state.settings = res?.settings || {};
      if (res?.settings) this._settingsLoaded = true;
      this._applySkin();
      this._applyTheme();
      if (res && "cpu_pinning_supported" in res) this.state.cpuPinningSupported = !!res.cpu_pinning_supported;
      this._applyDataMode(res?.settings?.data_mode);
      this._updateBadges();
      this._renderNav();
      this._scheduleRender();
      this._telemetryFlush();
      this._countViewLink();
    } catch (e) {
      // Non-fatal
      this._toast("Settings load failed (will retry on refresh).", true);
    }
  }

  /** The top bar's data-mode label. "…" until the server has said which:
   *  the constructor's "sample" is a default, not an answer (#88). */
  _dataModeLabel(){
    if(!this.state._dataModeKnown) return "…";
    if(this.state.dataMode === "live" && this._sampleConfirmT) return "Show demo data?";
    return (this.state.dataMode === "live") ? "Live" : "Sample";
  }

  /**
   * The top-bar Data button and the mobile pill. Each shows the CURRENT mode
   * and a click switches it, so a user who pressed "Live" to get live data
   * was put into Sample — the demo house (#88). Live -> Sample therefore
   * takes a second click within 3 s: the first only turns the label into
   * what the second will do, and it goes back by itself. Sample -> Live
   * stays one click; "…" (mode not known yet) does nothing.
   *
   * A click less than 500 ms after the one before is the rest of the same
   * gesture — a double-click, a double-tap — and not an answer: a
   * double-click on "Live" landed in the demo house without "Show demo
   * data?" ever being read. (A held Enter would be a click per key repeat;
   * the buttons' keydown handlers stop those.)
   */
  async _onDataModeClick(){
    if(!this.state._dataModeKnown) return;   // "…": nothing to toggle from yet
    const now = performance.now();
    const sinceLast = now - (this._dataModeClickAt ?? -Infinity);
    this._dataModeClickAt = now;
    if(sinceLast < 500) return;
    if(this.state.dataMode === "live" && !this._sampleConfirmT){
      this._sampleConfirmT = setTimeout(() => { this._sampleConfirmT = null; this._paintDataModeLabel(); }, 3000);
      this._paintDataModeLabel();
      return;
    }
    clearTimeout(this._sampleConfirmT);
    this._sampleConfirmT = null;
    this._paintDataModeLabel();
    await this._setDataMode(this.state.dataMode === "sample" ? "live" : "sample");
  }

  /**
   * Both data-mode buttons: the same label, and the mobile pill's Live
   * colour. The one writer of either, called from _updateBadges (every
   * refresh and poll, so after every mode change), _renderNav, and the
   * confirm above. The pill used to be painted only by _renderNav: a phone
   * on a Live install read "…" until the first tab change, and after a
   * switch it read "Sample" in Live's green.
   */
  _paintDataModeLabel(){
    const label = this._dataModeLabel();
    const b = this.$("#dataModeToggle");
    if(b) b.textContent = label;
    const pill = this.$("#mobileDataPill");
    if(pill){
      pill.textContent = label;
      pill.className = "mobile-topbar-pill" + (this.state.dataMode === "live" ? " live" : "");
    }
  }

  /**
   * The data mode is still unknown because every settings_get so far failed
   * (#88): ask again. Nothing else re-asks on a page nobody touches. The
   * poll runs only in Live mode, and the watchdog's own refresh only when
   * #content is empty, so a wall kiosk that booted during an HA restart sat
   * on an empty screen for good. Called from the 5 s watchdog; one attempt
   * in flight at a time, or a new one after 20 s if that one never answers
   * (it still counts if it does). Once the mode is known, one full refresh
   * brings the data and, in Live mode, the poll starts.
   */
  _retryDataMode(){
    if(this.state._dataModeKnown) return;
    const now = Date.now();
    if(this._modeRetry && now - this._modeRetry < 20000) return;
    this._modeRetry = now;
    this._fetchSettings()
      .then(() => {
        if(!this.state._dataModeKnown || this._modeRetryRefreshed) return;
        this._modeRetryRefreshed = true;
        return this._refreshAll(false).then(() => {
          if(this.state.dataMode === "live" && !this._pollTimer) this._startDataPoll();
        });
      })
      .catch(() => {})
      .finally(() => { if(this._modeRetry === now) this._modeRetry = 0; });
  }

  /**
   * The one place a data_mode reported by the server (settings_get,
   * settings_set, the factory reset's re-read) lands in state.
   *
   * Rule (#88): the demo snapshot is shown ONLY when the server said
   * data_mode=sample. dataMode starts as "sample" before settings arrive, and
   * that default used to be read as a real answer: a failed first settings
   * fetch put SAMPLE_SNAPSHOT on screen, a later successful fetch flipped the
   * badge to Live without removing it, and every failed live_snapshot kept
   * it — "Live" over the demo house's radios. So this records that the mode
   * is now known, and a Live answer evicts the demo snapshot on the spot.
   */
  _applyDataMode(raw){
    // Sample / Live is this browser's own choice (M3): one person's preview
    // must not turn every screen in the house (a wall display) to the sample
    // house. The rule:
    //   - this browser has a choice (localStorage padspan_data_mode, set by
    //     its own Sample / Live switch): that, whatever the server says;
    //   - no choice yet: the server's data_mode on the page's first answer
    //     (a house still in Sample from before stays there, and a new
    //     install starts on the sample house), and after that the server
    //     only ever turns it to Live (onboarding.py's first scanner, another
    //     screen's "Back to my house"), never to Sample.
    // The #88 rule stands: nothing is known before the server has answered.
    const server = (String(raw || "sample").toLowerCase() === "live") ? "live" : "sample";
    const own = _localDataMode();
    const mode = own || (!this.state._dataModeKnown || server === "live" ? server : this.state.dataMode);
    this.state.dataMode = mode;
    this.state._dataModeKnown = true;
    if(this._modeGate) this._modeGate.release();
    if(mode === "live" && (this.state.live.snapshot === SAMPLE_SNAPSHOT || this.state.live.fromSample)){
      this.state.live.snapshot = null;
      this.state.live.fromSample = false;
      this._recomputeDerived();
    }
    // The sample house in front of Home Assistant, or not (Sample mode).
    this._syncSampleHass();
  }

  /**
   * Switch between "sample" and "live" data modes.
   * Sample mode: assigns SAMPLE_SNAPSHOT (static demo data) so all views work
   *   without real BLE hardware — useful for demos and development.
   * Live mode: clears the sample snapshot and starts polling the backend for
   *   real BLE data every 5 seconds.
   * The choice is persisted server-side via settings_set.
   */
  async _liveFirstCheck(){
    try {
      await this._fetchSettings();
      if(this.state.dataMode !== "live") return;
      // Only when the server made the switch, not someone's own click or
      // another tab.
      if(this.state.settings?.onboarding?.live_first === "switched")
        this._toast("PadSpan found your Bluetooth scanners: this is your own house now.");
      await this._refreshAll(false);
      this._startPolling();
      this._scheduleRender();
    } catch(e){}
  }

  async _setDataMode(mode){
    try {
      mode = mode === "live" ? "live" : "sample";
      const was = this.state.dataMode;
      // This browser's choice (_applyDataMode): Sample is never sent to the
      // server. Back to Live is, while the server still says sample, so the
      // server's own Live-only work (Forensics recording, the room tags)
      // runs again, and screens with no choice of their own follow. The
      // choice is kept only once the server took it: a refusal (Enhanced
      // security and no admin) or no answer leaves this screen in Sample,
      // and says so, rather than Live over a server still in Sample.
      let server = this.state.settings && this.state.settings.data_mode;
      if(mode === "live" && server !== "live"){
        let res;
        try { res = await this._callWS({ type: "padspan_ha/settings_set", data_mode: "live" }); }
        catch(err){
          this._adminOnlyToastUntil = 0;
          this._toast(err && err.code === "admin_only"
            ? "Only an admin can switch the house back to live data while Enhanced security is on. Ask an admin to press \"Back to my house\"; this screen stays on the sample house."
            : "Couldn't switch back to live data: Home Assistant didn't answer. This screen stays on the sample house; try again in a moment.", true);
          return;
        }
        if(res && res.settings){ this.state.settings = res.settings; server = res.settings.data_mode; }
      }
      // Opt-in report: the preview opened, counted while still Live (Sample
      // mode counts nothing, _sampleKind "drop").
      if(mode === "sample" && was === "live") this._telemetryEvent("preview_open");
      _saveLocalDataMode(mode);
      // A Live answer clears the sample snapshot here (see _applyDataMode) so
      // the first live fetch replaces it.
      this._applyDataMode(server);
      // ... and left, counted once Live again.
      if(mode === "live" && was === "sample" && this.state.dataMode === "live") this._telemetryEvent("preview_back");
      this._toast(`Data mode: ${this.state.dataMode.toUpperCase()}`);
      // When switching to sample, explicitly assign sample snapshot: the
      // small demo house's, only when the sample house (whose own comes
      // with the refresh below) could not load.
      if(this.state.dataMode !== "live" && !(this._sampleGateOn() && await this._ensureSampleHouse())){
        this.state.live.snapshot = SAMPLE_SNAPSHOT;
        this._recomputeDerived();
      }
      await this._refreshAll(false);
      if(this.state.dataMode === "live") this._startPolling();
      else this._stopPolling();
    } catch (e) {
      this._toast("Failed to switch data mode. The browser console has the details.", true);
      console.error(e);
    }
  }

  async _getVersionInfo(){
    try {
      const res = await this._callWS({ type: "padspan_ha/version" });
      this.state.versionInfo = res;
    } catch (e) {
      this.state.versionInfo = null;
    }
  }

  /** The backend's build arrives with every full refresh: first load, and
   *  each reconnect after Home Assistant restarts. */
  _checkBuild(){
    const vi = this.state.versionInfo;
    const be = (vi && typeof vi.build_id === "string") ? vi.build_id : "";
    let reloadedFor = "";
    try { reloadedFor = sessionStorage.getItem("padspan_reloaded_for") || ""; } catch(e) {}
    const wall = this.state.kioskMode || (wallScreen(false) && untouchedFor(120000));
    const act = staleBuildAction(RELEASE_BUILD_ID, be, wall, reloadedFor);
    // Not under someone's hands (the guards _renderCurrentView keeps): an
    // open dialog, a pin being placed, a map being dragged, uploaded or
    // edited. The periodic check tries again. An open dialog counts only
    // while somebody is there, though: a room or scanner dialog opened by one
    // tap never closes by itself, and counting it after two untouched minutes
    // kept a wall screen on the old build for good. Idle that long, the dialog
    // is closed and the page reloads; unsaved work in Maps or a drag still waits.
    const s = this.state;
    const idle = untouchedFor(120000);
    const busy = (!idle && this.$modal && !this.$modal.classList.contains("hidden"))
      || s._calibTune?._dragging || s._calibBeacon?._dragging || s._calibTune?._confirming || s._calibBeacon?._confirming
      || s.maps?._stackDragging || s.maps?._editDragging
      || (s.view === "maps" && (s.mapsTab === "upload" || s.mapsTab === "stack" || s.mapsTab === "edit"));
    if(act && act.reload && !busy){
      let remembered = false;
      try {
        sessionStorage.setItem("padspan_reloaded_for", be); remembered = true;
        sessionStorage.setItem("padspan_reload_how", "panel:" + (this.state.kioskMode ? "kiosk" : "fullscreen"));
      } catch(e) {}
      if(remembered){ this._closeModal(); location.reload(); return; }   // can't remember it: show the bar, don't risk a loop
    }
    const bar = this.$("#staleBuild");
    if(!bar) return;
    bar.textContent = "";
    if(!act){ bar.classList.add("hidden"); return; }
    const theirs = (vi && vi.version) || "?";
    bar.appendChild(document.createTextNode(act.newer
      ? `PadSpan was updated to v${theirs}. This page is still running v${APP_VERSION}.`
      : `This page is v${APP_VERSION}, but Home Assistant is running PadSpan v${theirs}. If you just updated, restart Home Assistant.`));
    const btn = document.createElement("button");
    btn.className = "btn inline";
    btn.textContent = "Reload";
    btn.addEventListener("click", () => location.reload());
    bar.appendChild(btn);
    bar.classList.remove("hidden");
  }

  async _getStatus(){
    const res = await this._callWS({ type: "padspan_ha/status" });
    const entry = (res?.entries && res.entries[0]) ? res.entries[0] : {};
    this.state.status = entry;
  }

  /**
   * Recompute derived state from the latest snapshot.
   * The room-tag map has three layers: saved (persisted), live (from snapshot),
   * and missing (tags referencing rooms that no longer exist in HA).
   * This separation lets the UI show live positions while preserving the
   * saved map for settings/configuration views.
   */
  /**
   * Reconcile the three room-tag-map sources into the one `roomTagMap` views
   * actually read. A snapshot (live or sample) can carry its OWN live-derived
   * tag map (room_tag_map_live) alongside the persisted one (room_tag_map);
   * live takes priority when present because it reflects the current
   * session's actual detections, not just what was last saved. With no
   * snapshot at all (e.g. before the first live_snapshot fetch lands) fall
   * back to whatever was last fetched from the backend via _getRoomTags
   * (savedRoomTagMap), so the UI never blanks out mid-boot. savedRoomTagMap
   * itself is only ever refreshed from a LIVE snapshot — sample mode's
   * static demo data has no real persisted map to promote it to, and doing
   * so would overwrite the real saved map with demo content.
   */
  _recomputeDerived(){
    const saved = this.state.savedRoomTagMap || {};
    const snap = this.state.live?.snapshot;
    if(snap && snap.room_tag_map){
      this.state.roomTagMap = (snap.room_tag_map_live || snap.room_tag_map) || {};
      this.state.missingRoomTagMap = snap.room_tag_map_missing || {};
      // Only update savedRoomTagMap from live data (sample snapshot has no persistent map)
      if(this.state.dataMode === "live"){
        this.state.savedRoomTagMap = snap.room_tag_map_saved || {};
      }
    } else {
      this.state.roomTagMap = saved || {};
    }
  }

  async _getRoomTags(){
    const res = await this._callWS({ type: "padspan_ha/room_tags" });
    this.state.savedRoomTagMap = res?.room_tag_map || {};
    this._recomputeDerived();
    if(res?.sources) this.state.live.sources = res.sources;
  }

  /**
   * Fetch the live BLE snapshot from the backend, or use SAMPLE_SNAPSHOT in sample mode.
   * Sample mode uses a static demo snapshot (from sample_data.js) so every view
   * renders with realistic data even without any BLE hardware connected.
   * In live mode, we keep the last good snapshot on failure to prevent UI flickering.
   */
  async _getLiveSnapshot(){
    if(this.state.dataMode !== "live") {
      // "sample" before any settings answer is the constructor default, not
      // the server's choice — no demo data until the mode is known (#88).
      if(!this.state._dataModeKnown) return;
      // The sample house's people where they are now (sample_house.js), or
      // the website demo's own; never a request to a real Home Assistant
      // (_sampleCall answers it). SAMPLE_SNAPSHOT if neither is there.
      let snap = null;
      const demo = !!(this._realHass && this._realHass.padspan_demo === true);
      if(demo || (this._sampleGateOn() && await this._ensureSampleHouse())){
        try { snap = (await this._callWS({ type: "padspan_ha/live_snapshot" }))?.snapshot || null; } catch(e) { snap = null; }
      }
      if(this.state.dataMode !== "live" && snap && typeof snap === "object"){
        this.state.live.snapshot = snap;
        this.state.live.fromSample = true;
      }
      // But only assign if we don't already have a live snapshot cached
      // (prevents race conditions during _refreshAll where settings haven't loaded yet).
      else if(!this.state.live.snapshot || this.state.live.snapshot === SAMPLE_SNAPSHOT){
        this.state.live.snapshot = SAMPLE_SNAPSHOT;
      }
      this.state.live.error = null;
      this._recomputeDerived();
      return;
    }
    try {
      // Optimize for scale (Settings): the Overview draws people, so it asks
      // for the slim snapshot; every other view gets the whole one.
      const slim = !!(this.state.settings && this.state.settings.optimize_for_scale) && this.state.view === "overview";
      const res = await this._callWS(slim ? { type: "padspan_ha/live_snapshot", slim: true } : { type: "padspan_ha/live_snapshot" });
      const snap = res?.snapshot;
      // Only replace the snapshot if we got a valid response.
      // Keep the last good snapshot on WS failure to prevent flickering.
      if(snap && typeof snap === "object"){
        this.state.live.snapshot = snap;
        this.state.live.error = null;
        this._recomputeDerived();
        const objCount = snap?.objects?.summary?.total ?? 0;
        this._logEvent("snapshot", `${objCount} objects`);
      }
    } catch(e) {
      // Keep whatever snapshot we had — do NOT wipe to null
      this.state.live.error = String(e);
    }
  }

  /**
   * Keep the signed floor-plan links working on a screen left open
   * (called from the watchdog every 10 minutes).
   *
   * A link lasts 24 h and dies with an HA restart, which an open panel may
   * not see as a reconnect. The server hands back the same link until one of
   * those happens, so asking costs no image downloads. Two different answers:
   *  - a link whose ?v= differs: the picture changed on another screen. Its
   *    width and height changed with it, and drawing the new picture in this
   *    screen's old frame is the stretched map of issue #62, so the whole map
   *    list is re-read and the links come with it (not in the maps view,
   *    which may be mid-edit; it re-reads the list on its own saves).
   *  - only the signatures differ (a restart, or a link near its end): swap
   *    them in.
   */
  async _renewMapImageUrls(){
    const r = await this._callWS({ type: "padspan_ha/maps_image_urls" });
    if(!r || !r.image_urls) return;
    const fresh = r.image_urls, old = _mapImageUrls;
    const ver = (u) => { const m = /[?&]v=([^&]*)/.exec(u || ""); return m ? m[1] : ""; };
    const ids = Object.keys(fresh);
    const pictureChanged = ids.length !== Object.keys(old).length
      || ids.some(id => !(id in old) || ver(old[id]) !== ver(fresh[id]));
    if(pictureChanged){
      if(this.state.view !== "maps"){
        await this._getMapsList(false);   // sets the links and their time
        this._scheduleRender(true);
      } else {
        // Mid-edit: the changed pictures wait for the list, the unchanged
        // ones still get their fresh signatures (they may have died with a
        // restart).
        const kept = {};
        for(const id of Object.keys(old)){
          kept[id] = (id in fresh && ver(fresh[id]) === ver(old[id])) ? fresh[id] : old[id];
        }
        _mapImageUrls = kept;
        this._mapUrlsAt = Date.now();     // ask again in 10 minutes, not every tick
      }
      return;
    }
    this._mapUrlsAt = Date.now();
    if(ids.some(id => old[id] !== fresh[id])){
      _mapImageUrls = fresh;
      if(this.state.view !== "maps") this._scheduleRender(true);
    }
  }

  async _getMapsList(retry = true){
    // The floor plan is invisible without this list, so unlike other fetches
    // a failure here gets one retry, and a failed/malformed response never
    // clobbers a previously-good list (blank-map prevention).
    // Which house it is for: _houseGen, not this._hass (a new one on every
    // state change). An answer about the other house is dropped and asked again.
    const gen = this._houseGen;
    try {
      const res = await this._callWS({ type: "padspan_ha/maps_list" });
      if(gen !== this._houseGen) return this._getMapsList(retry);
      if(Array.isArray(res?.maps)){
        _mapImageUrls = res.image_urls || {};
        this._mapUrlsAt = Date.now();
        this.state.maps.list = res.maps;
        this.state._mapsLoaded = true;      // an empty list is still an ANSWER
        if(this.state.activeMapId && !this.state.maps.list.find(m=>m.id===this.state.activeMapId)){
          this.state.activeMapId = null;
        }
      }
    } catch(e){
      if(retry){
        await new Promise(r => setTimeout(r, 1000));
        return this._getMapsList(false);
      }
      console.warn("PadSpan: maps_list failed after retry:", e);
      throw e;  // let callers (allSettled logging) see the failure
    }
  }


  async _getModel(){
    const gen = this._houseGen;  // as in _getMapsList
    try {
      const res = await this._callWS({ type: "padspan_ha/model_get" });
      if(gen !== this._houseGen) return this._getModel();
      // Copy EVERYTHING the backend sends. This used to be a hand-written
      // whitelist, and it dropped keys three separate times in one session —
      // origin forwarding, the migration marker, then light_positions_m and
      // floor_elevations, which left every correctly-placed light rendering as
      // unplaced. A whitelist here can only ever be wrong in one direction:
      // the backend adds a field, the panel silently discards it, and the
      // symptom shows up somewhere unrelated. Defaults below exist only so
      // views can index the common collections without null checks; any key
      // the backend adds from now on simply arrives.
      const defaults = {
        floors: [], areas: [], room_meta: {}, scanners: {}, room_adjacency: {},
        fabric_sync_mode: "auto", scanner_positions_m: {}, room_geometry_m: {},
        rf_barriers_m: [], map_transforms: {}, beacon_positions_m: {},
        light_positions_m: {}, floor_elevations: {}, fabric_floors: {},
      };
      this.state.model = { ...defaults, ...(res && typeof res === "object" ? res : {}) };
      this.state._modelLoaded = true;
    } catch (e) {
      if(gen !== this._houseGen) return this._getModel();
      // non-fatal
      console.warn("model_get failed", e);
    }
    // Views that resolve HA area NAMES (the Lights tab's entity registry
    // pipeline) must wait for this fetch to settle — resolving before it
    // lands marks every light unassigned and caches that. Set on failure
    // too, or the view would show a loading state forever.
    this.state._modelLoaded = true;
  }

  async _runAutoDiag(userAction=false){
    try {
      const t0 = performance.now();
      const res = await this._callWS({ type: "padspan_ha/auto_diagnostics" });
      this.state.diag = res;
      this.state.timing.lastDiagMs = Math.round(performance.now() - t0);
      if(userAction) this._toast("Auto diagnostics complete.");
    } catch (e) {
      this.state.diag = {
        version: APP_VERSION,
        error: String(e),
        summary: { ok:false, total:1, passed:0, failed:1 },
        checks: [{ name:"ws_auto_diagnostics", ok:false, detail:String(e) }],
        recommendations: ["Check Home Assistant logs for padspan_ha errors."],
      };
      if(userAction) this._toast("Auto diagnostics failed. See Monitor → Export for support.", true);
    }
  }

  /**
   * Full data refresh — fetches ALL backend state in parallel.
   * Called on boot, reconnect, wake-up, and user "Refresh" button.
   *
   * IMPORTANT ordering: settings are fetched FIRST (awaited) so that dataMode
   * is correct before _getLiveSnapshot runs. Without this, a race condition
   * causes _getLiveSnapshot to see "sample" mode and assign SAMPLE_SNAPSHOT
   * even when the user is in live mode.
   */
  async _refreshAll(userAction=false){
    if(!this._hass) return;
    const t0 = performance.now();
    if(userAction) this._toast("Refreshing…");
    await Promise.allSettled([this._fetchSettings()]);
    // Sample mode: the sample house answers everything below (_sampleCall).
    if(this._sampleGateOn()) await this._ensureSampleHouse();
    // Stamp the throttle _pollTick's own quiet settings repoll checks
    // against, so the very next 5s tick doesn't immediately re-fetch what
    // was just fetched here.
    this._settingsPollTs = Date.now();
    // Fetch the small critical geometry FIRST, awaited: the floor plan is
    // unrenderable without maps_list + model, and batching them with the
    // heavyweight live_snapshot meant a snapshot big enough to kill the WS
    // connection took the map geometry down with it (blank map on first
    // entry). These two are tiny; land them before anything heavy runs.
    const critResults = await Promise.allSettled([
      this._getMapsList(),
      this._getModel(),
    ]);
    // Now run remaining fetches in parallel (dataMode is now correct)
    const results = await Promise.allSettled([
      this._getVersionInfo(),
      this._getStatus(),
      this._getRoomTags(),
      this._getLiveSnapshot(),
      this._runAutoDiag(false),
      this._loadAlertConfigs(),
    ]);
    // Log any WS failures to console for debugging
    const critNames = ["getMapsList","getModel"];
    critResults.forEach((r,i)=>{ if(r.status==="rejected") console.warn("PadSpan refresh:", critNames[i], "failed:", r.reason); });
    const names = ["getVersionInfo","getStatus","getRoomTags","getLiveSnapshot","runAutoDiag","loadAlerts"];
    results.forEach((r,i)=>{ if(r.status==="rejected") console.warn("PadSpan refresh:", names[i], "failed:", r.reason); });
    this._recomputeDerived();
    try { this.state.timing.lastRefreshMs = Math.round(performance.now() - t0); } catch(e){}
    try { this._updateBadges(); } catch(e){}
    this._versionPollTs = Date.now();
    try { this._checkBuild(); } catch(e){}
    this._scheduleRender();
  }

  /** Update the desktop topbar status pills and mobile topbar pills to reflect current state. */
  /** Basic / Advanced / Development: the toggle at the top, and a view that
   *  needs Advanced for what was just asked of it (Mapping's Open in Basic,
   *  Jay 2026-10-04: the button did nothing at all). */
  _setComplexity(mode){
    this.state.complexity = mode;
    this.state._focus = null;   // a focused part is Basic's only (views/focus.js)
    try { localStorage.setItem("padspan_complexity", mode); } catch(e) {}
    // If switching to basic/advanced and current view isn't visible, go to
    // follow — unless the URL explicitly pinned the view (kiosk deep-link).
    if (mode !== "development") {
      const visible = this._getVisibleTabs();
      if (!visible.has(this.state.view) && this.state.view !== this._urlPinnedView) this.state.view = "follow";
    }
    this._updateBadges();
    this._renderNav();
    this._scheduleRender();
  }

  _updateBadges(){
    const scan = this.state.status?.scan_interval ?? "—";
    const st = this.state.status?.status ?? "—";
    this.$("#scanBadge").textContent = `Scan: ${scan}s`;
    this.$("#statusBadge").textContent = `Status: ${st}`;
    this.$("#cloudBadge").textContent = "Cloud disabled";
    this._updateEmergencyBanner();
    this._paintStatusDot();

    this._paintDataModeLabel();
    const cb = this.$("#complexityToggle");
    if(cb){
      const mode = this.state.complexity;
      cb.textContent = mode === "basic" ? "Basic" : mode === "advanced" ? "Advanced" : "Dev";
      cb.style.outline = mode === "basic" ? "2px solid rgba(94,234,212,.6)"
                       : mode === "development" ? "2px solid rgba(239,83,80,.5)" : "";
    }
  }

  /** The status dot (views/status_dot.js): one live poll's look at what is
   *  wrong, through the persistence rule. `failed`: the poll got no answer. */
  _updateStatusDot(failed){
    if (!STATUS_DOT) return;
    // Warm-up: from the first poll, and again whenever PadSpan answers after
    // not answering (Home Assistant restarting), receivers get two minutes to
    // report in before "no receivers reporting" can count.
    const now = Date.now();
    if (!this._statusDotWarmUntil || (!failed && this._statusDotLastFailed)) this._statusDotWarmUntil = now + STATUS_DOT.WARMUP_MS;
    this._statusDotLastFailed = !!failed;
    const s = this.state.settings || {};
    const excluded = [...(Array.isArray(s.excluded_scanners) ? s.excluded_scanners : []),
      ...Object.keys(s.lost_radios || {}), ...Object.keys(s.disabled_radios || {})];
    const issues = STATUS_DOT.statusIssues({
      live: this.state.dataMode === "live", failed,
      snapshot: this.state.live && this.state.live.snapshot,
      excluded, warmup: now < this._statusDotWarmUntil,
      receivers: !(EDITIONS && EDITIONS.surfacesForEdition) || EDITIONS.surfacesForEdition(["receivers"], s).length > 0,
    });
    this._statusDotTrack = this._statusDotTrack || new Map();
    this._statusDotActive = STATUS_DOT.trackIssues(this._statusDotTrack, issues);
    this._paintStatusDot();
  }

  /** Nothing when all is well (and in sample mode); a dot with a mark and a
   *  count otherwise, its words in the tooltip and aria-label. On a wall
   *  screen red only: ?kiosk=1 hides the top bars, so there it sits in a
   *  corner and only says so (nobody is there to click). No toast, no sound. */
  _paintStatusDot(){
    if (!STATUS_DOT || !this.shadowRoot || !this.state) return;
    if (this.state.dataMode !== "live") { this._statusDotTrack = null; this._statusDotActive = null; }
    const kiosk = !!this.state.kioskMode;
    // A full-screen window counts as a wall once nobody has touched it for two
    // minutes (the self-reload's own rule): a desktop at F11 still sees amber.
    const wall = kiosk || (wallScreen(false) && untouchedFor(120000));
    const view = STATUS_DOT.dotView(this._statusDotActive || [], { wall });
    for (const b of this.shadowRoot.querySelectorAll("[data-status-dot]")) {
      const wallHost = b.getAttribute("data-status-dot") === "wall";
      const show = !!view && (wallHost ? kiosk : !kiosk);
      if (!show) {
        if (!b.classList.contains("hidden")) { b.className = "status-dot hidden" + (wallHost ? " status-dot-wall" : ""); b.textContent = ""; }
        b.removeAttribute("title"); b.removeAttribute("aria-label");
        continue;
      }
      const sig = view.level + "|" + view.count + "|" + view.label;
      b.className = "status-dot status-dot-" + view.level + (wallHost ? " status-dot-wall" : "");
      if (b._dotSig === sig && b.childElementCount) continue;
      b._dotSig = sig;
      b.title = view.label;
      b.setAttribute("aria-label", view.label);
      b.textContent = "";
      b.appendChild(el("span", { class: "status-dot-mark", "aria-hidden": "true" }, "!"));
      b.appendChild(el("span", { class: "status-dot-n", "aria-hidden": "true" },
        wallHost ? (view.count === 1 ? "1 problem" : view.count + " problems") : String(view.count)));
      // The wall's role="status" box is read out by its text, not a label:
      // the words, there for a screen reader only.
      if (wallHost) b.appendChild(el("span", { class: "status-dot-sr" }, view.label));
    }
  }

  /** The dot pressed: Health, where the details are (in every mode: Basic
   *  has it under More tools, so the mode stays as it is). */
  _openHealthFromDot(){
    this._telemetryEvent("status_dot_open");
    this.state.view = "health";
    this._logEvent("view_change", "health");
    if (this._closeDrawer) this._closeDrawer();
    this._updateBadges();
    this._renderNav();
    if (!VIEWS.health && _VIEW_PATHS.health) _loadView("health").then(() => this._scheduleRender());
    this._scheduleRender();
  }

  /** Flood alarm latches (flood_latch.py), off to the side regardless of the
   *  active tab (2026-09-19: "Is there something like an emergency
   *  resets button off to the side?") — not buried in whichever room/table
   *  row the sensor happens to appear in. Hidden entirely when nothing is
   *  latched; expires_at math mirrors flood_latch.py's is_active() and
   *  views/iso_lights.js's floodLatchActive(), same window, same rule. */
  _updateEmergencyBanner(){
    const latches = this.state.settings?.flood_latches || {};
    const nowS = Date.now() / 1000;
    const active = Object.entries(latches).filter(([, rec]) =>
      rec && typeof rec.expires_at === "number" && nowS < rec.expires_at);

    const banner = this.$("#emergencyBanner");
    const countEl = this.$("#emergencyBannerCount");
    const listEl = this.$("#emergencyBannerList");
    const mobilePill = this.$("#mobileEmergencyPill");
    if(!banner || !countEl || !listEl) return;

    if(!active.length){
      banner.classList.add("hidden");
      if(mobilePill) mobilePill.classList.add("hidden");
      this._emergencyListSig = "";
      return;
    }
    banner.classList.remove("hidden");
    countEl.textContent = `${active.length} active`;
    if(mobilePill){ mobilePill.classList.remove("hidden"); mobilePill.textContent = `🚨 ${active.length}`; }

    listEl.className = "emergency-banner-list";
    // Rebuilt only when the set of alarms changes: this runs on every poll,
    // and rebuilding wiped a Reset -> Yes/No confirm within a second or five,
    // so Yes was nearly impossible to press.
    // The latches are the real house's in Sample mode too: so are their names.
    const realStates = (this._realHass || this._hass)?.states;
    const sample = this.state.dataMode !== "live";
    const _sig = (sample ? "sample|" : "") + active.map(([eid]) => eid + "=" + (realStates?.[eid]?.attributes?.friendly_name || "")).sort().join("|");
    if(this._emergencyListSig === _sig && listEl.childElementCount) return;
    this._emergencyListSig = _sig;
    listEl.innerHTML = "";
    for(const [eid] of active){
      const name = realStates?.[eid]?.attributes?.friendly_name || eid;
      const row = document.createElement("div");
      row.className = "emergency-banner-row";
      const nameEl = document.createElement("span");
      nameEl.className = "name"; nameEl.title = name; nameEl.textContent = name;
      row.appendChild(nameEl);
      const wrap = document.createElement("span");
      // Two-click confirm — the same "Reset -> Yes/No" pattern the Manage
      // tab's Untag button already uses, so a stray tap can't dismiss a
      // real alarm.
      const makeResetBtn = () => {
        const b = document.createElement("button");
        b.className = "btn tiny"; b.textContent = "Reset";
        b.addEventListener("click", (e) => {
          e.stopPropagation();
          wrap.innerHTML = "";
          const yes = document.createElement("button");
          yes.className = "btn tiny"; yes.style.cssText = "background:#7f1d1d;border-color:#dc2626;color:#fecaca";
          yes.textContent = "Yes";
          const no = document.createElement("button");
          no.className = "btn tiny"; no.textContent = "No";
          yes.addEventListener("click", async (e2) => {
            e2.stopPropagation();
            wrap.innerHTML = "";
            this._emergencyListSig = "";     // the next update rebuilds the row, Reset and all
            try { await this._callWS({ type: "padspan_ha/flood_reset", entity_id: eid }); await this._loadSettings(); }
            catch(err){ console.warn("flood reset failed", err); wrap.appendChild(makeResetBtn()); }
          });
          no.addEventListener("click", (e2) => { e2.stopPropagation(); wrap.innerHTML = ""; wrap.appendChild(makeResetBtn()); });
          wrap.appendChild(yes); wrap.appendChild(no);
        });
        return b;
      };
      // Sample mode: the alarm is the real house's, and so is its Reset: the way there.
      if (sample) {
        const back = document.createElement("button");
        back.className = "btn tiny"; back.textContent = "Back to my house";
        back.addEventListener("click", (e) => { e.stopPropagation(); this._setDataMode("live"); });
        wrap.appendChild(back);
      } else wrap.appendChild(makeResetBtn());
      row.appendChild(wrap);
      listEl.appendChild(row);
    }
  }

  // ── Navigation & View Routing ───────────────────────────────────────────────
  // The sidebar (desktop) and bottom nav (mobile) are built from the MENU array,
  // filtered by the current complexity mode. Clicking a nav item sets state.view
  // and calls _renderCurrentView(), which looks up the module in the VIEWS map
  // and calls its render(ctx) function.

  /** Return the Set of tab IDs in the menu: every screen, in every mode
   *  (the mode decides only which of them sit under More tools). */
  _getVisibleTabs(){
    // Forensics is settings-gated in EVERY mode (including Dev): the tab only
    // exists while the opt-in forensics_enabled setting is on.
    const forensicsOn = this.state.settings?.forensics_enabled === true;
    // Guests the same way: the tab exists only while guest tags are on
    // (Settings → Presence → Guest tags), in every mode.
    const guestsOn = this.state.settings?.guest_tags_enabled === true;
    let out = new Set(MENU.map(x => x[0]));
    if (!forensicsOn) out.delete("forensics");
    if (!guestsOn) out.delete("guests");
    if (!this._setupInMenu()) out.delete("setup");
    // The EDITION decides last: a Bright build shows its lighting surfaces
    // (and the rest only behind the reveal switch). The full edition is
    // untouched by this — surfacesForEdition returns its input.
    if (EDITIONS && EDITIONS.surfacesForEdition) {
      out = new Set(EDITIONS.surfacesForEdition([...out], this.state.settings || {}));
    }
    return out;
  }

  /** Setup in the menu (owner's D4, 2026-11-13; review 2026-11-11): at the
   *  top of the build group until the house has FINISHED set-up (every step
   *  done) or SKIPPED it (Getting started's "Skip
   *  setup", onboarding_completed; Setup's Finish, setup_progress.done; or
   *  every step not done skipped), so a new house with nothing yet has it
   *  (review 2026-11-11, item 0). Out of it Setup is still reached from
   *  Getting started and Mapping's Setup button. Only on the house's own
   *  data, never on a wall screen, once the stores that answer it are in.
   *  Calibration's points are asked only when calibration is the one step
   *  that decides, once a page load (never on a wall; not on the Overview,
   *  which asks them itself and draws the menu again when they come); a
   *  failure leaves the menu as it is until the next page load. */
  _setupInMenu(){
    const st = this.state, ss = SETUP_STATUS;
    if (st.dataMode !== "live" || st.kioskMode || !ss || !st._mapsLoaded || !st._modelLoaded) return false;
    const s = st.settings || {}, p = s.setup_progress || {};
    const skipped = Array.isArray(p.skipped) ? p.skipped : [];
    if (s.onboarding_completed || p.done === true) return false;
    const open = ss.setupSteps(st).filter(x => ss.stepDone(st, x.id) !== true && !skipped.includes(x.id));
    if (!open.length) return false;
    if (st.calibration || open.some(x => x.id !== "calibration")) return true;
    if (!this._menuCalAsked && this._callWS && st.view !== "overview") {
      this._menuCalAsked = true;
      this._callWS({ type: "padspan_ha/calibration_get" })
        .then(d => { if (!this.state.calibration && d) { this.state.calibration = d; this._renderNav(); } })
        .catch(() => {});
    }
    return false;
  }

  /** The tabs in the main groups for the current mode; every other visible
   *  tab is under More tools. Basic keeps its short list; Advanced and
   *  Development share one (Development changes detail inside screens), plus
   *  the tabs Settings → UI Structure opted in. Forensics and Guests, while
   *  switched on, are main tabs in every mode. */
  _getMainTabs(){
    const s = this.state.settings || {};
    const out = new Set(this.state.complexity === "basic" ? BASIC_TABS : ADVANCED_DEFAULT);
    if (this.state.complexity !== "basic") for (const t of (s.advanced_extra_tabs || [])) out.add(t);
    out.add("forensics");
    out.add("guests");
    const visible = this._getVisibleTabs();
    return new Set([...out].filter(id => visible.has(id)));
  }

  /** More tools open or closed: closed until opened, remembered per browser. */
  _moreToolsOpen(){
    try { return localStorage.getItem("padspan_more_tools") === "open"; }
    catch (e) { return this._moreToolsMem === true; }
  }

  _toggleMoreTools(){
    const open = !this._moreToolsOpen();
    this._moreToolsMem = open;
    try { localStorage.setItem("padspan_more_tools", open ? "open" : "closed"); } catch (e) {}
    // Opt-in usage report: whether anyone opens it (only the opening is counted).
    if (open) this._telemetryEvent("menu_more_tools_open");
    this._renderNav();
  }

  /** Whether a view opened by a ?view= link stays open though the menu
   *  doesn't list it (issue #93): it opens "regardless of the complexity
   *  mode", so only what really isn't there sends it back to the menu's
   *  first item: a view this edition doesn't have (Bright), or Forensics
   *  while it is switched off. Until settings arrive neither can be known,
   *  and the first nav render comes before them, so the link is kept. */
  _keepsLinkedView(view){
    if (!view || view !== this._urlPinnedView) return false;
    if (!this._settingsLoaded) return true;
    const settings = this.state.settings || {};
    if (view === "forensics" && settings.forensics_enabled !== true) return false;
    if (view === "guests" && settings.guest_tags_enabled !== true) return false;
    if (EDITIONS && EDITIONS.surfacesForEdition && !EDITIONS.surfacesForEdition([view], settings).length) return false;
    return true;
  }

  /** Rebuild the sidebar nav, mobile bottom nav, and mobile topbar to match current state. */
  _renderNav(){
    const isBasic = this.state.complexity === "basic";
    const visible = this._getVisibleTabs();
    this.$nav.innerHTML = "";
    this.$nav.className = isBasic ? "nav basic-nav" : "nav";
    const navLabel = this.shadowRoot.querySelector("#navLabel");
    if(navLabel) navLabel.textContent = isBasic ? "Basic Menu" : this.state.complexity === "development" ? "Dev Menu" : "Menu";

    const items = MENU.filter(x => visible.has(x[0]));
    // A view this build does not show cannot stay current: a Bright install
    // starts on Overview by default and Overview is a presence surface, so it
    // lands on the first surface it does show (Mapping). A ?view= link is
    // kept, as the deep-link block promises (_keepsLinkedView, issue #93).
    if (items.length && !visible.has(this.state.view) && !_VIEW_PATHS_HIDDEN_OK.has(this.state.view)
        && !this._keepsLinkedView(this.state.view)) {
      this.state.view = items[0][0];
      this._scheduleRender();
    }
    // Main groups and More tools. More tools lists in MENU_GROUPS order
    // (Live, Build, Diagnose, Internals), anything ungrouped last.
    const main = this._getMainTabs();
    const _order = MENU_GROUPS.flatMap(g => g[1]);
    const _rank = (id) => { const i = _order.indexOf(id); return i < 0 ? _order.length : i; };
    const moreItems = items.filter(x => !main.has(x[0])).sort((a, b) => _rank(a[0]) - _rank(b[0]));
    const moreOpen = this._moreToolsOpen();
    // The disclosure, then its screens. Closed, it still shows the screen
    // open now if that is one of them, so the menu always says where you are.
    const _moreTools = (button) => {
      if (!moreItems.length) return;
      const t = el("button", {
        class: "navbtn navmore", title: "More tools", "aria-expanded": moreOpen ? "true" : "false",
        onclick: () => this._toggleMoreTools()
      });
      t.innerHTML = '<svg class="navicon navchev" viewBox="0 0 24 24" aria-hidden="true"><path d="M9 6l6 6-6 6"/></svg>';
      t.appendChild(el("span", { class: "navlabel" }, "More tools"));
      this.$nav.appendChild(t);
      for (const [id, label] of moreItems) {
        if (moreOpen || id === this.state.view) this.$nav.appendChild(button(id, label));
      }
    };
    const _switchView = (id) => {
      // Clear traceback active flag when leaving traceback tab
      if (this.state._traceback && this.state.view === "traceback" && id !== "traceback") {
        this.state._traceback.active = false;
        if (this.state._traceback._animTimer) {
          clearInterval(this.state._traceback._animTimer);
          this.state._traceback._animTimer = null;
          this.state._traceback.playing = false;
        }
      }
      // Leaving Calibration ends any confirm it had open (Delete radio, an
      // overlapping-map popup): the render guard reads these flags panel-wide,
      // so a pending one kept every other view from rendering.
      if (this.state.view === "calibration" && id !== "calibration") {
        if (this.state._calibTune) this.state._calibTune._confirming = false;
        if (this.state._calibBeacon) this.state._calibBeacon._confirming = false;
        if (this.state._calib) this.state._calib._resultsCounted = false;   // the next visit to Results counts
      }
      // A link's focused part in Basic (views/focus.js): the menu's Settings
      // is Appearance again, its Mapping Library.
      this.state._focus = null;
      this.state.view = id;
      this.state._setupReturn = null;   // a menu pick leaves the guided Setup's step
      this._logEvent("view_change", id);
      // Opt-in usage report: count the tab open.
      this._telemetryEvent("tab:" + id);
      if (this._closeDrawer) this._closeDrawer();
      this._renderNav();
      // On-demand: if the view module isn't loaded yet, fetch it then render
      if (!VIEWS[id] && _VIEW_PATHS[id]) {
        this._scheduleRender(); // shows skeleton placeholder
        _loadView(id).then(() => this._scheduleRender());
      } else {
        this._scheduleRender();
      }
    };

    if (this._skin === "2025") {
      // Grouped icon list. `items` above stays the flat, MENU-ordered
      // visibility set — the items[0][0] fallback a few lines up depends on
      // that, so headings are appended as a separate pass and never enter it.
      const byId = new Map(items.filter(x => main.has(x[0])).map(x => [x[0], x[1]]));
      const _navButton = (id, label) => {
        const btn = el("button", {
          class: "navbtn" + (this.state.view === id ? " active" : ""),
          title: label,          // survives the collapse to the 60px icon rail
          onclick: () => _switchView(id)
        });
        // MENU_ICONS is a module constant, never user input.
        btn.innerHTML = `<svg class="navicon" viewBox="0 0 24 24" aria-hidden="true">${MENU_ICONS[id] || ""}</svg>`;
        btn.appendChild(el("span", { class: "navlabel" }, label));
        return btn;
      };
      const seen = new Set();
      let firstHeading = true;
      const _heading = (text) => {
        // Basic mode shows six tabs; headings would outnumber the content.
        if (isBasic) return;
        this.$nav.appendChild(el("div", { class: "navgrp" + (firstHeading ? " first" : "") }, text));
        firstHeading = false;
      };
      for (const [heading, ids] of MENU_GROUPS) {
        const present = ids.filter(id => byId.has(id));
        if (!present.length) continue;
        _heading(heading);
        for (const id of present) { seen.add(id); this.$nav.appendChild(_navButton(id, byId.get(id))); }
      }
      // A MENU entry that nobody added to MENU_GROUPS still renders.
      const orphans = items.filter(x => byId.has(x[0]) && !seen.has(x[0]));
      if (orphans.length) {
        _heading("More");
        for (const [id, label] of orphans) this.$nav.appendChild(_navButton(id, label));
      }
      _moreTools(_navButton);
    } else {
      const _classicButton = (id, label) => {
        const color = MENU_COLORS[id] || "#37588f";
        return el("button",{
          class:"navbtn"+(this.state.view===id?" active":""),
          style:`--navcolor:${color}`,
          onclick:()=>_switchView(id)
        }, [el("span",{class:"navdot"}), el("span",{}, label)]);
      };
      for(const [id,label] of items.filter(x => main.has(x[0]))) this.$nav.appendChild(_classicButton(id, label));
      _moreTools(_classicButton);
    }

    // ── Mobile bottom nav: pinned tabs + "More" button ──────────────
    const bottomNav = this.shadowRoot.querySelector("#mobileBottomNav");
    if (bottomNav) {
      bottomNav.innerHTML = "";
      // Pinned tabs vary by complexity mode
      const pinned = isBasic
        ? ["follow","overview","maps","settings"]
        : ["follow","overview","maps","calibration"];
      for (const pid of pinned) {
        const mi = MENU.find(x => x[0] === pid);
        if (!mi) continue;
        const color = MENU_COLORS[pid] || "#37588f";
        const isActive = this.state.view === pid;
        const btn = document.createElement("button");
        btn.className = "mobile-bottom-nav-btn" + (isActive ? " active" : "");
        btn.style.cssText = `--navcolor:${color}`;
        btn.innerHTML = `<span class="bn-dot" style="background:${color}"></span><span>${esc(mi[1])}</span>`;
        btn.addEventListener("click", () => _switchView(pid));
        bottomNav.appendChild(btn);
      }
      // "More" button opens the sidebar drawer
      const moreBtn = document.createElement("button");
      moreBtn.className = "mobile-bottom-nav-btn";
      moreBtn.style.cssText = "--navcolor:#78909c";
      // Highlight "More" if the current view isn't one of the pinned tabs
      if (!pinned.includes(this.state.view)) {
        moreBtn.classList.add("active");
        moreBtn.style.cssText = `--navcolor:${MENU_COLORS[this.state.view] || "#78909c"}`;
      }
      moreBtn.innerHTML = `<span class="bn-dot" style="background:#78909c"></span><span>More</span>`;
      moreBtn.addEventListener("click", () => {
        if (this.$("#app").classList.contains("mobile-open")) {
          if (this._closeDrawer) this._closeDrawer();
        } else {
          this.$("#app").classList.add("mobile-open");
          this.$("#sideBackdrop").classList.add("active");
        }
      });
      bottomNav.appendChild(moreBtn);
    }

    // ── Mobile topbar: update title and pills ───────────────────────
    const mobileTitle = this.shadowRoot.querySelector("#mobileTitle");
    if (mobileTitle) {
      const mi = MENU.find(x => x[0] === this.state.view);
      mobileTitle.textContent = mi ? mi[1] : this.state.view === "setup" ? "Setup" : UNLISTED_VIEW_TITLES[this.state.view] || "PadSpan";
    }
    this._paintDataModeLabel();
    const mobileModePill = this.shadowRoot.querySelector("#mobileModePill");
    if (mobileModePill) {
      mobileModePill.textContent = isBasic ? "Basic" : this.state.complexity === "development" ? "Dev" : "Adv";
      mobileModePill.className = "mobile-topbar-pill" + (isBasic ? " basic" : "");
    }
    this._renderSidebarTrial();
  }

  /** HELP in hass's language, loaded on first need (the first "?" or the
   *  Training page), not at startup: a shipped one fetches
   *  i18n/<lang>/help.json (~340 KB) and rebuilds HELP through it; English
   *  keeps the imported HELP untouched and fetches nothing. Once per language;
   *  one that failed to load (offline, a 404) is tried again by a "?" a
   *  minute or more later. */
  _loadHelpLanguage(){
    const lang = this._langSeen, was = this._helpLoad;
    if(was && was.lang === lang && !(was.failedAt && Date.now() - was.failedAt >= 60000)) return was.p;
    const before = HELP;
    const load = this._helpLoad = { lang, p: null, done: false, failedAt: 0 };
    let I18N = null;
    const p = load.p = Promise.all([_i18nPromise, _criticalPromise]).then(([m]) => (I18N = m) ? I18N.useLanguage(this._hass, ["help"]) : "en").then(got => {
      // A shipped language that came back English: its help.json didn't load.
      if(got === "en" && I18N && I18N.LANGUAGES.includes(I18N.langOf(this._hass))) load.failedAt = Date.now();
      if(HELP_MOD && (got !== "en" || HELP !== HELP_MOD.HELP)) HELP = got === "en" ? HELP_MOD.HELP : HELP_MOD.helpTexts();
      // Training draws from HELP: redraw it once the translation is in.
      if(HELP !== before && this.state && this.state.view === "training") this._scheduleRender();
    }).catch(err => { load.failedAt = Date.now(); console.warn("PadSpan: help translation failed to load", err); });
    p.then(() => { load.done = true; });
    return p;
  }

  /** Open a help modal for the given key. While the translated help is still
   *  loading, the modal opens at once with a loading line and fills in when
   *  it arrives, or in English after 2 s; a translation arriving later still
   *  replaces that English if the same help is open. An unknown key says so
   *  at once, but only once help_content.js is in (HELP_MOD): a "?" before
   *  that waits for it like the rest. */
  _showHelp(key){
    this._loadHelpLanguage();
    if(this._helpLoad.done || (HELP_MOD && !HELP[key])) return this._openHelp(key);
    this._openModal("", '<div style="color:#94a3b8;font-size:14px">Loading help…</div>');
    const top = () => this.$modal && this.$modal.firstChild;
    let shown = top();   // our modal, until it is closed or another replaces it
    // No such help (help_content.js never loaded): close the loading line, toast.
    const fill = () => { if(shown && shown === top()){ if(!HELP[key]) this._closeModal(); this._openHelp(key); shown = top(); } };
    // The latest load: a language changed meanwhile is followed to its end.
    const settled = (load) => load.p.then(() => this._helpLoad !== load ? settled(this._helpLoad) : null);
    let english = null, waited = false;
    settled(this._helpLoad).then(() => { waited = true; if(english !== HELP) fill(); });
    setTimeout(() => { if(!waited){ english = HELP; fill(); } }, 2000);
  }

  /** The help modal itself (content from help_content.js). */
  _openHelp(key){
    const h = HELP[key];
    if(!h){ this._toast("No help entry for: " + key, false); return; }
    const body = document.createElement("div");
    body.style.cssText = "line-height:1.75;font-size:14px";
    // A translated page opens with a note: the rest of the panel is English.
    const note = HELP_MOD && HELP_MOD.helpNote ? HELP_MOD.helpNote() : "";
    if(note){
      const n = document.createElement("div");
      n.style.cssText = "margin-bottom:12px;color:#94a3b8;font-size:13px;font-style:italic";
      n.textContent = note;
      body.appendChild(n);
    }
    const paras = Array.isArray(h.body) ? h.body : [h.body];
    for(const p of paras){
      const d = document.createElement("div");
      d.style.cssText = "margin-bottom:12px;color:#cbd5e1";
      d.textContent = p;
      body.appendChild(d);
    }
    this._openModal(h.title, body, "");
  }

  // ── Context Object (ctx) ────────────────────────────────────────────────────
  // Every view's render(ctx) receives this object. It provides:
  //   ctx.hass     — the HA hass object (for callWS, states, etc.)
  //   ctx.state    — the full application state (read-only by convention)
  //   ctx.helpers  — pure utility functions (el, esc, roomColor, etc.)
  //   ctx.actions  — mutation methods that update state + trigger re-renders
  //   ctx.toast    — show a temporary notification message
  //
  // This pattern keeps views as pure render functions with no direct access
  // to the PadSpanHaApp instance, making them easier to test and reason about.
  // A screen opened from a link inside another one ("All rooms", "All
  // receivers"): counted as a tab open, highlighted like a menu pick, loaded
  // if the background load has not reached it yet.
  _openCountedView(id){
    this.state._focus = null;   // views/focus.js
    this.state.view = id;
    this._telemetryEvent("tab:" + id);
    this._renderNav();
    if (!VIEWS[id]) _loadView(id).then(() => this._scheduleRender());
    this._scheduleRender();
  }

  _ctx(){
    const self = this;
    return {
      hass: this._hass,
      state: this.state,
      helpers: {
        el, esc, pill,
        HELP,
        /** "" in English; in a shipped language, the note a translated help page opens with. */
        helpNote: () => (HELP_MOD && HELP_MOD.helpNote ? HELP_MOD.helpNote() : ""),
        trainingNote: () => (HELP_MOD && HELP_MOD.trainingNote ? HELP_MOD.trainingNote() : ""),
        mapImageUrl,
        radioShortId,
        awayTimeoutS,
        isAway,
        /** Map source → friendly name from live radios. Returns "" if no name or same as source. */
        radioName: (source)=>{
          const s = String(source || "");
          const radios = (self.state.live?.snapshot?.ble?.radios) || [];
          const r = radios.find(r => String(r.source || "") === s);
          const n = r && (r.display_name || r.name);
          return (n && n !== s) ? n : "";
        },
        scannerStatus,
        roomColor: (n)=>roomColor(n, this.state.model),
        roomColorAlpha,
        helpBtn: (key, title)=>{
          const b = document.createElement("button");
          b.className = "btn-help";
          b.title = title || "Help";
          b.textContent = "?";
          b.addEventListener("click", (e)=>{ e.stopPropagation(); self._showHelp(key); });
          return b;
        },
        /** Set of uppercase addresses/sources belonging to known BLE scanners.
         *  Use to filter scanners out of object/tracking views. */
        scannerAddrs: ()=>{
          const s = new Set();
          const radios = (self.state.live?.snapshot?.ble?.radios) || [];
          for(const r of radios){
            if(r.source) s.add(String(r.source).toUpperCase());
            if(r.name) s.add(String(r.name).toUpperCase());
          }
          return s;
        },
        /** Returns true if this object is a known scanner (not a trackable device). */
        isScanner: (obj)=>{
          const radios = (self.state.live?.snapshot?.ble?.radios) || [];
          const addr = (obj.address || "").toUpperCase();
          const name = (obj.name || "").toUpperCase();
          const eid = (obj.entity_id || "").toUpperCase();
          for(const r of radios){
            const rs = (r.source || "").toUpperCase();
            const rn = (r.name || "").toUpperCase();
            if(rs && (rs === addr || rs === eid || rs === name)) return true;
            if(rn && (rn === addr || rn === name)) return true;
            // Match by MAC in source against any of the object's addresses
            if(rs && Array.isArray(obj.all_addresses)){
              for(const a of obj.all_addresses){ if(a && String(a).toUpperCase() === rs) return true; }
            }
          }
          return false;
        },
      },
      // ── Actions ──────────────────────────────────────────────────────────
      // All state mutations flow through these action methods.
      // Views call ctx.actions.xyz() which updates state, makes WS calls,
      // and triggers re-renders as needed. Grouped by domain below.
      actions: {
        // Re-render triggers (views call these after local UI changes)
        renderRooms: ()=>this._scheduleRender(),
        renderNav: ()=>this._renderNav(),
        // The Receivers page (views/receivers.js), from the screens that list
        // receivers (their "All receivers" link): counted as a tab open.
        openReceivers: ()=>this._openCountedView("receivers"),
        // The Rooms page (views/rooms.js), from the screens' "All rooms" links: the same.
        openRooms: ()=>this._openCountedView("rooms"),
        // Whether this build's menu has a screen (a Bright install has no
        // Rooms or Receivers): its links are left out where it hasn't.
        canOpen: (id)=>this._getVisibleTabs().has(id),
        // A guided Setup step's own tool, with the bar back to Setup
        // (views/setup.js openStep), loading Setup first if need be;
        // `mapId`: on that plan.
        // Setup's bar over a step's tool drawn again in place, from the step now (setup.js stepNow): Edit's tool buttons
        // redraw only the editor, and the refresh skips the Edit tab (review 2026-11-11, item 9).
        setupBar: ()=>{
          const old = this.$content && this.$content.querySelector('[data-setup="return"]');
          if (!old || !VIEWS.setup || !VIEWS.setup.returnBar) return;
          const nb = VIEWS.setup.returnBar(this._ctx());
          if (nb) old.replaceWith(nb); else old.remove();
        },
        openSetupStep: (id, mapId=null, door=null)=>{
          _loadView("setup").then(m => { if (m && m.openStep) m.openStep(this._ctx(), id, mapId, door); });
        },
        // Targeted tag-list re-render — avoids a full view rebuild which would
        // cause infinite loops in the Objects view's search/filter interaction
        renderTags: (target=null)=>{
          const node = target || this.shadowRoot?.querySelector("#content #tags");
          if(!node) return;
          try { VIEWS.objects?.renderTags?.(this._ctx(), node); } catch (e) { console.error(e); }
        },
        renderDiag: ()=>this._scheduleRender(),
        // Modal used by Overview/Objects drilldowns
        openModal: (title, bodyNode, subtitle="")=>this._openModal(title, bodyNode, subtitle),
        closeModal: ()=>this._closeModal(),
        callWS: (payload)=>this._callWS(payload),

        // Object label actions (tag/untag BLE devices)
        objectLabelSet: async (address, label)=>{
          const res = await this._callWS({ type:"padspan_ha/object_label_set", address, label });
          // Duplicate-label guard: the same label on two devices merges them
          // into one HA device with doubled sensors — warn so the user picks
          // a unique name instead of silently colliding.
          if (res && res.warning) this._toast(res.warning, true);
          return res;
        },
        objectLabelDelete: async (address)=>{
          return await this._callWS({ type:"padspan_ha/object_label_delete", address });
        },
        objectLabelList: async ()=>{
          return await this._callWS({ type:"padspan_ha/object_label_list" });
        },
        tagObjectPrompt: (addr, currentLabel)=>this._tagObjectPrompt(addr, currentLabel),
        radioAreaSet: async (payload)=>await this._callWS({ type:"padspan_ha/radio_area_set", ...payload }),
        radioLostSet: async (source, lost)=>await this._callWS({ type:"padspan_ha/radio_lost_set", source, lost }),
        radioDisabledSet: async (source, disabled)=>await this._callWS({ type:"padspan_ha/radio_disabled_set", source, disabled }),
        // radioReset: full reset + re-fetch + re-render (use for user-initiated resets)
        radioReset: async (source)=>{ const r = await this._callWS({ type:"padspan_ha/radio_reset", source }); await this._getLiveSnapshot(); await this._loadSettings(); this._scheduleRender(); return r; },
        // radioResetQuiet: WS-only reset with no re-render — use in async UI flows
        // (e.g. calibration) where the caller manages rendering separately
        radioResetQuiet: async (source)=>{ return await this._callWS({ type:"padspan_ha/radio_reset", source }); },
        refreshSnapshot: async ()=>{ await this._getLiveSnapshot(); this._scheduleRender(); },
        refreshSnapshotQuiet: async ()=>{ await this._getLiveSnapshot(); },
        clearSessionEvents: ()=>{ this.state._sessionEvents.length = 0; this._scheduleRender(); },
        followAlertSave: async (payload)=>await this._callWS({ type:"padspan_ha/follow_alert_save", ...payload }),
        followAlertDelete: async (addr)=>{
          await this._callWS({ type:"padspan_ha/follow_alert_delete", addr });
          delete this.state.followAlertConfig[addr];
        },
        followAlertGet: async ()=>{
          try {
            const res = await this._callWS({ type:"padspan_ha/follow_alert_get" });
            if(res && res.configs) this.state.followAlertConfig = res.configs;
          } catch(e){ /* non-fatal */ }
        },
        showHelp: (key)=>this._showHelp(key),
        // A device's quiet lines (name links). "list": a row, never in Basic.
        // "own": its own view. Neither on a wall, where nobody is there to answer.
        labelLines: (obj, where="list", after=null)=>this._labelLines(obj, where, after),

        // Area / entity management
        areaDelete: async (area_id) =>
            await this._callWS({ type: "padspan_ha/area_delete", area_id }),
        entityDelete: async (entity_id) =>
            await this._callWS({ type: "padspan_ha/entity_delete", entity_id }),
        roomTagPurgeMissing: async () =>
            await this._callWS({ type: "padspan_ha/room_tag_purge_missing" }),
        integrationReload: async () =>
            await this._callWS({ type: "padspan_ha/integration_reload" }),
        factoryReset: async () => {
            const res = await this._callWS({ type: "padspan_ha/factory_reset", confirm: "FACTORY RESET" });
            // Clear frontend-side localStorage caches so stale data doesn't survive reload
            try { localStorage.removeItem("padspan_followed"); } catch(e){}
            try { localStorage.removeItem("padspan_followAddr"); } catch(e){}
            try { localStorage.removeItem("padspan_hiddenMapIds"); } catch(e){}
            // Reset in-memory followed state immediately
            this.state.followedAddrs = new Set();
            this.state.followAddr = "";
            // Allow _fetchSettings to overwrite followedAddrs from server on next refresh
            this._followedLoadedFromServer = false;
            // Clear cached snapshot so stale objects with labels/followed don't linger
            this.state.live = { snapshot: null, error: null };
            return res;
        },
        refreshAll: async () => { await this._refreshAll(false); },
        modelRefresh: async () => { await this._getModel(); this._scheduleRender(); },

        // Detail modals
        showObjectDetail: (obj) => this._showObjectDetail(obj),
        showRoomDetail: (roomName) => this._showRoomDetail(roomName),
        showScannerDetail: (scanner) => this._showScannerDetail(scanner),

        // Mapping suite actions
        setMapsTab: (t)=>{
          this.state.mapsTab = t;
          // Opt-in usage report. This called a telemetryEvent() helper off
          // `this.actions`,
          // and `this.actions` has never existed on the element — the actions
          // live on the ctx object handed to views. So EVERY Mapping sub-tab
          // click threw a TypeError here, before reaching the render below.
          // The tab state changed and the screen never redrew, which is what
          // "the Mapping tabs don't load" was: not a hang, a swallowed throw
          // leaving the previous tab's DOM on screen.
          //
          // Through the one door, like every other event.
          this._telemetryEvent("tab:maps/" + t);
          if (t === "library") this._getMapsList().then(()=>this._scheduleRender()).catch(()=>this._scheduleRender());
          else this._scheduleRender();
        },
        mapsRefresh: async ()=>{ await this._getMapsList(); this._scheduleRender(); },
        mapsSetActive: (id)=>{ this.state.activeMapId=id; this._scheduleRender(); },
        setComplexity: (mode)=>this._setComplexity(mode),
        mapsDelete: async (id)=>{ await this._callWS({ type:"padspan_ha/maps_delete", map_id:id }); await this._getMapsList(); if(this.state.activeMapId===id) this.state.activeMapId=null; this._scheduleRender(); },
        mapsDeleteMigrate: async (mapId, targetMapId, extendCanvas=false)=>{ const r = await this._callWS({ type:"padspan_ha/maps_delete_migrate", map_id:mapId, target_map_id:targetMapId, extend_canvas:!!extendCanvas }); await this._getMapsList(); if(this.state.activeMapId===mapId) this.state.activeMapId=null; this._scheduleRender(); return r; },
        mapsUpload: async (payload)=>{ const r = await this._callWS(Object.assign({type:"padspan_ha/maps_upload"}, payload)); await this._getMapsList(); return r; },
        mapsUpdate: async (payload)=>{ await this._callWS(Object.assign({type:"padspan_ha/maps_update"}, payload)); await this._getMapsList(); this._scheduleRender(); },
        mapsUpdateQuiet: async (payload)=>{ await this._callWS(Object.assign({type:"padspan_ha/maps_update"}, payload)); },
        mapsRefreshQuiet: async ()=>{ await this._getMapsList(); },
        mapsReplaceImage: async (payload)=>{ const res = await this._callWS(Object.assign({type:"padspan_ha/maps_replace_image"}, payload)); await this._getMapsList(); this._scheduleRender(); return res; },
        modelUpdate: async (payload)=>{ await this._callWS(Object.assign({type:"padspan_ha/model_update"}, payload)); await this._getModel(); this._scheduleRender(); },

        // Settings actions
        settingsSet: async (payload) => {
          // Do NOT bundle data_mode here: this.state.dataMode defaults to
          // "sample" until settings load, so echoing it back can silently
          // flip a live install into sample mode (backend keeps data_mode
          // untouched when the message omits it).
          const res = await this._callWS(Object.assign({ type: "padspan_ha/settings_set" }, payload));
          this.state.settings = res?.settings || this.state.settings;
          this._applySkin();
          this._applyTheme();
          this._renderNav();
          this._scheduleRender();
          return res;
        },
        scannerOffsetSet: async (source, offset_db) => {
          const res = await this._callWS({ type: "padspan_ha/scanner_offset_set", source, offset_db });
          await this._getLiveSnapshot();
          await this._loadSettings();
          return res;
        },
        // BLE calibration actions
        calibrationGet: async () => await this._callWS({ type: "padspan_ha/calibration_get" }),
        calibrationSavePoint: async (point) => await this._callWS({ type: "padspan_ha/calibration_save_point", point }),
        calibrationDeletePoint: async (point_id) => await this._callWS({ type: "padspan_ha/calibration_delete_point", point_id }),
        calibrationClear: async () => await this._callWS({ type: "padspan_ha/calibration_clear" }),
        calibrationClearMap: async (map_id) => await this._callWS({ type: "padspan_ha/calibration_clear_map", map_id }),
        objectEvict: async (key) => await this._callWS({ type: "padspan_ha/object_evict", key }),
        calibrationComputeModel: async () => await this._callWS({ type: "padspan_ha/calibration_compute_model" }),
        calibrationSwapRadio: async (old_source, new_source) => await this._callWS({ type: "padspan_ha/calibration_swap_radio", old_source, new_source }),
        calibrationRelearnRadio: async (source, gain_db) => {
          const res = await this._callWS({ type: "padspan_ha/calibration_relearn_radio", source, gain_db });
          await this._getLiveSnapshot();
          return res;
        },
        calibrationHealthCheck: async () => await this._callWS({ type: "padspan_ha/calibration_health_check" }),
        wsCall: async (type, data={}) => await this._callWS({ type, ...data }),
        // Record a data_mode the server just reported (factory reset re-read).
        applyDataMode: (mode) => this._applyDataMode(mode),
        // Switch Sample/Live as the top bar does ("Preview a finished house",
        // "Back to my house").
        setDataMode: (mode) => this._setDataMode(mode),
        // Opt-in usage report: count one allow-listed event. A no-op unless the
        // person turned the report on — no traffic leaves the browser otherwise.
        telemetryEvent: (name, extra) => this._telemetryEvent(name, extra),
        // Open another screen from inside one (the guided Setup's steps):
        // highlighted like a menu pick, loaded if the background load has not
        // reached it yet.
        showView: (id, opts) => {
          // Another screen: a link's focused part is left (views/focus.js),
          // unless focus.js opens the screen on that part (opts.keepFocus).
          if (!(opts && opts.keepFocus)) this.state._focus = null;
          this.state.view = id;
          this._renderNav();
          if (!VIEWS[id] && _VIEW_PATHS[id]) _loadView(id).then(() => this._scheduleRender());
          this._scheduleRender();
        },
        // ── Followed Beacons ──────────────────────────────────────────────
        // Multi-device follow set — persisted both to server (via settings_set)
        // and to localStorage as a fallback. Addresses are stored uppercase.
        followedHas: (addr) => !!addr && this.state.followedAddrs.has(String(addr).toUpperCase()),
        followedToggle: (addr) => {
          if(!addr) return;
          const key = String(addr).toUpperCase();
          if(this.state.followedAddrs.has(key)){
            this.state.followedAddrs.delete(key);
          } else {
            this.state.followedAddrs.add(key);
          }
          // Persist to server (fire-and-forget); not from Sample mode (_keepLiveFollow)
          if(this.state.dataMode === "live") this._callWS({
            type: "padspan_ha/settings_set",
            followed_addrs: [...this.state.followedAddrs],
          }).catch(()=>{});
          // Also mirror to localStorage as fallback
          try { localStorage.setItem("padspan_followed", JSON.stringify([...this.state.followedAddrs])); } catch(e){}
          this._scheduleRender();
        },
      },
      toast: (m, isErr=false)=>this._toast(m, isErr),
    };
  }

  // ── Modal System ────────────────────────────────────────────────────────────
  // Overlay modal used by detail views (object detail, room detail, scanner detail)
  // and by the tag/rename prompt. Built with raw DOM — no framework dependency.
  // ESC key and clicking the overlay backdrop both close the modal.
  _openModal(title, bodyNode, subtitle=""){
    if(!this.$modal) return;
    this.$modal.classList.remove("hidden");
    this.$modal.innerHTML = "";

    const overlay = el("div",{class:"overlay"});
    const panel = el("div",{class:"panel"});

    const closeBtn = el("button",{class:"btn inline close"}, "Close");
    closeBtn.addEventListener("click", ()=>this._closeModal());

    const head = el("div",{class:"head"},[
      el("div",{class:"title"}, title || ""),
      el("div",{class:"sub"}, subtitle || ""),
      closeBtn
    ]);

    const body = el("div",{class:"body"});
    if(typeof bodyNode === "string"){
      body.innerHTML = bodyNode;
    } else if(bodyNode){
      body.appendChild(bodyNode);
    }

    panel.appendChild(head);
    panel.appendChild(body);
    overlay.appendChild(panel);

    overlay.addEventListener("click",(e)=>{ if(e.target === overlay) this._closeModal(); });
    this.$modal.appendChild(overlay);

    // ESC closes — remove stale handler before registering new one
    if(this._modalEsc) window.removeEventListener("keydown", this._modalEsc);
    const esc = (e)=>{ if(e.key === "Escape"){ this._closeModal(); } };
    this._modalEsc = esc;
    // Not { once: true }: typing a letter in the modal's own box (Tag,
    // Rename) used the listener up, and Escape stopped closing it.
    window.addEventListener("keydown", esc);
  }

  _closeModal(){
    if(this._modalEsc){ window.removeEventListener("keydown", this._modalEsc); this._modalEsc = null; }
    if(!this.$modal) return;
    this.$modal.classList.add("hidden");
    this.$modal.innerHTML = "";
  }


  // ── Tag/Rename Prompt ───────────────────────────────────────────────────────
  // Opens a modal with an input field to assign or update a human-readable label
  // on a BLE device. Labels are stored server-side via object_label_set and
  // appear throughout the UI wherever the device's address would normally show.
  _tagObjectPrompt(addr, currentLabel){
    const input = el("input",{type:"text", placeholder:"Enter a label…", maxLength:48});
    input.value = currentLabel || "";
    input.style.minWidth = "min(240px, 100%)";

    const status = el("div",{class:"muted", style:"min-height:20px;margin-top:6px"});

    const saveBtn = el("button",{class:"btn"}, currentLabel ? "Update label" : "Save label");
    const clearBtn = el("button",{class:"btn"}, "Untag");
    clearBtn.disabled = !currentLabel;
    clearBtn.title = currentLabel ? `Remove label "${currentLabel}"` : "No label to remove";
    const cancelBtn = el("button",{class:"btn inline"}, "Cancel");
    cancelBtn.addEventListener("click", ()=>this._closeModal());

    saveBtn.addEventListener("click", async ()=>{
      const label = input.value.trim();
      if(!label){ status.textContent = "Label cannot be empty."; return; }
      try {
        await this._callWS({ type:"padspan_ha/object_label_set", address: addr, label });
        this._logEvent("tag", `${addr} → ${label}`);
        this._closeModal();
        this._toast(`Tagged: ${label}`);
        await this._getLiveSnapshot();
        this._scheduleRender();
      } catch(e) {
        status.textContent = "Failed to save label. Check HA logs.";
      }
    });

    clearBtn.addEventListener("click", async ()=>{
      try {
        await this._callWS({ type:"padspan_ha/object_label_delete", address: addr });
        this._logEvent("tag", `${addr} untagged`);
        this._closeModal();
        this._toast("Label removed.");
        await this._getLiveSnapshot();
        this._scheduleRender();
      } catch(e) {
        status.textContent = "Failed to remove label. Check HA logs.";
      }
    });

    // Allow Enter key to save
    input.addEventListener("keydown",(e)=>{ if(e.key==="Enter") saveBtn.click(); });

    const body = el("div",{}, [
      el("div",{class:"muted", style:"margin-bottom:8px"}, `BLE address: ${addr}`),
      el("div",{class:"row", style:"gap:8px;flex-wrap:wrap"}, [input, saveBtn, clearBtn, cancelBtn]),
      status,
    ]);
    this._openModal("Tag BLE Object", body, "Assign a human-readable label to identify this device");
    // Focus input after modal renders
    requestAnimationFrame(()=>{ try{ input.focus(); }catch(e){} });
  }

  // ── Detail Modals ───────────────────────────────────────────────────────────
  // Rich detail views for objects, rooms, and scanners. These are opened from
  // Overview cards, Follow view, and anywhere a "Details" button appears.
  // Each builds a DOM tree with identity info, status, location, and actions.

  /** Look up floor name from floor_id using the model's floor list. */
  _floorName(floor_id){
    if(!floor_id) return "—";
    const floors = this.state.model?.floors || [];
    const f = floors.find(x => x.id === floor_id);
    return f ? f.name : "—";
  }

  /**
   * Show a rich detail modal for a BLE object.
   * Sections: identity (name, kind, addresses), status (RSSI, age, calibration),
   * location (room, floor, nearest receiver), detection sources table,
   * raw BLE data (manufacturer data, service UUIDs), rename form, and
   * action buttons (follow, delete, close).
   * Handles all BLE kinds: ble, private_ble, ibeacon, and HA entities.
   */
  _labelLines(obj, where, after){
    if(!DEVICE_NAME || !DEVICE_NAME.labelLines) return null;
    if(this.state.kioskMode || (wallScreen(false) && untouchedFor(120000))) return null;
    if(where === "list" && this.state.complexity === "basic") return null;
    return DEVICE_NAME.labelLines(el, obj, {
      wsCall: (type, data) => this._callWS({ type, ...data }),
      toast: (msg, bad) => this._toast(msg, bad),
      showHelp: (key) => this._showHelp(key),
      after: async () => { if(after) after(); await this._getLiveSnapshot(); this._scheduleRender(); },
    });
  }

  _showObjectDetail(obj){
    const addr = obj.address || "";
    const userLabel = obj.user_label || "";
    const name = DEVICE_NAME ? DEVICE_NAME.deviceName(obj, "Unknown") : (obj.best_name || userLabel || obj.name || obj.entity_id || addr || "Unknown");
    const kind = obj.kind || "";
    const identified = !!obj.identified;
    const what = DEVICE_NAME ? DEVICE_NAME.deviceWhat(obj) : (obj.what_it_is || obj.auto_class || null);

    // Canonical address for rename (varies by kind)
    const tagAddr = kind === "private_ble" ? (obj.canonical_id || addr)
                  : kind === "ibeacon"     ? (obj.key || "")
                  : addr;
    const canRename = (kind==="ble"||kind==="private_ble"||kind==="ibeacon") && !!tagAddr;

    let howEl = null;
    if(kind !== "entity" && (obj.how_known || obj.best_name)){
      howEl = el("span", {style:"color:#94a3b8"}, obj.how_known || "");
      if(DEVICE_NAME) DEVICE_NAME.fillHowKnown(howEl, obj, (type, data) => this._callWS({ type, ...data }));
    }

    const body = el("div", {style:"display:flex;flex-direction:column;gap:14px"});

    // Identity
    body.appendChild(el("div", {}, [
      el("div", {style:"display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:6px"}, [
        el("div", {style:"font-size:20px;font-weight:800;color:#e2e8f0"}, name),
        el("span", {class:"badge"+(identified?"":" warn"), style:
          kind==="private_ble" ? (identified?"background:#1a3a5a;color:#7dd3fc;border-color:#3b82f6":"") :
          kind==="ibeacon" ? (identified?"background:#3a2a0a;color:#fbbf24;border-color:#d97706":"") : ""},
          kind==="private_ble" ? (identified?"Private BLE · Identified":"Private BLE · Unidentified") :
          kind==="ibeacon" ? (identified?"iBeacon · Identified":"iBeacon · Unidentified") :
          kind==="ble" ? (identified?"BLE · Identified":"BLE · Unidentified") : "HA Entity"),
      ]),
      addr ? el("div", {class:"muted", style:"font-family:monospace;font-size:12px;display:flex;align-items:center;gap:6px;flex-wrap:wrap"}, [
        addr,
        DEVICE_NAME ? DEVICE_NAME.addressBadge(el, obj) : null,
      ].filter(Boolean)) : null,
      // What it is, who made it, and how we know
      (kind !== "entity" && (obj.how_known || obj.best_name || what)) ? el("div", {style:"margin-top:8px;display:grid;grid-template-columns:auto minmax(0,1fr);gap:2px 10px;font-size:13px"}, [
        ...(obj.company_name || obj.maker_guess ? [
          el("span", {class:"muted"}, "Maker"),
          el("span", {}, obj.company_name || `Probably ${obj.maker_guess}`),
        ] : []),
        ...(obj.service_owner ? [
          el("span", {class:"muted"}, "Service"),
          el("span", {title: DEVICE_NAME ? DEVICE_NAME.SERVICE_HOW : ""}, `Uses a service from ${obj.service_owner}`),
        ] : []),
        ...(what ? [el("span", {class:"muted"}, "What it is"), el("span", {}, what)] : []),
        ...(howEl ? [el("span", {class:"muted"}, "How we know"), howEl] : []),
      ]) : null,
      this._labelLines(obj, "own", () => this._closeModal()),
      obj.canonical_id ? el("div", {class:"muted", style:"font-size:11px"}, `Canonical: ${obj.canonical_id}`) : null,
      (Array.isArray(obj.all_addresses) && obj.all_addresses.length > 1)
        ? el("div", {class:"muted", style:"font-size:11px"}, `Addresses (${obj.all_addresses.length}): ${obj.all_addresses.slice(0,5).join(", ")}${obj.all_addresses.length>5?" + "+(obj.all_addresses.length-5)+" more":""}`)
        : null,
      obj._dedup_reason ? el("div", {class:"muted", style:"font-size:10px;color:#a78bfa"}, `Merged: ${obj._dedup_reason}`) : null,
      obj.entity_id ? el("div", {class:"muted", style:"font-size:12px"}, `Entity: ${obj.entity_id}`) : null,
      obj.ibeacon_key ? el("div", {class:"muted", style:"font-size:11px;color:#fbbf24"}, `Linked iBeacon: ${obj.ibeacon_key}`) : null,
      (Array.isArray(obj.linked_entities) && obj.linked_entities.length)
        ? el("div", {class:"muted", style:"font-size:11px;color:#60a5fa"}, `Linked entities: ${obj.linked_entities.join(", ")}`)
        : null,
      // Enrichment badges
      ((obj.service_names && obj.service_names.length) || obj.connectable != null)
        ? el("div", {style:"display:flex;flex-wrap:wrap;gap:5px;margin-top:6px"}, [
            ...(obj.service_names || []).map(sn =>
              el("span",{class:"badge",style:"background:#1a3a2a;color:#a7f3d0;border-color:#166534"}, sn)
            ),
            obj.connectable === true  ? el("span",{class:"badge",style:"font-size:10px"}, "Connectable") : null,
            obj.connectable === false ? el("span",{class:"badge",style:"font-size:10px;background:#2a1a0a;color:#fbbf24;border-color:#92400e"}, "Non-connectable") : null,
          ].filter(Boolean))
        : null,
    ].filter(Boolean)));

    // Status / Last seen
    {
      const statusItems = [];
      // Last seen age
      if (obj.age_s != null) {
        const ageStr = fmtAgo(obj.age_s);
        const objIsAway = isAway(obj, awayTimeoutS(this.state.settings));
        statusItems.push(el("div", {style:"display:flex;align-items:center;gap:8px"}, [
          el("span", {style:"font-weight:600"}, "Last seen:"),
          el("span", {}, ageStr + " ago"),
          objIsAway ? el("span", {class:"badge", style:"background:#3a0a0a;color:#f87171;border-color:#7f1d1d;font-size:10px"}, "Away") : null,
        ].filter(Boolean)));
      }
      // Last seen timestamp
      if (obj.last_seen) {
        try {
          const d = new Date(obj.last_seen);
          statusItems.push(el("div", {class:"muted", style:"font-size:11px"}, `Last seen: ${d.toLocaleString()}`));
        } catch(e){}
      }
      // First seen timestamp
      if (obj.first_seen) {
        try {
          const d = new Date(obj.first_seen);
          statusItems.push(el("div", {class:"muted", style:"font-size:11px"}, `First seen: ${d.toLocaleString()}`));
        } catch(e){}
      }
      // RSSI summary
      if (obj.rssi != null) {
        const pct = rssiToPercent(obj.rssi);
        const bar = el("div", {style:`width:${pct.toFixed(0)}%;height:6px;background:#52b788;border-radius:3px;min-width:2px`});
        statusItems.push(el("div", {style:"display:flex;align-items:center;gap:8px;margin-top:2px"}, [
          el("span", {style:"font-weight:600"}, "Signal:"),
          el("span", {}, `${obj.rssi} dBm`),
          el("div", {style:"width:80px;background:#1a2e1e;border-radius:3px"}, bar),
        ]));
      }
      // iBeacon details
      if (kind === "ibeacon") {
        if (obj.ibeacon_uuid) statusItems.push(el("div", {class:"muted", style:"font-size:11px;font-family:monospace"}, `UUID: ${obj.ibeacon_uuid}`));
        if (obj.ibeacon_major != null) statusItems.push(el("div", {class:"muted", style:"font-size:11px"}, `Major: ${obj.ibeacon_major} · Minor: ${obj.ibeacon_minor}`));
        if (obj.tx_power != null) statusItems.push(el("div", {class:"muted", style:"font-size:11px"}, `TX Power: ${obj.tx_power} dBm (factory calibrated at 1m)`));
        // Merged protocols badge (iBeacon + Eddystone, etc.)
        if (Array.isArray(obj.merged_protocols) && obj.merged_protocols.length > 1) {
          statusItems.push(el("div", {style:"display:flex;gap:4px;flex-wrap:wrap;margin-top:2px"},
            obj.merged_protocols.map(p => el("span", {class:"badge", style:"font-size:10px;background:#2a1a3a;color:#c4b5fd;border-color:#5b21b6"}, p))
          ));
        }
        // Eddystone service data (UUID feaa)
        const svcData = obj.service_data || {};
        const eddyPayload = svcData["0000feaa-0000-1000-8000-00805f9b34fb"] || svcData["feaa"];
        if (eddyPayload) {
          statusItems.push(el("div", {style:"margin-top:4px"}, [
            el("span", {style:"font-weight:600;font-size:12px;color:#fbbf24"}, "Eddystone: "),
            el("span", {class:"muted", style:"font-family:monospace;font-size:11px"}, String(eddyPayload)),
          ]));
        }
      }
      // Private BLE details
      if (kind === "private_ble") {
        if (obj.private_ble_name) statusItems.push(el("div", {class:"muted", style:"font-size:11px"}, `Identity: ${obj.private_ble_name}`));
        if (Array.isArray(obj.all_addresses) && obj.all_addresses.length > 1)
          statusItems.push(el("div", {class:"muted", style:"font-size:11px"}, `Active rotating MACs: ${obj.all_addresses.length}`));
      }
      // Unsure (positioning_unsure, off by default): the room is kept on thin evidence
      if (obj.room_unsure) {
        statusItems.push(el("div", {class:"muted", style:"font-size:11px"},
          obj.room_unsure === "few_scanners" ? "Room unsure: fewer than 3 scanners hear it" : "Room unsure: no calibration point matches it well"));
      }
      // KNN calibration confidence
      if (obj.knn_confidence > 0) {
        statusItems.push(el("div", {style:"display:flex;align-items:center;gap:8px;margin-top:2px"}, [
          el("span", {style:"font-weight:600"}, "Calibrated:"),
          el("span", {style:"color:#52b788"}, `${Math.round(obj.knn_confidence * 100)}% confidence`),
        ]));
      }
      if (statusItems.length) {
        body.appendChild(el("div", {}, [
          el("div", {style:"font-weight:600;margin-bottom:4px"}, "Status"),
          ...statusItems,
        ]));
      }
    }

    // Location — an away object is shown as where it was LAST, not where it is.
    const _objAway = isAway(obj, awayTimeoutS(this.state.settings));
    // A departed object has no current room; the snapshot moves where it was
    // last seen to last_room.
    const objRoom = obj.room || obj.last_room || "—";
    const haArea = (this.state.model?.areas||[]).find(a => a.name === objRoom);
    const floorName = haArea ? this._floorName(haArea.floor_id) : "—";
    const rc = roomColor(objRoom, this.state.model);
    body.appendChild(el("div", {}, [
      el("div", {style:"font-weight:600;margin-bottom:4px"}, _objAway ? "Last location" : "Location"),
      el("div", {style:"display:flex;align-items:center;gap:8px;flex-wrap:wrap"}, [
        el("span", {class:"dot", style:`background:${rc}`}),
        el("span", {}, objRoom),
        el("span", {class:"muted"}, `· ${floorName}`),
      ]),
      obj.nearest_receiver ? el("div", {class:"muted", style:"font-size:12px;margin-top:4px"}, `Nearest: ${obj.nearest_receiver}`) : null,
    ].filter(Boolean)));

    // Detection sources table
    const sources = obj.sources || [];
    // Build source→name lookup from live radios so we show friendly names
    const _radioMap = {};
    const _radios = this.state.live?.snapshot?.ble?.radios || [];
    for(const r of _radios){
      if(r.source) _radioMap[r.source] = r.display_name || r.name || r.source;
    }
    const _friendlySource = (src) => _radioMap[src] || src || "—";
    const makeSourceRow = (srcName, rssi, age_s) => {
      const pct = rssiToPercent(rssi);
      const bar = el("div", {style:`width:${pct.toFixed(0)}%;height:6px;background:#52b788;border-radius:3px;min-width:2px`});
      const barWrap = el("div", {style:"width:80px;background:#1a2e1e;border-radius:3px"}, bar);
      return el("tr", {}, [
        el("td", {style:"font-size:11px;max-width:200px;overflow:hidden;text-overflow:ellipsis"}, _friendlySource(srcName)),
        el("td", {}, barWrap),
        el("td", {}, rssi != null ? `${rssi}` : "—"),
        el("td", {class:"muted", style:"font-size:11px"}, fmtAgo(age_s)),
      ]);
    };
    if(sources.length || obj.rssi != null){
      const tbody = el("tbody");
      if(sources.length){
        for(const s of sources){
          const srcName = typeof s === "string" ? s : (s.source || "");
          const rssi = typeof s === "object" ? s.rssi : obj.rssi;
          const age_s = typeof s === "object" ? s.age_s : obj.age_s;
          tbody.appendChild(makeSourceRow(srcName, rssi, age_s));
        }
      } else {
        tbody.appendChild(makeSourceRow(obj.source || "unknown", obj.rssi, obj.age_s));
      }
      const srcSection = el("div", {}, [
        el("div", {style:"font-weight:600;margin-bottom:6px"}, "Detection sources"),
        el("table", {class:"table"}, [
          el("thead", {}, el("tr", {}, [el("th",{},"Source"),el("th",{},"Signal"),el("th",{},"dBm"),el("th",{},"Age")])),
          tbody,
        ]),
      ]);
      body.appendChild(srcSection);
    }

    // "Why this room?" — the k-NN/RF room vote normalised to fractions
    // (gap #2, best-in-class roadmap), not just the single winning number
    // the "Calibrated: X% confidence" line above already showed. A single
    // room with 100% of the vote is not a "why" worth a bar chart.
    const roomBars = roomScoreBars(obj.room_scores);
    if (roomBars.length > 1) {
      body.appendChild(el("div", {style:"margin-top:2px"}, [
        el("div", {style:"font-weight:600;margin-bottom:6px"}, "Why this room?"),
        ...roomBars.map(({room, pct}) => el("div", {style:"display:flex;align-items:center;gap:8px;margin-bottom:3px"}, [
          el("span", {style:"width:90px;font-size:11px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex-shrink:0"}, room),
          el("div", {style:"flex:1;background:#1a2e1e;border-radius:3px"},
            el("div", {style:`width:${pct}%;height:6px;background:${room===objRoom?"#52b788":"#4a6052"};border-radius:3px;min-width:2px`})),
          el("span", {class:"muted", style:"font-size:11px;width:30px;text-align:right;flex-shrink:0"}, `${pct}%`),
        ])),
      ]));
    }

    // Evidence diagram — a dashed ring per scanner at its estimated distance
    // for this object; where the rings overlap is the position's evidence,
    // the same idea the spatial solver's multilateration uses (gap #2).
    const _scanPosM = this.state.model?.scanner_positions_m || {};
    const _evidenceScanners = Object.entries(obj.source_distances_m || {}).map(([src, dist]) => {
      const p = _scanPosM[src] || {};
      return { source: src, name: _friendlySource(src), x_m: p.x_m, y_m: p.y_m, distance_m: dist };
    });
    const _objXY = (typeof obj.x_m === "number" && typeof obj.y_m === "number") ? [obj.x_m, obj.y_m] : null;
    const evidenceSvg = buildEvidenceSvg({ objXY: _objXY, scanners: _evidenceScanners });
    if (evidenceSvg) {
      const diagWrap = el("div", {});
      diagWrap.innerHTML = evidenceSvg;
      body.appendChild(el("div", {}, [
        el("div", {style:"font-weight:600;margin-bottom:6px"}, "Evidence — distance from each scanner"),
        diagWrap,
      ]));
    }

    // Device info
    if(obj.device && (obj.device.manufacturer || obj.device.model || obj.device.name)){
      const dev = obj.device;
      body.appendChild(el("div", {}, [
        el("div", {style:"font-weight:600;margin-bottom:4px"}, "Device"),
        el("div", {class:"muted", style:"font-size:12px"}, [dev.manufacturer, dev.model].filter(Boolean).join(" · ") || dev.name || ""),
      ]));
    }

    // Raw BLE data (collapsible)
    const manufData = obj.manufacturer_data || {};
    const svcData = obj.service_data || {};
    const svcUUIDs = obj.service_uuids || [];
    const svcUuidMap = obj.service_uuid_map || {};
    if((kind==="ble"||kind==="private_ble"||kind==="ibeacon") && (Object.keys(manufData).length || Object.keys(svcData).length || svcUUIDs.length)){
      const det = document.createElement("details");
      det.style.cssText = "margin-top:4px";
      const sum = document.createElement("summary");
      sum.style.cssText = "cursor:pointer;font-weight:600;font-size:13px;color:#52b788";
      sum.textContent = "Raw BLE data";
      det.appendChild(sum);
      if(DEVICE_NAME){
        const copyBtn = el("button", {class:"btn tiny", onclick: async () => {
          const ok = await DEVICE_NAME.copyText(DEVICE_NAME.rawBroadcast(obj));
          copyBtn.textContent = ok ? "Copied" : "Couldn't copy here: see Raw BLE data below";
          if(!ok) det.open = true;
          setTimeout(() => { copyBtn.textContent = "Copy raw broadcast"; }, 2500);
        }}, "Copy raw broadcast");
        body.appendChild(el("div", {}, copyBtn));
      }
      if(Object.keys(manufData).length){
        det.appendChild(el("div", {style:"font-size:12px;color:#94a3b8;margin-top:8px"}, "Manufacturer data:"));
        det.appendChild(el("table", {class:"table", style:"margin-top:4px"}, [
          el("thead", {}, el("tr", {}, [el("th",{},"Company ID"),el("th",{},"Company"),el("th",{},"Payload (hex)")])),
          el("tbody", {}, Object.entries(manufData).map(([k,v]) =>
            el("tr", {}, [
              el("td",{},String(k)),
              el("td",{style:"font-size:11px;color:#7dd3fc"}, obj.company_name && String(k) === Object.keys(manufData)[0] ? obj.company_name : "—"),
              el("td",{class:"muted",style:"font-family:monospace;font-size:11px;max-width:200px;overflow:hidden;text-overflow:ellipsis"},String(v)),
            ])
          )),
        ]));
      }
      if(Object.keys(svcData).length){
        det.appendChild(el("div", {style:"font-size:12px;color:#94a3b8;margin-top:8px"}, "Service data:"));
        det.appendChild(el("table", {class:"table", style:"margin-top:4px"}, [
          el("thead", {}, el("tr", {}, [el("th",{},"Service UUID"),el("th",{},"Name"),el("th",{},"Payload (hex)")])),
          el("tbody", {}, Object.entries(svcData).map(([k,v]) => {
            const uKey = String(k).toLowerCase();
            const sName = svcUuidMap[uKey] || svcUuidMap[k] || (uKey.includes("feaa") ? "Eddystone" : "—");
            return el("tr", {}, [
              el("td",{style:"font-size:11px;font-family:monospace"},String(k)),
              el("td",{style:"font-size:11px;color:#fbbf24"}, sName),
              el("td",{class:"muted",style:"font-family:monospace;font-size:11px;max-width:200px;overflow:hidden;text-overflow:ellipsis"},String(v)),
            ]);
          })),
        ]));
      }
      if(svcUUIDs.length){
        det.appendChild(el("div", {style:"font-size:12px;color:#94a3b8;margin-top:8px"}, "Service UUIDs:"));
        det.appendChild(el("div", {style:"margin-top:4px;display:flex;flex-wrap:wrap;gap:6px"},
          svcUUIDs.map(u => {
            const uStr = String(u);
            const svcName = svcUuidMap[uStr];
            const label = svcName ? `${uStr} (${svcName})` : uStr;
            return el("span", {class:"pill"}, label);
          })
        ));
      }
      body.appendChild(det);
    }

    // Linked entities
    const linked = obj.linked_entities || [];
    if(linked.length){
      body.appendChild(el("div", {}, [
        el("div", {style:"font-weight:600;margin-bottom:4px"}, "Linked entities"),
        el("div", {style:"display:flex;flex-wrap:wrap;gap:6px"}, linked.map(eid => el("span", {class:"pill"}, eid))),
      ]));
    }

    // Inline rename section (BLE / private_ble / ibeacon)
    if(canRename){
      const renameInput = el("input",{type:"text",placeholder:"Enter a label…",style:"flex:1;min-width:160px"});
      renameInput.value = userLabel;
      const renameStatus = el("div",{class:"muted",style:"min-height:16px;font-size:12px;margin-top:4px"});
      const saveRenameBtn = el("button",{class:"btn"}, userLabel ? "Update" : "Tag");
      saveRenameBtn.addEventListener("click", async()=>{
        const label = renameInput.value.trim();
        if(!label){ renameStatus.textContent = "Label cannot be empty."; return; }
        try {
          await this._callWS({ type:"padspan_ha/object_label_set", address: tagAddr, label });
          this._closeModal();
          this._toast(`Renamed: ${label}`);
          await this._getLiveSnapshot();
          this._scheduleRender();
        } catch(e){ renameStatus.textContent = "Failed to save. Check HA logs."; }
      });
      renameInput.addEventListener("keydown",(e)=>{ if(e.key==="Enter") saveRenameBtn.click(); });
      const renameRow = el("div",{style:"display:flex;gap:8px;flex-wrap:wrap;align-items:center"},[renameInput, saveRenameBtn]);
      if(userLabel){
        const untagBtn = el("button",{class:"btn"}, "Untag");
        untagBtn.addEventListener("click", async()=>{
          try {
            await this._callWS({ type:"padspan_ha/object_label_delete", address: tagAddr });
            this._closeModal();
            this._toast("Label removed.");
            await this._getLiveSnapshot();
            this._scheduleRender();
          } catch(e){ renameStatus.textContent = "Failed to remove label."; }
        });
        renameRow.appendChild(untagBtn);
      }
      body.appendChild(el("div",{style:"padding-top:12px;border-top:1px solid #1b3526;margin-top:4px"},[
        el("div",{style:"font-weight:600;margin-bottom:6px"}, "Rename"),
        renameRow,
        renameStatus,
      ]));
      requestAnimationFrame(()=>{ try{ renameInput.focus(); }catch(e){} });
    }

    // Actions row
    const actionsRow = el("div",{style:"display:flex;gap:8px;flex-wrap:wrap;padding-top:8px;border-top:1px solid #1b3526;margin-top:8px"});
    // Follow toggle (multi-device Set)
    const _followKey = (addr || obj.entity_id || "").toUpperCase();
    if(_followKey){
      const _isFollowed = this.state.followedAddrs.has(_followKey);
      const followBtn = el("button",{
        class:"btn inline",
        style: _isFollowed ? "background:#1a3a2a;border-color:#52b788;color:#52b788" : "",
      }, _isFollowed ? "Following" : "Follow");
      followBtn.addEventListener("click", ()=>{
        const wasFollowed = this.state.followedAddrs.has(_followKey);
        if(wasFollowed) this.state.followedAddrs.delete(_followKey);
        else this.state.followedAddrs.add(_followKey);
        // Persist to server (not from Sample mode: _keepLiveFollow)
        if(this.state.dataMode === "live") this._callWS({
          type: "padspan_ha/settings_set",
          followed_addrs: [...this.state.followedAddrs],
        }).catch(()=>{});
        try { localStorage.setItem("padspan_followed", JSON.stringify([...this.state.followedAddrs])); } catch(e){}
        const nowFollowed = this.state.followedAddrs.has(_followKey);
        followBtn.textContent = nowFollowed ? "Following" : "Follow";
        followBtn.style.cssText = nowFollowed
          ? "width:auto;margin-top:0;background:#1a3a2a;border-color:#52b788;color:#52b788" : "width:auto;margin-top:0";
      });
      actionsRow.appendChild(followBtn);
    }
    // Locate flash (gap #10, best-in-class roadmap) — jumps to Overview and
    // flashes the object's marker (a ported one-shot ring, see overview.js's
    // own header note on why it's reproduced there rather than imported).
    // Cleared after the animation's own duration (2 x 1.9s) so it does not
    // re-trigger on every 5s poll re-render.
    {
      const _locateKey = obj.key || addr || obj.entity_id || "";
      if (_locateKey) {
        const locateBtn = el("button", { class: "btn inline" }, "📍 Locate");
        locateBtn.addEventListener("click", () => {
          this.state._overviewLocateKey = _locateKey;
          this.state.view = "overview";
          this._closeModal();
          this._scheduleRender();
          setTimeout(() => {
            if (this.state._overviewLocateKey === _locateKey) {
              this.state._overviewLocateKey = null;
              this._scheduleRender();
            }
          }, 3900);
        });
        actionsRow.appendChild(locateBtn);
      }
    }
    // Delete button — unfollow + remove label + purge from view
    if(_followKey || canRename){
      const deleteBtn = el("button",{
        class:"btn inline",
        style:"background:#3b1219;border-color:#f87171;color:#f87171",
      }, "Delete");
      deleteBtn.addEventListener("click", async()=>{
        // Unfollow
        if(_followKey && this.state.followedAddrs.has(_followKey)){
          this.state.followedAddrs.delete(_followKey);
          if(this.state.dataMode === "live") this._callWS({
            type: "padspan_ha/settings_set",
            followed_addrs: [...this.state.followedAddrs],
          }).catch(()=>{});
          try { localStorage.setItem("padspan_followed", JSON.stringify([...this.state.followedAddrs])); } catch(e){}
        }
        // Remove label
        if(canRename && tagAddr){
          try { await this._callWS({ type:"padspan_ha/object_label_delete", address: tagAddr }); } catch(e){}
        }
        this._closeModal();
        this._toast("Deleted: " + (userLabel || name));
        await this._getLiveSnapshot();
        this._scheduleRender();
      });
      actionsRow.appendChild(deleteBtn);
    }
    actionsRow.appendChild(el("button",{class:"btn inline",onclick:()=>this._closeModal()}, "Close"));
    body.appendChild(actionsRow);

    this._openModal(name, body, kind==="ble" ? `BLE object · ${identified?"identified":"unidentified"}` : "HA entity");
  }

  /** Show a detail modal for a room: objects currently in it, assigned scanners, HA entities. */
  _showRoomDetail(roomName){
    const snap = this.state.live?.snapshot;
    // "Objects currently in this room" is present tense. An object keeps its
    // last known room forever so a dropout does not erase where it was, but
    // listing a departed one here says it is still standing there — a car gone
    // for an hour stayed in the Garage while its own entities read not_home.
    const _awayS = awayTimeoutS(this.state.settings);
    const objects = (snap?.objects?.list||[])
      .filter(o => o.room === roomName && !isAway(o, _awayS));
    const radios = (snap?.ble?.radios||[]).filter(r => r.area_name === roomName || r.area === roomName);
    const area = (this.state.model?.areas||[]).find(a => a.name === roomName);
    const floorName = area ? this._floorName(area.floor_id) : "—";
    const rc = roomColor(roomName, this.state.model);

    const body = el("div", {style:"display:flex;flex-direction:column;gap:14px"});

    // Header with color swatch + floor
    body.appendChild(el("div", {style:"display:flex;align-items:center;gap:10px"}, [
      el("span", {style:`display:inline-block;width:20px;height:20px;border-radius:50%;background:${rc};flex-shrink:0`}),
      el("div", {}, [
        el("div", {style:"font-weight:700;font-size:16px"}, roomName),
        el("div", {class:"muted", style:"font-size:12px"}, `Floor: ${floorName}`),
      ]),
    ]));

    // Objects in room
    const objSection = el("div", {}, [
      el("div", {style:"font-weight:600;margin-bottom:6px"}, `Objects now (${objects.length})`),
    ]);
    if(objects.length){
      for(const o of objects){
        const oName = DEVICE_NAME ? DEVICE_NAME.pickName(o, "Unknown") : (o.best_name || o.user_label || o.name || o.entity_id || o.address || "Unknown");
        const oKey = (o.address || o.entity_id || "").toUpperCase();
        const isFollowed = oKey && this.state.followedAddrs.has(oKey);
        const oc = isFollowed ? "#fbbf24" : (o.identified ? "#5eead4" : "#f59e0b");
        const rssiTxt = o.rssi != null ? `${o.rssi} dBm` : "";
        const ageTxt = o.age_s != null ? fmtAgo(o.age_s) : "";
        const oRow = el("div", {style:"display:flex;align-items:center;gap:8px;padding:6px 0;border-bottom:1px solid #0d1f12"}, [
          el("span", {style:`width:8px;height:8px;border-radius:50%;background:${oc};flex-shrink:0`}),
          el("div", {style:"flex:1"}, oName),
          isFollowed ? el("span", {class:"badge", style:"background:#fbbf2422;color:#fbbf24;border-color:#fbbf24"}, "Following") : null,
          rssiTxt ? el("span", {class:"badge"}, rssiTxt) : null,
          ageTxt ? el("span", {class:"muted", style:"font-size:11px"}, ageTxt) : null,
          el("button", {class:"btn tiny", onclick:()=>{ this._closeModal(); this._showObjectDetail(o); }}, "Details"),
        ].filter(Boolean));
        objSection.appendChild(oRow);
      }
    } else {
      objSection.appendChild(el("div", {class:"muted", style:"font-size:12px"}, "No objects currently detected in this room."));
    }
    body.appendChild(objSection);

    // Radios in room
    const radioSection = el("div", {}, [
      el("div", {style:"font-weight:600;margin-bottom:6px"}, `Bluetooth scanners (${radios.length})`),
    ]);
    if(radios.length){
      for(const r of radios){
        const rName = r.display_name || r.name || r.source || "Scanner";
        const sid = radioShortId(r.source || "");
        const rRow = el("div", {style:"display:flex;align-items:center;gap:8px;padding:6px 0;border-bottom:1px solid #0d1f12"}, [
          el("span", {style:"font-family:monospace;font-weight:700;font-size:12px;letter-spacing:.04em;color:#52b788;flex-shrink:0"}, sid),
          el("div", {style:"flex:1"}, [
            el("div", {}, rName),
            r.source ? el("div", {class:"muted", style:"font-size:11px;font-family:monospace"}, r.source) : null,
          ].filter(Boolean)),
          (()=>{ const ss = scannerStatus(r, snap?.ble?.advertisements); const b = el("span",{class:ss.cls,title:ss.title},ss.label); if(ss.style) b.style.cssText+=ss.style; return b; })(),
          el("button", {class:"btn tiny", onclick:()=>{ this._closeModal(); this._showScannerDetail(r); }}, "Details"),
        ].filter(Boolean));
        radioSection.appendChild(rRow);
      }
    } else {
      radioSection.appendChild(el("div", {class:"muted", style:"font-size:12px"}, "No Bluetooth scanners assigned to this room."));
    }
    body.appendChild(radioSection);

    // HA Entities
    const entities = Object.keys(this.state.roomTagMap?.[roomName] || {});
    if(entities.length){
      body.appendChild(el("div", {}, [
        el("div", {style:"font-weight:600;margin-bottom:6px"}, `HA Entities (${entities.length})`),
        el("div", {style:"display:flex;flex-wrap:wrap;gap:6px"}, entities.map(eid => el("span", {class:"pill"}, eid))),
      ]));
    }

    this._openModal(roomName, body, `Room · ${floorName}`);
  }

  /** Show a detail modal for a BLE scanner: status, network info, area, visible devices. */
  _showScannerDetail(scanner){
    const snap = this.state.live?.snapshot;
    const devices = (snap?.objects?.list||[]).filter(
      o => (o.sources||[]).some(s => (typeof s==="string" ? s : s.source) === scanner.source)
    ).map(o => {
      const srcEntry = (o.sources||[]).find(s => (typeof s==="string" ? s : s.source) === scanner.source);
      return {
        ...o,
        srcRssi: typeof srcEntry==="object" ? (srcEntry?.rssi ?? o.rssi) : o.rssi,
        srcAge: typeof srcEntry==="object" ? (srcEntry?.age_s ?? o.age_s) : o.age_s,
      };
    }).sort((a,b) => (b.srcRssi ?? -999) - (a.srcRssi ?? -999));

    const name = scanner.display_name || scanner.name || scanner.source || "Scanner";
    const sid  = radioShortId(scanner.source || "");
    const body = el("div", {style:"display:flex;flex-direction:column;gap:14px"});

    // Status badges (include short ID and lost status)
    const statusRow = el("div", {style:"display:flex;gap:8px;flex-wrap:wrap;align-items:center"});
    statusRow.appendChild(el("span", {class:"pill", style:"font-family:monospace;font-weight:700;font-size:13px;letter-spacing:.04em", title: name + " \u00b7 " + (scanner.source||"")}, sid));
    if(scanner.lost)     statusRow.appendChild(el("span", {class:"badge warn", style:"background:rgba(245,158,11,.18)"}, "⚠ Lost"));
    if(scanner.disabled) statusRow.appendChild(el("span", {class:"badge warn", style:"background:rgba(148,100,220,.18);color:#c084fc"}, "⊘ Disabled"));
    { const ss = scannerStatus(scanner, snap?.ble?.advertisements); const b = el("span",{class:ss.cls,title:ss.title},ss.label); if(ss.style) b.style.cssText+=ss.style; statusRow.appendChild(b); }
    if(scanner.connectable != null) statusRow.appendChild(el("span", {class:"badge"}, scanner.connectable?"connectable":"not connectable"));
    if(scanner.adapter) statusRow.appendChild(el("span", {class:"muted", style:"font-family:monospace;font-size:12px"}, `adapter: ${scanner.adapter}`));
    body.appendChild(statusRow);

    // Network info (IP, SSID, WiFi signal)
    if(scanner.ip || scanner.ssid || scanner.wifi_signal != null || scanner.connection_type){
      const netRow = el("div", {style:"display:flex;gap:8px;flex-wrap:wrap;align-items:center"});
      if(scanner.ip) netRow.appendChild(el("span", {class:"badge", style:"font-family:monospace;font-size:11px"}, scanner.ip));
      if(scanner.ssid) netRow.appendChild(el("span", {class:"badge", style:"font-size:11px"}, scanner.ssid));
      else if(scanner.connection_type) netRow.appendChild(el("span", {class:"badge", style:"font-size:11px"}, scanner.connection_type));
      if(scanner.wifi_signal != null) netRow.appendChild(el("span", {class:"muted", style:"font-size:11px"}, `WiFi ${scanner.wifi_signal} dBm`));
      body.appendChild(netRow);
    }

    // Area + Lost toggle
    const areaSection = el("div", {});
    areaSection.appendChild(el("div", {style:"font-weight:600;margin-bottom:6px"}, "Area assignment"));
    const areaRow = el("div", {style:"display:flex;gap:8px;align-items:center;flex-wrap:wrap"});
    areaRow.appendChild(
      scanner.area_name
        ? el("span", {class:"badge"}, scanner.area_name)
        : el("span", {class:"muted"}, "Not assigned to an area")
    );
    // Lost toggle button
    const lostBtn = el("button", {class:"btn tiny"+(scanner.lost?" primary":""),
      style: scanner.lost ? "border-color:#f59e0b;color:#f59e0b" : "border-color:#7d5c2b"
    }, scanner.lost ? "Restore Radio" : "Mark as Lost");
    lostBtn.addEventListener("click", async ()=>{
      lostBtn.disabled = true;
      try {
        await this._callWS({ type:"padspan_ha/radio_lost_set", source: scanner.source||"", lost: !scanner.lost });
        this._closeModal();
        this._toast(scanner.lost ? "Radio restored." : "Radio marked as Lost.");
        await this._getLiveSnapshot();
        this._scheduleRender();
      } catch(e) {
        lostBtn.disabled = false;
        this._toast("Failed to update lost status.", true);
      }
    });
    areaRow.appendChild(lostBtn);
    // Disabled toggle button
    const disabledBtn = el("button", {class:"btn tiny"+(scanner.disabled?" primary":""),
      style: scanner.disabled ? "border-color:#c084fc;color:#c084fc" : "border-color:#5b3b7a"
    }, scanner.disabled ? "Re-enable Radio" : "Mark as Disabled");
    disabledBtn.addEventListener("click", async ()=>{
      disabledBtn.disabled = true;
      try {
        await this._callWS({ type:"padspan_ha/radio_disabled_set", source: scanner.source||"", disabled: !scanner.disabled });
        this._closeModal();
        this._toast(scanner.disabled ? "Radio re-enabled." : "Radio marked as Disabled.");
        await this._getLiveSnapshot();
        this._scheduleRender();
      } catch(e) {
        disabledBtn.disabled = false;
        this._toast("Failed to update disabled status.", true);
      }
    });
    areaRow.appendChild(disabledBtn);
    areaSection.appendChild(areaRow);
    if(scanner.lost && scanner.lost_since){
      areaSection.appendChild(el("div", {class:"muted", style:"font-size:11px;margin-top:4px"},
        `Marked lost: ${new Date(scanner.lost_since).toLocaleString()}`));
    }
    if(scanner.disabled && scanner.disabled_since){
      areaSection.appendChild(el("div", {class:"muted", style:"font-size:11px;margin-top:4px"},
        `Disabled since: ${new Date(scanner.disabled_since).toLocaleString()}`));
    }
    body.appendChild(areaSection);

    // Visible devices
    const devSection = el("div", {}, [
      el("div", {style:"font-weight:600;margin-bottom:6px"}, `Devices visible (${devices.length})`),
    ]);
    if(devices.length){
      for(const d of devices){
        const dName = DEVICE_NAME ? DEVICE_NAME.deviceName(d, "Unknown") : (d.best_name || d.user_label || d.name || d.address || "Unknown");
        const rssi = d.srcRssi;
        const pct = rssiToPercent(rssi);
        const bar = el("div", {style:`width:${pct.toFixed(0)}%;height:5px;background:#52b788;border-radius:2px`});
        const barWrap = el("div", {style:"width:60px;background:#1a2e1e;border-radius:2px"}, bar);
        const ageTxt = d.srcAge != null ? (()=>{ const s=Math.round(Number(d.srcAge)); if(s<60) return s+"s"; const m=Math.floor(s/60); if(m<60) return m+"m"; return Math.floor(m/60)+"h"; })() : "";
        const dRow = el("div", {style:"display:flex;align-items:center;gap:8px;padding:5px 0;border-bottom:1px solid #0d1f12"}, [
          el("div", {style:"flex:1"}, [
            el("div", {style:"font-weight:600"}, dName),
            d.address ? el("div", {class:"muted", style:"font-size:11px;font-family:monospace"}, d.address) : null,
          ].filter(Boolean)),
          barWrap,
          rssi != null ? el("span", {class:"muted", style:"font-size:11px"}, `${rssi}dBm`) : null,
          ageTxt ? el("span", {class:"muted", style:"font-size:11px"}, ageTxt) : null,
          d.identified ? el("span", {class:"badge"}, "identified") : el("span", {class:"badge warn"}, "unknown"),
          el("button", {class:"btn tiny", onclick:()=>{ this._closeModal(); this._showObjectDetail(d); }}, "Details"),
        ].filter(Boolean));
        devSection.appendChild(dRow);
      }
    } else {
      devSection.appendChild(el("div", {class:"muted", style:"font-size:12px"}, "No objects currently visible from this scanner."));
    }
    body.appendChild(devSection);

    // Source ID
    body.appendChild(el("div", {style:"margin-top:4px"}, [
      el("span", {class:"muted", style:"font-size:11px"}, "Source ID: "),
      el("span", {style:"font-family:monospace;font-size:11px;color:#94a3b8"}, scanner.source || "—"),
    ]));

    this._openModal(name, body, `Bluetooth scanner · ${scanner.area_name || "unassigned"}`);
  }

  // ── View Rendering & Re-render Guards ────────────────────────────────────────
  // This is the single render entry point. Every view change, poll update, and
  // recovery path calls this method. The fromPoll flag indicates whether the
  // render was triggered by the 5s poll loop (true) or by a user action (false).
  //
  // RE-RENDER GUARDS: Multiple flags prevent the poll from destroying interactive
  // UI state. These are critical — removing any guard causes real bugs:
  //   _dragging / _confirming  — calibration pin placement (Tune / Beacon Tune)
  //   _stackDragging / _editDragging — map alignment drag operations
  //   _ptAlign.active          — Point Align mode (side-by-side maps)
  //   _traceback.active        — traceback animation playback
  //   _factoryResetInProgress  — factory reset progress UI
  //   focused input/select     — user typing in a form field
  //   _lastUserInteraction     — any click/scroll within last 3 seconds
  //
  // The general strategy: poll renders are "nice to have" (data freshness),
  // but user interactions are sacred (never destroy mid-action).
  /** A view drawn as its loading placeholder (a deep link straight to it, ?view=maps&tab=lights: Atlas's "✎ Edit
   *  map"): loaded now and drawn when it lands, once. Review 2026-11-11: nothing else asked for it (the deferred
   *  loads draw nothing when they land, and the poll does not redraw Mapping's or Settings' tabs), so the
   *  placeholder stayed until a menu click. */
  _loadMissingView(v){
    if (!_VIEW_PATHS[v] || this._viewAsked === v) return;
    this._viewAsked = v;
    _loadView(v).then(m => { this._viewAsked = null; if (m && this.state.view === v) this._scheduleRender(); });
  }

  _renderCurrentView(fromPoll){
    if(this.state._factoryResetInProgress) return;
    // A visit to a view: counted each time a view is drawn after another one (the rooms helper's "came back later",
    // views/ai_wizard_offer.js stepSeen, means a later visit, not only a reload).
    if(this.state.view !== this._visitView){ this._visitView = this.state.view; this.state._viewVisit = (this.state._viewVisit || 0) + 1; }
    // Setup steps into or out of the menu as the house's steps get done (_setupInMenu): the menu follows.
    { const _inMenu = this._setupInMenu(); if(_inMenu !== this._setupMenuShown){ this._setupMenuShown = _inMenu; this._renderNav(); } }
    // Training is the manual: its translated help is fetched on first open.
    if(this.state.view === "training" && !this._helpLoad) this._loadHelpLanguage();
    // Left the Overview holding a slim snapshot (Optimize for scale): fetch
    // the whole one now, not at the next poll, so no view draws from it.
    if(this.state.view !== "overview" && this.state.live && this.state.live.snapshot && this.state.live.snapshot.slim && !this._slimRefetch){
      this._slimRefetch = true;
      this._getLiveSnapshot().finally(()=>{ this._slimRefetch = false; this._scheduleRender(); });
    }
    if(this.state.view === "calibration" && (this.state._calibTune?._dragging || this.state._calibBeacon?._dragging || this.state._calibTune?._confirming || this.state._calibBeacon?._confirming)) return;
    if(this.state.maps?._stackDragging || this.state.maps?._editDragging) return;
    if(this.state._traceback?.active && this.state.view === "traceback") return;
    // Maps upload/stack/edit tabs have fragile state (file inputs, drag handles)
    if(fromPoll && this.state.view === "maps" && (this.state.mapsTab === "upload" || this.state.mapsTab === "stack" || this.state.mapsTab === "edit")) return;
    // Overview: on polls, only update object dots (cheap) — don't rebuild the
    // entire isometric SVG which causes flicker + scroll reset.  The overview
    // view registers state._isoUpdateObjects() during its initial render;
    // calling it here replaces only the object dot layer while leaving the
    // static room geometry, floor plan image, and scanner markers untouched.
    // Resetting _lastGoodRender prevents the stale-check (10s) from triggering
    // a forced full rebuild on the next poll cycle.
    if(fromPoll && this.state.view === "overview") {
      // Detect suspend state change — force full rebuild so banner appears/disappears
      const _curSusp = !!(this.state.live?.snapshot?.suspended);
      if(this._lastSuspendState !== _curSusp) {
        // Fall through to full rebuild below. Recorded only once that
        // rebuild happens (after the swap): a rebuild the interaction guard
        // skipped — the "Resume Normal" click itself — must not count as
        // done, or the banner stays up for good (round 6). The dots keep
        // moving meanwhile: a guard can hold the rebuild back for minutes
        // (a focused slider), and they used to freeze with it (round 7).
        if (typeof this.state._isoUpdateObjects === "function") {
          try { this.state._isoUpdateObjects(); } catch(e) {}
        }
        if (typeof this.state._whosWhereUpdate === "function") {
          try { this.state._whosWhereUpdate(); } catch(e) {}
        }
      } else {
        // Update suspend countdown in-place (no full rebuild)
        if(_curSusp) {
          const _bEl = this.$content.querySelector("[data-suspend-countdown]");
          if(_bEl) {
            const _r = this.state.live?.snapshot?.suspend_remaining_s ?? 0;
            const _m = Math.floor(_r / 60), _s = _r % 60;
            _bEl.textContent = "Raw radio only \u00b7 " + (_r > 0 ? `${_m}:${String(_s).padStart(2,"0")} remaining` : "ending soon");
          }
        }
        if (typeof this.state._isoUpdateObjects === "function") {
          try { this.state._isoUpdateObjects(); } catch(e) {}
        }
        if (typeof this.state._whosWhereUpdate === "function") {
          try { this.state._whosWhereUpdate(); } catch(e) {}
        }
        this._lastGoodRender = performance.now();
        return;
      }
    }
    // Preact overview: let Preact handle its own diffing — just re-call render()
    // which diffs efficiently instead of rebuilding the entire DOM.
    // Pure Live showing the classic Overview (the Atlas is Overview): a poll
    // moves its dots, as on the Overview tab, instead of rebuilding it.
    if(fromPoll && this.state.view === "purelive" && this.state._liveClassic && VIEWS.overview
       && VIEWS.overview.atlasHomeOn && VIEWS.overview.atlasHomeOn(this._ctx())) {
      if (typeof this.state._isoUpdateObjects === "function") {
        try { this.state._isoUpdateObjects(); } catch(e) {}
      }
      if (typeof this.state._whosWhereUpdate === "function") {
        try { this.state._whosWhereUpdate(); } catch(e) {}
      }
      this._lastGoodRender = performance.now();
      return;
    }
    if(fromPoll && this.state.view === "purelive") {
      try {
        const mod = VIEWS["purelive"];
        if(mod && mod.render) mod.render(this._ctx());
      } catch(e) {}
      this._lastGoodRender = performance.now();
      return;
    }
    // Skip POLL re-renders when the user is actively interacting.
    // Only applies to fromPoll=true — explicit renders (tab clicks, actions)
    // must always go through immediately.
    if(fromPoll){
      // A deliberate skip is a live view, not a stall: stamp it, or the
      // watchdog rebuilds the view mid-typing (round 4). Only while someone
      // is using it — a field left focused on an idle screen would otherwise
      // hold the view frozen for good (round 5).
      try {
        const active = (this.shadowRoot || this).querySelector(":focus");
        if(active){
          const tag = active.tagName;
          if(tag === "INPUT" || tag === "SELECT" || tag === "TEXTAREA"){
            if(this._lastUserInteraction && (performance.now() - this._lastUserInteraction) < 120_000) this._lastGoodRender = performance.now();
            return;
          }
        }
      } catch(e) { /* ignore */ }
      if(this._lastUserInteraction && (performance.now() - this._lastUserInteraction) < 3000){ this._lastGoodRender = performance.now(); return; }
    }
    // Verify $content is a live node in the shadow DOM (not a stale detached reference)
    if(!this.$content || !this.$content.isConnected){
      this._ensureShadowDom();
      if(!this.$content) return;
    }
    const v = this.state.view;
    const mod = VIEWS[v];

    // Preserve scroll positions for common scroll containers so periodic 5s
    // live refreshes don't reset the user's reading position.  We capture both
    // the main content scroll and inner scrollable lists (rooms, tags, etc.),
    // then restore them in a rAF after the DOM swap completes.
    // Uses index-based matching (selector + nth occurrence) which is stable
    // because the DOM structure is rebuilt identically each render cycle.
    const selectors = [".rooms",".tags",".list-scroll",".bt-adv-list",".bt-list"];
    const scrollState = [];
    let _mainScrollTop = 0;
    try { _mainScrollTop = this.$content.scrollTop || 0; } catch(e){}
    try {
      for(const sel of selectors){
        const nodes = this.$content.querySelectorAll(sel);
        nodes.forEach((n,i)=>{ scrollState.push({ sel, i, top: n.scrollTop }); });
      }
    } catch(e) { /* ignore */ }

    // ── Fragment-first rendering ──────────────────────────────────────────
    // Build new content into a DocumentFragment BEFORE clearing $content.
    // If the view's render() throws, old content stays visible (no blank screen).
    // Only after successful render do we swap: clear old, append new.
    const frag = document.createDocumentFragment();

    // BLE health banner — show once per session when Bluetooth feed is unhealthy
    if(!this.state._bleBannerDismissed){
      const snap = this.state.live?.snapshot;
      const bleDiag = snap?.ble?.diag;
      if(bleDiag && (bleDiag.ok === false || (Array.isArray(bleDiag.errors) && bleDiag.errors.length))){
        const banner = document.createElement("div");
        banner.style.cssText = "background:#1a0a0a;border:1px solid #7f1d1d;border-radius:8px;padding:12px 16px;margin-bottom:12px;display:flex;align-items:flex-start;gap:10px";
        const msg = document.createElement("div");
        msg.style.cssText = "flex:1;font-size:12px;color:#fca5a5;line-height:1.5";
        msg.innerHTML = "<b style='font-size:13px'>Bluetooth feed unavailable</b><br>"
          + "PadSpan™ can't see BLE scanners. This usually means Home Assistant needs a <b>full restart</b> "
          + "(Settings → System → Restart) — a reload isn't enough after first install.";
        const dismissBtn = document.createElement("button");
        dismissBtn.className = "btn inline";
        dismissBtn.style.cssText = "padding:2px 8px;font-size:11px;color:#fca5a5;border-color:#7f1d1d;flex-shrink:0";
        dismissBtn.textContent = "Dismiss";
        dismissBtn.addEventListener("click", ()=>{ this.state._bleBannerDismissed = true; banner.remove(); });
        banner.appendChild(msg);
        banner.appendChild(dismissBtn);
        frag.appendChild(banner);
      }
    }

    // A step opened from the guided Setup (views/setup.js): which step, and
    // the way back, over the tool that does it. Gone with a menu pick.
    if (this.state._setupReturn && (v === "maps" || v === "calibration") && VIEWS.setup && VIEWS.setup.returnBar) {
      try { const _sb = VIEWS.setup.returnBar(this._ctx()); if (_sb) frag.appendChild(_sb); }
      catch(e) { console.warn("PadSpan: setup bar failed", e); }
    }

    // ── Onboarding wizard ──────────────────────────────────────────────────
    // Shows a persistent progress bar when setup is incomplete. Detects each
    // step's completion from live state. Navigates to the right view on click.
    {
      const _onboardingDone = !!(this.state.settings && this.state.settings.onboarding_completed);
      // Each step's name, number, words and "done" are setup_status.js's, the one
      // rule Setup and the Setup Wizard read (review 2026-11-13: one order, one
      // vocabulary; this card kept its own inline copy before, held equal by
      // tests/js/setup_status_parity.mjs). The card waits for the module.
      const _ss = SETUP_STATUS;
      const _order = _ss ? _ss.setupSteps(this.state) : [];
      // Someone on the map NOW: what the steps above are for. An object the
      // engine counts as the house's own (presence_coordinator
      // is_identified_object: labelled, identified, or an IRK phone) with a
      // real position in the LIVE snapshot. Sample data never counts, and
      // until a live snapshot has arrived the answer is unknown, not "no":
      // the card waits for it (_posKnown), the same rule as _setupKnown.
      const _liveSnap = this.state.dataMode === "live" && this.state.live && this.state.live.snapshot !== SAMPLE_SNAPSHOT
        ? this.state.live.snapshot : null;
      const _posKnown = !!this.state._dataModeKnown && (this.state.dataMode !== "live" || !!_liveSnap);
      const _hasPositioned = !!_liveSnap && ((_liveSnap.objects && _liveSnap.objects.list) || []).some(o => o
        && !o._stale && !o._ghost && (o.user_label || o.identified || o.kind === "private_ble")
        && typeof o.x_m === "number" && Number.isFinite(o.x_m) && typeof o.y_m === "number" && Number.isFinite(o.y_m));
      // The ids are the report's (telemetry.GETTING_STARTED_STEPS); `step` is Setup's.
      const _lbl = (step) => { const x = _order.find(t => t.id === step); return x ? `${x.n}. ${x.label}` : step; };
      const _steps = [
        { id: "upload",   label: _lbl("plan"),        step: "plan" },
        { id: "scale",    label: _lbl("scale"),       step: "scale" },
        { id: "rooms",    label: _lbl("rooms"),       step: "rooms" },
        { id: "floors",   label: _lbl("floors"),      step: "floors" },
        { id: "scanners", label: _lbl("receivers"),   step: "receivers" },
        { id: "calibrate", label: _lbl("calibration"), step: "calibration" },
        { id: "positioned", label: "See someone on the map", done: _hasPositioned, view: "follow",
          hint: this.state.dataMode === "live" ? "Follow \u2192 pick your phone or a tag" : "Switch the top bar to Live first" },
      ].filter(s => !s.step || _order.some(t => t.id === s.step))
        .map(s => s.step ? { ...s, done: _ss.stepDone(this.state, s.step) === true, hint: _ss.STEP_ABOUT[s.step] } : s);
      // Counted and dotted: the set-up steps only, as Setup counts them; "See someone on the map" is shown after them as
      // what comes next, never a step (review 2026-11-11, C8). ▶ is setup_status.firstOpenStep, Setup's "Next".
      const _setupRows = _steps.filter(s => s.step);
      const _completedCount = _setupRows.filter(s => s.done).length;
      const _skipped = ((this.state.settings && this.state.settings.setup_progress) || {}).skipped;
      const _nextStep = _ss ? _ss.firstOpenStep(this.state, Array.isArray(_skipped) ? _skipped : []) : null;
      // Setup is the map-building steps. "See someone on the map" depends on
      // who is home right now (and on sample mode), so it is shown as a step
      // but never decides "done": a house set up long ago must not get the
      // card back on the day nobody is in.
      const _allDone = !!_ss && _steps.every(s => s.done || s.id === "positioned");
      // Persisted per install (settings.onboarding_completed), straight to
      // the wire: `this.actions` is never assigned on the element, so the
      // settingsSet these two used to optional-chain was never called and
      // neither "done" nor "Skip setup" survived a settings reload.
      const _markOnboarded = () => {
        if (this._onboardingSaving) return;
        this._onboardingSaving = true;
        this._callWS({ type: "padspan_ha/settings_set", onboarding_completed: true })
          .then(res => { if (res && res.settings) this.state.settings = res.settings; })
          .catch(() => {})
          .finally(() => { this._onboardingSaving = false; });
      };

      // Auto-mark completed when all steps done \u2014 tried once per page, so a
      // save that fails is not re-sent on every render.
      // Never from Sample mode: the sample house is finished, the real one may not be.
      if (_allDone && !_onboardingDone && this.state.settings && !this._onboardingAutoTried && this.state.dataMode === "live") {
        this._onboardingAutoTried = true;
        _markOnboarded();
      }

      // Do not answer "is setup done?" before the stores that answer it have
      // arrived. A new install still sees the card the moment they settle -
      // an empty maps list is an answer; an unfetched one is not.
      const _setupKnown = this.state._mapsLoaded && this.state._modelLoaded;
      if (_setupKnown && !_onboardingDone && !_allDone && _posKnown && _ss && !this.state._onboardingDismissed && this.state.view === "overview") {
        // Opt-in usage report: the card was seen, once per page.
        if (!this._gettingStartedCounted) { this._gettingStartedCounted = true; this._telemetryEvent("getting_started_shown"); }
        this._overviewCardShown = true;   // the trial milestone waits for another page load
        const bar = el("div",{"data-getting-started":"card",style:"background:#0a1f14;border:1px solid #1a4228;border-radius:8px;padding:10px 14px;margin-bottom:12px"});
        // Header
        const hdr = el("div",{style:"display:flex;align-items:center;justify-content:space-between;margin-bottom:8px"});
        // A live house with no room drawn already has Who's where now on the
        // Overview (views/whos_where.js): the map steps are the optional next
        // step, not a gate in front of seeing anything.
        const _mapOptional = this.state.dataMode === "live" && !Object.keys((this.state.model || {}).room_geometry_m || {}).length;
        hdr.appendChild(el("div",{style:"font-weight:700;font-size:13px;color:#52b788"},
          _mapOptional ? `Make it a map (optional) \u2014 ${_completedCount}/${_setupRows.length}` : `Getting started \u2014 ${_completedCount}/${_setupRows.length}`));
        const skipBtn = el("span",{"data-getting-started":"dismiss",style:"cursor:pointer;font-size:10px;color:#64748b;text-decoration:underline"}, "Skip setup");
        skipBtn.addEventListener("click", () => {
          this.state._onboardingDismissed = true;
          if (this.state.settings) this.state.settings.onboarding_completed = true;
          bar.remove();
          this._telemetryEvent("getting_started_dismissed");
          _markOnboarded();
          this._scheduleRender();
        });
        // The guided Setup: the same steps in order, with skip and resume.
        const setupBtn = el("span",{"data-getting-started":"setup",style:"cursor:pointer;font-size:11px;color:#5eead4;text-decoration:underline;margin-right:12px"}, "Open Setup");
        setupBtn.addEventListener("click", () => {
          this.state.view = "setup";
          this._renderNav();
          if (!VIEWS.setup) _loadView("setup").then(() => this._scheduleRender());
          this._scheduleRender();
        });
        const gsHelp = el("button",{class:"btn-help",title:"Help","data-getting-started":"help",style:"margin-left:10px"}, "?");
        gsHelp.addEventListener("click", (e) => { e.stopPropagation(); this._showHelp("getting_started"); });
        hdr.appendChild(el("span",{style:"display:flex;align-items:baseline"},[setupBtn, skipBtn, gsHelp]));
        bar.appendChild(hdr);
        if (_mapOptional) bar.appendChild(el("div",{style:"font-size:12px;color:#94a3b8;margin:-4px 0 8px"},
          "Who's where already works below. A floor plan adds the map, and with three or more receivers placed on it, positions between them."));

        // Progress dots
        const dots = el("div",{style:"display:flex;gap:4px;margin-bottom:8px"});
        for (const s of _setupRows) {
          dots.appendChild(el("div",{style:`flex:1;height:4px;border-radius:2px;background:${s.done ? "#52b788" : "#1b3526"}`}));
        }
        bar.appendChild(dots);

        // Step list
        const list = el("div",{style:"display:flex;flex-direction:column;gap:4px"});
        for (let i = 0; i < _steps.length; i++) {
          const s = _steps[i];
          const isNext = !!s.step && s.step === _nextStep;
          const then = !s.step;   // See someone on the map: what the steps lead to, after them
          const row = el("div",{style:`display:flex;align-items:center;gap:8px;padding:4px 8px;border-radius:4px;font-size:12px;${isNext ? "background:#0f2a1a;cursor:pointer" : "cursor:pointer"}${then ? ";margin-top:4px;border-top:1px solid #1b3526" : ""}`});
          row.appendChild(el("span",{style:`font-size:14px`}, s.done ? "\u2705" : isNext ? "\u25b6\ufe0f" : then ? "\u27a1\ufe0f" : "\u2b1c"));
          row.appendChild(el("span",{style:`color:${s.done ? "#52b788" : isNext ? "#5eead4" : "#64748b"};font-weight:${isNext ? "700" : "400"}`}, then ? "Then: " + s.label : s.label));
          if (isNext) row.appendChild(el("span",{style:"font-size:10px;color:#94a3b8;margin-left:auto"}, s.hint));
          row.setAttribute("data-getting-started", "step-" + s.id);
          row.addEventListener("click", () => {
            this._telemetryEvent("getting_started_step:" + s.id);
            // A Setup step opens as Setup's own Start does (views/setup.js openStep): its tool, the bar back to Setup.
            if (s.step) { this._ctx().actions.openSetupStep(s.step, null, "getting_started"); return; }
            this.state.view = s.view;
            // A view reached from here is highlighted like one picked from
            // the menu, and loads if the background load has not reached it.
            this._renderNav();
            if (!VIEWS[s.view] && _VIEW_PATHS[s.view]) _loadView(s.view).then(() => this._scheduleRender());
            if (this.actions?.renderRooms) this.actions.renderRooms();
            else this._scheduleRender();
          });
          list.appendChild(row);
          // Under Draw Rooms: Claude can draw them from the plan (experimental), where the rule offers it.
          if (s.id === "rooms" && !s.done && AIW) {
            try { const _aiw = AIW.gettingStartedRow(this._ctx()); if (_aiw) list.appendChild(_aiw); } catch(e) { /* no offer */ }
          }
        }
        // Last line: the 90-day trial (views/trial_offer.js) — an offer, not a
        // step, so it is not counted above. Only while there is no key; the
        // card opens in place, under the list.
        let _trialOffer = false;
        try { _trialOffer = !!(TRIAL && TRIAL.trialOfferable(this.state.settings)); } catch(e) { /* no offer */ }
        if (TRIAL && (_trialOffer || this.state._gettingStartedTrialOpen)) {
          const row = el("div",{"data-getting-started":"step-trial",style:"display:flex;align-items:center;gap:8px;padding:4px 8px;border-radius:4px;font-size:12px;cursor:pointer;margin-top:2px;border-top:1px solid #1a4228"});
          row.appendChild(el("span",{style:"font-size:14px"}, "✨"));
          row.appendChild(el("span",{style:"color:#8ee5b4"}, "Try all of PadSpan Pro on your house — 90 days free, no card"));
          row.addEventListener("click", () => {
            this.state._gettingStartedTrialOpen = !this.state._gettingStartedTrialOpen;
            if (this.state._gettingStartedTrialOpen) this._telemetryEvent("getting_started_step:trial");
            this._scheduleRender();
          });
          list.appendChild(row);
          if (this.state._gettingStartedTrialOpen) {
            try {
              const card = TRIAL.trialOfferFromCtx(this._ctx(), "overview");
              if (card) list.appendChild(card);
            } catch(e) { console.warn("PadSpan: trial offer failed", e); }
          }
        }
        bar.appendChild(list);
        const _ask = this._telemetryAskCard(true);
        if (_ask) bar.appendChild(_ask);
        frag.appendChild(bar);
      } else if (this.state.view === "overview") {
        // Set-up skipped but not finished (Skip setup, or Setup's own Finish): one quiet way back where the card was
        // (review 2026-11-11, item 10), on the house's own data, never on a wall; ✕ hides it in this browser. A
        // finished house has none.
        const _p = (this.state.settings && this.state.settings.setup_progress) || {};
        let _lineHidden = false;
        try { _lineHidden = localStorage.getItem("padspan_setup_line") === "hidden"; } catch (e) { _lineHidden = !!this._setupLineHidden; }
        // Only while calibration is known to be not done: a calibrated house is in use and is never asked back to
        // Setup for an older step, and "not known yet" (its points not read) shows nothing (review 2026-11-14).
        if (_setupKnown && _ss && !_allDone && _ss.stepDone(this.state, "calibration") === false
            && (_onboardingDone || _p.done === true) && this.state.dataMode === "live"
            && !this.state.kioskMode && !_lineHidden && !this._setupLineHidden) {
          const line = el("div",{"data-setup-line":"",style:"display:flex;align-items:center;gap:10px;font-size:12px;color:#94a3b8;margin-bottom:10px"});
          line.appendChild(el("span",{}, `Set-up: ${_completedCount} of ${_setupRows.length} done \u00b7 `));
          const open = el("span",{"data-setup-line":"open",style:"cursor:pointer;color:#5eead4;text-decoration:underline"}, "Open Setup");
          open.addEventListener("click", () => {
            this.state.view = "setup";
            this._renderNav();
            if (!VIEWS.setup) _loadView("setup").then(() => this._scheduleRender());
            this._scheduleRender();
          });
          const hide = el("span",{"data-setup-line":"hide",title:"Hide this line in this browser",style:"cursor:pointer;margin-left:auto;color:#64748b"}, "\u2715");
          hide.addEventListener("click", () => {
            this._setupLineHidden = true;
            try { localStorage.setItem("padspan_setup_line", "hidden"); } catch (e) { /* this page only */ }
            line.remove();
          });
          line.appendChild(open);
          line.appendChild(hide);
          frag.appendChild(line);
        }
        // Setup is done or was skipped — the checklist is gone, so these cards
        // stand on their own. What changed first: it is the more perishable of
        // the two, and it is the reason the panel looks different today.
        const _new = this._whatsNewCard();
        if (_new) frag.appendChild(_new);
        const _ask = this._telemetryAskCard(false);
        if (_ask) frag.appendChild(_ask);
        if (_new || _ask) this._overviewCardShown = true;
        // The trial's one-time milestone card — one card at a time, so never
        // beside the two above (the update banner carries its own trial line),
        // nor right after them on the same page load (_overviewCardShown, read
        // in _trialMilestoneCard), and never before the stores and the live
        // answer are in (no flash).
        if (!_new && !_ask && _setupKnown && _posKnown) {
          try {
            // The launch price's card first (it ends November 30), then a Pro
            // invite, the one-time tester card, then the trial's: whichever is
            // first to be due, one at a time.
            const _ms = this._launchPriceCard() || this._proInviteOverviewCard() || this._testerOverviewCard(_hasPositioned)
              || this._aiWizardOverviewCard() || this._trialMilestoneCard(_hasPositioned);
            if (_ms) frag.appendChild(_ms);
            // Last in line: the accuracy tips, only when no other card is up.
            else { const _tips = this._accuracyTipsCard(); if (_tips) frag.appendChild(_tips); }
          } catch(e) { console.warn("PadSpan: trial milestone failed", e); }
        }
      }
    }

    if(!mod || typeof mod.render !== "function") {
      // Skeleton loading placeholder while views load
      const skel = el("div",{style:"display:flex;flex-direction:column;gap:12px"});
      for(let i = 0; i < 3; i++){
        const card = el("div",{class:"card",style:"min-height:80px"});
        card.appendChild(el("div",{style:"height:14px;width:40%;background:rgba(255,255,255,0.06);border-radius:4px;margin-bottom:12px"}));
        card.appendChild(el("div",{style:"height:10px;width:70%;background:rgba(255,255,255,0.04);border-radius:3px;margin-bottom:8px"}));
        card.appendChild(el("div",{style:"height:10px;width:55%;background:rgba(255,255,255,0.04);border-radius:3px"}));
        skel.appendChild(card);
      }
      frag.appendChild(skel);
      this._loadMissingView(v);
      // Swap only after new content is ready
      this.$content.innerHTML = "";
      this.$content.appendChild(frag);
      this._lastGoodRender = performance.now();
      this._renderFailCount = 0;
      return;
    }
    try {
      let node;
      const _ov = VIEWS.overview;
      if (v === "purelive" && _ov && _ov.atlasHomeOn && _ov.atlasHomeOn(this._ctx())) {
        // The Atlas is Overview: Pure Live carries a switch to the classic one.
        const _c = this._ctx();
        node = document.createElement("div");
        const _sw = _ov.liveSwitch(_c);
        // Pure Live's own view pulls itself up 14px (margin:-14px): room for that.
        if (!this.state._liveClassic) _sw.style.marginBottom = "26px";
        node.appendChild(_sw);
        node.appendChild(this.state._liveClassic ? _ov.renderClassic(_c) : mod.render(_c));
      } else {
        node = mod.render(this._ctx());
      }

      // If the view returned a cached DOM node already displayed in $content,
      // skip the destructive swap on poll renders to preserve scroll positions.
      // ONLY for views with 100% static content (ESPHome Configs YAML blocks).
      // Dynamic views (overview, follow, objects, etc.) MUST always swap so
      // updated object positions, RSSI values, and live data are displayed.
      const _staticViews = new Set(["esphome_configs"]);
      const _isStaticTab = v === "bluetooth" && this.state.btTab === "esphome_configs";
      if(fromPoll && _isStaticTab && node && node.parentNode === this.$content){
        this._lastGoodRender = performance.now();
        this._renderFailCount = 0;
        return;
      }

      frag.appendChild(node);

      // ── Swap: clear old content and append new content atomically ────────
      this.$content.innerHTML = "";
      this.$content.appendChild(frag);
      this._lastGoodRender = performance.now();
      this._renderFailCount = 0;
      if(v === "overview") this._lastSuspendState = !!(this.state.live?.snapshot?.suspended);

      // Restore scroll after DOM paint
      requestAnimationFrame(()=> {
        try {
          // Restore main content scroll
          if (_mainScrollTop > 0 && fromPoll) this.$content.scrollTop = _mainScrollTop;
          for(const s of scrollState){
            const nodes = this.$content.querySelectorAll(s.sel);
            const n = nodes && nodes[s.i];
            if(n) n.scrollTop = s.top;
          }
        } catch(e) { /* ignore */ }
      });
    } catch (e) {
      // Render failed — OLD content is still visible (not cleared).
      // Only show error UI if content is actually empty (e.g. first render).
      console.error("PadSpan render error:", e);
      this._renderFailCount = (this._renderFailCount || 0) + 1;
      if(!this.$content.children.length){
        this.$content.innerHTML = "";
        this.$content.appendChild(frag); // banners at least
        const errDiv = document.createElement("div");
        errDiv.style.cssText = "background:#1a0a0a;border:1px solid #7f1d1d;border-radius:8px;padding:16px;margin:16px 0;color:#fca5a5";
        const h = document.createElement("div");
        h.style.cssText = "font-weight:700;font-size:15px;margin-bottom:8px";
        h.textContent = "UI render error — view: " + this.state.view;
        const sub = document.createElement("div");
        sub.style.cssText = "font-size:12px;margin-bottom:8px;color:#fca5a5";
        sub.textContent = "A JavaScript error prevented this view from rendering. Open browser console (F12) for details.";
        const pre = document.createElement("pre");
        pre.style.cssText = "font-size:11px;white-space:pre-wrap;word-break:break-all;background:#0a0000;padding:10px;border-radius:4px;overflow:auto;max-height:300px;color:#f87171";
        pre.textContent = String(e?.stack || e);
        const retryBtn = document.createElement("button");
        retryBtn.className = "btn";
        retryBtn.style.cssText = "margin-top:10px";
        retryBtn.textContent = "Retry";
        retryBtn.addEventListener("click", ()=>{ this._renderFailCount = 0; this._refreshAll(true); });
        errDiv.appendChild(h); errDiv.appendChild(sub); errDiv.appendChild(pre); errDiv.appendChild(retryBtn);
        this.$content.appendChild(errDiv);
      }
    }
  }


  // ── Toast Notifications ─────────────────────────────────────────────────────
  // Temporary message bar at the top of the content area. Auto-hides after 4.5s.
  // Used for confirmations ("Tagged: Kitchen Beacon"), errors ("WS call failed"),
  // and progress ("Refreshing..."). Only one toast visible at a time.
  _toast(msg, isErr=false){
    const t = this.$("#toast");
    if(!t) return;
    if(isErr && this._adminOnlyToastUntil && Date.now() < this._adminOnlyToastUntil) return;
    t.textContent = msg;
    t.classList.toggle("error", !!isErr);
    t.classList.remove("hidden");
    clearTimeout(this._toastTimer);
    this._toastTimer = setTimeout(()=>t.classList.add("hidden"), 4500);
  }
}

// ── Register Custom Element ──────────────────────────────────────────────────
// HA discovers this via the panel config in __init__.py. Once defined,
// HA creates an instance and drives it through connectedCallback + set hass().
//
// Guard against a duplicate definition: on an integration reload/update the
// panel re-registers with a fresh BUILD_ID module_url, so a browser that still
// has the previous module imported will load BOTH copies. An unguarded define()
// throws "name 'padspan-ha-app' has already been used", which aborts panel
// init mid-way and leaves the UI half-rendered (dead buttons, broken search,
// watchdog "no successful render" loop). Defining once and no-opping the
// duplicate keeps the panel functional until the next full refresh.
if (!customElements.get("padspan-ha-app")) {
  customElements.define("padspan-ha-app", PadSpanHaApp);
}
