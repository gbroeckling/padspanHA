// PadSpan HA — BLE Room-Presence Tracking for Home Assistant
// Copyright (C) 2026 Garry Broeckling
// Licensed under the GNU General Public License v3.0
// See LICENSE file or https://www.gnu.org/licenses/gpl-3.0.html
//
// Editions and tiers, on the frontend side — a mirror of licence.py, read
// from the settings payload (settings.tier / settings.edition / tier_floor)
// and never re-derived here.
//
//   EDITION  which build was downloaded: "full" (PadSpan HA / PadSpan Pro)
//            or "bright" (PadSpan Bright / PadSpan Bright Pro).  Visibility.
//   TIER     what the key says: free < bright < pro.  Capability.
//
// Every navigable surface is classified below, once. A Bright build renders
// the `lighting` surfaces only. The map is asserted TOTAL by
// tests/test_editions_map.py: add a view to panel.js and forget to classify
// it, and the suite goes red — that is the entire mechanism by which "the
// rest just flows" without anyone remembering Bright.

// ── Where a licence comes from, and where it goes ───────────────────────────
// A gate that names a product without saying where to buy one or where to put
// the key is a dead end, and until 2026-08-24 every gate in PadSpan was one:
// the light-placement refusal said "needs PadSpan Bright Pro or PadSpan Pro"
// with no price and no link, and the ONLY key-entry field in the whole panel
// was a prompt() hidden inside the Forensics toggle — so a customer who bought
// Pro to place lights had to enable an unrelated recording feature to activate
// it. These four constants are the single source for every gate message, so a
// refusal can always answer "then what?".
export const BUY_URL = "https://padspan.traks.ca/#pro";
export const LIGHTS_URL = "https://padspan.traks.ca/#lights";
// Suggest an idea: GitHub Discussions → Ideas (where ideas are voted on), or
// by email for anyone without GitHub. release_notes.js has its own copy of
// IDEAS_NEW_URL (it imports nothing); tests/test_suggest_idea.py holds them equal.
export const IDEAS_URL = "https://github.com/gbroeckling/padspanHA/discussions/categories/ideas";
export const IDEAS_NEW_URL = "https://github.com/gbroeckling/padspanHA/discussions/new?category=ideas";
export const IDEAS_MAIL = "mailto:hello@traks.ca?subject=PadSpan%20idea";
export const PRO_PRICE = "$45 CAD/year";
// The other two SKUs padspan.traks.ca#editions actually sells — pinned exactly
// against the site's own PayPal forms by tests/test_site_claims.py. Added so
// anything quoting the Bright ladder (the tiers help card, the onboarding
// wizard) has one source too, the same discipline PRO_PRICE already gives Pro.
export const BRIGHT_PRICE = "$35 CAD/year";
export const BRIGHT_UPGRADE_PRICE = "$12 CAD";
// PadSpan Pro for life: $89 CAD at the launch price until November 30, 2026,
// then $168 CAD from December 1, for good (2026-10-22). The site
// switches its PayPal form at the same moment; the licence server accepts
// $89 for a week after, for late payment notices. Pinned to the site like the rest.
export const PRO_LIFETIME_LAUNCH_PRICE = "$89 CAD";
export const PRO_LIFETIME_FULL_PRICE = "$168 CAD";
export const PRO_LIFETIME_LAUNCH_UNTIL = "2026-12-01T08:00:00Z";
export function proLifetimeLaunch(now = Date.now()) { return now < Date.parse(PRO_LIFETIME_LAUNCH_UNTIL); }
/** What lifetime costs now, said one way everywhere: "$89 CAD, once, until
 *  November 30 (then $168)", or "$168 CAD, once". */
export function proLifetimeWords(now = Date.now()) {
  return proLifetimeLaunch(now) ? PRO_LIFETIME_LAUNCH_PRICE + ", once, until November 30 (then $168)"
                                : PRO_LIFETIME_FULL_PRICE + ", once";
}
// Lifetime is always on sale now; kept for callers asking whether to offer it.
export function proLifetimeOpen() { return true; }
// The launch price's one Overview card (panel.js _launchPriceCard), the last
// word on it: shown once, to an administrator, until the launch price ends
// (proLifetimeLaunch, the date above: no second date). Due where the licence
// card offers lifetime too (no key, a trial, a lapsed key) and, until the
// launch price ends (owner, 2026-11-19), to a running key for a year (Pro or
// Bright Pro): paid with the same email, the licence server makes that key
// lifetime (issue_lifetime). A lifetime key runs to 2099, so "under ten years
// left" is a year's key. Only once the backend says it was never shown
// (launch_card_done: a key an older backend does not send reads as "not
// known", never as "due").
export const LAUNCH_CARD_TITLE = "The launch price ends November 30";
export function launchCardAnnual(settings) {
  const s = settings || {};
  return s.pro_has_key === true && s.pro_active === true && !s.license_is_trial
    && typeof s.pro_days_left === "number" && s.pro_days_left < 3650;
}
export function launchCardDue(settings, now = Date.now()) {
  const s = settings || {};
  if (!proLifetimeLaunch(now) || !("launch_card_done" in s) || s.launch_card_done) return false;
  if (typeof s.pro_has_key !== "boolean") return false;            // not loaded yet: no flash
  return !s.pro_has_key || s.pro_active === false || !!s.license_is_trial || launchCardAnnual(s);
}
export const EDITIONS_URL = "https://padspan.traks.ca/#editions";
// Where "what changed" lives. The same page the update-check manifest
// points at (release.py sets notes_url to it), so the notification and the
// in-panel card cannot disagree about where the release notes are. ?hl=en
// because the notes are English only: without it, a visitor from Germany,
// Austria or Switzerland lands on the German page (site/.htaccess) instead.
export const WHATSNEW_URL = "https://padspan.traks.ca/?hl=en#whatsnew";

// ── What to say about the paid half, to whom ────────────────────────────────
// Most free installs have never seen the paid features — the only place they
// are named is a refusal you hit by trying to use them. The what's-new card
// is a fair place to say what they are: once per release, one line, no badge
// and no banner.
//
// What it says depends on what the licence already covers, because pitching
// somebody a thing they have already bought is an insult:
//
//   pro     -> null. They have it all. Say nothing.
//   bright  -> what Pro adds: the 3D house, the wall screen and Forensics;
//              light placement is already theirs.
//   free    -> the main paid features, light placement first.
//   lapsed  -> what stopped (Forensics stops recording; what it recorded
//              stays searchable), and that nothing was lost.
//
// Pure on purpose: it takes the settings payload and returns text, so the rule
// can be tested without a browser (tests/js/pro_pitch.mjs).
export function proPitch(settings) {
  const st = settings || {};
  const tier = String(st.tier || "free").toLowerCase();
  const hasKey = !!st.pro_has_key;
  const lapsed = st.pro_active === false;

  if (hasKey && lapsed) {
    // A Bright build shows no Forensics, Locate or Busy Times: name only what it shows.
    const off = currentEdition(st) === "bright"
      ? "light placement is read-only and the 3D house and the wall screen are off. "
      : "light placement is read-only, Forensics has stopped recording (what it recorded stays searchable "
        + "for its retention period), and the 3D house, the wall screen, Locate and Busy Times are off. ";
    return {
      kind: "lapsed",
      text: "Your licence has lapsed, so " + off
          + "Everything you set up is still here and comes back as you left it when you renew. ",
      cta: `Renew PadSpan Pro — ${PRO_PRICE}`,
      url: BUY_URL,
    };
  }
  if (tier === "pro") return null;
  if (tier === "bright") {
    return {
      kind: "bright",
      text: "Your key covers the lighting half. PadSpan Pro adds the 3D house (Live Aboard), the wall "
          + "screen and Forensics — which Bluetooth devices were near a given scanner in any time window, "
          + "with dwell time and CSV export. ",
      cta: `PadSpan Pro — ${PRO_PRICE}`,
      url: BUY_URL,
    };
  }
  return {
    kind: "free",
    text: "What a licence adds, in case you have never hit it: light placement, which puts every "
        + "light exactly where it hangs instead of clustered in the middle of its room; the 3D house "
        + "(Live Aboard); the wall screen; and Forensics, which answers which Bluetooth devices were "
        + "near a scanner in any time window. ",
    cta: `PadSpan Pro — ${PRO_PRICE}`,
    url: BUY_URL,
  };
}
// The one true path to the licence card. If this moves, it moves here.
export const LICENCE_PATH = "Settings \u2192 Features \u2192 PadSpan licence";

export const TIERS = ["free", "bright", "pro"];

export function tierAtLeast(tier, want) {
  const r = t => { const i = TIERS.indexOf(String(t || "").toLowerCase()); return i < 0 ? 0 : i; };
  return r(tier) >= r(want);
}

/** The effective tier the backend computed, off the settings payload. */
export function currentTier(settings) {
  const t = String((settings && settings.tier) || "").toLowerCase();
  return TIERS.includes(t) ? t : "free";
}

export function currentEdition(settings) {
  return String((settings && settings.edition) || "").toLowerCase() === "bright" ? "bright" : "full";
}

// The classification. `lighting` is what PadSpan Bright is; `presence` is
// everything the lighting product does not show. Health and Settings are
// lighting because a Bright install still has to be diagnosed and configured
// — both trim themselves by edition inside, as Rooms does (no receivers or
// people in Bright: views/rooms.js).
export const SURFACE_CLASS = Object.freeze({
  overview:    "presence",
  purelive:    "presence",
  follow:      "presence",
  objects:     "presence",
  devices:     "presence",
  bluetooth:   "presence",
  presence:    "presence",
  history:     "presence",
  monitor:     "presence",
  maps:        "lighting",
  rooms:       "lighting",      // the Rooms page (2026-10-30); in Bright it trims itself to the lighting fields
  events:      "presence",
  health:      "lighting",
  settings:    "lighting",
  manage:      "presence",
  debug:       "presence",
  diagnostics: "presence",
  qa:          "presence",
  training:    "presence",
  calibration: "presence",
  receivers:   "presence",    // Bluetooth receivers: the presence build's
  traceback:   "presence",
  forensics:   "presence",
  sandbox:     "presence",
  occupancy:   "presence",
  guests:      "presence",      // guest tags (0.38.178): a tag lent to a guest is presence
  setup:       "presence",      // the guided Setup: receivers and calibration are presence
  ai_wizard:   "presence",      // Let Claude draw your rooms: rooms for presence (never offered in Bright)
  // The developer's install-base dashboard is about BOTH builds' installs,
  // but it is a presence-build surface: Bright has no Pro key to present.
  installbase: "presence",
});

/**
 * Which of `ids` a build shows. The full edition shows everything it is
 * handed. Bright shows the lighting surfaces — and the presence ones too when
 * the reveal switch is on (settings.bright_reveal_presence): hide-by-default,
 * never hidden for good.
 */
export function surfacesForEdition(ids, settings) {
  const edition = currentEdition(settings);
  if (edition !== "bright") return ids.slice();
  const reveal = !!(settings && settings.bright_reveal_presence);
  return ids.filter(id => reveal || SURFACE_CLASS[id] === "lighting");
}
