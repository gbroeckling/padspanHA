// PadSpan HA — BLE Room-Presence Tracking for Home Assistant
// Copyright (C) 2026 Garry Broeckling
// Licensed under the GNU General Public License v3.0
// See LICENSE file or https://www.gnu.org/licenses/gpl-3.0.html
/**
 * Radio Map & Distortion Map — SVG overlay generators for map views.
 *
 * Radio Map: modelled coverage (scanner positions + path loss) or an RSSI
 *   heatmap from calibration data, interpolated using barrier-aware IDW.
 *   Walls come from the fabric (rf_barriers_m, in metres) — never from a
 *   list on a photograph — and penalize the IDW weights: signal that must
 *   pass through a wall contributes less to cells on the other side.
 *
 * Distortion Map: For each calibration point, computes the LOO k-NN predicted
 *   position vs actual position, rendering disagreement vectors as arrows.
 *   Reveals where walls/furniture/interference cause positioning errors.
 *
 * Both output SVG strings in viewBox="0 0 1 1" space for compositing into
 * any map overlay (2D Overview, Maps tab, 3D Stack).
 *
 * Gated behind: settings.radio_map_enabled / settings.distortion_map_enabled
 */

// Shared stack transform; query inherited from our own module URL so the ?b=
// cache-buster propagates (see docs/06_UI_CACHE_BUSTING.md).
const { fabricWorldScanners, fabricWorldBarriers } =
  await import(`./stack_transform.js${new URL(import.meta.url).search}`);

const GRID_RES = 42;       // 42x42 interpolation grid (1764 cells) for 2D
const IDW_POWER = 2.5;     // IDW exponent (higher = more local, sharper near barriers)
// dBm penalty per slab crossed. Tracks _SLAB_PENALTY_DB in presence_coordinator:
// the picture and the solver must model cross-floor loss the same way, or the
// heatmap shows a cross-floor reading the engine never believed.
export const FLOOR_ATTEN_DB = 10;
const KNN_K = 3;           // k for LOO cross-validation
const BARRIER_PENALTY_DB_TO_DIST = 0.01; // each dB of barrier attenuation adds this much "virtual distance"

// ── Model-Based RF Propagation ───────────────────────────────────────────────
// Computes predicted RSSI at any point based on scanner positions + path-loss
// model. No calibration data needed — pure physics + wall attenuation.
export const DEFAULT_REF_POWER = -59;   // dBm at 1 meter
export const DEFAULT_PATH_LOSS_N = 2.5; // indoor path-loss exponent

// The floor a set of floor maps is drawn for — the id every wall on that
// floor carries in the fabric.
function _floorId(floorMaps) {
  const m = (floorMaps || [])[0];
  return m ? String((m.stack && m.stack.floor_id) || m.floor_id || "main") : null;
}

/**
 * Scanners for a modelled heatmap, in stack-world coordinates, from the fabric.
 *
 * Returns { scanners, mPerWorld }. scanners is empty when the fabric cannot
 * place them — an empty fabric, or maps never measured so there is no metre
 * anchor — and the caller then renders nothing. There is deliberately no fall
 * back to receiver pin positions: those are photo fractions, and re-deriving a
 * physical position from a picture is what moved scanners after a trim.
 *
 * mPerWorld is the stored metres-per-world-unit, so callers convert distance
 * using what the fabric actually measured rather than assuming a plan width.
 *
 * floorDist is the number of slabs between a scanner's floor and the floor
 * being drawn, from the fabric floor level where the floor has one and from the
 * map stack level only as a display fallback.
 *
 * dz is the scanner's height above the assumed device height on the drawn
 * floor, so the model can use a real slant range.
 */
function _fabricScanners(mapsList, model, drawnZ, mapZByMapId, scannerQuality, settings) {
  const fab = fabricWorldScanners(model);
  if (!fab) return { scanners: [], mPerWorld: 0 };

  // Fallback floor→level only for floors the fabric has not levelled yet.
  const levelByFloor = {};
  for (const m of mapsList || []) {
    const fid = String(m.floor_id || "");
    if (fid && levelByFloor[fid] === undefined && mapZByMapId[m.id] !== undefined) {
      levelByFloor[fid] = mapZByMapId[m.id];
    }
  }

  const bases = (model && model.floor_elevations) || {};
  const carry = Number(settings?.assumed_device_height_m ?? 1.0);
  // The device is assumed to be at carry height on the floor being drawn.
  let drawnBase = 0;
  for (const [fid, lvl] of Object.entries(levelByFloor)) {
    if (lvl === drawnZ) { drawnBase = Number(bases[fid]) || 0; break; }
  }
  const deviceZ = drawnBase + carry;

  const out = [];
  for (const sc of fab.scanners) {
    const lvl = sc.level !== undefined && sc.level !== null
      ? sc.level : levelByFloor[sc.floor_id];
    if (lvl === undefined) continue;          // unplaced floor — not drawable
    const floorDist = Math.abs(lvl - drawnZ);
    if (floorDist > 2) continue;
    out.push({
      wx: sc.wx, wy: sc.wy, source: sc.source, floorDist,
      dz: sc.abs_z - deviceZ,
      qualityOffset: scannerQuality[sc.source] || 0,
    });
  }
  return { scanners: out, mPerWorld: fab.m_per_unit };
}

// ── Color Scales ─────────────────────────────────────────────────────────────

// ── Hatch Pattern System ─────────────────────────────────────────────────────
// 16 color buckets from -95 to -30 dBm. Each bucket gets a <pattern> with 45°
// diagonal lines in that color. Grid cells reference url(#rmh_N) instead of
// solid fills, letting the map image show through the gaps.

const HATCH_BUCKETS = 16;
// Data-adaptive scale: computed from actual calibration data at render time.
// These defaults are overridden by setHatchRange() before rendering.
let HATCH_WORST = -85;
let HATCH_BEST  = -55;
let HATCH_RANGE = HATCH_BEST - HATCH_WORST;

/**
 * Set the data-adaptive range for heatmap colors.
 * @param {number} worst - weakest RSSI in data
 * @param {number} best - strongest RSSI in data
 * @param {number} gain - user gain offset in dBm (shifts entire scale, default 0)
 * @param {number} contrast - user contrast offset (widens range when negative, narrows when positive, default 0)
 */
export function setHatchRange(worst, best, gain, contrast) {
  const g = gain || 0;
  const c = contrast || 0;
  const pad = Math.max(2, (best - worst) * 0.05);
  HATCH_WORST = worst - pad + g - c;
  HATCH_BEST = best + pad + g + c;
  HATCH_RANGE = HATCH_BEST - HATCH_WORST;
  if (HATCH_RANGE < 5) { HATCH_WORST = HATCH_BEST - 20; HATCH_RANGE = HATCH_BEST - HATCH_WORST; }
}

// User gain/contrast stored module-level so all renderers pick them up
let _userGain = 0;
let _userContrast = 0;
/** Set user gain/contrast before rendering. Called from overview.js. */
export function setUserGainContrast(gain, contrast) {
  _userGain = gain || 0;
  _userContrast = contrast || 0;
}

// Compute opaque RGB for a bucket index (0 = worst, HATCH_BUCKETS-1 = best)
// Color gradient is pure visual — independent of dBm thresholds.
function _bucketRGB(idx) {
  const t = idx / (HATCH_BUCKETS - 1); // 0=worst, 1=best — LINEAR
  let r, g, b;
  if (t < 0.15) {
    // very dark maroon → dark red (-90 to -84 dBm)
    const u = t / 0.15;
    r = Math.round(30 + u * 100);   // 30→130
    g = Math.round(u * 8);          // 0→8
    b = Math.round(5 + u * 5);      // 5→10
  } else if (t < 0.35) {
    // dark red → bright red (-84 to -76 dBm)
    const u = (t - 0.15) / 0.20;
    r = Math.round(130 + u * 110);  // 130→240
    g = Math.round(8 + u * 35);     // 8→43
    b = 10;
  } else if (t < 0.55) {
    // bright red → orange-yellow (-76 to -68 dBm)
    const u = (t - 0.35) / 0.20;
    r = 240;
    g = Math.round(43 + u * 170);   // 43→213
    b = Math.round(10 + u * 15);    // 10→25
  } else if (t < 0.70) {
    // orange-yellow → bright lime green (-68 to -62 dBm)
    const u = (t - 0.55) / 0.15;
    r = Math.round(240 - u * 210);  // 240→30
    g = Math.round(213 + u * 42);   // 213→255
    b = Math.round(25 + u * 25);    // 25→50
  } else {
    // bright lime green → electric neon green (-62 to -50 dBm)
    const u = (t - 0.70) / 0.30;
    r = Math.round(30 - u * 30);    // 30→0
    g = 255;                         // full green channel
    b = Math.round(50 + u * 80);    // 50→130 (adds cyan punch at peak)
  }
  return `rgb(${r},${g},${b})`;
}

// Map RSSI → bucket index
function _rssiBucket(rssi) {
  if (rssi == null || isNaN(rssi)) return -1;
  return Math.max(0, Math.min(HATCH_BUCKETS - 1,
    Math.round((rssi - HATCH_WORST) / HATCH_RANGE * (HATCH_BUCKETS - 1))
  ));
}

/**
 * Generate <defs> block with 45° crosshatch patterns for heatmap cells.
 * @param {string} prefix - unique prefix to avoid SVG ID collisions (e.g. "rm2d", "rmiso", "rmfl")
 * @param {number} spacing - pattern tile size in the coordinate system (e.g. 0.012 for viewBox 0-1)
 * @param {number} lineW - stroke width of hatch lines
 * @returns {string} SVG <defs>...</defs> block
 */
export function hatchDefs(prefix, spacing, lineW) {
  let s = "<defs>";
  // Airy dotted pattern: short dot, long gap — mostly empty space
  const dotLen = (lineW * 1.2).toFixed(5);
  const gapLen = (lineW * 4.0).toFixed(5);
  const dash = `${dotLen} ${gapLen}`;
  for (let i = 0; i < HATCH_BUCKETS; i++) {
    const c = _bucketRGB(i);
    const sp = spacing.toFixed(5);
    // Line width grows with bucket index: weakest = base, strongest = 1.6× base
    const scale = 1.0 + (i / (HATCH_BUCKETS - 1)) * 0.6;
    const lw = (lineW * scale).toFixed(5);
    // Rotate from 45° (red/worst) to 185° (green/best) — 140° sweep
    const angle = 45 + (i / (HATCH_BUCKETS - 1)) * 140;
    // Gap is wider for red (more sparse/airy) and tighter for green (more solid/confident)
    const gapScale = 8.0 - (i / (HATCH_BUCKETS - 1)) * 4.5; // 8.0 (red, very sparse) → 3.5 (green, denser)
    const dotS = (lineW * scale * 1.2).toFixed(5);
    const gapS = (lineW * scale * gapScale).toFixed(5);
    s += `<pattern id="${prefix}_${i}" x="0" y="0" width="${sp}" height="${sp}" patternUnits="userSpaceOnUse" patternTransform="rotate(${angle.toFixed(1)})">`;
    s += `<line x1="0" y1="0" x2="0" y2="${sp}" stroke="${c}" stroke-width="${lw}" stroke-dasharray="${dotS} ${gapS}" stroke-linecap="round" opacity="0.8"/>`;
    s += `</pattern>`;
  }
  // Null bucket for no-data cells
  s += `<pattern id="${prefix}_null" x="0" y="0" width="${spacing.toFixed(5)}" height="${spacing.toFixed(5)}" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">`;
  s += `<line x1="0" y1="0" x2="0" y2="${spacing.toFixed(5)}" stroke="#333" stroke-width="${lineW.toFixed(5)}" stroke-dasharray="${dash}" stroke-linecap="round" opacity="0.1"/>`;
  s += `</pattern>`;
  s += "</defs>";
  return s;
}

/** Get fill attribute for a cell: url(#prefix_N) */
function _hatchFill(prefix, rssi) {
  const idx = _rssiBucket(rssi);
  return idx < 0 ? `url(#${prefix}_null)` : `url(#${prefix}_${idx})`;
}

// ── Line Segment Intersection ────────────────────────────────────────────────
// Returns true if segment (ax,ay)→(bx,by) intersects segment (cx,cy)→(dx,dy)

function _segmentsIntersect(ax, ay, bx, by, cx, cy, dx, dy) {
  const denom = (bx - ax) * (dy - cy) - (by - ay) * (dx - cx);
  if (Math.abs(denom) < 1e-12) return false;
  const t = ((cx - ax) * (dy - cy) - (cy - ay) * (dx - cx)) / denom;
  const u = ((cx - ax) * (by - ay) - (cy - ay) * (bx - ax)) / denom;
  return t >= 0 && t <= 1 && u >= 0 && u <= 1;
}

/**
 * Compute total barrier attenuation (dBm) between two points.
 * Checks every barrier segment for intersections with the line (x1,y1)→(x2,y2).
 */
export function barrierAttenuation(x1, y1, x2, y2, barriers) { return _barrierAttenuation(x1, y1, x2, y2, barriers); }

function _barrierAttenuation(x1, y1, x2, y2, barriers) {
  let totalDb = 0;
  for (const bar of barriers) {
    const pts = bar.points || [];
    const atten = bar.attenuation_dbm ?? 6;
    for (let i = 0; i < pts.length - 1; i++) {
      const [cx, cy] = pts[i];
      const [dx, dy] = pts[i + 1];
      if (_segmentsIntersect(x1, y1, x2, y2, cx, cy, dx, dy)) {
        totalDb += atten;
      }
    }
  }
  return totalDb;
}

// ── Barrier-aware IDW Interpolation ──────────────────────────────────────────

/**
 * Interpolate RSSI at (qx, qy) from calibration points using barrier-aware IDW.
 * Barriers between query point and calibration point add virtual distance,
 * reducing the weight of points on the other side of walls.
 */
function _idw(qx, qy, points, barriers) {
  if (!points.length) return null;
  let wSum = 0, vSum = 0;
  for (const p of points) {
    const dx = qx - p.x_frac;
    const dy = qy - p.y_frac;
    let dist = Math.sqrt(dx * dx + dy * dy);
    if (dist < 0.001) return p.rssi; // exact match

    // Add virtual distance for barriers crossed
    if (barriers && barriers.length) {
      const attenDb = _barrierAttenuation(qx, qy, p.x_frac, p.y_frac, barriers);
      if (attenDb > 0) {
        dist += attenDb * BARRIER_PENALTY_DB_TO_DIST;
      }
    }

    const w = 1.0 / Math.pow(dist, IDW_POWER);
    wSum += w;
    vSum += w * p.rssi;
  }
  return wSum > 0 ? vSum / wSum : null;
}

/** Scanner sources seen on one map's own calibration points, most-sampled first. */
export function getMapScanners(calPoints, mapId) {
  const mapPts = (calPoints || []).filter(p => p.map_id === mapId);
  const scannerMap = {};
  for (const pt of mapPts) {
    for (const r of (pt.scanner_readings || [])) {
      if (!r.source) continue;
      if (!scannerMap[r.source]) scannerMap[r.source] = { source: r.source, name: r.name || r.source, pointCount: 0 };
      scannerMap[r.source].pointCount++;
    }
  }
  return Object.values(scannerMap).sort((a, b) => b.pointCount - a.pointCount);
}


// ── Isometric overlays: one storey of the fabric, in metres ─────────────────
//
// The overview draws the building from the metric fabric, and these overlays
// are drawn ON that building, so they take the building the same way: as a
// STOREY the caller has already resolved from the fabric —
//
//   {
//     z,          // the storey's height in the frame; what iso(x, y, z) takes
//     rooms:     [{ room, pts: [[x_m, y_m], ...] }],        // rooms on it
//     scanners:  [{ source, x_m, y_m, dz_m, floorDist }],   // within 2 storeys
//     barriers:  [{ points: [[x_m, y_m], ...], attenuation_dbm, floorDist }],
//                // also within 2 storeys, for a cross-floor scanner's ray —
//                // _modelRssiAt skips a wall whose floorDist exceeds the
//                // scanner's own, so a same-floor ray only ever crosses
//                // this storey's walls, matching the 2D model.
//     calPoints: [{ x_m, y_m, query: { source: rssi } }],   // taken on it
//   }
//
// Every coordinate is metres and iso() is the frame's own projection, so a
// cell lands exactly on the room it covers. These used to take the photos
// grouped at a level and a per-photo pixel transform, and computed the grid's
// extent from the CORNERS OF THE PICTURES — a plan photographed with a wide
// margin heated the driveway, and once indoor plans stopped carrying a pixel
// transform at all the extent was empty and nothing drew. A floor with no
// photograph never had an overlay. The building's extent is its rooms.
//
// dz_m is scanner height minus the assumed device height on the drawn storey,
// so a ceiling radio directly overhead models as a slant range, not zero.

const ISO_RASTER_GRID = 56; // model samples across a storey's extent — the
                             // ONLY resolution the model runs at now; the
                             // range pass, the raster and the hatch-mosaic
                             // fallback all read the same cached grid (see
                             // _storeyModelGridCached) instead of each
                             // sampling the model at its own resolution.
const DISTORTION_GRID = 30; // ~30 cells across the storey's shorter side

/** The storey's extent in metres: the box around its rooms. Null if none. */
function _storeyExtent(storey) {
  const bb = { minX: Infinity, minY: Infinity, maxX: -Infinity, maxY: -Infinity };
  for (const r of (storey.rooms || [])) {
    for (const [x, y] of (r.pts || [])) {
      if (x < bb.minX) bb.minX = x; if (x > bb.maxX) bb.maxX = x;
      if (y < bb.minY) bb.minY = y; if (y > bb.maxY) bb.maxY = y;
    }
  }
  if (!isFinite(bb.minX)) return null;
  if (bb.maxX - bb.minX < 1e-6 || bb.maxY - bb.minY < 1e-6) return null;
  return bb;
}

/**
 * Per-scanner quality offset from what the radios are hearing right now:
 * a scanner whose best current RSSI sits above the fleet median is modelled
 * a little hotter, one below it a little colder. Clamped to ±10 dB.
 */
function _scannerQuality(liveSnap) {
  const out = {};
  const ads = (liveSnap && liveSnap.ble && liveSnap.ble.advertisements) || [];
  if (!ads.length) return out;
  const best = {};
  for (const ad of ads) {
    if (!ad.source || ad.rssi == null || (ad.age_s || 0) > 30) continue;
    if (best[ad.source] === undefined || ad.rssi > best[ad.source]) best[ad.source] = ad.rssi;
  }
  const vals = Object.values(best).sort((a, b) => a - b);
  if (vals.length < 2) return out;
  const median = vals[Math.floor(vals.length / 2)];
  for (const [src, b] of Object.entries(best)) out[src] = Math.max(-10, Math.min(10, b - median));
  return out;
}

/**
 * Modelled RSSI at a point on the storey: the strongest scanner by log-distance
 * path loss over the 3D range, less a slab per storey of separation, less every
 * barrier the ray crosses. -120 when there is nothing to hear.
 */
function _modelRssiAt(x, y, scanners, barriers, refPower, pathLossN, quality) {
  let best = -120;
  for (const sc of scanners) {
    const horiz = Math.hypot(x - sc.x_m, y - sc.y_m);
    const distM = Math.max(0.3, Math.hypot(horiz, sc.dz || 0));
    let rssi = (refPower + (quality[sc.source] || 0)) - 10 * pathLossN * Math.log10(distM);
    if (sc.floorDist > 0) rssi -= sc.floorDist * FLOOR_ATTEN_DB;
    for (const bar of barriers) {
      // barriers carries every wall within 2 storeys (overview.js's
      // _storeyOf) because a scanner on another floor DOES need this
      // storey's and the intervening storeys' walls. A same-floor scanner
      // (floorDist 0) does not — its ray never leaves this storey, so a
      // wall on a DIFFERENT floor whose plan-view projection happens to
      // cross the ray must not attenuate it. Caught live: the 2D sibling
      // (modelFloorHeatmapSVG) already filters to same-floor walls only via
      // fabricWorldBarriers, so the two heatmaps disagreed on this exact
      // case before this line existed.
      if ((bar.floorDist ?? 0) > (sc.floorDist ?? 0)) continue;
      const bp = bar.points;
      for (let i = 0; i < bp.length - 1; i++) {
        if (_segmentsIntersect(x, y, sc.x_m, sc.y_m, bp[i][0], bp[i][1], bp[i + 1][0], bp[i + 1][1])) {
          rssi -= (bar.attenuation_dbm ?? 6);
        }
      }
    }
    if (rssi > best) best = rssi;
  }
  return best;
}

/** The storey's rooms in the shape the adaptive lookup hit-tests. */
function _storeyRoomPolys(storey) {
  return (storey.rooms || []).map(r => ({ room: r.room, polyW: r.pts }));
}

/**
 * <defs> for the 3D hatch patterns. Emit ONCE per svg, before any storey.
 */
export function isoHatchDefs() {
  return hatchDefs("rmiso", 6, 2.5);
}

/**
 * The modelled RSSI over a storey's extent: the grid the heatmap paints and
 * the range it spans. Null when there is nothing to model (no rooms, or no
 * scanner within reach).
 */
function _storeyModelGrid(storey, liveSnap, settings, res = ISO_RASTER_GRID) {
  const bb = _storeyExtent(storey);
  if (!bb) return null;
  const scanners = storey.scanners || [];
  if (!scanners.length) return null;
  const barriers = storey.barriers || [];
  const refPower = settings?.ref_power ?? DEFAULT_REF_POWER;
  const pathLossN = settings?.path_loss_exp ?? DEFAULT_PATH_LOSS_N;
  const quality = _scannerQuality(liveSnap);
  const roomPolys = (_sourceBlend > 0 && _adaptiveFingerprints) ? _storeyRoomPolys(storey) : [];

  const cellW = (bb.maxX - bb.minX) / res, cellH = (bb.maxY - bb.minY) / res;
  let minR = 0, maxR = -120;
  const grid = new Float32Array(res * res);
  for (let gy = 0; gy < res; gy++) {
    for (let gx = 0; gx < res; gx++) {
      const qx = bb.minX + (gx + 0.5) * cellW;
      const qy = bb.minY + (gy + 0.5) * cellH;
      let rssi = _modelRssiAt(qx, qy, scanners, barriers, refPower, pathLossN, quality);
      if (roomPolys.length) {
        const aOff = _adaptiveOffset(qx, qy, roomPolys);
        if (aOff != null) rssi += aOff * (_sourceBlend / 100);
      }
      grid[gy * res + gx] = rssi;
      if (rssi > maxR) maxR = rssi;
      if (rssi < minR) minR = rssi;
    }
  }
  return { bb, res, cellW, cellH, grid, minR, maxR };
}

// Storey objects are recreated fresh every build (overview.js's _storeyOf
// makes a new one per z per call), so a plain WeakMap self-clears — nothing
// to invalidate, nothing that outlives the build it was made for. The range
// pass, the raster paint and the hatch-mosaic fallback all want the SAME
// modelled grid for the same storey; without this each ran the model
// separately, up to three times per storey per build (one 36-cell pass for
// the range, a 56-cell pass for the raster, then a THIRD 36-cell pass if the
// raster's canvas encode failed) at model-plus-canvas cost that runs on
// every full rebuild — gain/contrast slider moves included.
const _storeyGridCache = new WeakMap();
function _storeyModelGridCached(storey, liveSnap, settings) {
  let g = _storeyGridCache.get(storey);
  if (g === undefined) {
    g = _storeyModelGrid(storey, liveSnap, settings);
    _storeyGridCache.set(storey, g);
  }
  return g;
}

/**
 * The RSSI range a storey's model spans, so the caller can put every storey
 * on ONE colour scale — otherwise each floor is scaled to itself and a badly
 * covered floor looks as green as a good one. Null when nothing models.
 */
export function isoStoreyRssiRange(storey, liveSnap, settings) {
  const g = _storeyModelGridCached(storey, liveSnap, settings);
  return g ? { minR: g.minR, maxR: g.maxR } : null;
}

// ── Continuous coverage raster ──────────────────────────────────────────────
// The storey heat used to be a 36×36 mosaic of iso-projected quads, each filled
// with one of 16 sparse dotted-hatch patterns rotated to a different angle per
// bucket: ~1300 mismatched, mostly-empty textures in 16 colour steps, which is
// what "very poor resolution" looked like (Garry, 2026-09-09). Real coverage
// tools draw a continuous interpolated raster clipped to the plan. So: model
// the RSSI on a finer grid, upsample it bilinearly to pixels, colour each pixel
// from a continuous ramp, encode to PNG once, and place it as ONE <image> whose
// matrix() maps it onto the slab exactly (the iso projection is affine in x,y
// for a fixed storey). The hatch mosaic stays as the fallback wherever a real
// 2D canvas is unavailable (node's DOM shim), so every install still draws.

const ISO_RASTER_UP   = 4;    // pixels per model sample after bilinear upsample
const ISO_RASTER_ALPHA = 158; // 0.62 — the slab pattern and room fills stay legible

// Red = worst, green = best, as everywhere else in PadSpan. Interpolated in
// OKLab so there is no muddy band between stops, and with lightness rising
// monotonically from worst to best so the magnitude reads by luminance alone
// (colour-vision deficiency, print, a dim panel) — not only by hue.
// Stops: deep red → red → amber → lime → mint. OKLab L ≈ .38 .53 .72 .82 .86.
const HEAT_STOPS = [
  [0.00, 0x6b, 0x0d, 0x12],
  [0.25, 0xc8, 0x26, 0x2a],
  [0.50, 0xef, 0x8f, 0x1f],
  [0.72, 0xb9, 0xd3, 0x32],
  [1.00, 0x3e, 0xf0, 0xa3],
];
const _s2l = c => { c /= 255; return c <= 0.04045 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4); };
const _l2s = c => { c = Math.max(0, Math.min(1, c)); return Math.round(255 * (c <= 0.0031308 ? 12.92 * c : 1.055 * Math.pow(c, 1 / 2.4) - 0.055)); };
/** sRGB 0–255 → OKLab. Exported for the ramp-monotonicity test. */
export function srgbToOklab(r, g, b) {
  const lr = _s2l(r), lg = _s2l(g), lb = _s2l(b);
  const l = Math.cbrt(0.4122214708 * lr + 0.5363325363 * lg + 0.0514459929 * lb);
  const m = Math.cbrt(0.2119034982 * lr + 0.6806995451 * lg + 0.1073969566 * lb);
  const s = Math.cbrt(0.0883024619 * lr + 0.2817188376 * lg + 0.6299787005 * lb);
  return [
    0.2104542553 * l + 0.7936177850 * m - 0.0040720468 * s,
    1.9779984951 * l - 2.4285922050 * m + 0.4505937099 * s,
    0.0259040371 * l + 0.7827717662 * m - 0.8086757660 * s,
  ];
}
function _oklabToSrgb(L, a, b) {
  const l = Math.pow(L + 0.3963377774 * a + 0.2158037573 * b, 3);
  const m = Math.pow(L - 0.1055613458 * a - 0.0638541728 * b, 3);
  const s = Math.pow(L - 0.0894841775 * a - 1.2914855480 * b, 3);
  return [
    _l2s(+4.0767416621 * l - 3.3077115913 * m + 0.2309699292 * s),
    _l2s(-1.2684380046 * l + 2.6097574011 * m - 0.3413193965 * s),
    _l2s(-0.0041960863 * l - 0.7034186147 * m + 1.7076147010 * s),
  ];
}
// 256-entry LUT, built once: t in [0,1] → [r,g,b].
const HEAT_LUT = (() => {
  const lab = HEAT_STOPS.map(([t, r, g, b]) => [t, ...srgbToOklab(r, g, b)]);
  const out = new Uint8ClampedArray(256 * 3);
  for (let i = 0; i < 256; i++) {
    const t = i / 255;
    let k = 0;
    while (k < lab.length - 2 && t > lab[k + 1][0]) k++;
    const [t0, L0, a0, b0] = lab[k], [t1, L1, a1, b1] = lab[k + 1];
    const u = t1 > t0 ? Math.max(0, Math.min(1, (t - t0) / (t1 - t0))) : 0;
    const [r, g, b] = _oklabToSrgb(L0 + (L1 - L0) * u, a0 + (a1 - a0) * u, b0 + (b1 - b0) * u);
    out[i * 3] = r; out[i * 3 + 1] = g; out[i * 3 + 2] = b;
  }
  return out;
})();
/** Ramp colour for t in [0,1] (0 = worst, 1 = best). Clamped. */
export function heatRamp(t) {
  const i = Math.max(0, Math.min(255, Math.round((isFinite(t) ? t : 0) * 255)));
  return [HEAT_LUT[i * 3], HEAT_LUT[i * 3 + 1], HEAT_LUT[i * 3 + 2]];
}
/** The ramp as a CSS gradient, for a legend bar beside the map. */
export function heatRampCSS(n = 12) {
  const stops = [];
  for (let i = 0; i <= n; i++) {
    const [r, g, b] = heatRamp(i / n);
    stops.push(`rgb(${r},${g},${b}) ${((i / n) * 100).toFixed(0)}%`);
  }
  return `linear-gradient(90deg, ${stops.join(", ")})`;
}
/** The dBm the ramp's two ends currently stand for (after gain/contrast). */
export function heatScale() {
  return { worst: HATCH_WORST, best: HATCH_BEST };
}

/**
 * Bilinearly upsample a res×res RSSI grid to (res·up)×(res·up) RGBA pixels,
 * coloured through the ramp on the [worst, worst+range] dBm scale. A NaN
 * sample is transparent (nothing modelled); anything at or below `worst`
 * is the deepest red, as the hatch mosaic already drew it.
 */
export function heatRaster(grid, res, up, worst, range, alpha = ISO_RASTER_ALPHA) {
  const w = res * up, h = res * up;
  const px = new Uint8ClampedArray(w * h * 4);
  const inv = range > 0 ? 1 / range : 0;
  for (let y = 0; y < h; y++) {
    // Sample centres: pixel (y+0.5)/up lands on grid coordinate gy - 0.5.
    const fy = Math.max(0, Math.min(res - 1, (y + 0.5) / up - 0.5));
    const y0 = Math.floor(fy), y1 = Math.min(res - 1, y0 + 1), ty = fy - y0;
    for (let x = 0; x < w; x++) {
      const fx = Math.max(0, Math.min(res - 1, (x + 0.5) / up - 0.5));
      const x0 = Math.floor(fx), x1 = Math.min(res - 1, x0 + 1), tx = fx - x0;
      const v00 = grid[y0 * res + x0], v10 = grid[y0 * res + x1];
      const v01 = grid[y1 * res + x0], v11 = grid[y1 * res + x1];
      const v = (v00 * (1 - tx) + v10 * tx) * (1 - ty) + (v01 * (1 - tx) + v11 * tx) * ty;
      const o = (y * w + x) * 4;
      if (!isFinite(v)) { px[o + 3] = 0; continue; }
      const t = (v - worst) * inv;
      const c = heatRamp(t);
      px[o] = c[0]; px[o + 1] = c[1]; px[o + 2] = c[2]; px[o + 3] = alpha;
    }
  }
  return { px, w, h };
}

/**
 * The SVG matrix(a b c d e f) that maps a w×h image onto the storey's extent
 * under `iso`: image pixel (0,0) lands on iso(bb.minX, bb.minY), (w,0) on
 * iso(bb.maxX, bb.minY), (0,h) on iso(bb.minX, bb.maxY). Exact because the
 * projection is affine in x,y for a fixed storey.
 */
export function isoImageMatrix(iso, bb, z, w, h) {
  const p0 = iso(bb.minX, bb.minY, z), p1 = iso(bb.maxX, bb.minY, z), p3 = iso(bb.minX, bb.maxY, z);
  return [
    (p1[0] - p0[0]) / w, (p1[1] - p0[1]) / w,
    (p3[0] - p0[0]) / h, (p3[1] - p0[1]) / h,
    p0[0], p0[1],
  ];
}

/**
 * RGBA pixels → PNG data URL through a 2D canvas. Null wherever a real canvas
 * is unavailable (node's DOM shim answers createImageData with undefined), so
 * the caller falls back to the hatch mosaic instead of drawing a blank image.
 */
export function rasterPNG(px, w, h) {
  try {
    if (typeof document === "undefined" || !document.createElement) return null;
    const cv = document.createElement("canvas");
    cv.width = w; cv.height = h;
    const c2 = cv.getContext && cv.getContext("2d");
    if (!c2 || typeof c2.createImageData !== "function") return null;
    const img = c2.createImageData(w, h);
    if (!img || !img.data || img.data.length !== px.length) return null;
    img.data.set(px);
    c2.putImageData(img, 0, 0);
    const url = cv.toDataURL("image/png");
    return (typeof url === "string" && url.length > 40 && url.startsWith("data:image/png")) ? url : null;
  } catch (_e) {
    return null;
  }
}

/**
 * Modelled coverage heatmap for one storey: a continuous raster over the
 * storey's extent, clipped to its rooms, coloured by the strongest scanner's
 * predicted RSSI and blended with the room's observed offset when a source
 * blend is set; the hatch mosaic where no canvas can encode a raster. `range`
 * is the shared colour scale ({minR, maxR}); the storey's own range when
 * omitted.
 */
export function isoStoreyHeatmapSVG(storey, iso, liveSnap, settings, range) {
  const z = storey.z;
  const f = v => v.toFixed(1);

  // ── Raster path ── same grid isoStoreyRssiRange already modelled for the
  // shared range, and the one the fallback below reuses if the canvas fails.
  const gr = _storeyModelGridCached(storey, liveSnap, settings);
  if (!gr) return "";
  setHatchRange(range ? range.minR : gr.minR, range ? range.maxR : gr.maxR, _userGain, _userContrast);
  const ras = heatRaster(gr.grid, gr.res, ISO_RASTER_UP, HATCH_WORST, HATCH_RANGE);
  const png = rasterPNG(ras.px, ras.w, ras.h);
  if (png) {
    const [a, b, c, d, e, ff] = isoImageMatrix(iso, gr.bb, z, ras.w, ras.h);
    // The scale terms are small (screen px per raster px); one decimal would
    // round them to zero and collapse the image.
    const m = v => (+v).toFixed(5);
    const clipId = `rmisoclip_${String(z).replace(/[^0-9A-Za-z_-]/g, "_")}`;
    let s = `<clipPath id="${clipId}" clipPathUnits="userSpaceOnUse">`;
    for (const r of (storey.rooms || [])) {
      const pp = (r.pts || []).map(p => { const q = iso(p[0], p[1], z); return `${f(q[0])},${f(q[1])}`; }).join(" ");
      if (pp) s += `<polygon points="${pp}"/>`;
    }
    s += `</clipPath>`;
    // The clip lives on a wrapper <g>, not on the <image>: a userSpaceOnUse
    // clip-path is evaluated in the clipped element's OWN coordinate system,
    // so on the transformed image the screen-space room polygons would be
    // pushed through the matrix too and clip to a wedge in the wrong place.
    s += `<g clip-path="url(#${clipId})">`
       + `<image href="${png}" x="0" y="0" width="${ras.w}" height="${ras.h}" preserveAspectRatio="none" `
       + `transform="matrix(${m(a)} ${m(b)} ${m(c)} ${m(d)} ${m(e)} ${m(ff)})"/>`
       + `</g>`;
    return s;
  }

  // ── Fallback: the hatch mosaic — same grid as the raster attempt above,
  // not a third model pass; setHatchRange already ran, so the fallback
  // colours against the exact same scale the raster would have painted.
  const { bb, res, cellW, cellH, grid } = gr;
  const _pfx = "rmiso";
  let s = "";
  // Slight overlap prevents hairline gaps between cells in iso projection.
  const pad = cellW * 0.08;
  for (let gy = 0; gy < res; gy++) {
    for (let gx = 0; gx < res; gx++) {
      const fill = _hatchFill(_pfx, grid[gy * res + gx]);
      const x0 = bb.minX + gx * cellW - pad, y0 = bb.minY + gy * cellH - pad;
      const x1 = x0 + cellW + pad * 2, y1 = y0 + cellH + pad * 2;
      const p0 = iso(x0, y0, z), p1 = iso(x1, y0, z), p2 = iso(x1, y1, z), p3 = iso(x0, y1, z);
      s += `<polygon points="${f(p0[0])},${f(p0[1])} ${f(p1[0])},${f(p1[1])} ${f(p2[0])},${f(p2[1])} ${f(p3[0])},${f(p3[1])}" fill="${fill}"/>`;
    }
  }
  return s;
}

/**
 * Deformation grid for one storey. A regular square grid in metres, each
 * node displaced toward where k-NN over the storey's calibration points
 * PREDICTS that node to be: square where positioning is faithful, warped
 * where it is not. Lines carry the modelled-coverage colour so the two
 * overlays read on one scale; `range` is that shared scale ({minR, maxR}).
 */
export function isoStoreyDistortionSVG(storey, iso, liveSnap, settings, range) {
  const bb = _storeyExtent(storey);
  if (!bb) return "";
  const calWorldPts = (storey.calPoints || [])
    .filter(p => p && p.x_m != null && p.y_m != null && p.query && Object.keys(p.query).length)
    .map(p => ({ wx: p.x_m, wy: p.y_m, query: p.query }));
  if (calWorldPts.length < KNN_K + 1) return "";
  const scanners = storey.scanners || [];
  const barriers = storey.barriers || [];
  const refPower = settings?.ref_power ?? DEFAULT_REF_POWER;
  const pathLossN = settings?.path_loss_exp ?? DEFAULT_PATH_LOSS_N;
  const quality = _scannerQuality(liveSnap);
  const roomPolys = (_sourceBlend > 0 && _adaptiveFingerprints) ? _storeyRoomPolys(storey) : [];

  const wW = bb.maxX - bb.minX, wH = bb.maxY - bb.minY;
  // Square cells: one size for both axes.
  const cellSize = Math.min(wW, wH) / DISTORTION_GRID;
  // Cap columns/rows: a long narrow storey (corridor-shaped) would otherwise
  // produce hundreds of cells instead of the intended ~DISTORTION_GRID.
  const resX = Math.min(90, Math.max(2, Math.ceil(wW / cellSize)));
  const resY = Math.min(90, Math.max(2, Math.ceil(wH / cellSize)));
  const cellW = wW / resX, cellH = wH / resY;
  const f = v => v.toFixed(1);
  const z = storey.z;

  let minR = 0, maxR = -120;
  const grid = [];
  for (let gy = 0; gy <= resY; gy++) {
    grid[gy] = [];
    for (let gx = 0; gx <= resX; gx++) {
      const wx = bb.minX + gx * cellW, wy = bb.minY + gy * cellH;
      const [pwx, pwy] = _predictPosition(wx, wy, calWorldPts);
      let rssi = _modelRssiAt(wx, wy, scanners, barriers, refPower, pathLossN, quality);
      if (roomPolys.length) {
        const aOff = _adaptiveOffset(wx, wy, roomPolys);
        if (aOff != null) rssi += aOff * (_sourceBlend / 100);
      }
      if (rssi > maxR) maxR = rssi;
      if (rssi < minR) minR = rssi;
      grid[gy][gx] = { wx, wy, pwx, pwy, rssi };
    }
  }
  setHatchRange(range ? range.minR : minR, range ? range.maxR : maxR, _userGain, _userContrast);

  const blend = _distortionIntensity / 100;
  const seg = (a, b) => {
    const ax = a.wx + (a.pwx - a.wx) * blend, ay = a.wy + (a.pwy - a.wy) * blend;
    const bx = b.wx + (b.pwx - b.wx) * blend, by = b.wy + (b.pwy - b.wy) * blend;
    const bucket = _rssiBucket((a.rssi + b.rssi) / 2);
    const color = bucket >= 0 ? _bucketRGB(bucket) : "#333";
    const [sx1, sy1] = iso(ax, ay, z), [sx2, sy2] = iso(bx, by, z);
    return `<line x1="${f(sx1)}" y1="${f(sy1)}" x2="${f(sx2)}" y2="${f(sy2)}" stroke="${color}" stroke-width="1.5" opacity="0.7"/>`;
  };
  let s = "";
  for (let gy = 0; gy <= resY; gy++) for (let gx = 0; gx < resX; gx++) s += seg(grid[gy][gx], grid[gy][gx + 1]);
  for (let gx = 0; gx <= resX; gx++) for (let gy = 0; gy < resY; gy++) s += seg(grid[gy][gx], grid[gy + 1][gx]);
  return s;
}


// ═══════════════════════════════════════════════════════════════════════════════
// World-Space Floor Heatmap
// ═══════════════════════════════════════════════════════════════════════════════
// Merges calibration data from ALL maps on a floor into a single unified
// interpolation in world coordinates. No per-map isolation — a calibration
// point on Map A contributes to the heatmap in Map B's territory if they
// share the same floor. Barriers from all maps are also combined.

const FLOOR_GRID = 42; // 42x42 grid in world space

/**
 * Model-based RF heatmap — uses scanner positions + path-loss physics.
 * No calibration data needed. Shows predicted signal coverage from known
 * scanner locations, attenuated by walls.
 */
export function modelFloorHeatmapSVG(floorMaps, mapPtFns, w2v, wBB, settings, allMaps, liveSnap, model) {
  if (!floorMaps.length) return "";

  const refPower = settings?.ref_power ?? DEFAULT_REF_POWER;
  const pathLossN = settings?.path_loss_exp ?? DEFAULT_PATH_LOSS_N;
  const _floorZ = (floorMaps[0].stack?.z_level) ?? 0;
  const _allMapZ = {};
  for (const m of (allMaps || floorMaps)) { _allMapZ[m.id] = (m.stack?.z_level) ?? 0; }

  // ── Per-scanner quality factor from live advertisement data ──
  // Computes effective ref_power per scanner based on actual observed signal strength.
  // Good scanners (strong antenna, good placement) get higher effective power.
  const scannerQuality = {}; // source → quality offset in dB
  const ads = (liveSnap?.ble?.advertisements) || [];
  if (ads.length) {
    const scannerBestRssi = {}; // source → best RSSI seen from any device
    const scannerDevCount = {}; // source → device count
    for (const ad of ads) {
      if (!ad.source || ad.rssi == null || (ad.age_s || 0) > 30) continue;
      if (!scannerBestRssi[ad.source] || ad.rssi > scannerBestRssi[ad.source]) {
        scannerBestRssi[ad.source] = ad.rssi;
      }
      scannerDevCount[ad.source] = (scannerDevCount[ad.source] || 0) + 1;
    }
    // Fleet best (median of per-scanner bests)
    const bestVals = Object.values(scannerBestRssi);
    if (bestVals.length > 1) {
      bestVals.sort((a, b) => a - b);
      const fleetMedianBest = bestVals[Math.floor(bestVals.length / 2)];
      for (const [src, best] of Object.entries(scannerBestRssi)) {
        // Quality offset: how much better/worse than fleet median
        // Capped at ±10 dB to prevent extreme distortion
        scannerQuality[src] = Math.max(-10, Math.min(10, best - fleetMedianBest));
      }
    }
  }

  // Scanner positions come from the fabric, never from a photo.
  const { scanners, mPerWorld } = _fabricScanners(
    allMaps || floorMaps, model, _floorZ, _allMapZ, scannerQuality, settings);
  if (!scanners.length) return "";

  // Walls come from the fabric, in the same world frame as the scanners —
  // never from a list on a photograph.
  const worldBarriers = fabricWorldBarriers(model, _floorId(floorMaps)) || [];

  // Build room boundary polygons in world coords (for adaptive data lookup)
  // — fabric-first, per-photo bounds as fallback
  const roomBoundsWorld = [];
  if (_sourceBlend > 0 && _adaptiveFingerprints) {
    const _fab = _fabricRoomPolysW(floorMaps);
    if (_fab) {
      roomBoundsWorld.push(..._fab);
    } else {
    for (const m of floorMaps) {
      const mpt = mapPtFns[m.id]; if (!mpt) continue;
      for (const [room, b] of Object.entries(m.room_bounds || {})) {
        if (!b || b.type !== "poly" || !Array.isArray(b.points) || b.points.length < 3) continue;
        const polyW = b.points.map(p => mpt(Number(p[0]), Number(p[1])));
        roomBoundsWorld.push({ room, polyW });
      }
    }
    }
  }

  const wW = wBB.maxX - wBB.minX, wH = wBB.maxY - wBB.minY;
  if (wW < 1e-6 || wH < 1e-6) return "";

  const blend = _sourceBlend / 100; // 0 = model only, 1 = adaptive only
  let minR = 0, maxR = -120;
  const res = FLOOR_GRID;
  const cellW = wW / res, cellH = wH / res;
  const gridRssi = new Float32Array(res * res);
  for (let gy = 0; gy < res; gy++) {
    for (let gx = 0; gx < res; gx++) {
      const qwx = wBB.minX + (gx + 0.5) * cellW;
      const qwy = wBB.minY + (gy + 0.5) * cellH;
      // Adjust scanners on other floors with attenuation
      let best = -120;
      for (const sc of scanners) {
        const dx = qwx - sc.wx, dy = qwy - sc.wy;
        const horizM = Math.sqrt(dx * dx + dy * dy) * mPerWorld;
        const distM = Math.max(0.3, Math.hypot(horizM, sc.dz || 0));
        // Per-scanner effective power: base ref_power + quality offset from live data
        let rssi = (refPower + (sc.qualityOffset || 0)) - 10 * pathLossN * Math.log10(distM);
        if (sc.floorDist > 0) rssi -= sc.floorDist * FLOOR_ATTEN_DB;
        // Barrier attenuation
        for (const bar of worldBarriers) {
          const bpts = bar.points;
          for (let i = 0; i < bpts.length - 1; i++) {
            if (_segmentsIntersect(qwx, qwy, sc.wx, sc.wy, bpts[i][0], bpts[i][1], bpts[i+1][0], bpts[i+1][1])) {
              rssi -= (bar.attenuation_dbm ?? 6);
            }
          }
        }
        if (rssi > best) best = rssi;
      }
      // Blend model + adaptive data
      let finalRssi = best;
      if (blend > 0 && roomBoundsWorld.length) {
        const aOff = _adaptiveOffset(qwx, qwy, roomBoundsWorld);
        if (aOff != null) finalRssi = best + aOff * blend;
      }
      gridRssi[gy * res + gx] = finalRssi;
      if (finalRssi > maxR) maxR = finalRssi;
      if (finalRssi < minR) minR = finalRssi;
    }
  }

  setHatchRange(minR, maxR, _userGain, _userContrast);

  const _pfx = "rmfl";
  const f = v => v.toFixed(5);
  let s = hatchDefs(_pfx, 0.008, 0.003);

  for (let gy = 0; gy < res; gy++) {
    for (let gx = 0; gx < res; gx++) {
      const rssi = gridRssi[gy * res + gx];
      const fill = _hatchFill(_pfx, rssi);
      const [v0x, v0y] = w2v(wBB.minX + gx * cellW, wBB.minY + gy * cellH);
      const [v1x, v1y] = w2v(wBB.minX + (gx+1) * cellW, wBB.minY + gy * cellH);
      const [v2x, v2y] = w2v(wBB.minX + (gx+1) * cellW, wBB.minY + (gy+1) * cellH);
      const [v3x, v3y] = w2v(wBB.minX + gx * cellW, wBB.minY + (gy+1) * cellH);
      s += `<polygon points="${f(v0x)},${f(v0y)} ${f(v1x)},${f(v1y)} ${f(v2x)},${f(v2y)} ${f(v3x)},${f(v3y)}" fill="${fill}"/>`;
    }
  }

  // Barrier lines — open/loft barriers render thin + dotted (no wall);
  // solid walls render thicker in proportion to their dB attenuation.
  const matColors = { metal: "#f87171", concrete: "#fb923c", brick: "#fbbf24", custom: "#94a3b8", open: "#38bdf8" };
  for (const bar of worldBarriers) {
    const color = matColors[bar.material] || matColors.custom;
    const d = bar.points.map((p, i) => { const [vx, vy] = w2v(p[0], p[1]); return `${i === 0 ? "M" : "L"}${f(vx)},${f(vy)}`; }).join(" ");
    if (bar.material === "open") {
      s += `<path d="${d}" fill="none" stroke="${color}" stroke-width="0.002" stroke-dasharray="0.004,0.008" opacity="0.5"/>`;
    } else {
      const sw = Math.max(0.003, Math.min(0.008, (bar.attenuation_dbm ?? 6) * 0.0006));
      s += `<path d="${d}" fill="none" stroke="${color}" stroke-width="${f(sw)}" stroke-dasharray="0.012,0.006" opacity="0.7"/>`;
    }
  }

  // Scanner position markers
  for (const sc of scanners.filter(sc => sc.floorDist === 0)) {
    const [vx, vy] = w2v(sc.wx, sc.wy);
    s += `<circle cx="${f(vx)}" cy="${f(vy)}" r="0.010" fill="#52b788" stroke="#071008" stroke-width="0.002" opacity="0.9"/>`;
  }

  // Legend
  const ly = 0.92;
  s += `<rect x="0.02" y="${ly - 0.01}" width="0.34" height="0.07" rx="0.006" fill="rgba(7,16,8,0.85)"/>`;
  s += `<text x="0.035" y="${ly + 0.008}" fill="#e2e8f0" font-size="0.014" font-weight="600" font-family="system-ui,sans-serif">Model RF Coverage</text>`;
  const flLegSteps = 8;
  const bw = 0.028;
  for (let i = 0; i < flLegSteps; i++) {
    const bucketIdx = Math.round(i / (flLegSteps - 1) * (HATCH_BUCKETS - 1));
    s += `<rect x="${(0.035 + i * bw).toFixed(3)}" y="${ly + 0.02}" width="${bw.toFixed(3)}" height="0.012" fill="${_bucketRGB(bucketIdx)}"/>`;
  }
  s += `<text x="0.035" y="${ly + 0.048}" fill="#fca5a5" font-size="0.01" font-family="system-ui,sans-serif">${Math.round(minR)}</text>`;
  s += `<text x="${(0.035 + (flLegSteps - 1) * bw).toFixed(3)}" y="${ly + 0.048}" fill="#52b788" font-size="0.01" font-family="system-ui,sans-serif">${Math.round(maxR)} dBm</text>`;
  s += `<text x="0.035" y="${ly + 0.058}" fill="#94a3b8" font-size="0.009" font-family="system-ui,sans-serif">${scanners.filter(sc=>sc.floorDist===0).length} scanners \u2022 path-loss n=${pathLossN}</text>`;

  return s;
}

/**
 * Legacy calibration-based heatmap (kept as fallback for installs still
 * relying on measured calibration points rather than the model-based
 * heatmap above). Generates a unified floor heatmap in view-normalized
 * coordinates by IDW-interpolating measured RSSI, not physics.
 *
 * @param {Array} calPoints - ALL calibration points from calibrationGet()
 * @param {Array} floorMaps - maps on this floor [{id, rf_barriers, ...}]
 * @param {Object} mapPtFns - {mapId: (lx,ly)=>[wx,wy]} transform per map
 * @param {Function} w2v - (wx,wy)=>[vx,vy] world→view transform
 * @param {Object} wBB - {minX,minY,maxX,maxY} world bounding box
 * @param {string|null} scannerSource - specific scanner or null for combined
 * @returns {string} SVG content (rects + markers in view coords)
 */
export function floorHeatmapSVG(calPoints, floorMaps, mapPtFns, w2v, wBB, scannerSource, allMaps, model) {
  if (!calPoints || !floorMaps.length) return "";

  const floorMapIds = new Set(floorMaps.map(m => m.id));
  // Determine this floor's z-level
  const _floorZ = (floorMaps[0].stack?.z_level) ?? 0;
  // Build map → z-level lookup from all maps (for cross-floor bleed)
  const _allMapZ = {};
  for (const m of (allMaps || floorMaps)) { _allMapZ[m.id] = (m.stack?.z_level) ?? 0; }

  // ── 1. Collect calibration points from this floor AND adjacent floors ──
  const worldPoints = [];
  for (const pt of calPoints) {
    const mpt = mapPtFns[pt.map_id];
    if (!mpt) continue;
    const ptZ = _allMapZ[pt.map_id];
    if (ptZ == null) continue;
    const floorDist = Math.abs(ptZ - _floorZ);
    if (floorDist > 2) continue; // skip floors more than 2 levels away

    const readings = pt.scanner_readings || [];
    let rssi;
    if (scannerSource) {
      const r = readings.find(rd => rd.source === scannerSource);
      if (!r || r.mean_rssi == null) continue;
      rssi = r.mean_rssi;
    } else {
      const rssis = readings.map(r => r.mean_rssi).filter(v => v != null);
      if (!rssis.length) continue;
      rssi = Math.max(...rssis);
    }
    // Attenuate cross-floor signal
    if (floorDist > 0) rssi -= floorDist * FLOOR_ATTEN_DB;

    const [wx, wy] = mpt(pt.x_frac, pt.y_frac);
    worldPoints.push({ wx, wy, rssi });
  }

  if (!worldPoints.length) return "";

  // Data-adaptive color range
  const _lvlRssis = worldPoints.map(p => p.rssi);
  setHatchRange(Math.min(..._lvlRssis), Math.max(..._lvlRssis), _userGain, _userContrast);

  // ── 2. Walls, from the fabric, in the world frame ─────────────────────────
  const worldBarriers = fabricWorldBarriers(model, _floorId(floorMaps)) || [];

  // ── 3. IDW interpolation in world space ────────────────────────────────────
  const wW = wBB.maxX - wBB.minX;
  const wH = wBB.maxY - wBB.minY;
  if (wW < 1e-6 || wH < 1e-6) return "";

  // Convert world points to IDW-compatible format (use world coords directly)
  const idwPoints = worldPoints.map(p => ({ x_frac: p.wx, y_frac: p.wy, rssi: p.rssi }));

  const cellW = wW / FLOOR_GRID;
  const cellH = wH / FLOOR_GRID;
  const f = v => v.toFixed(5);
  const _pfx = "rmfl";
  let s = hatchDefs(_pfx, 0.008, 0.003);

  for (let gy = 0; gy < FLOOR_GRID; gy++) {
    for (let gx = 0; gx < FLOOR_GRID; gx++) {
      const qwx = wBB.minX + (gx + 0.5) * cellW;
      const qwy = wBB.minY + (gy + 0.5) * cellH;
      const rssi = _idw(qwx, qwy, idwPoints, worldBarriers);
      const fill = _hatchFill(_pfx, rssi);

      // Convert cell corners from world → view coords
      const [v0x, v0y] = w2v(wBB.minX + gx * cellW, wBB.minY + gy * cellH);
      const [v1x, v1y] = w2v(wBB.minX + (gx+1) * cellW, wBB.minY + gy * cellH);
      const [v2x, v2y] = w2v(wBB.minX + (gx+1) * cellW, wBB.minY + (gy+1) * cellH);
      const [v3x, v3y] = w2v(wBB.minX + gx * cellW, wBB.minY + (gy+1) * cellH);

      s += `<polygon points="${f(v0x)},${f(v0y)} ${f(v1x)},${f(v1y)} ${f(v2x)},${f(v2y)} ${f(v3x)},${f(v3y)}" fill="${fill}"/>`;
    }
  }

  // ── 4. Barrier lines in view coords ────────────────────────────────────────
  // Open/loft: thin dotted (no wall). Solid walls: thickness ∝ attenuation dB.
  const matColors = { metal: "#f87171", concrete: "#fb923c", brick: "#fbbf24", custom: "#94a3b8", open: "#38bdf8" };
  for (const bar of worldBarriers) {
    const color = matColors[bar.material] || matColors.custom;
    const d = bar.points.map((p, i) => {
      const [vx, vy] = w2v(p[0], p[1]);
      return `${i === 0 ? "M" : "L"}${f(vx)},${f(vy)}`;
    }).join(" ");
    if (bar.material === "open") {
      s += `<path d="${d}" fill="none" stroke="${color}" stroke-width="0.002" stroke-dasharray="0.004,0.008" opacity="0.5"/>`;
    } else {
      const sw = Math.max(0.003, Math.min(0.008, (bar.attenuation_dbm ?? 6) * 0.0006));
      s += `<path d="${d}" fill="none" stroke="${color}" stroke-width="${f(sw)}" stroke-dasharray="0.012,0.006" opacity="0.7"/>`;
    }
  }

  // ── 5. Calibration point markers — colored + labeled for data verification ──
  for (const wp of worldPoints) {
    const [vx, vy] = w2v(wp.wx, wp.wy);
    const _wpB = _rssiBucket(wp.rssi);
    const _wpC = _wpB >= 0 ? _bucketRGB(_wpB) : "#e2e8f0";
    s += `<circle cx="${f(vx)}" cy="${f(vy)}" r="0.008" fill="${_wpC}" stroke="#071008" stroke-width="0.002" opacity="0.9"/>`;
    s += `<rect x="${f(vx + 0.008)}" y="${f(vy - 0.006)}" width="0.032" height="0.012" rx="0.002" fill="rgba(7,16,8,0.85)"/>`;
    s += `<text x="${f(vx + 0.012)}" y="${f(vy + 0.003)}" fill="${_wpC}" font-size="0.01" font-weight="700" font-family="monospace" opacity="0.95">${Math.round(wp.rssi)}</text>`;
  }

  // ── 6. Legend ──────────────────────────────────────────────────────────────
  const ly = 0.92;
  s += `<rect x="0.02" y="${ly - 0.01}" width="0.34" height="0.07" rx="0.006" fill="rgba(7,16,8,0.85)"/>`;
  s += `<text x="0.035" y="${ly + 0.008}" fill="#e2e8f0" font-size="0.014" font-weight="600" font-family="system-ui,sans-serif">${scannerSource ? "Scanner" : "Floor"} Radio Map</text>`;
  const flLegSteps = 8;
  const bw = 0.028;
  for (let i = 0; i < flLegSteps; i++) {
    const bucketIdx = Math.round(i / (flLegSteps - 1) * (HATCH_BUCKETS - 1));
    s += `<rect x="${(0.035 + i * bw).toFixed(3)}" y="${ly + 0.02}" width="${bw.toFixed(3)}" height="0.012" fill="${_bucketRGB(bucketIdx)}"/>`;
  }
  // _lvlRssis is THIS function's own range. The legend used to read a local
  // of a different function that did not exist here, and threw a
  // ReferenceError every time a floor heatmap was drawn.
  s += `<text x="0.035" y="${ly + 0.048}" fill="#fca5a5" font-size="0.01" font-family="system-ui,sans-serif">${Math.round(Math.min(..._lvlRssis))}</text>`;
  s += `<text x="${(0.035 + (flLegSteps - 1) * bw).toFixed(3)}" y="${ly + 0.048}" fill="#52b788" font-size="0.01" font-family="system-ui,sans-serif">${Math.round(Math.max(..._lvlRssis))} dBm</text>`;
  s += `<text x="0.035" y="${ly + 0.058}" fill="#94a3b8" font-size="0.009" font-family="system-ui,sans-serif">${worldPoints.length} points from ${floorMapIds.size} map${floorMapIds.size > 1 ? "s" : ""}</text>`;

  return s;
}

/**
 * Get unique scanner sources across all maps on a floor.
 */
export function getFloorScanners(calPoints, floorMapIds) {
  const idSet = new Set(floorMapIds);
  const scannerMap = {};
  for (const pt of (calPoints || [])) {
    if (!idSet.has(pt.map_id)) continue;
    for (const r of (pt.scanner_readings || [])) {
      if (!r.source) continue;
      if (!scannerMap[r.source]) scannerMap[r.source] = { source: r.source, name: r.name || r.source, pointCount: 0 };
      scannerMap[r.source].pointCount++;
    }
  }
  return Object.values(scannerMap).sort((a, b) => b.pointCount - a.pointCount);
}


// ═══════════════════════════════════════════════════════════════════════════════
// Deformation Grid — Distortion visualization
// ═══════════════════════════════════════════════════════════════════════════════
// Draws a regular grid where each intersection is warped to where the k-NN
// positioning system predicts it should be. Grid cells are colored with the
// same heatmap colors as the radio map. Distorted cells show where the system
// confuses physical space.


// Distortion intensity: 0 = no warp (regular grid), 100 = full warp. User-adjustable.
let _distortionIntensity = 50; // default 50%
export function setDistortionIntensity(v) { _distortionIntensity = Math.max(0, Math.min(100, v || 50)); }

// Source blend: 0 = pure model (physics), 100 = pure historical (adaptive data)
let _sourceBlend = 0; // default: model only
let _adaptiveFingerprints = null; // { room: { scanner: mean_rssi } }
export function setSourceBlend(v) { _sourceBlend = Math.max(0, Math.min(100, v ?? 0)); }
export function setAdaptiveData(fps) { _adaptiveFingerprints = fps; }

// Fabric room shapes in world coords (from stack_transform.fabricWorldRooms),
// set by the caller before rendering. When present, adaptive point-in-room
// hit-testing uses the committed fabric instead of per-photo room_bounds.
let _fabricWorld = null; // { room: { floor_id, pts: [[wx,wy],...] } } | null
export function setFabricWorld(fw) { _fabricWorld = fw || null; }
function _fabricRoomPolysW(maps) {
  if (!_fabricWorld) return null;
  const fids = new Set((maps || []).map(m => String(m.stack?.floor_id || m.floor_id || "main")));
  const out = [];
  for (const [room, fr] of Object.entries(_fabricWorld)) {
    if (fids.has(fr.floor_id)) out.push({ room, polyW: fr.pts });
  }
  return out.length ? out : null;
}

/**
 * Get adaptive correction for a world point.
 * Returns a dBm OFFSET (positive = real coverage is better than model,
 * negative = worse) based on the mean observed RSSI vs fleet average.
 * Returns null if no data.
 */
function _adaptiveOffset(wx, wy, roomBoundsWorld) {
  if (!_adaptiveFingerprints || !roomBoundsWorld) return null;
  for (const { room, polyW } of roomBoundsWorld) {
    let inside = false;
    for (let i = 0, j = polyW.length - 1; i < polyW.length; j = i++) {
      const [xi, yi] = polyW[i], [xj, yj] = polyW[j];
      if (((yi > wy) !== (yj > wy)) && (wx < (xj - xi) * (wy - yi) / (yj - yi) + xi)) inside = !inside;
    }
    if (!inside) continue;
    const roomFp = _adaptiveFingerprints[room];
    if (!roomFp) return null;
    const vals = Object.values(roomFp);
    if (!vals.length) return null;
    // Mean across all scanners for this room (not max — mean represents overall coverage quality)
    const roomMean = vals.reduce((a, b) => a + b, 0) / vals.length;
    // Compare to fleet average: how does this room compare to the typical room?
    // Fleet average from all rooms' means
    let fleetSum = 0, fleetN = 0;
    for (const rFp of Object.values(_adaptiveFingerprints)) {
      const rv = Object.values(rFp);
      if (rv.length) { fleetSum += rv.reduce((a,b)=>a+b,0)/rv.length; fleetN++; }
    }
    const fleetMean = fleetN > 0 ? fleetSum / fleetN : roomMean;
    // Offset: ONLY negative (can reveal problems, never boost).
    // If room is worse than fleet average → negative offset → redder.
    // If room is better than average → 0 (model already shows it as green).
    const raw = roomMean - fleetMean;
    return Math.max(-15, Math.min(0, raw));
  }
  return null;
}

/**
 * At a world-space query point, build a synthetic RSSI fingerprint by IDW from
 * nearby calibration points, then run k-NN to predict where the system thinks
 * this point is. Returns the predicted world position.
 */
function _predictPosition(qwx, qwy, calWorldPts) {
  if (calWorldPts.length < KNN_K) return [qwx, qwy];

  // Build synthetic fingerprint at (qwx,qwy) by IDW from nearby cal points
  const allSources = new Set();
  for (const p of calWorldPts) for (const src of Object.keys(p.query)) allSources.add(src);
  const synthFp = {};
  for (const src of allSources) {
    // IDW interpolation of this source's RSSI at the query point
    let wSum = 0, vSum = 0;
    for (const p of calWorldPts) {
      if (p.query[src] == null) continue;
      const dx = qwx - p.wx, dy = qwy - p.wy;
      const dist = Math.sqrt(dx * dx + dy * dy);
      if (dist < 0.001) { wSum = 1; vSum = p.query[src]; break; }
      const w = 1.0 / Math.pow(dist, 2.0);
      wSum += w; vSum += w * p.query[src];
    }
    if (wSum > 0) synthFp[src] = vSum / wSum;
  }

  // k-NN: find closest calibration points by RSSI distance
  const scored = [];
  for (const p of calWorldPts) {
    const shared = Object.keys(synthFp).filter(s => p.query[s] != null);
    if (!shared.length) continue;
    let distSq = 0;
    for (const s of shared) distSq += (synthFp[s] - p.query[s]) ** 2;
    scored.push({ distSq, p });
  }
  if (scored.length < KNN_K) return [qwx, qwy];
  scored.sort((a, b) => a.distSq - b.distSq);
  const topK = scored.slice(0, KNN_K);
  let wT = 0, pwx = 0, pwy = 0;
  for (const { distSq, p } of topK) {
    const w = 1.0 / (Math.sqrt(distSq) + 0.001);
    pwx += w * p.wx; pwy += w * p.wy; wT += w;
  }
  if (wT < 1e-10) return [qwx, qwy];
  let predX = pwx / wT, predY = pwy / wT;
  // Clamp displacement to prevent wild extrapolation at grid edges.
  // Max displacement = 20% of the distance to the nearest calibration point.
  const dists = calWorldPts.map(p => Math.sqrt((qwx - p.wx)**2 + (qwy - p.wy)**2));
  const nearestDist = Math.min(...dists);
  const maxDisp = Math.max(nearestDist * 0.3, 0.01);
  const dx = predX - qwx, dy = predY - qwy;
  const disp = Math.sqrt(dx * dx + dy * dy);
  if (disp > maxDisp) {
    const scale = maxDisp / disp;
    predX = qwx + dx * scale;
    predY = qwy + dy * scale;
  }
  return [predX, predY];
}

/**
 * 2D floor deformation grid. Square by default, warps where predictions differ.
 * Same colors as heatmap. Replaces crosshatch when distortion is on.
 */
export function floorDistortionSVG(calPoints, floorMaps, mapPtFns, w2v, wBB, allMaps, model) {
  if (!calPoints || !floorMaps.length) return "";
  const floorMapIds = new Set(floorMaps.map(m => m.id));
  const _floorZ = (floorMaps[0].stack?.z_level) ?? 0;
  const _allMapZ = {};
  for (const m of (allMaps || floorMaps)) { _allMapZ[m.id] = (m.stack?.z_level) ?? 0; }

  // Collect cal points with RSSI fingerprints (for prediction) + best RSSI (for coloring)
  const calWorldPts = [];
  for (const pt of calPoints) {
    const mpt = mapPtFns[pt.map_id]; if (!mpt) continue;
    const ptZ = _allMapZ[pt.map_id]; if (ptZ == null) continue;
    const floorDist = Math.abs(ptZ - _floorZ);
    if (floorDist > 2) continue;
    const query = {};
    for (const r of (pt.scanner_readings || [])) {
      if (r.source && r.mean_rssi != null) query[r.source] = r.mean_rssi;
    }
    if (!Object.keys(query).length) continue;
    const [wx, wy] = mpt(pt.x_frac, pt.y_frac);
    let bestRssi = Math.max(...Object.values(query));
    if (floorDist > 0) bestRssi -= floorDist * FLOOR_ATTEN_DB;
    calWorldPts.push({ wx, wy, query, rssi: bestRssi });
  }
  if (calWorldPts.length < KNN_K + 1) return "";

  const _rssis = calWorldPts.map(p => p.rssi);
  setHatchRange(Math.min(..._rssis), Math.max(..._rssis), _userGain, _userContrast);

  const wW = wBB.maxX - wBB.minX, wH = wBB.maxY - wBB.minY;
  if (wW < 1e-6 || wH < 1e-6) return "";

  // Square cells
  const _flCellSize = Math.min(wW, wH) / DISTORTION_GRID;
  // Cap columns/rows: a long narrow storey (corridor-shaped) would otherwise
  // produce hundreds of cells instead of the intended ~DISTORTION_GRID.
  const _flResX = Math.min(90, Math.max(2, Math.ceil(wW / _flCellSize)));
  const _flResY = Math.min(90, Math.max(2, Math.ceil(wH / _flCellSize)));
  const cellW = wW / _flResX, cellH = wH / _flResY;
  const idwPts = calWorldPts.map(p => ({ x_frac: p.wx, y_frac: p.wy, rssi: p.rssi }));
  const fv = v => v.toFixed(5);
  const blend = _distortionIntensity / 100;

  const grid = [];
  for (let gy = 0; gy <= _flResY; gy++) {
    grid[gy] = [];
    for (let gx = 0; gx <= _flResX; gx++) {
      const wx = wBB.minX + gx * cellW, wy = wBB.minY + gy * cellH;
      const [pwx, pwy] = _predictPosition(wx, wy, calWorldPts);
      const rssi = _idw(wx, wy, idwPts, []);
      grid[gy][gx] = { wx, wy, pwx, pwy, rssi };
    }
  }

  let s = "";
  // Horizontal grid lines
  for (let gy = 0; gy <= _flResY; gy++) {
    for (let gx = 0; gx < _flResX; gx++) {
      const a = grid[gy][gx], b = grid[gy][gx + 1];
      const ax = a.wx + (a.pwx - a.wx) * blend, ay = a.wy + (a.pwy - a.wy) * blend;
      const bx = b.wx + (b.pwx - b.wx) * blend, by = b.wy + (b.pwy - b.wy) * blend;
      const rssi = (a.rssi != null && b.rssi != null) ? (a.rssi + b.rssi) / 2 : a.rssi || b.rssi;
      const bucket = _rssiBucket(rssi);
      const color = bucket >= 0 ? _bucketRGB(bucket) : "#333";
      const [vx1, vy1] = w2v(ax, ay), [vx2, vy2] = w2v(bx, by);
      s += `<line x1="${fv(vx1)}" y1="${fv(vy1)}" x2="${fv(vx2)}" y2="${fv(vy2)}" stroke="${color}" stroke-width="0.003" opacity="0.75"/>`;
    }
  }
  // Vertical grid lines
  for (let gx = 0; gx <= _flResX; gx++) {
    for (let gy = 0; gy < _flResY; gy++) {
      const a = grid[gy][gx], b = grid[gy + 1][gx];
      const ax = a.wx + (a.pwx - a.wx) * blend, ay = a.wy + (a.pwy - a.wy) * blend;
      const bx = b.wx + (b.pwx - b.wx) * blend, by = b.wy + (b.pwy - b.wy) * blend;
      const rssi = (a.rssi != null && b.rssi != null) ? (a.rssi + b.rssi) / 2 : a.rssi || b.rssi;
      const bucket = _rssiBucket(rssi);
      const color = bucket >= 0 ? _bucketRGB(bucket) : "#333";
      const [vx1, vy1] = w2v(ax, ay), [vx2, vy2] = w2v(bx, by);
      s += `<line x1="${fv(vx1)}" y1="${fv(vy1)}" x2="${fv(vx2)}" y2="${fv(vy2)}" stroke="${color}" stroke-width="0.003" opacity="0.75"/>`;
    }
  }

  return s;
}
