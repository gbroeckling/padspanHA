// PadSpan HA — BLE Room-Presence Tracking for Home Assistant
// Copyright (C) 2026 Garry Broeckling
// Licensed under the GNU General Public License v3.0
// See LICENSE file or https://www.gnu.org/licenses/gpl-3.0.html
/**
 * Full house activity — Traceback's PadSpan Pro option (Garry, 2026-09-23).
 *
 * Turning it on swaps Traceback's 3D stack for the Atlas map and plays the
 * whole house back, not just the beacons: every light, door, window, lock and
 * motion sensor as it was at the frame's moment, with the beacons on top in
 * Traceback's own marker style. Traceback's controls drive it unchanged.
 *
 * Nothing new is recorded. Beacon positions are TracebackStore's frames; the
 * house is Home Assistant's own recorder, fetched once per loaded window with
 * history/history_during_period. The Atlas drawing (buildIsoSVG) is a pure
 * function of entity states and a "now", so a frame is drawn by handing it
 * the states rebuilt for that moment and that moment as its now — the same
 * map, fed from history instead of live.
 *
 * The pure helpers are exported for tests; renderHouseFrame is the only
 * piece that needs a browser.
 */

const _q = new URL(import.meta.url).search;
const { buildIsoSVG, fabricFrame, floorNameAtLevel, pointInPolygon } = await import(`./iso_lights.js${_q}`);
const { gatherLights, ensureLightsRegistry, lightIsTouched, atlasLookFromSettings, atlasIsoLookOpts,
        sunElevationDeg, ambientFromElevation, sunAmbient } = await import(`./lights_map.js${_q}`);
const { airQualityBadness, airQualityWord, AIR_QUALITY_CLASSES, isAirQualityEntity, readingNeedsPlacement } =
  await import(`./light_codes.js${_q}`);

/** Normalise one HA history row (compressed WS or full REST shape) to ms times. */
function _row(r) {
  if (!r) return null;
  if ("s" in r) {
    const lu = Number(r.lu) * 1000;
    return { t: lu, state: r.s, attributes: r.a, lc: r.lc != null ? Number(r.lc) * 1000 : lu };
  }
  const lu = Date.parse(r.last_updated || r.last_changed);
  return { t: lu, state: r.state, attributes: r.attributes, lc: Date.parse(r.last_changed || r.last_updated) };
}

/**
 * {entity_id: rows[]} → {entity_id: [{t, state, attributes, lc}]} sorted by t.
 * A row without attributes inherits the previous row's (HA omits unchanged ones).
 *
 * The start-of-window row is not a change. HA builds it with lu = the window
 * start and no lc (recorder/history: the start state's timestamps are 0), so
 * taking its lc at face value made every quiet motion sensor read "just
 * triggered" at the start of every playback (review 2026-09-23). Its real
 * last_changed is only known when the entity has not changed since: then the
 * live last_changed is it. Otherwise an "on" row is dated to the window start
 * (it was on then) and anything else to 0 — unknown, drawn as long ago.
 */
export function buildStateTimeline(history, { startMs = null, live = {} } = {}) {
  const out = {};
  for (const [eid, rows] of Object.entries(history || {})) {
    const list = (rows || []).map(_row).filter(r => r && Number.isFinite(r.t)).sort((a, b) => a.t - b.t);
    let attrs = {};
    for (const r of list) {
      if (r.attributes && typeof r.attributes === "object") attrs = r.attributes;
      else r.attributes = attrs;
    }
    const first = list[0];
    if (first && startMs != null && first.t <= startMs + 1) {
      const lv = live[eid];
      const liveLc = lv ? Date.parse(lv.last_changed) : NaN;
      if (lv && lv.state === first.state && Number.isFinite(liveLc) && liveLc <= startMs) {
        first.lc = liveLc;
        // Its last REPORT too, when that was also before the window — the
        // start row is dated to the window start, and a sensor that last
        // reported an hour earlier read as fresh (live check 2026-09-24).
        const liveLu = Date.parse(lv.last_updated);
        if (Number.isFinite(liveLu) && liveLu <= startMs) first.lu = liveLu;
      } else first.lc = first.state === "on" ? startMs : 0;
      first.start = true;
    }
    // A row is a CHANGE only when its state differs from the last real state
    // before it. HA also dates a state to every reconnect after an offline
    // gap and to every restart (live check 2026-09-24: ESPHome reconnects
    // read as "just triggered" for hours) — unchanged, it keeps the real
    // change's time. Changed while offline, it changed after the gap began:
    // dated there, not to the reconnect; with nothing known before an
    // offline start, long ago. "on" is a reading of now and keeps its own
    // time — an old one made a sensor back after hours read as stuck on
    // (review round 13).
    let real = null, gapAt = null;
    for (const r of list) {
      if (r.state === "unavailable" || r.state === "unknown") {
        if (gapAt === null) gapAt = r.t;
        continue;
      }
      if (r.state !== "on") {
        if (real && r.state === real.state) r.lc = real.lc;
        else if (gapAt !== null) r.lc = real ? gapAt : 0;
      }
      real = r;
      gapAt = null;
    }
    if (list.length) out[eid] = list;
  }
  return out;
}

/** The last row at or before tMs (the start-state row covers the window's start). */
function _rowAt(list, tMs) {
  let lo = 0, hi = list.length - 1, best = -1;
  while (lo <= hi) {
    const mid = (lo + hi) >> 1;
    if (list[mid].t <= tMs) { best = mid; lo = mid + 1; } else hi = mid - 1;
  }
  return best < 0 ? null : list[best];
}

/**
 * hass.states-shaped map for the moment tMs. Entities with no recorder rows
 * (excluded from the recorder) keep their live state — nothing else to show.
 */
// Attributes that describe what a device IS, not what it was doing: HA has
// not recorded a light's colour, brightness or effect list since 2024.8, so
// a replayed light kept only its name — every WLED lost its class, strips
// their shape, and the codes shifted (live check 2026-09-24). These come from
// the live entity; what it was DOING (colour, brightness) is never borrowed
// from today.
const _WHAT_IT_IS = ["friendly_name", "effect_list", "supported_color_modes", "supported_features",
  "min_color_temp_kelvin", "max_color_temp_kelvin", "min_mireds", "max_mireds", "device_class",
  "unit_of_measurement", "state_class", "icon", "entity_id", "group_entities"];
// Today's, overriding the recorded row's: the replay draws the device the
// Atlas draws — a light renamed since keeps today's name, shape and code
// (review round 13).
function _whatItIs(liveA) {
  const out = {};
  for (const k of _WHAT_IT_IS) if (k in liveA) out[k] = liveA[k];
  return out;
}

export function statesAt(timeline, liveStates, eids, tMs) {
  const out = {};
  for (const eid of eids) {
    const list = timeline[eid];
    const r = list ? _rowAt(list, tMs) : null;
    if (!r) {
      // Not recorded (excluded from the recorder), or no row yet at tMs:
      // what it was then is unknown — drawn as unknown, never as today's
      // state under a past timestamp, and never silently missing.
      const lv = liveStates[eid];
      const la = (lv && lv.attributes) || {};
      if (lv) out[eid] = { entity_id: eid, state: "unknown",
        attributes: eid.startsWith("light.") || eid.startsWith("fan.") ? _whatItIs(la) : la,
        last_changed: new Date(0).toISOString(), last_updated: new Date(0).toISOString() };
      continue;
    }
    const liveA = liveStates[eid]?.attributes || {};
    const recorded = r.attributes && Object.keys(r.attributes).length ? r.attributes : null;
    let attrs;
    if (recorded || eid.startsWith("light.") || eid.startsWith("fan.")) {
      attrs = { ...(recorded || {}), ..._whatItIs(liveA) };
    } else attrs = liveA;          // recorded without attributes: they don't change
    out[eid] = {
      entity_id: eid,
      state: r.state,
      attributes: attrs,
      last_changed: new Date(r.lc).toISOString(),
      last_updated: new Date(r.lu ?? r.t).toISOString(),
    };
  }
  return out;
}

/**
 * Every real state change inside [startMs, endMs] — the side list's events.
 * The first row of each entity is its start-of-window state, not a change.
 */
const _NOT_A_CHANGE = new Set(["unavailable", "unknown"]);
export function isEventEntity(eid) {
  // A numeric sensor's every reading is a "state change" — thousands a week
  // that buried every door and light in the list (review 2026-09-23).
  return !String(eid).startsWith("sensor.");
}
/**
 * A reading as the Atlas shows it (gatherLights): whole degrees, whole
 * percent, an air sensor's band — or null for a sensor it shows no reading
 * for. Every report is not a change anyone can see on the map.
 */
export function shownReading(eid, state, attrs) {
  const dc = attrs && attrs.device_class;
  const n = Number(state);
  if (dc === "temperature") return Number.isFinite(n) ? `${Math.round(n)}°` : null;
  if (dc === "humidity") return Number.isFinite(n) ? `${Math.round(n)}%` : null;
  if (AIR_QUALITY_CLASSES.includes(dc)) {
    return Number.isFinite(n) ? airQualityWord(airQualityBadness({ device_class: dc, air_value: n })) : null;
  }
  if (dc === "enum" && isAirQualityEntity(eid, attrs)) {
    // The sensor's own word, as the Atlas labels it (airQualityLabel) —
    // banding it merged "very poor" with "unhealthy" (review round 16).
    const w = String(state).toLowerCase();
    if (!w || /^(unknown|unavailable|none)$/.test(w)) return null;
    const t = w.replace(/_/g, " ");
    return t.charAt(0).toUpperCase() + t.slice(1);
  }
  return null;
}

/**
 * What a change of a reading is judged on: what the Atlas DRAWS — for an air
 * sensor that grades itself in words, its bars (airQualityBadness): two
 * words that draw the same ("excellent", "good") are no change (review
 * round 17). Otherwise the shown reading itself.
 */
export function readingKey(eid, state, attrs) {
  const dc = attrs && attrs.device_class;
  if (dc === "enum" && isAirQualityEntity(eid, attrs)) {
    const w = String(state).toLowerCase();
    if (!w || /^(unknown|unavailable|none)$/.test(w)) return null;
    const b = airQualityBadness({ air_level: w });
    // A word the table doesn't know ("very_unhealthy") draws no bars — the
    // same as "good"; skipping it as no reading lost the bars going and
    // coming back (review round 18).
    return Number.isFinite(b) ? b : 0;
  }
  return shownReading(eid, state, attrs);
}

/**
 * With `attrsOf(eid)` the sensors count too (Traceback's 💡 Devices, Garry
 * 2026-09-24: "follows all devices that atlas can see") — temperature,
 * humidity and air quality, by the reading the Atlas shows (shownReading),
 * not by every report.
 */
export function activityEvents(timeline, nameOf, startMs, endMs, attrsOf = null) {
  const ev = [];
  for (const [eid, list] of Object.entries(timeline)) {
    const reading = !isEventEntity(eid);
    if (reading && !attrsOf) continue;
    const attrs = reading ? (attrsOf(eid) || {}) : null;
    const shown = reading ? (s) => shownReading(eid, s, attrs) : (s) => s;
    const keyOf = reading ? (s) => readingKey(eid, s, attrs) : (s) => s;
    // A whole degree or percent counts once the reading has moved a clear
    // step (0.8) from the one last counted, or has HELD for 10 minutes — then
    // at the moment the map changed. A sensor on a rounding edge flipped
    // 20°/21° on every report, hundreds a day that buried the doors and
    // lights (round 16); a small step that stayed was never counted (17).
    const edge = reading && (attrs.device_class === "temperature" || attrs.device_class === "humidity");
    const HOLD_MS = 10 * 60 * 1000;
    // Compare each real state with the last REAL state before it, so an
    // "off → unavailable → on" still reads as the off → on it was
    // (re-review 2026-09-23: skipping both sides of a gap lost the change).
    let prevKey = null, prevLabel = null, prevNum = null, pend = null;
    const commit = (c) => {
      if (prevKey !== null && c.t >= startMs && c.t <= endMs) {
        ev.push({ t: c.t, eid, name: nameOf(eid), from: prevLabel, to: c.label });
      }
      prevKey = c.k; prevLabel = c.label; prevNum = c.num;
    };
    for (let i = 0; i < list.length; i++) {
      const r = list[i];
      if (_NOT_A_CHANGE.has(r.state)) {
        // Offline: a small step waiting to hold is judged when the sensor
        // is back (review rounds 18-19).
        if (pend && pend.darkAt == null) pend.darkAt = r.t;
        continue;
      }
      const k = keyOf(r.state);
      if (k == null) continue;
      if (pend && pend.darkAt != null) {
        // Back within 10 minutes: a blip, the step still stands — ESPHome
        // reconnects are hours of blips, and dropping it at each one never
        // counted it (round 19). Offline longer: it counts only if it had
        // held before it went (round 18).
        if (r.t - pend.darkAt < HOLD_MS) pend.darkAt = null;
        else { if (pend.darkAt - pend.t >= HOLD_MS) commit(pend); pend = null; }
      }
      if (pend && r.t - pend.t >= HOLD_MS) { commit(pend); pend = null; }
      // Drawn the same: no change — but the word it goes by is the latest.
      if (k === prevKey) { pend = null; prevLabel = shown(r.state); continue; }
      const c = { k, label: shown(r.state), num: Math.round(Number(r.state)), t: r.t };
      if (prevKey === null) { commit(c); continue; }        // the starting value — no change
      if (edge && Math.abs(Number(r.state) - prevNum) < 0.8) {
        if (!pend || pend.k !== k) pend = c;                // held long enough, or a clear step later
        continue;
      }
      // A clear step to the value a small one already showed: the map
      // changed at the small one (round 18: timed one report late).
      commit(pend && pend.k === k ? { ...c, t: pend.t } : c);
      pend = null;
    }
    // Held to the window's end — or to now, when the window runs past it
    // (round 18: a step a minute old counted as held in a future window) —
    // or to when it went offline for good.
    if (pend && (pend.darkAt != null ? pend.darkAt : Math.min(endMs, Date.now())) - pend.t >= HOLD_MS) commit(pend);
  }
  return ev.sort((a, b) => a.t - b.t);
}

/**
 * The devices a replayed Atlas frame SHOWS a change of (💡 Devices): a marker
 * drawn at its place or clustered in its room, not hidden — a reading only
 * when placed (its digits, its air bars); a door or window only as its
 * linked wall, which no filter hides. Review round 16: unplaced, hidden and
 * unlinked ones were counted and named with nothing on the map changing.
 */
export function atlasShownEids(model, settings, lights, shapeOverrides = {}, frame = null) {
  // What the frame DRAWS, from the frame's own fabric (review round 17): the
  // outside floor's rooms and placements are drawn on no plate, and a wall
  // on a floor with no slab is never drawn.
  const fr = frame || fabricFrame(model || {}, (model && model.floors) || [], 150, 0);
  const drawnLevels = new Set(fr.levels);
  const placed = new Map(fr.lights.map(p => [String(p.eid), p]));
  const rooms = new Set(fr.rooms.map(r => r.room));
  // A door, window or LOCK linked to a wall is drawn as that wall, which no
  // filter hides (a lock linked to a wall was dropped — round 17).
  const walls = new Set(((model && model.rf_barriers_m) || [])
    .filter(b => b && b.linked_entity_id && drawnLevels.has(fr.levelOf(String(b.floor_id || "main"))))
    .map(b => String(b.linked_entity_id)));
  const hidden = _hiddenOnMap(settings, model, lights, shapeOverrides);
  const out = new Set();
  for (const l of lights || []) {
    const eid = String(l.entity_id);
    if (walls.has(eid)) { out.add(eid); continue; }
    if (l.isDoor || hidden.has(eid)) continue;
    const p = placed.get(eid);
    if (readingNeedsPlacement(l)) {
      // Digits at the placement; an air sensor's bars fill the room it is
      // placed in — outside every room outline, nothing changes.
      if (p && (!l.isAir || fr.rooms.some(r => r.z === p.z && pointInPolygon(r.pts, p.x, p.y)))) out.add(eid);
      continue;
    }
    if (p || (l.area_name && rooms.has(l.area_name))) out.add(eid);
  }
  return out;
}
// The Atlas's own hiding: the hidden list, and its "hide untouched" look.
function _hiddenOnMap(settings, model, lights, shapeOverrides) {
  const hidden = new Set(Array.isArray(settings && settings.lights_hidden) ? settings.lights_hidden : []);
  if (!atlasLookFromSettings(settings || {}).hideUntouched) return hidden;
  for (const l of lights || []) if (!lightIsTouched(l, shapeOverrides, (model && model.light_positions_m) || {})) hidden.add(l.entity_id);
  return hidden;
}
/** hs.events, only the ones a frame shows (hs.shown); all while not yet known (null). */
export function shownHouseEvents(hs) {
  if (hs._shownEvSrc !== hs.events || hs._shownEvKey !== hs.shownKey) {
    hs._shownEvSrc = hs.events;
    hs._shownEvKey = hs.shownKey;
    hs._shownEv = hs.shown ? (hs.events || []).filter(e => hs.shown.has(e.eid)) : (hs.events || []);
  }
  return hs._shownEv;
}
/**
 * The Atlas's device list for the replay (hs.eids) and which of them a frame
 * shows a change of (hs.shown / hs.shownKey), from the live house. hs.shown
 * stays null while the entity registry loads: rooms decide which unplaced
 * devices are drawn. Returns the registry maps.
 */
export function refreshHouseDevices(ctx, hs, onRegistry) {
  const model = ctx.state.model || {};
  const settings = ctx.state.settings || {};
  if (!ctx.state._lightsRegStore) ctx.state._lightsRegStore = {};
  const reg = ctx.state._modelLoaded
    ? ensureLightsRegistry(ctx.state._lightsRegStore, ctx.hass, model.areas || [], onRegistry)
    : { areaMap: {}, platformMap: {}, loading: true };
  const shapeOverrides = (settings.light_shapes && typeof settings.light_shapes === "object") ? settings.light_shapes : {};
  const typeOverrides = (settings.light_type_overrides && typeof settings.light_type_overrides === "object") ? settings.light_type_overrides : {};
  // The Atlas entity set comes from the live house; history fills its states.
  // Side-effect free: this is a replay, not the house now.
  const liveLights = gatherLights(ctx.hass?.states || {}, reg.areaMap, shapeOverrides, settings.tier, reg.platformMap,
    typeOverrides, reg.pairMap, reg.manufacturerMap, undefined, true);
  hs.eids = liveLights.map(l => l.entity_id);
  hs.regLoading = !!reg.loading;
  // null while unknown: an EMPTY set once known is a set like any other — it
  // shared the loading key "" and was never applied (round 17).
  if (reg.loading) { hs.shown = null; hs.shownKey = null; return reg; }
  const shown = atlasShownEids(model, settings, liveLights, shapeOverrides);
  const key = [...shown].sort().join(",");
  if (!hs.shown || key !== hs.shownKey) { hs.shown = shown; hs.shownKey = key; }
  return reg;
}

/**
 * Mark the events Vacation Mode caused (Garry, 2026-09-23): the recorder can't
 * tell its switching from a person's, so vacation_mode.py logs its own. An
 * event is Vacation Mode's when a logged action for the same entity, to the
 * same on/off, came at most `slackMs` before the state change landed.
 * `actions` rows are [epoch_s, entity_id, 1|0]. Mutates and returns `events`.
 */
export function markVacationEvents(events, actions, slackMs = 60000) {
  const byEid = {};
  for (const [ts, eid, on] of actions || []) (byEid[eid] = byEid[eid] || []).push([ts * 1000, on ? "on" : "off"]);
  for (const e of events) {
    const acts = byEid[e.eid];
    e.vacation = !!acts && acts.some(([t, to]) => to === e.to && t <= e.t + 1000 && e.t - t <= slackMs);
  }
  return events;
}

/** True when tMs falls inside a Vacation Mode span ([start_s, end_s|null]). */
export function inVacation(periods, tMs) {
  const t = tMs / 1000;
  return (periods || []).some(([s, e]) => s != null && t >= s && (e == null || t < e));
}

/**
 * Traceback only records a frame while a tracked object is home, so playback
 * over beacon frames alone could never show the house while it was empty —
 * the very case the 🌴 marking exists for. With house activity on, every
 * house event gets a frame of its own, at the event's exact moment (a frame
 * rounded to the second could land before the change and draw the old
 * state — re-review 2026-09-23).
 *
 * A synthetic frame carries the beacons of the last real frame while the gap
 * is no longer than the beacon cadence itself — beacon frames arrive ~10 s
 * apart, but a long range comes back evenly thinned (get_frames), so a fixed
 * 30 s made everyone vanish on every event of a week's replay. Past that
 * bound nobody is drawn: nobody was recorded.
 */
export function mergeHouseFrames(rawFrames, events, thinFactor = 1) {
  const have = new Set(rawFrames.map(f => f.ts));
  const extra = [];
  for (const e of events || []) {
    const ts = e.t / 1000;
    if (have.has(ts)) continue;
    have.add(ts);
    extra.push({ ts, o: null, house: true });
  }
  if (!extra.length) return rawFrames.slice();
  // Beacons are recorded at the presence poll (1-60 s, the coordinator's
  // clamp), so 1.5 x the typical gap bounds "still there" — but never more
  // than 1.5 x 60 s times however much the backend THINNED the list: a tag
  // seen twice an hour apart has a one-hour "gap" that is really an absence
  // (rounds 3 and 4).
  const gaps = [];
  for (let k = 1; k < rawFrames.length; k++) gaps.push(rawFrames[k].ts - rawFrames[k - 1].ts);
  gaps.sort((a, b) => a - b);
  const median = gaps.length ? gaps[gaps.length >> 1] : 0;
  const cap = 90 * Math.max(1, Number(thinFactor) || 1);
  const carryS = Math.max(30, Math.min(1.5 * median, cap));
  const all = [...rawFrames, ...extra].sort((a, b) => a.ts - b.ts);
  let last = null;
  for (const f of all) {
    if (!f.house) { last = f; continue; }
    f.o = last && f.ts - last.ts <= carryS ? last.o : [];
  }
  return all;
}

/**
 * The Atlas's own floor-focus positions (All, each floor, each adjacent
 * pair) and labels — the same list lights_map.js builds. Traceback's slider
 * indexes photo z_levels; the Atlas drawn in house mode has fabric floors,
 * which can differ (review 2026-09-23: "Floor 1" focused the basement).
 */
export function atlasFocusPositions(model, floorGap = 150, horizGap = 0) {
  const floors = (model && model.floors) || [];
  const frame = fabricFrame(model || {}, floors, floorGap, horizGap);
  const levels = frame.levels;
  const positions = [null];
  for (let i = 0; i < levels.length; i++) {
    positions.push(levels[i]);
    if (i < levels.length - 1) positions.push([levels[i], levels[i + 1]]);
  }
  const labelOf = (idx) => {
    const pos = positions[Math.max(0, Math.min(idx, positions.length - 1))];
    if (pos === null) return "All floors";
    return (Array.isArray(pos) ? pos : [pos])
      .map(z => floorNameAtLevel(frame, model, floors, z) || `L${z}`).join(" + ");
  };
  return { positions, labelOf };
}

/** Metre centroid of a room, from the fabric's own room geometry. */
function _roomCentroidM(model, room) {
  const g = (model && model.room_geometry_m) || {};
  const key = g[room] ? room : Object.keys(g).find(k => k.toLowerCase() === String(room || "").toLowerCase());
  const r = key && g[key];
  if (!r || !Array.isArray(r.points_m) || r.points_m.length < 3) return null;
  const n = r.points_m.length;
  return {
    x: r.points_m.reduce((a, p) => a + p[0], 0) / n,
    y: r.points_m.reduce((a, p) => a + p[1], 0) / n,
    floor_id: r.floor_id || null,
  };
}

/**
 * One frame's beacons for buildIsoSVG, in Traceback's style: colour, label,
 * room and the last few positions as a trail. A room-only record (no metre
 * fix) sits at its room's centroid, as Traceback's own map places it.
 */
export function beaconsForFrame(frames, idx, model, { keep, colorOf, labelOf, trailLen = 12 } = {}) {
  const f = frames[idx];
  if (!f) return [];
  const posOf = (o) => {
    if (typeof o.x_m === "number" && typeof o.y_m === "number") return { x: o.x_m, y: o.y_m, floor_id: o.f || null };
    return o.r ? _roomCentroidM(model, o.r) : null;
  };
  const out = [];
  for (const o of (f.o || [])) {
    if (!o.k || (keep && !keep(o))) continue;
    const p = posOf(o);
    if (!p) continue;
    const trail = [];
    for (let i = Math.max(0, idx - trailLen); i < idx; i++) {
      const prev = (frames[i].o || []).find(x => x.k === o.k);
      const pp = prev && posOf(prev);
      if (pp && String(pp.floor_id || "") === String(p.floor_id || "")) trail.push([pp.x, pp.y]);
    }
    out.push({
      key: o.k, label: labelOf ? labelOf(o) : (o.n || o.k), room: o.r || "",
      x_m: p.x, y_m: p.y, floor_id: p.floor_id, color: colorOf ? colorOf(o.k) : "#fbbf24", trail,
    });
  }
  return out;
}

/**
 * Fetch the recorder history for every Atlas entity over [startS, endS] and
 * store the timeline on `hs` (Traceback's per-tab state). hs.pending is the
 * in-flight promise, so a Traceback re-mounted mid-fetch can wait on it too.
 *
 * Two requests (review 2026-09-23: one full-attribute request over every
 * Atlas entity for 7 days ran to tens of MB): lights and fans with their
 * attributes (colour, brightness), everything else state-only — its
 * attributes (device_class, unit) do not change and come from the live
 * entity in statesAt.
 */
export function loadHouseHistory(ctx, hs, startS, endS) {
  const live = ctx.hass?.states || {};
  const eids = hs.eids || [];
  const rich = eids.filter(e => e.startsWith("light.") || e.startsWith("fan."));
  const lean = eids.filter(e => !(e.startsWith("light.") || e.startsWith("fan.")));
  const base = {
    type: "history/history_during_period",
    start_time: new Date(startS * 1000).toISOString(),
    end_time: new Date(endS * 1000).toISOString(),
    include_start_time_state: true,
  };
  const call = (ids, extra) => ids.length ? ctx.hass.callWS({ ...base, entity_ids: ids, ...extra }) : Promise.resolve({});
  // A new window starts empty: the old window's timeline would draw live
  // states (before its first row) and list the old events meanwhile.
  hs.timeline = null; hs.events = []; hs.vacationPeriods = [];
  hs.loading = true; hs.error = null; hs.window = [startS, endS];
  hs.pending = (async () => {
    try {
      const [a, b] = await Promise.all([
        call(rich, { significant_changes_only: false, minimal_response: false, no_attributes: false }),
        call(lean, { significant_changes_only: true, minimal_response: true, no_attributes: true }),
      ]);
      hs.timeline = buildStateTimeline({ ...a, ...b }, { startMs: startS * 1000, live });
      const nameOf = (eid) => live[eid]?.attributes?.friendly_name || eid;
      // Every device the Atlas shows — its readings too (💡 Devices).
      hs.events = activityEvents(hs.timeline, nameOf, startS * 1000, endS * 1000,
        (eid) => live[eid]?.attributes || {});
      // Vacation Mode's own switching and spans — a missing log (older
      // backend) just means nothing is marked.
      const vac = await ctx.actions.wsCall("padspan_ha/vacation_log_get", { start_ts: startS - 60, end_ts: endS })
        .catch(() => ({ actions: [], periods: [] }));
      markVacationEvents(hs.events, vac.actions);
      hs.vacationPeriods = vac.periods || [];
    } catch (e) {
      // No timeline: the map draws no device states rather than today's
      // under a past timestamp. The status line offers a retry.
      hs.error = String((e && (e.message || e.code)) || e);
      hs.timeline = null; hs.events = [];
    }
    hs.loading = false;
    hs.version = (hs.version || 0) + 1;
  })();
  return hs.pending;
}

/**
 * The Atlas SVG for one Traceback frame. `hs` carries the registry-derived
 * entity list (hs.eids, filled here on first call) and the loaded timeline.
 * `devices: false` draws the Atlas and the beacons with no devices (Full
 * house activity without 💡 Devices); `changedEids` rings the devices that
 * changed at this frame's moment.
 */
export function renderHouseFrame(ctx, hs, frames, frameIdx, beaconOpts, onRegistry,
                                 { changedEids = null, devices = true } = {}) {
  const settings = ctx.state.settings || {};
  // Without devices: no registry (a multi-MB fetch for nothing), no device
  // list, and a door's wall drawn closed (neutralWalls) — not "no reading"
  // dashes (round 16), nor gone (round 17).
  const model = ctx.state.model || {};
  const floors = model.floors || [];
  const reg = devices ? refreshHouseDevices(ctx, hs, onRegistry) : { areaMap: {}, platformMap: {}, loading: false };
  const shapeOverrides = (settings.light_shapes && typeof settings.light_shapes === "object") ? settings.light_shapes : {};
  const typeOverrides = (settings.light_type_overrides && typeof settings.light_type_overrides === "object") ? settings.light_type_overrides : {};
  const live = ctx.hass?.states || {};

  const frame = frames[frameIdx];
  const tMs = frame ? frame.ts * 1000 : Date.now();
  // Until history is in (or when it failed), no device states at all —
  // never today's states under a past timestamp.
  const states = devices && hs.timeline ? statesAt(hs.timeline, live, hs.eids, tMs) : {};
  const lights = gatherLights(states, reg.areaMap, shapeOverrides, settings.tier, reg.platformMap, typeOverrides, reg.pairMap, reg.manufacturerMap, tMs, true);
  const lightsByEid = {};
  for (const l of lights) lightsByEid[l.entity_id] = l;
  const hidden = new Set(Array.isArray(settings.lights_hidden) ? settings.lights_hidden : []);
  const byRoom = {};
  for (const l of lights) if (l.area_name && !hidden.has(l.entity_id)) (byRoom[l.area_name] = byRoom[l.area_name] || []).push(l);
  // The Atlas tab's own look (Garry, 2026-09-23: "should match the atlas tab
  // settings and look") — the same reading the Atlas panel makes. Its
  // "hide untouched" filter hides on the drawing only, as there. Daylight is
  // the replayed moment's sun, from the house's own location.
  const look = atlasLookFromSettings(settings);
  const hiddenOnMap = _hiddenOnMap(settings, model, lights, shapeOverrides);
  const lat = Number(ctx.hass?.config?.latitude), lon = Number(ctx.hass?.config?.longitude);
  const ambient = Number.isFinite(lat) && Number.isFinite(lon) && ctx.hass?.config?.latitude != null
    ? ambientFromElevation(sunElevationDeg(lat, lon, tMs)) : sunAmbient(ctx.hass);

  const floorGap = ctx.state._overviewFloorGap ?? settings.overview_iso_floor_gap ?? 150;
  const horizGap = ctx.state._overviewHorizGap ?? settings.overview_iso_horiz_gap ?? 0;
  const { positions } = atlasFocusPositions(model, floorGap, horizGap);
  const focusZ = positions[Math.max(0, Math.min(hs.focusIdx ?? 0, positions.length - 1))];

  return buildIsoSVG(model, byRoom, hiddenOnMap, focusZ, floorGap, horizGap, lightsByEid, !!reg.loading, floors, {
    ...atlasIsoLookOpts(look, ambient),
    beacons: beaconsForFrame(frames, frameIdx, model, beaconOpts),
    // No restart gate: the timeline already keeps a restart's or a
    // reconnect's row at the real change's time (buildStateTimeline), and
    // the gate silenced real motion in the minutes after a boot — and a
    // change carried from before it (review round 13).
    nowMs: tMs,
    floodLatches: settings.flood_latches || {},
    changedEids: changedEids || [],
    neutralWalls: !devices,
  });
}
