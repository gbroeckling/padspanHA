// PadSpan HA — BLE Room-Presence Tracking for Home Assistant
// Copyright (C) 2026 Garry Broeckling
// Licensed under the GNU General Public License v3.0
// See LICENSE file or https://www.gnu.org/licenses/gpl-3.0.html
//
// Live Aboard, the 3D house (docs/IDEA_ATLAS_3D_HOUSE.md): the Atlas's 3D
// view. Normally off — the shared card (lights_map.js) imports this module
// only while settings.atlas_3d_enabled is on AND a screen has picked 3D, so
// with the feature off neither this file nor three.js is ever fetched.
//
// The house is read from the map the Atlas already holds (live_aboard_house.js
// turns it into numbers); three.js, bundled unmodified in vendor/three, is the
// only outside code, used as a library. The camera, the geometry merging and
// the whole-house cut-away are PadSpan's own.
//
// It has to survive the Atlas: the card is rebuilt from scratch every 5 s, so
// the view is ONE long-lived element per screen ("slot", like the weather
// overlay's), moved into each new card beside the flat stage, which it hides
// while it shows. The renderer, the GL context, the scene and the camera live
// in the slot and are never rebuilt by a poll; a poll only repaints the lights
// whose state changed (an intensity and a colour, never what is drawn, so
// three.js never rebuilds a shader), and rebuilds geometry only when the map
// itself changed. It renders only when something changed, and not at all
// while the panel is hidden. Any failure — no WebGL, a slow GPU by the
// frame-time check, a lost GL context, any error — puts the flat Atlas back
// and is counted once (the report's closed words, live_aboard_house.js).
//
// What the flat Atlas does, it does here too (part B). Doors, windows and
// locks linked to sensors open, shut and flash as the Atlas reads them;
// rooms take the Motion · Air colours on the Atlas's clocks; temperature,
// humidity and air float as readouts; and a press is the Atlas's own press
// (live_aboard_use.js): the picking is this file's, the actions the host's.
// Something moving by itself (a pulse, a flash, a door swinging) draws on
// a steady clock, slower on Low; nothing moving, nothing is drawn.

const THREE = await import(`../vendor/three/three.module.min.js${new URL(import.meta.url).search}`);
const HOUSE = await import(`./live_aboard_house.js${new URL(import.meta.url).search}`);
const USE = await import(`./live_aboard_use.js${new URL(import.meta.url).search}`);
// Part C: the 3D file's rules (doors and windows drawn in 3D, a barrier's
// hinge, swing, sill and head, device heights), read through the host.
const DRAFT = await import(`./live_aboard_draft.js${new URL(import.meta.url).search}`);
// The 3D editor (Door, Window, Heights), for those who may place lights.
const EDIT = await import(`./live_aboard_edit.js${new URL(import.meta.url).search}`);
const HEIGHTS = await import(`./atlas_heights.js${new URL(import.meta.url).search}`);
// P2 Furnish: furniture's rules, the pieces drawn and the Furnish tool, and
// the builders that draw each piece (missing or broken: every piece a box).
const PIECES = await import(`./live_aboard_pieces.js${new URL(import.meta.url).search}`);
const FURNISH = await import(`./live_aboard_furnish.js${new URL(import.meta.url).search}`);
const FURN = await import(`./live_aboard_furniture.js${new URL(import.meta.url).search}`).catch(() => null);
// The Strip tool: where a strip or a string of lights really goes (its runs),
// and the tool itself in the editor.
const RUNS = await import(`./live_aboard_runs.js${new URL(import.meta.url).search}`);
const STRIP = await import(`./live_aboard_strip.js${new URL(import.meta.url).search}`);
const NO_FILE = DRAFT.ownedOf(null);
// P8 atmosphere: rain and snow (the flat Atlas's own weather, drawn here).
// Optional: a module that fails to load leaves the house as it was.
// The flat Atlas's rain decision, for the open-window alert (optional too).
const AW = await import(`./atlas_weather.js${new URL(import.meta.url).search}`).catch(() => null);
const WEATHER = await import(`./live_aboard_weather.js${new URL(import.meta.url).search}`)
  .catch(err => { console.warn("PadSpan: live_aboard_weather failed to load", err); return null; });
// And the Atlas's Showcase look as this view's lighting (optional too).
const LOOKS = await import(`./live_aboard_showcase.js${new URL(import.meta.url).search}`)
  .catch(err => { console.warn("PadSpan: live_aboard_showcase failed to load", err); return null; });
// The Studio look (atlas_3d_look "studio"): a sky, a stage and soft light
// round Live Aboard's own colours (optional too: missing, Studio is its own look).
const STUDIO = await import(`./live_aboard_studio.js${new URL(import.meta.url).search}`)
  .catch(err => { console.warn("PadSpan: live_aboard_studio failed to load", err); return null; });
// Views ▾ → Look (live_aboard_looks.js): this screen's own look over Settings',
// and another after sunset (optional too: missing, Settings' look as ever).
const LOOKPICK = await import(`./live_aboard_looks.js${new URL(import.meta.url).search}`)
  .catch(err => { console.warn("PadSpan: live_aboard_looks failed to load", err); return null; });
// The room chips along the top and a room's panel beside the house
// (live_aboard_rooms.js; optional too: missing, no chips, and a room opens the Atlas's sheet).
const ROOMS = await import(`./live_aboard_rooms.js${new URL(import.meta.url).search}`)
  .catch(err => { console.warn("PadSpan: live_aboard_rooms failed to load", err); return null; });
// The Atlas's own word for the air (its room sheet's "Air Good").
const { airQualityWord, airQualityBadness } = await import(`./light_codes.js${new URL(import.meta.url).search}`);
// The heights in Live Aboard's file no view reads (out of date: the map's).
const { withoutGone, isTapLight, roomAggregate, openRoomSheet } = await import(`./lights_map.js${new URL(import.meta.url).search}`);
// P5: furniture that is a device behaves like it (optional too: missing, the
// pieces are only furniture and the fixtures stay where they are).
const DEVICES = await import(`./live_aboard_devices.js${new URL(import.meta.url).search}`)
  .catch(err => { console.warn("PadSpan: live_aboard_devices failed to load", err); return null; });
// P6: beacons, scanners and people where PadSpan tracks them (optional too).
const TRACKED = await import(`./live_aboard_tracked.js${new URL(import.meta.url).search}`)
  .catch(err => { console.warn("PadSpan: live_aboard_tracked failed to load", err); return null; });
// Trails: where each person and tag went in the last half hour, from
// Traceback's own history (optional too: missing, no Trails in the menu).
const TRAILS = await import(`./people_trails.js${new URL(import.meta.url).search}`)
  .catch(err => { console.warn("PadSpan: people_trails failed to load", err); return null; });
// The screen's rules, shared with the flat Atlas (the map alone, full screen).
const SCREEN = await import(`./atlas_screen.js${new URL(import.meta.url).search}`);
// The Atlas's other devices (leak sensors, locks), its codes and its class
// chips (optional too: missing, the house is as it was).
const MARKS = await import(`./live_aboard_marks.js${new URL(import.meta.url).search}`)
  .catch(err => { console.warn("PadSpan: live_aboard_marks failed to load", err); return null; });
// Motion (live_aboard_motion.js): the ring, the room's glow, the sensor, its
// marker and coverage, the Motion chip (optional: missing, motion is drawn
// as it was).
const MOTION = await import(`./live_aboard_motion.js${new URL(import.meta.url).search}`)
  .catch(err => { console.warn("PadSpan: live_aboard_motion failed to load", err); return null; });
// What stands on a line keeps clear of the words (live_aboard_raised.js)
// (optional: missing, each stands at its real height).
const RAISED = await import(`./live_aboard_raised.js${new URL(import.meta.url).search}`)
  .catch(err => { console.warn("PadSpan: live_aboard_raised failed to load", err); return null; });
// The wall panel (live_aboard_panel.js): a home view it goes back to, Follow,
// the People chip, the two switches in Views ▾ (optional: missing, as it was).
const PANEL = await import(`./live_aboard_panel.js${new URL(import.meta.url).search}`)
  .catch(err => { console.warn("PadSpan: live_aboard_panel failed to load", err); return null; });
// The ⋯ list, "Show on this screen" (live_aboard_show.js): what this screen
// draws, item by item (optional: missing, everything shows as it was).
const SHOW = await import(`./live_aboard_show.js${new URL(import.meta.url).search}`)
  .catch(err => { console.warn("PadSpan: live_aboard_show failed to load", err); return null; });
// The scene row (scene_row.js): the host's scenes and one-floor presets as
// small maps along the top of the bottom bar (optional: missing, no row).
const SCENES = await import(`./scene_row.js${new URL(import.meta.url).search}`)
  .catch(err => { console.warn("PadSpan: scene_row failed to load", err); return null; });
// The director (live_aboard_director.js): on the sidebar, the camera flies to
// a doorbell, door or alarm that went off (optional: missing, nothing does).
const DIRECTOR = await import(`./live_aboard_director.js${new URL(import.meta.url).search}`)
  .catch(err => { console.warn("PadSpan: live_aboard_director failed to load", err); return null; });
// Is a person home (person_home.js): the director's "Arrived home" asks it
// with the rooms and zones this view knows (missing: the director's own).
const PERSON_HOME = await import(`./person_home.js${new URL(import.meta.url).search}`)
  .catch(err => { console.warn("PadSpan: person_home failed to load", err); return null; });
// The frame-rate readout (live_aboard_fps.js), Settings → Live Aboard →
// Frame rate, this browser only (optional: missing, there is no readout).
const FPS = await import(`./live_aboard_fps.js${new URL(import.meta.url).search}`)
  .catch(err => { console.warn("PadSpan: live_aboard_fps failed to load", err); return null; });
// The house itself (live_aboard_storey.js): a solid floor under each storey,
// the roof, the openings stairs cut, how a door with no sensor stands
// (optional: missing, the house is drawn as it was).
const STOREY = await import(`./live_aboard_storey.js${new URL(import.meta.url).search}`)
  .catch(err => { console.warn("PadSpan: live_aboard_storey failed to load", err); return null; });
// An outdoor room's surface (outdoor_space.js): grey paving tiles, laid from its own corner.
const SURF = await import(`./outdoor_space.js${new URL(import.meta.url).search}`)
  .catch(err => { console.warn("PadSpan: outdoor_space failed to load", err); return null; });

// West Coast Forest's trees (live_aboard_forest.js): fetched the first time a
// view follows the Atlas with that theme on (syncForest); otherwise never.
let FOREST = null, forestImport = null;

export const HOUSE3D_EVENTS = HOUSE.HOUSE3D_EVENTS;
export const HOUSE3D_FALLBACK_KINDS = HOUSE.HOUSE3D_FALLBACK_KINDS;
/** Add data via plans with no 3D on this device: the list, in `box` (live_aboard_plans.js, loaded on this one click). */
export async function openPlansList(box, host){
  const PLANS = await import(`./live_aboard_plans.js${new URL(import.meta.url).search}`);
  return PLANS.openPlansList(box, { ...host, DRAFT, PIECES, FURN });
}

const D2R = Math.PI / 180;
const FOV = 40;
const BG = "#0c110f";
const MIN_PHI = 0.0015, MAX_PHI = 84 * D2R, MIN_R = 1.5, MAX_R = 260;
const SLAB_SIDE = "#c8b18c", EARTH_SIDE = "#4a3f33", TILE_MIX = "#d9d2c3";
const LAMP_I = 7;                          // a real lamp's intensity at full brightness
// The frame-time check: up to 22 frames, or 1.5 s once there are enough to
// judge; a screen that cannot draw six frames in 4 s is slow, full stop.
const MEASURE_FRAMES = 22, MEASURE_MS = 1500, MEASURE_MIN = 6, MEASURE_GIVE_UP_MS = 4000;
const HALO = { s: 0.16, m: 0.55, l: 1.05 };
const POOL_K = 0.34, WASH_K = 0.6;         // a light's pool on the floor, its wash on a wall: how bright at full
const AO_W = 0.38, AO_A = 0.42;            // High's contact shade along wall bases: width (m), darkest alpha
// The sun and the sky by day, and what is left of them at night (blended
// through twilight by live_aboard_house.js sunLight).
const SUN_I = 2.0, SKY_I_DAY = 1.6, SKY_I_NIGHT = 0.3;
const SUN_HIGH = "#fff0dc", SUN_LOW = "#ff9f5a";
const SKY_DAY = "#e6edf6", SKY_NIGHT = "#4a5d8a", GROUND_DAY = "#3a342c", GROUND_NIGHT = "#101318";
const SUN_STEP = 0.5;                      // degrees the sun must move before the house is drawn again
// The live parts (part B).
const NO_READING = "#64748b";              // the Atlas's "no reading" grey (its dashed line)
const SHUT_LINE = "#94a3b8";               // the Atlas's line across a linked barrier that reads closed
const SENSOR_ON = "#3b82f6", SENSOR_QUIET = "#cfd8d3";   // a motion sensor lit while active (the Atlas's MOTION_PULSE)
const DOOR_OPEN = 85 * D2R, WINDOW_OPEN = 50 * D2R, SWING_MS = 650;
// Drawn at full rate only while something has just started moving: about
// 30 frames a second, 15 on Low. A door or window swings; a pulse or a
// lock's flash plays for its first LIVE_MS; whatever carries on after (a
// pulse, a lock left unlocked, a room breathing after motion, the air's
// bars) is drawn still, so a house at rest draws nothing at all.
const AMBIENT_MS = { high: 33, low: 66 };
const LIVE_MS = 5000;
const meanOf = (v) => v.slice(1).reduce((a, x, i) => a + (x + v[i]) / 2, 0) / (v.length - 1);
const STILL = { active: meanOf(HOUSE.MOTION_PULSE.fill), recent: meanOf(HOUSE.MOTION_RECENT.op) };   // a pulse's, a breath's mean
const PICK_R = 22;                         // a device's reach for a tap (the Atlas's 44 px target)
const PIECE_D = PICK_R / 2;                // a press on a linked piece: a marker nearer than this wins
const CLOSE_PX = 8;                        // lights this much alike in reach of a tap: the chosen floor's, else the one in front
const TIE_PX = 2;                          // any other two devices this near alike on screen: the one in front wins
const PEOPLE_MS = 5000;                    // the people layer reads the live snapshot at most this often
const READ_H = 0.45, READ_PX = [22, 30];   // a readout chip's height (m), and never under / over this on screen (px)
const READ_W = 520, READ_C = 72;           // its canvas: the pill is drawn inside, as wide as its words
const RING_R0 = 0.6;                       // the motion ring's radius (m) at 1 (the Atlas's 0.7 → 2.4)
const FILL_K = 0.6, RECENT_K = 0.45, AIR_K = 1.6;   // how strongly a floor takes the Motion · Air colour
// The screen (the sidebar): zoomed in past the whole-house fit, the bars step
// aside for the map alone; back out to it, they return (atlas_screen.js
// soloStep, the flat map's rule too).
const COVER_Z = SCREEN.COVER_Z;
const NARROW_W = 560;                      // under this the bar is one compact row
const TAP_MS = 320, TAP2_MS = 420, TAP_PX = 10, TAP2_PX = 44, FLY_MS = 650;
const PREF_VIEWS = "views_", PREF_HINT = "hint_seen", VIEWS_MAX = 8;
const GUIDE_URL = "https://github.com/gbroeckling/padspanHA/blob/main/docs/LIVE_ABOARD_GUIDE.md";
const WET_INK = "#38bdf8", WET_WORD = "☔ Window open in the rain";
const WINDOW_GLOW = "#ffc978";                           // a lit room's window at night, from outside
const HEAT_A = 0.66;                                     // the heat map's strength over a room's floor
const WET_CSS = `.la3d-wet{position:absolute;left:50%;top:82px;z-index:2;transform:translateX(-50%);display:none;max-width:calc(100% - 140px);
  overflow:hidden;text-overflow:ellipsis;white-space:nowrap;padding:4px 12px;border-radius:999px;cursor:pointer;
  font:600 12px system-ui,"Segoe UI",sans-serif;color:#e0f2fe;background:rgba(7,28,44,.92);border:1px solid ${WET_INK};
  box-shadow:0 0 0 3px rgba(56,189,248,.18)}
.la3d-wet.on{display:block}
.la3d-wet:hover{background:rgba(12,45,70,.95)}`;
// Explode: with All floors showing, each storey lifted this much more (m)
// than the one under it, so the floors under the top one show too. On by
// default on the sidebar (it opens on every floor, pulled apart); off by
// default on a wall and in Mapping; a browser that set it keeps its own.
const PREF_EXPLODE = "explode", EXPLODE_M = 4;
// Labels by zoom level (2026-11-18): the whole house (every floor, not zoomed
// in past SCREEN.SOLO_IN of its fit) shows one tag per floor and no room
// names, readouts, markers or codes; one floor its rooms' names, readouts and
// markers; a room opened (flown into, or zoomed into at room scale) its
// devices' codes, the other rooms faded to ROOM_FADE. Zoomed out ROOM_OUT
// times past where it opened, the room closes.
const ROOM_FADE = 0.35, ROOM_OUT = 1.6;
// The room open is tinted (a room chip, its panel, a double-tap): its floor
// leans this far toward the accent green, in the same one upload as the fade.
const ROOM_TINT = "#52b788", ROOM_TINT_K = 0.22;
// Walls: Glass. What Cut takes away stands as tinted glass, its edges a little
// brighter so each wall still reads (drawn after the house, writing no depth).
const GHOST_COL = "#cfefff", GHOST_OP = 0.13, GHOST_EDGE_OP = 0.55;
const PREF_TRAILS = "trails";              // Trails on this screen ("1"), off by default
const PREF_FPS = "fps";                    // the frame-rate readout on this screen ("1"), off by default
// Readable night: a floor keeps this much of its day colour, its outline and
// the wall tops show, and a fixture that is off darkens with the house.
const NIGHT_FLOOR = 0.3, NIGHT_EDGE = 0.85, NIGHT_TOP = 0.42, NIGHT_GRID = 0.6;
// The ring on a covered patio's floor under an off ceiling light (its size, how far up).
const FLOOR_MARK_R = 0.12, FLOOR_MARK_UP = 0.02;
// A fixture seen from across a room (Garry, 2026-11-13, "Fixture bigger": a pot light its real 15 cm, a plain light a
// 7 cm ball, were a few pixels on a wall screen, and off they were half see-through and dark). A round fixture (a pot,
// a dome, a single ball) is drawn no smaller than SEEN_R in radius, at most SEEN_MAX times its size; a strip, a tube, a
// panel and a cluster of small bulbs (a chandelier) keep their own. Off, it is solid (OFF_OP) and leans less to the
// theme's dark (OFF_LEAN).
const SEEN_R = 0.13, SEEN_MAX = 3, OFF_OP = 0.9;
const MAGNET_R = 60;                       // with nothing under the finger, the nearest light this near takes the press, px
const seenK = (b, n) => (b.mat || b.prim === "box" || (b.prim === "sphere" && n > 2) ? 1 : Math.min(SEEN_MAX, Math.max(1, SEEN_R / Math.max(b.sx, b.sz))));
const NAME_PX = [12, 17];                  // a room's name on screen (px), never under / over
// A split level's floor's walls this close to the level's own rooms stand round them (sizeNames).
const OWN_WALL_M = 0.5;
// On a wall (?kiosk=1, lights_panel.js _wallOn) the names and the controls
// grow with the screen: --wall-ui is the screen against 1080p, never under 1.
// The wall is the page (the Atlas element carries data-wall), not the card,
// so it holds when the view leaves the card for the whole screen. Read once
// per window size (it is asked every frame), and only once the view is on
// the page: before that it can't see the wall it is in.
const onWallPage = (el) => {
  const rn = el && el.getRootNode ? el.getRootNode() : null;
  return !!(rn && rn.host && rn.host.hasAttribute && rn.host.hasAttribute("data-wall"));
};
const wallUiOf = (() => {
  const seen = new Map();   // property -> [key, value]
  return (el, prop = "--wall-ui") => {
    if (!el || !el.isConnected) return 1;
    const host = el.getRootNode && el.getRootNode().host;
    const k = `${innerWidth}x${innerHeight}:${host && host.style ? host.style.getPropertyValue(prop) : ""}`;
    const had = seen.get(prop);
    if (had && had[0] === k) return had[1];
    let v = 1;
    if (onWallPage(el)) {
      const n = parseFloat(getComputedStyle(el.getRootNode().host).getPropertyValue(prop));
      if (Number.isFinite(n) && n >= 1) v = n;
      else if (prop !== "--wall-ui") v = wallUiOf(el);   // a wall without --wall-ctl: the controls go with the text
    }
    seen.set(prop, [k, v]);
    return v;
  };
})();

// The view's own look: everything is scoped under .la3d, and the sheet travels
// inside the long-lived element, so nothing is added to styles.css and the
// flat Atlas cannot be touched by it. The bars reuse the Atlas's segmented
// control (.lv-zoomseg) so they wear the same face.
const CSS = `
.la3d{position:relative;display:block;width:100%;height:calc(100vh - 260px);min-height:360px;box-sizing:border-box;
  border-radius:14px;overflow:hidden;background:${BG};border:1px solid rgba(120,190,155,.18);
  -webkit-user-select:none;user-select:none;-webkit-touch-callout:none}
.lv-mapcard.lv-display .la3d{border-radius:0;border:none;width:calc(100% - 44px);margin-left:44px;height:calc(100vh - 84px)}
.lv-rail.hidden ~ .la3d{width:100%;margin-left:0}
@media (max-width:900px){.lv-mapcard.lv-display .la3d{height:calc(100vh - 130px)}}
@media (max-width:600px){.lv-mapcard.lv-display .la3d{height:calc(100vh - 175px)}}
.la3d canvas{display:block;width:100%;height:100%;touch-action:none;outline:none}
.la3d-bar{position:absolute;left:10px;right:10px;bottom:10px;display:flex;flex-wrap:wrap;gap:8px;
  justify-content:space-between;align-items:flex-end;pointer-events:none}
.la3d-bar > *{pointer-events:auto}
.la3d .lv-zoomseg{background:rgba(6,14,9,.86);box-shadow:0 4px 14px rgba(0,0,0,.35)}
.la3d .lv-zoomseg button{padding:7px 12px;font-size:12px}
.la3d .lv-zoomseg button[aria-pressed="true"]{background:rgba(82,183,136,.32);color:#e2e8f0}
.la3d-lbl{align-self:center;padding:0 6px 0 10px;font-size:11px;font-weight:600;letter-spacing:.06em;
  text-transform:uppercase;color:#94a3b8}
.la3d-compass{position:absolute;left:10px;top:10px;z-index:2;width:52px;height:52px;padding:0;border-radius:50%;
  border:1px solid rgba(120,190,155,.26);background:rgba(6,14,9,.86);box-shadow:0 4px 14px rgba(0,0,0,.35);cursor:pointer;
  touch-action:none}
.la3d-compass svg{display:block;width:100%;height:100%;pointer-events:none}
.la3d .la3d-north{position:absolute;left:10px;top:70px;z-index:3;display:none}
.la3d .la3d-north.on{display:inline-flex}
.la3d-toast{position:absolute;left:50%;bottom:64px;z-index:3;transform:translateX(-50%);display:flex;align-items:center;gap:10px;
  padding:6px 7px 6px 14px;border-radius:12px;background:rgba(6,14,9,.95);border:1px solid rgba(120,190,155,.26);
  color:#e2e8f0;font-size:13px;white-space:nowrap;box-shadow:0 12px 32px rgba(0,0,0,.5);animation:la3d-toast 6s ease forwards;pointer-events:none}
.la3d-toast button{all:unset;box-sizing:border-box;cursor:pointer;padding:5px 11px;border-radius:8px;font-weight:700;pointer-events:auto;
  color:#f59e0b;background:rgba(245,158,11,.12)}
@keyframes la3d-toast{0%{opacity:0;visibility:visible}5%{opacity:1}85%{opacity:1;visibility:visible}100%{opacity:0;visibility:hidden}}
.la3d-ov{position:absolute;left:0;top:0;width:100%;height:100%;pointer-events:none;overflow:visible;z-index:1}
.la3d-pressname{fill:#fff;font:800 15px Inter,system-ui,sans-serif;text-anchor:middle;paint-order:stroke;stroke:rgba(4,10,6,.92);stroke-width:5px;stroke-linejoin:round}
.la3d-btn circle{fill:rgba(8,16,11,.84);stroke:#cbd5e1;stroke-width:2}
.la3d-btn path{fill:none;stroke:#cbd5e1;stroke-linecap:round}
.la3d-btn .stem{stroke-width:1.5;stroke-opacity:.75;stroke-dasharray:1 4}
.la3d-btn .tip{stroke-width:7}
.la3d-btn[data-on="all"] path,.la3d-btn[data-on="some"] path{stroke:#fbbf24}
.la3d-btn[data-on="all"] circle{fill:#fbbf24;stroke:#fff7d6}
.la3d-btn[data-on="some"] circle{stroke:#fbbf24;stroke-width:3}
.la3d-btn[data-on="gone"]{opacity:.45}
.la3d-btn text{fill:#e2e8f0;font:800 13px Inter,system-ui,sans-serif;text-anchor:middle;dominant-baseline:central}
.la3d-btn[data-on="all"] text{fill:#111827}
.la3d-hud{position:absolute;left:122px;top:10px;z-index:3;max-width:calc(100% - 134px)}
.la3d-hud .lv-hoverhud{position:static}
.la3d-side{display:flex;flex-wrap:wrap;gap:8px;align-items:flex-end}
.la3d-side:last-child{justify-content:flex-end;margin-left:auto}
.la3d .la3d-floor .la3d-fname{min-width:64px;text-align:center;color:#e2e8f0}
.la3d .lv-zoomseg button[disabled]{opacity:.35;cursor:default}
.la3d .lv-zoomseg svg{display:block;width:14px;height:14px}
.la3d.la3d-narrow .la3d-w,.la3d:not(.la3d-narrow) .la3d-n{display:none}
.la3d.la3d-narrow .la3d-bar{left:8px;right:8px;bottom:8px;gap:6px;flex-wrap:nowrap}
.la3d.la3d-narrow .la3d-side{flex-wrap:nowrap;gap:6px}
.la3d .lv-zoomseg button{white-space:nowrap}
.la3d.la3d-narrow .lv-zoomseg button{padding:7px 8px}
.la3d.la3d-narrow .la3d-floor .la3d-fname{min-width:40px;max-width:76px;overflow:hidden;text-overflow:ellipsis}
.la3d .la3d-floor .la3d-fname{display:inline-flex;align-items:center;justify-content:center;gap:5px}
.la3d .la3d-fn{min-width:0;overflow:hidden;text-overflow:ellipsis}
.la3d .lv-dot{display:inline-block;flex:none;box-sizing:border-box}
.la3d-menu .lv-dot{margin-left:7px;vertical-align:1px}
.la3d .la3d-fb,.la3d-menu .la3d-fb{display:inline-flex;align-items:center;justify-content:center;flex:none;box-sizing:border-box;
  min-width:18px;height:18px;padding:0 4px;border-radius:9px;font:700 11px/1 system-ui,"Segoe UI",Roboto,sans-serif;color:#071008}
.la3d-menu .la3d-fb{margin-right:7px;vertical-align:1px}
.la3d.la3d-narrow .la3d-floor .la3d-fname:has(.la3d-fb) .la3d-fn{display:none}
.la3d-corner{all:unset;box-sizing:border-box;position:absolute;left:12px;bottom:12px;z-index:4;display:inline-flex;align-items:center;gap:6px;
  padding:5px 12px;border-radius:999px;background:rgba(6,14,9,.6);color:#e2e8f0;font-size:13px;font-weight:600;cursor:pointer;
  opacity:0;visibility:hidden;pointer-events:none}
.la3d.la3d-bare .la3d-corner.on{pointer-events:auto;animation:la3d-corner 2s ease forwards}
@keyframes la3d-corner{0%{opacity:0;visibility:visible}12%{opacity:.7}70%{opacity:.7;visibility:visible}100%{opacity:0;visibility:hidden}}
.la3d.la3d-bare .la3d-menu.la3d-keep{opacity:1;visibility:visible;pointer-events:auto}
.la3d-menu{position:absolute;z-index:5;min-width:170px;max-width:min(280px,calc(100% - 20px));padding:5px;border-radius:12px;
  background:rgba(6,14,9,.95);border:1px solid rgba(120,190,155,.26);box-shadow:0 12px 32px rgba(0,0,0,.5);display:flex;flex-direction:column;gap:2px}
.la3d-menu .la3d-mrow{display:flex;align-items:center;gap:2px}
.la3d-menu button{all:unset;box-sizing:border-box;cursor:pointer;flex:1;padding:8px 11px;border-radius:8px;font-size:13px;color:#e2e8f0;
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.la3d-menu button:hover,.la3d-menu button:focus-visible{background:rgba(82,183,136,.18)}
.la3d-menu button[aria-checked="true"]{color:#a7f3d0;font-weight:700}
.la3d-menu button.la3d-mx{flex:none;padding:8px 10px;color:#94a3b8}
.la3d-menu hr{border:none;border-top:1px solid rgba(120,190,155,.18);margin:3px 4px}
.la3d-menu{max-height:calc(100% - 76px);overflow-y:auto;overscroll-behavior:contain;scrollbar-width:thin}
.la3d-menu .la3d-mhead{flex:none;padding:8px 11px 2px;font-size:10.5px;font-weight:700;letter-spacing:.07em;text-transform:uppercase;color:#7fb79a}
.la3d-menu .la3d-mnote{flex:none;padding:6px 11px 8px;font-size:12px;line-height:1.35;color:#94a3b8;white-space:normal}
.la3d-menu .la3d-mseg{flex:none;display:flex;gap:4px;padding:3px}
.la3d-menu .la3d-mseg button{text-align:center;border:1px solid rgba(120,190,155,.26)}
.la3d-menu .la3d-mseg button[aria-pressed="true"]{background:rgba(82,183,136,.32);color:#fff;font-weight:700}
.la3d-menu .la3d-sw{display:inline-block;flex:none;width:18px;height:18px;margin-right:9px;border-radius:5px;vertical-align:-4px;
  box-shadow:inset 0 0 0 1px rgba(255,255,255,.22)}
.la3d-menu .la3d-mrow{flex:none}
.la3d-menu button[role="menuitemcheckbox"]::before{content:"";display:inline-block;width:12px;height:12px;margin-right:8px;vertical-align:-1px;
  border:2px solid #64748b;border-radius:4px}
.la3d-menu button[role="menuitemcheckbox"][aria-checked="true"]::before{background:#52b788;border-color:#52b788}
.la3d-tip{position:absolute;left:50%;top:12px;z-index:2;transform:translateX(-50%);max-width:calc(100% - 340px);padding:4px 12px;
  border-radius:999px;background:rgba(6,14,9,.6);color:#94a3b8;font-size:12px;white-space:nowrap;overflow:hidden;
  text-overflow:ellipsis;pointer-events:none}
.la3d.la3d-narrow .la3d-tip{display:none}
.la3d-bar,.la3d-compass,.la3d-tip{transition:opacity .25s ease,visibility .25s}
.la3d.la3d-bare .la3d-bar,.la3d.la3d-bare .la3d-compass,.la3d.la3d-bare .la3d-tip,.la3d.la3d-bare .la3d-north,
.la3d.la3d-bare .la3d-menu{opacity:0;visibility:hidden;pointer-events:none}
.la3d-solo{all:unset;box-sizing:border-box;position:absolute;right:12px;top:12px;z-index:4;width:40px;height:40px;border-radius:50%;
  display:none;align-items:center;justify-content:center;cursor:pointer;font-size:18px;color:#e2e8f0;background:rgba(6,14,9,.6);
  border:1px solid rgba(120,190,155,.26);box-shadow:0 4px 14px rgba(0,0,0,.35);opacity:.72}
.la3d-solo:hover,.la3d-solo:focus-visible{opacity:1}
.la3d.la3d-bare .la3d-solo{display:flex}
.la3d.la3d-cover{transition:left .25s ease,top .25s ease,width .25s ease,height .25s ease}
/* The whole house: one tag beside each floor (paintTags), a tap shows that floor alone. Sized in em: a wall's grow with it. */
.la3d-ftags{position:absolute;left:0;top:0;width:0;height:0;z-index:1}
.la3d-ftag{all:unset;box-sizing:border-box;position:absolute;left:0;top:0;display:flex;flex-direction:column;gap:.1em;padding:.5em 1em .55em;
  border-radius:1em;cursor:pointer;white-space:nowrap;background:rgba(6,14,9,.84);border:1px solid rgba(120,190,155,.34);
  box-shadow:0 4px 14px rgba(0,0,0,.35);color:#a7c4b5;font:600 12px/1.25 system-ui,"Segoe UI",Roboto,sans-serif}
.la3d-ftag b{font-size:1.2em;font-weight:800;color:#f3f6f4}
.la3d-ftag:hover,.la3d-ftag:focus-visible{border-color:#52b788;background:rgba(20,48,34,.92)}
.la3d:fullscreen{border-radius:0;border:none}
.la3d-card{position:absolute;left:50%;top:50%;z-index:6;transform:translate(-50%,-50%);width:min(360px,calc(100% - 32px));box-sizing:border-box;
  padding:16px 18px 14px;border-radius:14px;background:rgba(6,14,9,.95);border:1px solid rgba(120,190,155,.26);
  box-shadow:0 12px 32px rgba(0,0,0,.5);color:#e2e8f0;font-size:13px;line-height:1.45}
.la3d-card b{display:block;font-size:15px;margin-bottom:8px}
.la3d-card ul{margin:0 0 12px;padding-left:18px}
.la3d-card a.la3d-guide{display:block;margin:-4px 0 12px;color:#a7f3d0;font-size:13px;text-decoration:underline}
.la3d-card li{margin:3px 0}
.la3d-card button{all:unset;box-sizing:border-box;cursor:pointer;padding:7px 16px;border-radius:9px;font-weight:700;
  background:#2d6a4f;border:1px solid #52b788;color:#e2e8f0;float:right}
@media (prefers-reduced-motion:reduce){.la3d.la3d-cover,.la3d-bar,.la3d-compass,.la3d-tip{transition:none}}
/* Wall mode (?kiosk=1 on the sidebar Atlas; styles.css .lv-wall): the view
   takes what the legend leaves beside the scaled rail, its controls grow with
   the wall up to finger size (--wall-ctl), what is read (the HUD) with
   --wall-ui, and the touch hint goes. */
.lv-mapcard.lv-display.lv-wall > .la3d{flex:1 1 auto;min-height:0;height:auto;
  width:calc(100% - 44px * var(--wall-ctl,var(--wall-ui,1)));margin-left:calc(44px * var(--wall-ctl,var(--wall-ui,1)))}
.lv-mapcard.lv-display.lv-wall > .lv-rail.hidden ~ .la3d{width:100%;margin-left:0}
:host([data-wall]) .la3d-hud{zoom:var(--wall-ui,1)}
/* The People and Motion chips (their row, or the Motion chip alone when the
   people chip is not loaded), the motion colour key and the window-open-in-
   the-rain line under them are read like the HUD, so they grow with it and
   keep their gaps; on a 4K wall they used to stay 1080p-sized. */
:host([data-wall]) .la3d-chiprow,:host([data-wall]) .la3d > .la3d-mchip,:host([data-wall]) .la3d-mkey,:host([data-wall]) .la3d-wet{zoom:var(--wall-ui,1)}
:host([data-wall]) .la3d-bar,:host([data-wall]) .la3d-compass,:host([data-wall]) .la3d-north,
:host([data-wall]) .la3d-menu,:host([data-wall]) .la3d-toast,:host([data-wall]) .la3d-solo,:host([data-wall]) .la3d-corner,
:host([data-wall]) .la3d-dircard,:host([data-wall]) .la3d-sheet,:host([data-wall]) .la3d-card{zoom:var(--wall-ctl,var(--wall-ui,1))}
:host([data-wall]) .la3d-tip{display:none}
/* Vacation Mode's banner (styles.css .lv-vacation) is pinned dead centre over
   the map. While the ⋯ list or a menu is open (the panel's element carries
   data-la3d-menu) it steps under them, and is on top again once they close. */
:host([data-la3d-menu]) .lv-mapcard > .lv-vacation{z-index:4}
/* Over the 3D house (this sheet is in the page only while it shows) the
   banner takes a tap only on its controls: a light under it is still tapped.
   The flat map's banner is left exactly as it is. */
.lv-mapcard > .lv-vacation:not([role]):not(.lv-vacation-opts){pointer-events:none}
.lv-mapcard > .lv-vacation:not([role]):not(.lv-vacation-opts) :is(button,input){pointer-events:auto}`;
// While Live Aboard shows (its sheet travels with it): the flat Atlas's
// symbol legend matches nothing in 3D; on the sidebar the header's flat hint
// gives way to the view's own, and on a narrow screen the emergency pill
// folds to its icon, clear of the house. The flat map's scene row gives way
// to the view's own (scene_row.js).
const CSS_SHOWING = `.lv-legend{display:none}.psc-atlas{display:none}`;
// Covering the panel (the map alone, full screen): the Vacation banner and
// the emergency lighting dial stay on top, the dial in the cover's corner.
const COVER_TOP_Z = COVER_Z + 1;
// With the dial in the corner, ☰ (bring the bars back) sits under it, never
// beneath it: a tap meant for ☰ must not open, or start, the emergency test.
const DIAL_CLEAR = 14 + 72 + 12;
// A list or menu open over the cover: the banner stays over the map, but not
// over the list (the list is in the cover's own layer, so the banner can't be
// put between them): where they overlap, the list's box is cut out of it,
// for the eye and for a tap.
const coverCss = (c, dial, cut) => `.lv-vacation{z-index:${COVER_TOP_Z}}
:host([data-la3d-menu]) .lv-mapcard > .lv-vacation.lv-vacation{z-index:${COVER_TOP_Z}${cut ? `;clip-path:${cut}` : ""}}
.lv-emerg{position:fixed;z-index:${COVER_TOP_Z};top:${Math.round(c.top + 14)}px;right:${Math.round(Math.max(0, (window.innerWidth || 0) - c.left - c.width) + 14)}px}${
  dial ? `
.la3d .la3d-solo{top:${DIAL_CLEAR}px}` : ""}`;
const CSS_PANEL = `.lv-hero > .lv-hint{display:none}
@media (max-width:600px){.lv-emerg-label.on{max-width:32px;width:32px;padding:0;justify-content:center}
  .lv-emerg-label.on .lv-emerg-label-tx{display:none}.lv-emerg-label.on .lv-emerg-label-ic{display:inline-flex}}`;

const _slots = new Map();
/** One 3D view per screen ("atlas" — the sidebar; "builder" — Mapping). */
export function liveAboardSlot(key){
  const k = String(key || "atlas");
  if (!_slots.has(k)) _slots.set(k, createSlot(k));
  return _slots.get(k);
}
// Settings → Remove all furniture (settings.js, once house3d_clear has done
// it): every screen reads the 3D file again, so a removed piece is not drawn,
// nor saved back from a draft.
const FILE_CHANGED = "padspan-ha-house3d-changed";
if (typeof window !== "undefined" && typeof window.addEventListener === "function") {
  window.addEventListener(FILE_CHANGED, () => { for (const s of _slots.values()) s.reload(); });
  // Mapping's alarm tick (panel.js _mappingAlarmTick): a slot showing the Plans map says so.
  window.addEventListener("padspan-ha-alarms-now", (e) => {
    for (const s of _slots.values()) if (s.quietAlarmsNow(e.detail.states, e.detail.latches)) e.detail.plansOpen = true;
  });
}
/** The feature was switched off: give the screen's GL context back (a later
 *  switch-on starts afresh). */
export function releaseLiveAboardSlot(key){
  const s = _slots.get(String(key || "atlas"));
  if (!s) return;
  _slots.delete(String(key || "atlas"));
  s.release();
}

// ── Small three helpers ──────────────────────────────────────────────────────
const _m = new THREE.Matrix4(), _q = new THREE.Quaternion(), _p = new THREE.Vector3(), _s = new THREE.Vector3(), _c = new THREE.Color();
const _v = new THREE.Vector3(), _v2 = new THREE.Vector3(), _white = new THREE.Color(1, 1, 1);
const Y_AXIS = new THREE.Vector3(0, 1, 0);
const ZERO = new THREE.Matrix4().makeScale(0, 0, 0);
function compose(x, y, z, yaw, sx, sy, sz){
  _q.setFromAxisAngle(Y_AXIS, yaw); _p.set(x, y, z); _s.set(sx, sy, sz);
  return _m.compose(_p, _q, _s);
}
/** A colour from room_color.js's answer: "#rrggbb", or its "hsl(h s% l%)". */
function colorOf(str){
  const s = String(str || "").trim();
  const m = /^hsla?\(\s*([\d.]+)(?:deg)?[\s,]+([\d.]+)%[\s,]+([\d.]+)%/i.exec(s);
  if (m) return new THREE.Color().setHSL((Number(m[1]) % 360) / 360, Number(m[2]) / 100, Number(m[3]) / 100, THREE.SRGBColorSpace);
  if (/^#([0-9a-f]{3}|[0-9a-f]{6})$/i.test(s)) return new THREE.Color(s);
  return new THREE.Color("#7a8a80");
}
function radialTexture(stops){
  const c = document.createElement("canvas"); c.width = c.height = 128;
  const g = c.getContext("2d"), grd = g.createRadialGradient(64, 64, 0, 64, 64, 64);
  for (const [o, col] of stops) grd.addColorStop(o, col);
  g.fillStyle = grd; g.fillRect(0, 0, 128, 128);
  return new THREE.CanvasTexture(c);
}
// Light from a line (a strip, a cove, a pot by a wall) on what it falls on:
// brightest along the line (the canvas's bottom edge, v = 0) and fading away
// from it, soft at both ends ("fade"); a soft fan from the middle of the line
// ("scallop").
function washTexture(scallop){
  const c = document.createElement("canvas"); c.width = c.height = 64;
  const g = c.getContext("2d");
  if (scallop) {
    const grd = g.createRadialGradient(32, 64, 0, 32, 64, 64);
    grd.addColorStop(0, "rgba(255,255,255,1)"); grd.addColorStop(0.4, "rgba(255,255,255,0.45)"); grd.addColorStop(1, "rgba(255,255,255,0)");
    g.fillStyle = grd; g.fillRect(0, 0, 64, 64);
  } else {
    const v = g.createLinearGradient(0, 64, 0, 0);
    v.addColorStop(0, "rgba(255,255,255,1)"); v.addColorStop(0.35, "rgba(255,255,255,0.42)"); v.addColorStop(1, "rgba(255,255,255,0)");
    g.fillStyle = v; g.fillRect(0, 0, 64, 64);
    g.globalCompositeOperation = "destination-in";
    const u = g.createLinearGradient(0, 0, 64, 0);
    for (const [o, a] of [[0, 0], [0.06, 1], [0.94, 1], [1, 0]]) u.addColorStop(o, `rgba(0,0,0,${a})`);
    g.fillStyle = u; g.fillRect(0, 0, 64, 64);
  }
  return new THREE.CanvasTexture(c);
}
function rampTexture(){
  const c = document.createElement("canvas"); c.width = 4; c.height = 64;
  const g = c.getContext("2d"), grd = g.createLinearGradient(0, 0, 0, 64);
  grd.addColorStop(0, `rgba(0,0,0,${AO_A})`); grd.addColorStop(0.45, `rgba(0,0,0,${(AO_A * 0.35).toFixed(3)})`); grd.addColorStop(1, "rgba(0,0,0,0)");
  g.fillStyle = grd; g.fillRect(0, 0, 4, 64);
  return new THREE.CanvasTexture(c);
}
/** One air bar per repeat: a soft white band across a clear tile (the
 *  Atlas's bars are a fifth of the room apart, each a little under a fifth
 *  of that thick). Tinted and faded by its material. */
function barsTexture(){
  const c = document.createElement("canvas"); c.width = 4; c.height = 64;
  const g = c.getContext("2d"), grd = g.createLinearGradient(0, 0, 0, 64);
  grd.addColorStop(0, "rgba(255,255,255,0)"); grd.addColorStop(0.03, "rgba(255,255,255,1)");
  grd.addColorStop(0.15, "rgba(255,255,255,1)"); grd.addColorStop(0.19, "rgba(255,255,255,0)"); grd.addColorStop(1, "rgba(255,255,255,0)");
  g.fillStyle = grd; g.fillRect(0, 0, 4, 64);
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  return t;
}
/** PadSpan's own merge: the non-indexed attributes every part shares, one
 *  after the other — one draw for a floor's tiles. */
function mergeGeometries(geos){
  const parts = geos.map(g => (g.index ? g.toNonIndexed() : g));
  const names = ["position", "normal", "uv", "color"].filter(n => parts.every(g => g.getAttribute(n)));
  const out = new THREE.BufferGeometry();
  for (const n of names) {
    const size = parts[0].getAttribute(n).itemSize;
    let total = 0;
    for (const g of parts) total += g.getAttribute(n).count * size;
    const arr = new Float32Array(total);
    let off = 0;
    for (const g of parts) { const a = g.getAttribute(n); for (let i = 0; i < a.count * size; i++) arr[off + i] = a.array[i]; off += a.count * size; }
    out.setAttribute(n, new THREE.BufferAttribute(arr, size));
  }
  parts.forEach((g, i) => { if (g !== geos[i]) g.dispose(); });
  return out;
}

/** A paved room's outline, flat (as the floor tiles: plan (x, y) to world
 *  (x, ·, y)), each point's uv its place in tiles from the room's own corner
 *  (outdoor_space.js paverFrame): the grid square to the room, true to scale. */
function pavingGeometry(shapes, frame){
  const g = new THREE.ShapeGeometry(shapes), p = g.attributes.position, uv = g.attributes.uv;
  for (let i = 0; i < p.count; i++) { const [u, v] = SURF.paverUv(frame, p.getX(i), p.getY(i)); uv.setXY(i, u, v); }
  return g.rotateX(Math.PI / 2);
}

function createSlot(slotKey){
  // ── the long-lived element ────────────────────────────────────────────────
  let root = null, canvas = null, bar = null, rose = null, roseDeg = null;
  let renderer = null, scene = null, camera = null;
  let failed = null;                       // the fallback kind, once failed (for this page load)
  let stage = null;                        // the flat stage hidden while this shows
  let send = null;                         // the host's report sender (closed words only)
  let touchCb = null;                      // the card's "the map was touched" (closes an open drawer)
  let observers = [];
  let frames = 0, pending = false, dirty = true, visible = true, drawnW = 0, drawnH = 0;
  let fpsUi = null;                        // the frame-rate readout, while this screen has it on
  // The house, as drawn: shell (floors, rooms, walls) and fixtures.
  let shellSig = null, lightsSig = null, house = null, floorsUi = [], lights = [];
  // The map's house as last read (readHouse) and what it was read from: a
  // change in the 3D file alone (the editor's draft) draws from it again.
  let reading = null, readSig = null, readGap = 0;         // readGap: the Explode gap the house was read (and drawn) with
  const work = { reads: 0, shells: 0, lights: 0, sensors: 0, moves: 0 };   // how often each was done (the harness)
  let shellRes = [], lightRes = [];       // geometries, materials and textures a rebuild disposes
  let topElev = null, wallMode = "cut";
  // This screen's Glass walls line (the ⋯ list) as last followed: null until the first draw reads it.
  let glassPick = null;
  const quality = { setting: "auto", profile: null, measuring: null, measured: {}, intervals: [], t0: 0, last: 0 };
  // The camera fits the house until someone moves it (the first card may be
  // drawn before the map has arrived).
  const cam = { target: new THREE.Vector3(), theta: Math.PI / 4, phi: 0.98, radius: 30, needsFit: true, moved: false };
  let houseBox = { x0: -5, y0: -5, x1: 5, y1: 5, z0: 0, z1: 3 };
  // The sun as last read and as last drawn, and true north as drawn
  // (settings.fabric_bearing_deg, or the compass being spun).
  let sunRead = null, sunNow = null, bearing = 0;
  const sunDir = new THREE.Vector3(0, 1, 0);
  // North on the compass you spin (see "north: the compass you spin").
  const SPIN_SLOP = 6, NORTH_HOLD_MS = 60000;
  let storedBearing = 0;                   // the saved bearing, as the host last said
  let northPreview = null;                 // the bearing being tried, not saved
  let northHold = null;                    // {b, until}: just saved, until the host catches up
  let spin = null, compassEl = null, pill = null, pillBtns = [], unhookNorth = null, saveNorthCb = null;
  const camPts = new Map();                // fingers and buttons down on the house itself
  let dropPointers = () => {};             // ends every one of them, as a cancel (wirePointer)
  // Shared, made once per slot.
  let shared = null;
  let plumb = null;                          // the drop line under a hovered or pressed device
  let hemi = null, sun = null, lampPool = [], lampsDirty = true, ground = null, gridLines = null;
  const lampTarget = new THREE.Vector3(Infinity, 0, 0);
  // The live parts and the taps (part B). use: the press, the hover box and
  // the rings (live_aboard_use.js); apiOf: the host's use api, as the poll
  // last handed it; lbe: the Atlas's device records, live.
  let use = null, apiOf = null, apiNow = null, lbe = {}, haStarted = 0;
  // readouts: the sensors that read out; chips: one pill per room (or per
  // sensor outside every room) saying what they read.
  let openings = [], sensorsUi = [], tints = [], readouts = [], chips = [], heats = [];
  let sensorRes = [], sensorsSig = null;
  let liveMs = 0, lastAmbient = 0, rehoverDue = false;   // liveMs: how often something moving by itself is drawn (0: still)
  let northDismissed = null;               // the pointerdown that only put north back
  // The 3D file (part C), as the editor owns it (live_aboard_draft.js
  // ownedOf): read once through the host's load (house3d_get) when the view
  // first shows, and again after the screen went back to Map; null until
  // read. lastP: the card's newest data, to draw again from.
  let file = null, fileLoad = null, lastP = null;
  // The file as the host last handed it (house3d_get's or house3d_edit's
  // "data"), and heights just saved to placement records that the map's own
  // read may not have yet ({entity id: {z, was}}: see recordsNow). fileZ:
  // heights just written to the file for devices with no record, the newest
  // each has ({entity id: {over, gone}}: what the map said of it then; see
  // recordsNow and goneNow).
  let fileRaw = null, recZ = {}, fileZ = {}, shownMemo = null, shownSig = "";
  // A scanned plan's furniture ({id: piece}; house3d_get's scan_pieces): beside the file, never in it or in a draft.
  // Drawn only while this screen's ⋯ list has "Furniture from scans" ticked (piecesNow).
  let scanPieces = null;
  // Railings became choices (2026-11-02): after a Save of the person's own, the
  // Open edges from before get the word for what they show (stampEdgeRails).
  // True while that runs.
  let railsStamping = false;
  // Why the file cannot be edited: read but refused ({code: "read_failed"}),
  // or a newer PadSpan's ({code: "house3d_newer"}: read so, or a Save refused
  // so); null when it can. The next read that works says again.
  let fileErr = null;
  // The 3D editor (live_aboard_edit.js), made with the view; its draft, tool
  // and what is picked live here, so no rebuild touches them. shellGen moves
  // on every wall rebuild (the editor works out its walls again).
  let editor = null, shellGen = 0;
  // P8 atmosphere: the weather (live_aboard_weather.js), made only while Rain
  // and snow is on.
  let wx = null;
  // The Showcase look as drawn (live_aboard_showcase.js): Classic, today's
  // look, unless "Use the Atlas's Showcase look" is on.
  let lookKey = "classic", theme3d = LOOKS ? LOOKS.lookOf("classic") : null;
  // The same look as the Atlas (atlas_3d_look "atlas"; LOOKS.atlasLook):
  // its page, rooms, floor numbers and readouts. null: Live Aboard's own.
  let atlas = null;
  // The Studio look (live_aboard_studio.js), made only while it is picked.
  let studio = null;
  // What the house stands on as last built ({box, groundY, ground, grid}): Studio's stage goes there.
  let stageNow = null;
  // Studio could not be made on this slot (createStudio threw): the normal
  // look from then on, warned once, not tried again on every sync.
  let studioFailed = false;
  // West Coast Forest's trees (live_aboard_forest.js), made only while Live
  // Aboard follows the Atlas with that theme on; fetched the first time it does.
  let forest = null, forestFailed = false, forestDay = 0;
  // Furniture (P2 Furnish, live_aboard_furnish.js): every piece drawn on its
  // floor (layer). furnishP: what the Furnish tool needs of the host (its
  // connection, toast, settings, states), from the newest card; topCb: the
  // host's floor chips, which a piece moved up or down a floor follows.
  let layer = null, furnishP = null, topCb = null;
  let plansP = null;                                        // Add data via plans (experimental): what its tool needs of the host, or null
  // P5 (live_aboard_devices.js): what each linked piece shows, and the
  // outlines round the emergency lights while the Atlas's test runs.
  let devices = null, emOutlines = [], emKey = "";
  // P6 (live_aboard_tracked.js): scanners with a look where the map keeps
  // them; with Show tags & scanners on, every placed tag and every scanner;
  // with Show people on, people where PadSpan tracks them. peopleSnap: the
  // live snapshot as the host last handed it
  // (read through it, never more often than it says); off, none of it.
  let tracked = null, peopleSnap = null, peopleAt = 0, peopleLoad = null, peopleReads = 0;
  // Trails (people_trails.js): the last read (trailsOf's), when, the read in
  // flight, and how many reads; only while this screen has them on.
  let trailData = null, trailAt = 0, trailLoad = null, trailReads = 0;
  // live_aboard_marks.js: leak sensors and locks (marks), the code chips
  // (codes), the class chips' pick (classF), and the zoom label's callback.
  let marks = null, codes = null, classF = null, zoomCb = null, zoomShown = null;
  // live_aboard_motion.js: motion in the house (motionL) and the Motion chip.
  let motionL = null, mchip = null;
  // live_aboard_raised.js: what stands on a line, clear of the words; editing: its real height.
  let raisedL = null, raisedOff = false;
  let wetEl = null, wetRows = [], wetKey = "";           // a window open while it rains: its glow and its chip
  // live_aboard_panel.js: the home view, going back to it, Follow, the People chip.
  let panel = null;
  // live_aboard_director.js: the flight to what went off, its card, and back.
  let director = null;
  // live_aboard_show.js: the ⋯ list (showMenu); what each line is on this
  // screen (showOn, resolved on every update: this screen's ticks over the
  // house's own, showHouse); houseP: the card's data before the list hid
  // anything (what is ready is worked out from it).
  let showMenu = null, showOn = null, showHouse = {}, houseP = null;
  // scene_row.js: the scene row on the bottom bar (sceneRow), from the host's p.scenes.
  let sceneRow = null;
  // live_aboard_storey.js: each storey's floor and roof (storeyL); roofWant:
  // the roof is showing or on its way (the walls under it stand).
  let storeyL = null, roofWant = false;
  const PREF_ROOF = "roof_";
  // Furnish shows a plan beside the 3D view on a wide screen, drawn by the
  // same renderer in its own viewport; on a phone, Plan or 3D. The plan looks
  // straight down at the top floor showing.
  let furnishOn = false, planOnly = false, planCam = null, planSeg = null;
  const plan = { cx: 0, cy: 0, half: 6, fit: true };
  // The screen (the sidebar's host says mapOnly): bare, the bars stepped
  // aside (zoomed in); cover, the view over the whole panel (bare in the
  // panel, or full screen); fsOn, the panel full screen. fitR: the camera's
  // distance at the last whole-house fit (the "fit level"); soloHold: where
  // ☰ brought the bars back (zooming further in hides them again).
  let keepOff = null;                                       // full screen: the page's cards kept in sight
  let mapOnly = false, bare = false, cover = false, fsOn = false, fsTarget = null, fitR = null, soloHold = null;
  // The view about to show afresh (made, or back after Map): on the sidebar
  // (not a wall, not Furnish) its first frame steps the bars aside (openBare).
  let freshShow = true;
  let coverOff = null, coverStyle = null, panelCss = null, showCss = null, soloBtn = null, fullBtns = [], menuEl = null, menuOff = null, menuAnchor = null;
  let floorSteps = null, floorEls = [], hintCard = null, tipEl = null, narrow = false;
  // A camera kept per floor on this screen (and one for All), as the Atlas
  // keeps each floor's zoom and scroll: left on a floor, it is there again on
  // coming back (this page load only; saved Views keep theirs). floorKey: the
  // floor showing; keepCam: a piece moved a floor in Furnish, the camera stays.
  // selIds: the floor chips' choice (the floor ids at the top, null: All).
  const floorCams = new Map();
  let floorKey = null, keepCam = false, selIds = null;
  // A floor chosen with no camera kept for it, the house pulled apart or put
  // back together by it (Explode is All's): framed again once it is drawn so.
  let refitFloor = false;
  // Labels by zoom level (syncLevel): "house", "floor" or "room"; the room
  // open ({F, r, i, name, fid, r0 (the camera's distance it opened at), tx,
  // tz (where the camera's middle was last looked at)}), or null; the floor
  // tags beside the whole house ({fid -> {el, key, w, h, at}}).
  let level = "floor", levelKey = null, openRoom = null, tagsEl = null, tagsOn = false;
  const floorTags = new Map(), _fadeBg = new THREE.Color(), _tint = new THREE.Color(ROOM_TINT);
  // The rooms by name (live_aboard_rooms.js): the chips, a room's panel and the
  // Atlas's room sheet drawn in it, and a room a chip asked for whose floor is
  // still coming ({fid, name, at}).
  let roomChips = null, roomPanel = null, roomSheet = null, roomGo = null;
  // Views ▾ → Look: which part of the day the list picks for (by the sun: "day" or "night").
  let lookFor = "day";
  // The map alone: the floor's name, faint in a corner for a moment.
  let cornerEl = null, cornerOn = false;
  // The live read's own clock (Show people, Show tags & scanners): see peopleClock.
  let peopleTimer = null;
  // What this browser keeps for the view (its saved views, the first-time
  // card seen): the host's {get(k), set(k, v)}; without one, this page load's.
  let prefs = null;
  const prefsHere = new Map();
  const prefGet = (k) => { try { return prefs ? prefs.get(k) : prefsHere.get(k) ?? null; } catch (_) { return null; } };
  const prefSet = (k, v) => { try { if (prefs) prefs.set(k, v); else prefsHere.set(k, v); } catch (_) { /* kept for this page load only */ } };
  // A tap on nothing (for double-tap: fly to the room); a camera flight.
  let tapAt = null;
  // Readable night: how dark it is now (0 day, 1 night), and the wall tops' glow.
  let nightK = 0;
  let wakeUntil = 0, wakeK = 0, nightReal = 0;   // "Rooms as light switches": the house lit up by a touch (wake)
  const topGlow = { value: 0 };

  // ── failing back to the flat Atlas ────────────────────────────────────────
  function showFlat(){
    try { if (stage) stage.style.display = ""; } catch (_) { /* gone with its card */ }
    stage = null;
    try { if (root && root.parentNode) root.parentNode.removeChild(root); } catch (_) { /* already out */ }
  }
  function teardown(){
    rawP = null;                                             // the Plans tool closing with the view has nothing to draw again
    try { endSpin(false); hidePill(); dropPointers(); endScreen(); } catch (_) { /* nothing to undo */ }
    try { if (use) use.dispose(); } catch (_) { /* gone with the view */ }
    use = null;
    try { if (editor) editor.dispose(); } catch (_) { /* gone with the view */ }
    editor = null;
    try { if (devices) devices.dispose(); } catch (_) { /* gone with the view */ }
    devices = null; emOutlines = []; emKey = "";
    try { if (tracked) tracked.dispose(); } catch (_) { /* gone with the view */ }
    tracked = null; peopleSnap = null; peopleAt = 0; peopleLoad = null;
    trailData = null; trailAt = 0; trailLoad = null;
    try { if (marks) marks.dispose(); if (codes) codes.dispose(); } catch (_) { /* gone with the view */ }
    marks = null; codes = null; zoomCb = null;
    try { if (raisedL) raisedL.dispose(); } catch (_) { /* gone with the view */ }
    raisedL = null;
    try { if (motionL) motionL.dispose(); if (mchip) mchip.dispose(); } catch (_) { /* gone with the view */ }
    try { if (storeyL) storeyL.dispose(); } catch (_) { /* gone with the view */ }
    try { if (plumb) { plumb.dispose(); plumb = null; } } catch (_) { /* gone with the view */ }
    storeyL = null; roofWant = false;
    motionL = null; mchip = null;
    try { if (panel) panel.dispose(); } catch (_) { /* gone with the view */ }
    panel = null;
    try { if (director) director.dispose(); } catch (_) { /* gone with the view */ }
    director = null;
    try { if (showMenu) showMenu.dispose(); } catch (_) { /* gone with the view */ }
    showMenu = null; showOn = null; houseP = null;
    try { closeRoomPanel(); if (roomChips) roomChips.dispose(); } catch (_) { /* gone with the view */ }
    roomChips = null; roomPanel = null; roomSheet = null; roomGo = null;
    try { if (sceneRow) sceneRow.dispose(); } catch (_) { /* gone with the view */ }
    sceneRow = null;
    try { if (fpsUi) fpsUi.dispose(); } catch (_) { /* gone with the view */ }
    fpsUi = null;
    if (peopleTimer !== null) { clearTimeout(peopleTimer); peopleTimer = null; }
    try { if (layer) layer.dispose(); } catch (_) { /* gone with the view */ }
    layer = null; furnishP = null; topCb = null; plansP = null;
    for (const o of observers) { try { o(); } catch (_) { /* gone */ } }
    observers = [];
    disposeList(shellRes); disposeList(lightRes); disposeList(sensorRes);
    shellRes = []; lightRes = []; sensorRes = [];
    // three.js gives every sprite (a readout, a room's name) one geometry for
    // the whole page, and each renderer that drew one hangs a listener on it
    // that renderer.dispose() never takes off: that listener would keep this
    // whole view alive (the renderer, the canvas, this element, the scene and
    // the host's data) after every switch-off. Disposing it takes every such
    // listener off; another view still drawing sprites only uploads it again.
    try { if (scene) scene.traverse((o) => { if (o.isSprite && o.geometry) o.geometry.dispose(); }); } catch (_) { /* best effort */ }
    try { if (wx) wx.dispose(); } catch (_) { /* gone with the scene */ }
    wx = null;
    try { if (studio) studio.dispose(); } catch (_) { /* gone with the scene */ }
    studio = null;
    try { if (forest) forest.dispose(); } catch (_) { /* gone with the scene */ }
    forest = null;
    // Give the GPU its context back: the flat Atlas needs none.
    try { if (renderer) { renderer.dispose(); if (failed !== "context_lost") renderer.forceContextLoss(); } } catch (_) { /* best effort */ }
    renderer = null; scene = null; house = null; floorsUi = []; lights = []; stageNow = null;
    openRoom = null; levelKey = null; level = "floor"; floorTags.clear(); tagsEl = null; tagsOn = false; glassPick = null;
    openings = []; sensorsUi = []; tints = []; readouts = []; chips = []; heats = []; liveMs = 0;
    wetEl = null; wetRows = []; wetKey = "";
    // Nothing of the host's is kept: its card, its data, its callbacks.
    lastP = null; apiOf = null; apiNow = null; lbe = {}; stage = null; send = null; touchCb = null; saveNorthCb = null;
  }
  function fail(kind){
    if (failed) return;
    failed = HOUSE3D_FALLBACK_KINDS.includes(kind) ? kind : "error";
    HOUSE.countHouse3dOnce(`house3d_fallback:${failed}`, send);
    // And how big the house is (telemetry.HOUSE_SIZE_BANDS), so a slow screen
    // can be told from a very big house in the report.
    const nRooms = Object.keys((lastP && lastP.model && lastP.model.room_geometry_m) || {}).length;
    HOUSE.countHouse3dOnce(`house3d_fallback_size:${nRooms < 20 ? "lt20" : nRooms < 60 ? "20_60" : nRooms < 150 ? "60_150" : "gt150"}`, send);
    showFlat();
    teardown();
  }
  const guard = (fn) => function(...a){ try { return fn.apply(this, a); } catch (_) { fail("error"); return undefined; } };
  function disposeList(list){
    for (const r of list || []) { try { r.dispose(); } catch (_) { /* best effort */ } }
  }

  // ── start: WebGL or nothing ───────────────────────────────────────────────
  function buildRoot(){
    const d = (tag, cls) => { const n = document.createElement(tag); if (cls) n.className = cls; return n; };
    root = d("div", "la3d");
    root.setAttribute("data-la3d", slotKey);
    const style = d("style");
    style.textContent = CSS + (FPS ? FPS.FPS_CSS : "");
    root.appendChild(style);
    bar = d("div", "la3d-bar");
    const seg = (label, items) => {
      const s = d("span", "lv-zoomseg");
      if (label) { const l = d("span", "la3d-lbl"); l.textContent = label; s.appendChild(l); }
      for (const [text, title, act] of items) {
        const b = d("button");
        b.type = "button"; b.textContent = text; b.title = title;
        b.addEventListener("click", guard((e) => { e.stopPropagation(); act(); }));
        s.appendChild(b);
      }
      return s;
    };
    const WALLS = [["Cut", "Cut away the walls between you and the rooms", "cut"], ["Up", "All walls up", "up"], ["Down", "All walls down", "down"],
                   ["Glass", "See-through glass walls between you and the rooms", "glass"]];
    const ANGLES = [["Iso", "The Atlas's angle", "iso"], ["Top", "Straight down", "top"], ["⟳ 90°", "Turn the house a quarter", "turn"],
                    ["Fit", "Fit the floors that are showing", "fit"]];
    const walls = seg("Walls", WALLS.map(([t, title, m]) => [t, title, () => setWalls(m, true)]));
    walls.setAttribute("data-la3d-walls", "");
    walls.classList.add("la3d-w");
    // The roof: shown from outside (Auto) or never (Off); on a narrow screen, in Walls ▾.
    const ROOF = [["Roof: Auto", "The roof shows when you look at the house from outside", "auto"], ["Roof: Off", "Never show the roof", "off"]];
    if (STOREY) {
      const rb = seg(null, [["Roof", "The roof: shown from outside (Auto) or never (Off)", () => setRoof(roofPick() === "off" ? "auto" : "off")]]);
      rb.querySelector("button").setAttribute("data-la3d-roof", "");
      walls.appendChild(rb.querySelector("button"));
    }
    const views = seg(null, ANGLES.map(([t, title, n]) => [t, title, () => preset(n, true)]));
    views.setAttribute("data-la3d-views", "");
    views.classList.add("la3d-w");
    // The floor stepper: ▲ the floor above, its name (a tap: the floor's
    // sheet), ▼ the floor below, All. It drives the floor chips' choice.
    const floor = seg(null, [["▲", "The floor above", () => stepFloor(1)], ["", "", () => openFloorSheet()],
                             ["▼", "The floor below", () => stepFloor(-1)], ["All", "Every floor", () => stepFloor(0)],
                             ["⇕", "Explode: pull the floors apart to see each one", () => toggleExplode()]]);
    floor.classList.add("la3d-floor");
    floor.setAttribute("data-la3d-floor", "");
    floor.setAttribute("aria-label", "Floor");
    floorEls = [...floor.querySelectorAll("button")];
    if (floorEls[1]) floorEls[1].classList.add("la3d-fname");
    if (floorEls[3]) floorEls[3].classList.add("la3d-w");           // narrow: All is in View ▾
    if (floorEls[4]) floorEls[4].classList.add("la3d-w");
    floor.style.display = "none";
    // Views: every floor (to go straight to one), the whole house, and views
    // saved from the camera on this browser.
    const vbtn = seg(null, [["Views ▾", "A floor, the whole house, or a view you saved",
      () => openMenu(vbtn, [...floorItems(), ...(floorSteps ? [null] : []), ...viewItems(false)])]]);
    vbtn.classList.add("la3d-w");
    vbtn.setAttribute("data-la3d-saved", "");
    // A narrow screen: one row — Walls ▾, View ▾, the floor stepper, full screen.
    const wbtn = seg(null, [["Walls ▾", "Cut, Up, Down or Glass, and the roof", () => openMenu(wbtn, [
      ...WALLS.map(([t, , m]) => ({ text: t, on: wallMode === m, act: () => setWalls(m, true) })),
      ...(STOREY ? [null, ...ROOF.map(([t, title, v]) => ({ text: t, title, on: roofPick() === v, act: () => setRoof(v) }))] : [])])]]);
    wbtn.classList.add("la3d-n");
    const abtn = seg(null, [["View ▾", "Angles, the floors, the whole house and your views", () => openMenu(abtn, [
      ...ANGLES.map(([t, , n]) => ({ text: t, act: () => preset(n, true) })),
      ...(floorSteps ? [null, ...floorItems()] : []), null, ...viewItems()])]]);
    abtn.classList.add("la3d-n");
    abtn.setAttribute("data-la3d-view", "");
    const full = seg(null, [["", "", () => toggleFull()]]);
    full.setAttribute("data-la3d-full", "");
    fullBtns = [...full.querySelectorAll("button")];
    full.style.display = "none";
    const left = d("span", "la3d-side"), right = d("span", "la3d-side");
    left.append(walls, wbtn, abtn, floor);
    right.append(views, vbtn, full);
    bar.append(left, right);
    // Furnish on a narrow screen: the plan or the 3D view (a wide one shows both).
    planSeg = seg(null, [["3D", "The house in 3D", () => setPlanOnly(false)], ["Plan", "Straight down on the floor showing", () => setPlanOnly(true)]]);
    planSeg.setAttribute("data-la3d-plan", "");
    planSeg.style.display = "none";
    left.appendChild(planSeg);
    // The scene row: its own line along the top of the bar, over the controls.
    if (SCENES) {
      sceneRow = SCENES.createSceneRow({ doc: document, place: "aboard", guard });
      bar.insertBefore(sceneRow.el, bar.firstChild);
    }
    root.appendChild(bar);
    // The map alone: one small button brings the bars back.
    soloBtn = d("button", "la3d-solo");
    soloBtn.type = "button"; soloBtn.textContent = "☰";
    soloBtn.title = "Show the controls";
    soloBtn.setAttribute("aria-label", "Show the controls");
    soloBtn.setAttribute("data-la3d-solo", "");
    soloBtn.addEventListener("click", guard((e) => { e.stopPropagation(); setBare(false, true); }));
    root.appendChild(soloBtn);
    // The map alone: the floor's name (and what is on there), faint in a
    // corner for 2 s after a floor change or a touch (a CSS fade, no timer);
    // a tap on it while it shows lists the floors.
    cornerEl = d("button", "la3d-corner");
    cornerEl.type = "button";
    cornerEl.setAttribute("data-la3d-corner", "");
    cornerEl.addEventListener("click", guard((e) => { e.stopPropagation(); if (cornerOn && bare) openFloorList(cornerEl); }));
    cornerEl.addEventListener("animationend", guard(() => { cornerOn = false; cornerEl.classList.remove("on"); }));
    root.appendChild(cornerEl);
    // The whole house's floor tags (labels by zoom level), under the bars and menus.
    tagsEl = d("div", "la3d-ftags");
    tagsEl.setAttribute("data-la3d-ftags", "");
    tagsEl.style.display = "none";
    root.appendChild(tagsEl);
    // The room chips along the top (a narrow screen and a wall: one Rooms ▾), and a room's panel.
    if (ROOMS) {
      roomChips = ROOMS.createRoomChips({ root, guard, groups: () => chipGroups(), compact: () => narrow || wallScreen(),
        go: (c) => goRoom(c.fid, c.top, c.name), list: (anchor, items) => openMenu(anchor, items),
        current: () => (openRoom ? `${openRoom.fid}|${openRoom.name}` : null) });
      roomPanel = ROOMS.createRoomPanel({ root, guard, moreInfo: (eid) => USE.moreInfo(root, eid),
        onClose: () => { const s = roomSheet; roomSheet = null; if (s) s.close(); } });
    }
    tipEl = d("div", "la3d-tip");
    tipEl.textContent = "Drag to turn · pinch or wheel to zoom · tap a light · hold for controls · double-tap a room to go there";
    root.appendChild(tipEl);
    mchip = MOTION ? MOTION.createMotionChip({ root, fly: (eid) => findDevice(eid) }) : null;
    // A window open while it rains: one line under the Motion chip; a tap flies there.
    const wetCss = d("style");
    wetCss.textContent = WET_CSS;
    wetEl = d("button", "la3d-wet");
    wetEl.type = "button";
    wetEl.addEventListener("click", guard((e) => { e.stopPropagation(); if (wetRows[0]) flyToOpening(wetRows[0]); }));
    root.append(wetCss, wetEl);
    showCss = d("style");
    showCss.textContent = CSS_SHOWING;
    root.appendChild(showCss);
    panelCss = d("style");
    root.appendChild(panelCss);
    coverStyle = d("style");
    root.appendChild(coverStyle);
    // The compass: N is true north (settings.fabric_bearing_deg), and it
    // turns with the camera. A tap turns the house to north up.
    const compass = d("button", "la3d-compass");
    compass.type = "button";
    compass.title = "North up";
    compass.setAttribute("aria-label", "Compass: turn the view to north up");
    compass.innerHTML = '<svg viewBox="-26 -26 52 52" aria-hidden="true">'
      + '<circle r="23" fill="none" stroke="rgba(226,240,232,.18)" stroke-width="1.2"/>'
      + '<g class="la3d-rose"><path d="M0,-15 L4.6,0 L-4.6,0 Z" fill="#ef5350"/><path d="M0,15 L4.6,0 L-4.6,0 Z" fill="#cfd8d3"/>'
      + '<text x="0" y="-16.5" text-anchor="middle" font-size="8.5" font-weight="700" fill="#f3f6f4" '
      + 'font-family="system-ui,sans-serif">N</text></g></svg>';
    compass.addEventListener("pointerdown", guard((e) => spinDown(e)));
    compass.addEventListener("contextmenu", (e) => e.preventDefault());
    // Enter or Space on the focused compass (a click with no pointer behind
    // it): north up, like a tap. A pointer's own click is the spin's to decide.
    compass.addEventListener("click", guard((e) => {
      e.stopPropagation();
      if (e.detail !== 0) return;
      cam.moved = true; cam.needsFit = false;
      turnBy(HOUSE.northUpTheta(bearingNow()) - cam.theta);
      cam.theta = HOUSE.northUpTheta(bearingNow());
      applyCam();
    }));
    root.appendChild(compass);
    compassEl = compass;
    rose = compass.querySelector(".la3d-rose");
    // ⋯ beside it: what this screen shows (live_aboard_show.js).
    if (SHOW) showMenu = makeShowMenu();
    // Shown on release of a spin: nothing is saved until Save.
    pill = d("span", "lv-zoomseg la3d-north");
    pill.setAttribute("role", "group");
    pill.setAttribute("aria-label", "North");
    pillBtns = [["Save north", "Keep north where the needle points", () => saveNorth()],
                ["Cancel", "Put north back", () => cancelNorth()]].map(([text, title, act]) => {
      const b = d("button");
      b.type = "button"; b.textContent = text; b.title = title;
      b.addEventListener("click", guard((e) => { e.stopPropagation(); act(); }));
      pill.appendChild(b);
      return b;
    });
    root.appendChild(pill);
    paintWallButtons();
  }
  function paintWallButtons(){
    if (!bar) return;
    const btns = bar.querySelectorAll("[data-la3d-walls] button");
    HOUSE.WALL_MODES.forEach((m, i) => { if (btns[i]) btns[i].setAttribute("aria-pressed", String(wallMode === m)); });
    const rb = bar.querySelector("[data-la3d-roof]");
    if (rb) rb.setAttribute("aria-pressed", String(roofPick() !== "off"));
  }

  // ── the screen: the map alone, full screen (the sidebar) ──────────────────
  // Zoomed in past the whole-house fit, every bar steps aside — the view's
  // own and the panel's (header, rail, legend, chips, the light index) —
  // and the view covers the panel; ☰, Escape or zooming back out to the fit
  // brings them back. Full screen takes the panel's own element (it outlives
  // every card the poll builds), so Home Assistant's sidebar goes too, and
  // Escape leaves it; a screen that may not go full screen gets the map alone
  // in the panel instead. Only where the host says so (mapOnly: the sidebar).
  /** The panel's element: the host of the shadow root the view is in. */
  function hostEl(){ return SCREEN.panelHostOf(root); }
  /** The panel's box, to the window's right and bottom (the whole screen while full screen). */
  function coverRect(){ return SCREEN.coverRect(hostEl(), fsOn); }
  function layCover(){
    if (!cover) return;
    const c = coverRect();
    Object.assign(root.style, { left: `${c.left}px`, top: `${c.top}px`, width: `${c.width}px`, height: `${c.height}px` });
    const rn = root.getRootNode ? root.getRootNode() : null, scope = rn && rn.querySelector ? rn : document;
    const vac = menuOpen() ? scope.querySelector(".lv-mapcard > .lv-vacation") : null;
    if (coverStyle) coverStyle.textContent = coverCss(c, !!scope.querySelector(".lv-emerg"), vac ? cutOut(vac, root.querySelectorAll(".la3d-show, .la3d-menu")) : null);
  }
  /** `el`'s clip-path with each of `over`'s boxes cut out of it (even-odd), or null when none overlaps it. */
  function cutOut(el, over){
    const b = el.getBoundingClientRect(), px = (v) => `${Math.round(v)}px`;
    const holes = [...over].map(n => n.getBoundingClientRect())
      .filter(r => r.width > 0 && r.left < b.right && r.right > b.left && r.top < b.bottom && r.bottom > b.top)
      .map(r => { const x0 = px(r.left - b.left), y0 = px(r.top - b.top), x1 = px(r.right - b.left), y1 = px(r.bottom - b.top);
                  return `, ${x0} ${y0}, ${x1} ${y0}, ${x1} ${y1}, ${x0} ${y1}, ${x0} ${y0}, 0 0`; });
    return holes.length ? `polygon(evenodd, 0 0, 100% 0, 100% 100%, 0 100%, 0 0${holes.join("")})` : null;
  }
  const COVER_KEYS = ["position", "margin", "borderRadius", "border", "zIndex", "maxWidth", "left", "top", "width", "height",
                      "translate"];   // a wall's burn-in shift moves the full screen; back in the card, the card's own does
  function paintCover(){
    const want = !!(root && mapOnly && (bare || fsOn));
    if (want === cover) { layCover(); return; }
    cover = want;
    if (want) {
      // Out of the card, to the top of the panel's own tree: the poll's new
      // cards never move it, and nothing of the card stacks over it.
      const r0 = root.getBoundingClientRect(), rn = root.getRootNode ? root.getRootNode() : null;
      const home = rn && rn.host ? rn : document.body;
      if (home && root.parentNode !== home) home.appendChild(root);
      root.classList.remove("la3d-cover");
      Object.assign(root.style, { position: "fixed", margin: "0", borderRadius: "0", border: "none", zIndex: String(COVER_Z), maxWidth: "none",
                                  left: `${r0.left}px`, top: `${r0.top}px`, width: `${r0.width}px`, height: `${r0.height}px` });
      void root.offsetWidth;                                 // grown from where it was
      root.classList.add("la3d-cover");
      layCover();
      const onResize = guard(() => layCover());
      const onKey = guard((e) => { if (e.key === "Escape" && bare && !fsOn) setBare(false, true); });
      window.addEventListener("resize", onResize);
      window.addEventListener("keydown", onKey);
      const h = hostEl();
      let ro = null;
      if (h && typeof ResizeObserver !== "undefined") { ro = new ResizeObserver(onResize); ro.observe(h); }
      coverOff = () => { window.removeEventListener("resize", onResize); window.removeEventListener("keydown", onKey); if (ro) ro.disconnect(); };
    } else {
      if (coverOff) coverOff();
      coverOff = null;
      if (coverStyle) coverStyle.textContent = "";
      root.classList.remove("la3d-cover");
      for (const k of COVER_KEYS) root.style[k] = "";
      if (stage && stage.parentNode) stage.parentNode.insertBefore(root, stage.nextSibling);   // back beside the newest card's stage
    }
    resize();
  }
  /** The bars away (the map alone) or back. byHand: ☰ or Escape, so the
   *  same zoom does not hide them again at once. */
  function setBare(on, byHand){
    const want = !!(on && mapOnly && root);
    if (want === bare) return;
    bare = want;
    if (!want && byHand) soloHold = cam.radius;
    if (!want) { cornerOn = false; if (cornerEl) cornerEl.classList.remove("on"); }
    closeMenu();
    root.classList.toggle("la3d-bare", want);
    paintCover();
  }
  /** The sidebar's 3D opens with the bars aside, so the house fills the
   *  window from the first frame (☰, Escape or zooming out brings them back):
   *  once a showing, on its first frame drawn inside the panel. Not on a wall
   *  (its page has no bars; its own carry the scene row), nor in Furnish or Edit. */
  function openBare(){
    if (!root || !hostEl() || !((canvas && canvas.clientWidth) > 0)) return;   // not in the panel yet: the next frame
    freshShow = false;
    if (mapOnly && !wallScreen() && !furnishOn && !(editor && editor.active)) setBare(true, false);
  }
  /** After a zoom by hand (the wheel, a pinch, a double-tap): in past the
   *  fit level, the map alone; back out to it, the bars. */
  function afterZoom(inward){
    if (inward) roomByZoom();                                // in to room scale: the room in the middle opens
    if (!mapOnly || !fitR || furnishOn || (editor && editor.active)) return;
    const s = SCREEN.soloStep({ at: cam.radius, fit: fitR, bare, hold: soloHold, inward });
    soloHold = s.hold;
    if (s.bare !== bare) setBare(s.bare, false);
  }
  function canFull(){ return SCREEN.canFull(hostEl()); }
  function toggleFull(){
    closeMenu();
    if (fsOn) { leaveFull(); return; }
    if (!canFull()) { setBare(true, false); return; }        // not allowed here (a kiosk): the map alone in the panel
    const h = hostEl();
    fsTarget = h;
    SCREEN.askFull(h, guard(() => { fsTarget = null; if (!fsOn) setBare(true, false); }));
  }
  function leaveFull(){
    if (fsOn) SCREEN.leaveFull();
  }
  function onFullChange(){
    const now = SCREEN.isFullOf(fsTarget);
    if (now === fsOn) return;
    fsOn = now;
    // In, cards and sheets the page opens stay in sight (SCREEN.keepOverlaysIn).
    if (now) keepOff = SCREEN.keepOverlaysIn(fsTarget);
    else if (keepOff) { keepOff(); keepOff = null; }
    // Left (Escape, or the browser's own way out): everything back.
    if (!now) { fsTarget = null; if (bare) { bare = false; root.classList.remove("la3d-bare"); } }
    paintCover();
    paintFull();
  }
  function paintFull(){
    const seg = fullBtns[0] && fullBtns[0].parentNode;
    if (seg) seg.style.display = mapOnly ? "" : "none";
    const b = fullBtns[0];
    if (!b) return;
    const t = SCREEN.fullLabel(fsOn, canFull());
    b.title = t;
    b.setAttribute("aria-label", t);
    b.setAttribute("aria-pressed", String(fsOn));
    b.innerHTML = SCREEN.fullIconSvg(fsOn);
  }
  /** Out of the screen's ways (the view leaves, or is switched off). */
  function endScreen(){
    closeMenu();
    if (bare) { bare = false; if (root) root.classList.remove("la3d-bare"); }
    leaveFull();
    fsOn = false; fsTarget = null; soloHold = null;
    paintCover();
  }

  // ── the floor stepper: ▲ Main ▼ · All ─────────────────────────────────────
  // The host's floor chips, from the view: {names (lowest first), zs (each
  // one's storey, for its sheet), at (the top floor showing), all (every
  // floor), go(i) (i < 0: All), counts ([{on, motion}] per floor: the floor
  // chips' own numbers, lights and fans on and motion)}.
  function stepsOf(fs){
    if (!fs || !Array.isArray(fs.names) || fs.names.length < 2 || typeof fs.go !== "function") return null;
    const n = fs.names.length, at = Math.max(0, Math.min(n - 1, Math.round(Number(fs.at)) || 0));
    const counts = Array.isArray(fs.counts) && fs.counts.length === n
      ? fs.counts.map(c => ({ on: Math.max(0, Math.round(Number(c && c.on)) || 0), motion: Math.max(0, Math.round(Number(c && c.motion)) || 0) })) : null;
    return { names: fs.names.map(String), zs: Array.isArray(fs.zs) ? fs.zs : null, at, all: fs.all === true, go: fs.go, counts };
  }
  /** A floor's activity as the floor chips show it: how many are on, in a
   *  dot that turns blue with motion; nothing at all when all is quiet. */
  function dotOf(c){
    if (!c || !(c.on || c.motion)) return null;
    const s = document.createElement("span");
    s.className = "lv-dot" + (c.motion ? " motion" : "");
    s.textContent = c.on ? String(c.on) : "";
    return s;
  }
  const activityText = (c) => (c && (c.on || c.motion) ? `${c.on} on${c.motion ? ` · ${c.motion} motion` : ""}` : "nothing on");
  /** The floor's name and its dot, into `el` (the stepper's name, the corner). */
  function nameInto(el, s, i){
    const t = document.createElement("span");
    t.className = "la3d-fn";
    t.textContent = s.all && i === null ? "All floors" : s.names[i] || "";
    const dot = i === null ? null : dotOf(s.counts && s.counts[i]);
    const fb = i === null ? null : badgeOf(i);
    el.replaceChildren(...(fb ? [fb] : []), ...(dot ? [t, dot] : [t]));
  }
  /** The Atlas's number for a floor (its plate's badge: 1 at the bottom, in
   *  the plate's colour), with the Atlas's look. */
  function badgeOf(i){
    if (!atlas || !Number.isInteger(i) || i < 0) return null;
    const b = document.createElement("span");
    b.className = "la3d-fb";
    b.textContent = String(i + 1);
    b.style.background = HOUSE.LAYER_PAL[i % HOUSE.LAYER_PAL.length];
    b.setAttribute("aria-hidden", "true");
    return b;
  }
  function paintFloors(){
    const s = floorSteps, seg = floorEls[0] && floorEls[0].parentNode;
    if (seg) seg.style.display = s ? "" : "none";
    if (!s) return;
    const [up, name, down, all, xp] = floorEls, n = s.names.length;
    if (xp) { xp.style.display = s.all && n > 1 ? "" : "none"; xp.setAttribute("aria-pressed", String(!!explodeGap())); }
    up.disabled = s.at >= n - 1;
    down.disabled = s.at <= 0;
    nameInto(name, s, s.at);
    name.title = `${s.names[s.at] || ""}: everything on this floor${s.counts ? ` (${activityText(s.counts[s.at])})` : ""}`;
    all.setAttribute("aria-pressed", String(!!s.all));
    name.setAttribute("aria-pressed", String(!s.all));
  }
  /** Every floor with its activity, and All: to go straight to one (Views ▾,
   *  View ▾ on a narrow screen, the corner's list). Each acts on the floors
   *  as they are when tapped. */
  function floorItems(){
    const s = floorSteps;
    if (!s) return [];
    return [{ text: "All floors", on: s.all, act: () => stepFloor(0) },
            ...s.names.map((name, i) => ({ text: name, on: !s.all && s.at === i, dot: s.counts ? s.counts[i] : null, badge: i,
                                           title: s.counts ? `${name}: ${activityText(s.counts[i])}` : name,
                                           act: () => { const q = floorSteps; if (q && i < q.names.length && (q.all || i !== q.at)) q.go(i); } })),
            // ⇕ is hidden on a narrow screen: Explode is here too.
            ...(s.all && s.names.length > 1 ? [{ text: "⇕ Explode", on: !!explodeGap(), act: () => toggleExplode() }] : [])];
  }
  /** The floors listed over `anchor`; with the map alone too (the corner's). */
  function openFloorList(anchor){
    openMenu(anchor, floorItems());
    if (menuEl) menuEl.classList.add("la3d-keep");
  }
  /** The floor showing changed (the chips, the stepper, a menu, a key): the
   *  camera as left is kept for the floor left, the one kept for the floor
   *  now showing comes back (none kept yet: it stays where it is), and with
   *  the map alone the floor's name shows in the corner. */
  function followFloor(){
    // Kept by the floor's name, not its level: a floor deleted renumbers the levels.
    const s = floorSteps, key = s ? (s.all ? "all" : `floor:${s.names[s.at]}`) : null;
    if (key === floorKey) return;
    const was = floorKey;
    floorKey = key;
    if (roomGo) roomGo.wait = false;                       // a chip's room: its floor is here
    if (was === null || key === null) return;
    if (panel) panel.floorChanged();
    // Not yet framed (the floor the host picked as the view opened): there
    // is no view of that floor to keep, only the camera's starting values.
    if (!cam.needsFit) floorCams.set(was, { theta: cam.theta, phi: cam.phi, radius: cam.radius, target: cam.target.toArray() });
    const c = keepCam ? null : floorCams.get(key);
    refitFloor = !c && !keepCam;
    closeRoom();                                           // a room open on the floor left closes
    if (c) {
      cam.fly = null; cam.moved = true; cam.needsFit = false;
      cam.theta = c.theta; cam.phi = c.phi; cam.radius = c.radius; cam.target.fromArray(c.target);
      applyCam();
      afterZoom(false);                                    // zoomed back out, with the map alone: the bars come back
    }
    flashCorner();
  }
  /** The map alone: the floor's name in the corner, fading out over 2 s. */
  function flashCorner(){
    const s = floorSteps;
    if (!cornerEl || !bare || !s) return;
    nameInto(cornerEl, s, s.all ? null : s.at);
    cornerEl.title = s.all ? "All floors: tap for the list" : `${s.names[s.at]}${s.counts ? `, ${activityText(s.counts[s.at])}` : ""}: tap for the list`;
    cornerEl.classList.remove("on");
    void cornerEl.offsetWidth;                               // the fade starts again
    cornerEl.classList.add("on");
    cornerOn = true;
  }
  function stepFloor(d){
    const s = floorSteps;
    if (!s) return;
    if (!d) { if (!s.all) s.go(-1); return; }
    const i = s.at + d;
    if (i >= 0 && i < s.names.length && (i !== s.at || s.all)) s.go(i);
  }
  /** A wall screen (?kiosk=1, or the page says it is a wall). */
  const wallScreen = () => !!(lastP && lastP.kiosk === true) || onWallPage(root);
  /** Explode as this screen has it: as this browser set it, else on for the
   *  sidebar (not a wall) and off anywhere else. */
  function explodeOn(){
    const v = prefGet(PREF_EXPLODE);
    return v === "1" || (v !== "0" && mapOnly && !wallScreen());
  }
  /** How far Explode lifts each storey now (m): only with All picked and more than one floor. */
  function explodeGap(){
    const s = floorSteps;
    return explodeOn() && s && s.all && s.names.length > 1 ? EXPLODE_M : 0;
  }
  function toggleExplode(){
    prefSet(PREF_EXPLODE, explodeOn() ? "0" : "1");
    redraw();
    paintFloors();
    wholeHouse();
  }
  // ── a window open while it rains or snows (as neonplan3d warns) ───────────
  /** Wet now, by the flat Atlas's own decision (rain sensor, else the weather
   *  condition), whether or not the rain is drawn. No weather set up: dry. */
  function wetNow(p){
    const w = p && p.weather && p.weather.settings ? p.weather : null;
    if (!w || !AW) return false;
    try { return AW.decideAtlasWeather(AW.weatherSettingsFrom(w.settings), w.states || {}, w.entities, Date.now()).kind !== "off"; }
    catch (_) { return false; }
  }
  function paintWet(p){
    const wet = wetNow(p), rows = [];
    for (const { F, P } of openings) {
      const o = P.open, e = o.leaf, on = wet && o.kind === "window" && o.state === "open" && !!e;
      o.wetOn = on;
      if (on) {
        if (!o.wet) { o.wet = new THREE.Mesh(shared.glassBox, shared.wetMat); o.wet.matrixAutoUpdate = false; o.wet.renderOrder = 4; F.group.add(o.wet); }
        placeWet(F, P, !!P.cut);
        const dl = lbe[o.eid];
        rows.push({ F, P, name: String((dl && dl.friendly_name) || (o.bar && o.bar.name) || "A window") });
      } else if (o.wet) { o.wet.matrix.copy(ZERO); o.wet.matrixWorldNeedsUpdate = true; }
    }
    wetRows = rows;
    if (rows.length) HOUSE.countHouse3dOnce("house3d_wet_window", send);
    const text = rows.length ? `${WET_WORD} · ${rows[0].name}${rows.length > 1 ? ` and ${rows.length - 1} more` : ""}` : "";
    if (wetEl && text !== wetKey) {
      wetKey = text;
      wetEl.textContent = text;
      wetEl.title = rows.map(r => r.name).join(", ");
      wetEl.classList.toggle("on", !!text);
      requestRender();
    }
  }
  /** An open window's rain glow over its pane as the wall stands now: cut
   *  down with the wall (placePiece calls this as the camera turns), gone
   *  where the cut leaves no pane. */
  function placeWet(F, P, cut){
    const o = P.open, e = o && o.leaf;
    if (!o || !o.wet || !o.wetOn || !e) return;
    const z1 = cut && e.cuttable ? Math.min(e.z1, HOUSE.CUT_H) : e.z1, hgt = z1 - e.z0;
    o.wet.matrix.copy(hgt < 0.005 || goneHere(P, e) ? ZERO : compose(P.mx, F.fl.elev + e.z0 - 0.02, P.my, P.yaw, P.len + 0.08, hgt + 0.05, e.thick + 0.08));
    o.wet.matrixWorldNeedsUpdate = true;
  }
  /** Fly to a wet window: its floor shown, framed with a little of the room. */
  function flyToOpening(r){
    if (!renderer || failed || !camera) return;
    if (!r.F.group.visible && lastP && typeof lastP.setTopFloor === "function") lastP.setTopFloor(r.F.fl.id);
    const F = r.F, x = r.P.mx, y = r.P.my, pts = [];
    for (const dx of [-2.5, 2.5]) for (const dy of [-2.5, 2.5]) pts.push(new THREE.Vector3(x + dx, F.fl.elev, y + dy), new THREE.Vector3(x + dx, F.fl.elev + 1.6, y + dy));
    const g = frameFor(cam.theta, Math.max(0.35, Math.min(cam.phi, 1.05)), pts);
    g.radius = Math.max(MIN_R, g.radius);
    flyTo(g, false);
  }
  /** A tap on the floor's name: its sheet, as the Atlas's floor badge opens it. */
  function openFloorSheet(){
    const s = floorSteps, a = apiNow || (apiOf ? (apiNow = apiOf()) : null);
    if (s && a && typeof a.openFloor === "function" && s.zs && s.zs[s.at] !== undefined) a.openFloor(s.zs[s.at]);
  }

  // ── Views: the whole house, and views saved on this browser ───────────────
  function readViews(){
    try {
      const v = JSON.parse(prefGet(PREF_VIEWS + slotKey) || "[]");
      return Array.isArray(v) ? v.filter(x => x && typeof x.name === "string" && Array.isArray(x.target) && x.target.length === 3
        && [x.theta, x.phi, x.radius, ...x.target].every(Number.isFinite)).slice(-VIEWS_MAX) : [];
    } catch (_) { return []; }
  }
  function writeViews(v){ prefSet(PREF_VIEWS + slotKey, JSON.stringify(v.slice(-VIEWS_MAX))); }
  function viewItems(){
    const saved = readViews();
    return [{ text: "Whole house", act: () => wholeHouse() }, { text: "How it works", act: () => showHint(true) },
            ...saved.map((v, i) => ({ text: v.name, act: () => goView(v), del: () => { saved.splice(i, 1); writeViews(saved); } })),
            { text: "Save this view", act: () => saveView() },
            ...(trailsOffered() ? [{ text: `Trails, last 30 min: ${prefGet(PREF_TRAILS) === "1" ? "On" : "Off"}`, on: prefGet(PREF_TRAILS) === "1",
                                     title: "Where each person and tag went in the last half hour (this screen only)", act: () => toggleTrails() }] : []),
            ...(LOOKPICK && !furnishOn ? [{ text: `Look: ${lookWords()} ›`, data: "la3d-look",
                                            title: "The colours and light on this screen: Classic, Studio or a Showcase theme, and one after sunset",
                                            act: () => openLookMenu() }] : []),
            ...(showMenu ? [{ text: "Show on this screen ⋯", title: "Pick what this screen shows: lights, sensors, people, rain… (the ⋯ beside the compass)",
                              act: () => showMenu.open() }] : []),
            ...(panel ? panel.menuItems() : [])];
  }
  // The frame-rate readout: off unless this browser turned it on (Settings
  // → Live Aboard → Frame rate); each card the host builds asks again.
  function fpsOn(){ return prefGet(PREF_FPS) === "1"; }
  function syncFps(){
    if (!FPS || !root) return;
    if (!fpsUi && fpsOn()) fpsUi = FPS.createFpsReadout({ root, frames: () => frames, now: () => performance.now() });
    if (fpsUi) fpsUi.sync(fpsOn() && !failed);
  }
  /** The room the camera looks at, on the top floor showing it. */
  function roomNear(x, y){
    const hit = floorsUi.filter(F => F.group.visible).sort((a, b) => b.fl.elev - a.fl.elev)
      .map(F => F.rooms.find(r => HOUSE.inPoly(x, y, r.pts))).find(Boolean);
    return hit ? String(hit.name) : null;
  }
  function saveView(){
    const v = readViews(), base = roomNear(cam.target.x, cam.target.z) || "My view";
    let name = base;
    for (let n = 2; v.some(x => x.name === name); n++) name = `${base} ${n}`;
    v.push({ name, theta: cam.theta, phi: cam.phi, radius: cam.radius, target: cam.target.toArray(),
             floor: floorSteps ? (floorSteps.all ? -1 : floorSteps.at) : null });
    writeViews(v);
    toast(`Saved "${name}" in Views`);
  }
  function goView(v){
    const s = floorSteps;
    if (s && Number.isInteger(v.floor) && v.floor < s.names.length && (v.floor < 0 ? !s.all : (s.all || v.floor !== s.at))) s.go(v.floor);
    flyTo({ target: new THREE.Vector3().fromArray(v.target), radius: v.radius, theta: v.theta, phi: v.phi }, false);
  }
  /** Every floor, from the Atlas's angle, framed whole. */
  function wholeHouse(){
    if (floorSteps && !floorSteps.all) floorSteps.go(-1);
    const a = isoAngle();
    const g = frameFor(a.theta, a.phi, visiblePoints());
    flyTo(g, false);
    fitR = g.radius;
  }

  // ── Views ▾ → Look: this screen's look (live_aboard_looks.js) ─────────────
  // Kept per screen in prefs, as the ⋯ list's ticks; put over the card's data
  // as it comes in (update), so the house is drawn again only when the look
  // that shows changes: a pick, or sunset and sunrise with By the sun on.
  /** This screen's look as kept: {day, night}. */
  const lookHere = () => LOOKPICK.readLook(prefGet(LOOKPICK.lookPrefKey(slotKey)));
  /** The Showcase themes the host hands in (only for a tier with Showcase), or null. */
  const themesOf = (p) => (p && p.showcaseThemes && typeof p.showcaseThemes === "object" ? p.showcaseThemes : null);
  /** After sunset, by the card's sun (sun.sun's state, else the sun the view works out). */
  const nightNow = (p) => LOOKPICK.afterSunset(p && p.states, () => HOUSE.readSun(p && p.states, p && p.config, Date.now()).elevation);
  /** The pick that shows on this screen now. */
  function lookPickNow(p){ const L = lookHere(); return LOOKPICK.pickNow(L, L.night !== null && nightNow(p)); }
  /** The Look line in Views ▾: the pick, and the one after sunset. */
  function lookWords(){
    const L = lookHere(), t = themesOf(rawP), w = (pick) => LOOKPICK.pickWords(pick, t);
    return L.night === null ? w(L.day) : `${w(L.day)}, ${w(L.night)} after sunset`;
  }
  /** The list: Same as Settings, Live Aboard's own looks, the Showcase themes this tier has, and By the sun. */
  function lookItems(){
    const L = lookHere(), t = themesOf(rawP), sun = L.night !== null, cur = sun && lookFor === "night" ? L.night : L.day;
    const G = LOOKPICK.lookGroups(t, LOOKS ? LOOKS.SHOWCASE_LOOKS : null, STUDIO);   // Studio's module: its sky for the swatch, nothing run
    // By the sun first (a long list scrolls): with it on, which part of the day the list picks for.
    const out = [{ text: "By the sun: another look after sunset", check: true, on: sun, data: "la3d-bysun",
                   title: "One look by day and another after sunset (Home Assistant's sun)", act: () => toggleBySun() }];
    if (sun) {
      out.push({ seg: [{ text: "By day", on: lookFor !== "night", act: () => { lookFor = "day"; openLookMenu(); } },
                       { text: "After sunset", on: lookFor === "night", act: () => { lookFor = "night"; openLookMenu(); } }] });
    }
    out.push(null);
    out.push({ text: `Same as Settings (${LOOKPICK.settingsWords(rawP, t)})`, on: cur === LOOKPICK.SETTINGS, data: "la3d-look-settings",
               title: "Settings → Atlas → Live Aboard's Look, and the Atlas's Showcase theme", act: () => setLook(LOOKPICK.SETTINGS) });
    for (const g of G.groups) {
      out.push({ head: g.head });
      for (const it of g.items) out.push({ text: it.words, swatch: it.swatch, on: cur === it.pick, act: () => setLook(it.pick) });
    }
    if (G.note) out.push({ note: G.note });
    return out;
  }
  /** The list over Views ▾ (View ▾ on a narrow screen), where the Look line was. */
  function openLookMenu(){
    const a = menuAnchor && menuAnchor.isConnected !== false ? menuAnchor
      : bar ? bar.querySelector(narrow ? "[data-la3d-view] button" : "[data-la3d-saved] button") : null;
    if (a) openMenu(a, lookItems());
  }
  /** A look picked for the part of the day the list is on; Same as Settings all day forgets it. */
  function setLook(pick){
    const L = lookHere(), next = L.night !== null && lookFor === "night" ? { ...L, night: pick } : { ...L, day: pick };
    prefSet(LOOKPICK.lookPrefKey(slotKey), LOOKPICK.writeLook(next));
    // A look with colours of its own needs this screen's ⋯ Theme colours (unticked, it stays Classic).
    if (SHOW && pick !== LOOKPICK.SETTINGS && pick !== "classic") {
      const o = showOver();
      if (o.theme === false) prefSet(SHOW.prefKey(slotKey), JSON.stringify(SHOW.withTick(o, "theme", true, SHOW.houseOn(showHouse, "theme"))));
    }
    applyShow();
  }
  /** By the sun on (after sunset starts as the day's look, picked next) or off. */
  function toggleBySun(){
    const L = lookHere(), on = L.night === null;
    lookFor = on ? "night" : "day";
    prefSet(LOOKPICK.lookPrefKey(slotKey), LOOKPICK.writeLook(on ? { ...L, night: L.day } : { ...L, night: null }));
    applyShow();
    openLookMenu();
  }

  // ── a menu over the bar (Views, and the narrow screen's Walls and View) ───
  function closeMenu(){
    if (showMenu) showMenu.close();
    if (menuOff) menuOff();
    menuOff = null;
    if (menuEl && menuEl.parentNode) menuEl.parentNode.removeChild(menuEl);
    menuEl = null;
    markMenus();
  }
  /** The panel's element says whether the ⋯ list or a menu is open, so
   *  Vacation Mode's banner steps under it (the CSS's data-la3d-menu). */
  function markMenus(open = menuOpen()){
    const h = hostEl();
    if (!h || !h.setAttribute) return;
    if (open) h.setAttribute("data-la3d-menu", "");
    else h.removeAttribute("data-la3d-menu");
    layCover();
  }
  function menuOpen(){ return !!(menuEl || (showMenu && showMenu.isOpen)); }
  /** items: {text, act, on?, del?, dot? (a floor's activity), title?,
   *  swatch? ([background, ground, accent]: a look's), check? (a switch:
   *  on is its tick)}, {head} (a group's small heading), {note} (a plain
   *  line), {seg: [{text, on, act}]} (a row of choices) or null (a line
   *  between). A second tap on its button closes it. */
  function openMenu(anchor, items){
    const again = !!(menuEl && menuEl._from === anchor);
    closeMenu();
    if (again || !root) return;
    menuAnchor = anchor;
    const d = (tag, cls) => { const n = document.createElement(tag); if (cls) n.className = cls; return n; };
    const m = d("div", "la3d-menu");
    m.setAttribute("role", "menu");
    m._from = anchor;
    for (const it of items) {
      if (!it) { m.appendChild(d("hr")); continue; }
      if (it.head || it.note) { const h = d("div", it.head ? "la3d-mhead" : "la3d-mnote"); h.textContent = it.head || it.note; m.appendChild(h); continue; }
      if (it.seg) {
        const row = d("div", "la3d-mseg");
        row.setAttribute("role", "group");
        for (const s of it.seg) {
          const b = d("button");
          b.type = "button"; b.textContent = s.text;
          b.setAttribute("aria-pressed", String(!!s.on));
          b.addEventListener("click", guard((e) => { e.stopPropagation(); closeMenu(); s.act(); }));
          row.appendChild(b);
        }
        m.appendChild(row);
        continue;
      }
      const row = d("div", "la3d-mrow"), b = d("button");
      b.type = "button"; b.textContent = it.text;
      const fb = Number.isInteger(it.badge) ? badgeOf(it.badge) : null;
      if (fb) b.prepend(fb);
      if (Array.isArray(it.swatch)) {
        const sw = d("span", "la3d-sw");
        sw.style.background = `linear-gradient(135deg,${it.swatch[0]} 0 42%,${it.swatch[1]} 42% 66%,${it.swatch[2]} 66%)`;
        b.prepend(sw);
      }
      const dot = it.dot ? dotOf(it.dot) : null;
      if (dot) b.appendChild(dot);
      if (it.title) b.title = it.title;
      if (it.data) b.setAttribute(`data-${it.data}`, "");
      b.setAttribute("role", it.on === undefined ? "menuitem" : it.check ? "menuitemcheckbox" : "menuitemradio");
      if (it.on !== undefined) b.setAttribute("aria-checked", String(!!it.on));
      if (it.disabled) b.disabled = true;
      b.addEventListener("click", guard((e) => { e.stopPropagation(); closeMenu(); it.act(); }));
      row.appendChild(b);
      if (it.del) {
        const x = d("button", "la3d-mx");
        x.type = "button"; x.textContent = "✕"; x.title = `Forget "${it.text}"`;
        x.setAttribute("aria-label", x.title);
        x.addEventListener("click", guard((e) => { e.stopPropagation(); closeMenu(); it.del(); }));
        row.appendChild(x);
      }
      m.appendChild(row);
    }
    root.appendChild(m);
    const rr = root.getBoundingClientRect(), ar = anchor.getBoundingClientRect();
    // On a wall the menu is drawn k times larger (CSS zoom), and zoom scales
    // its left/bottom too: place it in screen pixels, then divide by k.
    const k = wallUiOf(root, "--wall-ctl"), mw = m.getBoundingClientRect().width || 180 * k;
    m.style.left = `${Math.max(8, Math.min(ar.left - rr.left, rr.width - 8 - mw)) / k}px`;
    // Over its button, as from the bar; under it from the top of the view (Rooms ▾).
    if (ar.top - rr.top < rr.height / 3) {
      m.style.top = `${Math.max(8, ar.bottom - rr.top + 6) / k}px`;
      // Down to the bar, not over it.
      const br = bar && typeof bar.getBoundingClientRect === "function" ? bar.getBoundingClientRect() : null;
      if (br && br.height > 0 && br.top - ar.bottom - 14 > 160) m.style.maxHeight = `${(br.top - ar.bottom - 14) / k}px`;
    } else m.style.bottom = `${Math.max(8, rr.bottom - ar.top + 6) / k}px`;
    menuEl = m;
    markMenus();
    const away = guard((e) => { const path = e.composedPath ? e.composedPath() : []; if (!path.includes(m) && !path.includes(anchor)) closeMenu(); });
    const esc = guard((e) => { if (e.key === "Escape") closeMenu(); });
    window.addEventListener("pointerdown", away, true);
    window.addEventListener("keydown", esc);
    menuOff = () => { window.removeEventListener("pointerdown", away, true); window.removeEventListener("keydown", esc); };
  }

  // ── the first time: a card with the ways round ────────────────────────────
  let hintShown = false;
  function showHint(again = false){
    if ((hintShown && !again) || hintCard || furnishOn || !root) return;
    const seen = prefGet(PREF_HINT) === "1";
    hintShown = true;
    if (seen && !again) return;
    if (!again && onWallPage(root)) return;   // a wall: nobody there to tap Got it
    const d = (tag, text) => { const n = document.createElement(tag); if (text) n.textContent = text; return n; };
    const card = document.createElement("div");
    card.className = "la3d-card";
    card.setAttribute("role", "dialog");
    card.setAttribute("aria-label", "How Live Aboard works");
    const ul = d("ul");
    for (const t of ["Live Aboard is experimental: it is still changing, and some of your house may not show yet.",
                     "Tap a light to switch it. Hold it for brightness and colour.",
                     "Drag to turn the house. Two fingers (or the right mouse button) move it; pinch or the wheel zooms.",
                     "Double-tap a room to go there.",
                     "Walls: Cut, Up or Down. ▲ and ▼ change the floor you see.",
                     ...(mapOnly ? ["Zoom in and the bars step aside for the map alone; ☰ brings them back. The corners button fills the screen.",
                                    "With the map alone, PgUp and PgDn change the floor and Home shows them all. Touch the map and the floor's name shows in the corner: tap it to pick a floor."] : [])]) {
      ul.appendChild(d("li", t));
    }
    const ok = d("button", "Got it");
    ok.type = "button";
    ok.addEventListener("click", guard((e) => {
      e.stopPropagation();
      prefSet(PREF_HINT, "1");
      if (card.parentNode) card.parentNode.removeChild(card);
      hintCard = null;
    }));
    // The whole guide, in a new tab (Views ▾ → How it works brings this card back).
    const more = d("a", "The full guide: everything Live Aboard does, and building in Edit");
    more.href = GUIDE_URL; more.target = "_blank"; more.rel = "noopener";
    more.className = "la3d-guide";
    card.append(d("b", "Live Aboard"), ul, more, ok);
    root.appendChild(card);
    hintCard = card;
  }

  function start(setting){
    canvas = document.createElement("canvas");
    let gl = null;
    try {
      // A stencil: rain and snow are never drawn over a room (live_aboard_weather.js).
      gl = canvas.getContext("webgl2", { antialias: setting !== "low", alpha: false, depth: true, stencil: true,
                                         powerPreference: "default", preserveDrawingBuffer: false });
    } catch (_) { gl = null; }
    if (!gl) { fail("no_webgl"); return false; }
    renderer = new THREE.WebGLRenderer({ canvas, context: gl });
    renderer.setClearColor(BG, 1);
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    const onLost = () => fail("context_lost");
    canvas.addEventListener("webglcontextlost", onLost);
    observers.push(() => canvas.removeEventListener("webglcontextlost", onLost));
    buildRoot();
    canvas.setAttribute("role", "img");
    canvas.setAttribute("aria-label", "Live Aboard");
    root.insertBefore(canvas, bar);
    scene = new THREE.Scene();
    scene.background = new THREE.Color(BG);
    scene.fog = new THREE.Fog(BG, 140, 420);
    camera = new THREE.PerspectiveCamera(FOV, 1, 0.1, 700);
    makeShared();
    hemi = new THREE.HemisphereLight(0xe6edf6, 0x3a342c, 1.6);
    sun = new THREE.DirectionalLight(0xfff0dc, 2.0);
    sun.shadow.mapSize.set(2048, 2048);
    sun.shadow.bias = -0.0004;
    sun.shadow.normalBias = 0.03;
    scene.add(hemi, sun, sun.target);
    // A fixed pool of real lamps: only their intensities ever change (Low
    // lights four of them, High all eight — a profile change, never a bulb).
    for (let i = 0; i < 8; i++) { const pl = new THREE.PointLight(0xffffff, 0, 7.5, 2); lampPool.push(pl); scene.add(pl); }
    // The press, the hover box and the rings: the Atlas's, over the house.
    use = USE.createUseSurface({
      root, pick: (x, y, noLights) => pickAt(x, y, noLights), screenOf,
      // Built once per poll, on first need: the host's api for this card.
      api: () => apiNow || (apiNow = apiOf ? apiOf() : null),
      frame: () => { if (!pending && !failed && renderer) { pending = true; requestAnimationFrame(frame); } },
      cursor: (on) => { canvas.style.cursor = on ? "pointer" : ""; },
      // A motion sensor hovered or pressed shows its coverage.
      marked: (t) => {
        const eid = t && t.kind === "device" ? t.eid : null;
        const a = !!(motionL && motionL.focus(eid)), b = plumbTo(eid);
        if (a || b) requestRender();
      },
      // The ⋯ list's "Tap a light to switch it" (on unless this screen unticks it), on the
      // Atlas tab and its walls (mapOnly); Mapping's builder does not offer it.
      lightTaps: () => lightTapsOn(),
      switched: (ok) => showSend(`house3d_show:light_tap:${ok ? "ok" : "failed"}`),
      // A light a tap switched says so, with the way back (proposal 4): a wrong one costs one more tap.
      switchedTo: (eid, on, undo) => { const l = lbe[eid]; toast(`${(l && l.friendly_name) || eid} ${on ? "on" : "off"}`, undo, "Undo"); },
      // The ⋯ list's "Lights as buttons": the buttons to paint; a tap on a sensor, a readout or a lock goes to its room
      // (not while a class chip picks its kind out: then it is what the screen is for); each button tap counted.
      buttons: () => buttonsUi(),
      roomTaps: (t) => buttonsOn() && !classF && !t.btn,
      tapped: (what) => showSend(`house3d_show:button_tap:${what}`),
      // "Rooms as light switches": a room switched or dimmed from its floor says so (a switch with the way back).
      roomSwitched: (room, what, n, undo) => {
        showSend(`house3d_show:room_tap:${what}`);
        if (what !== "dim") toast(`${room}: ${n} light${n === 1 ? "" : "s"} ${what}`, undo, "Undo");
      },
      // A room opened by a tap: its panel beside the house (live_aboard_rooms.js), flown to and tinted.
      openRoom: (room) => openRoomPanel(room),
    });
    // Furniture (P2): every piece drawn on its floor, in every view.
    layer = FURNISH.createPieceLayer({ THREE, PIECES, FURN: () => FURN, floors: () => floorsUi, blobTex: shared.blobTex,
      canon: (fid) => (house && house.canon ? house.canon(fid) : String(fid)),
      canonAt: (fid, x, y) => (house && house.canonAt ? house.canonAt(fid, x, y) : (house && house.canon ? house.canon(fid) : String(fid))),
      quality: () => (profileOf().pbr ? "high" : "low"),
      recipeOf: (p) => stairRecipe(p) });
    devices = DEVICES ? DEVICES.createDeviceLayer({ THREE, layer, FURN: () => FURN, halo: shared.haloMats.m,
      quality: () => (profileOf().pbr ? "high" : "low") }) : null;
    tracked = TRACKED ? TRACKED.createTrackedLayer({ THREE, FURN: () => FURN, floors: () => floorsUi, uiScale: () => wallUiOf(root),
      canon: (fid) => (house && house.canon ? house.canon(fid) : String(fid)),
      canonAt: (fid, x, y) => (house && house.canonAt ? house.canonAt(fid, x, y) : (house && house.canon ? house.canon(fid) : String(fid))),
      quality: () => (profileOf().pbr ? "high" : "low"), floorAbove,
      fadeOf: TRAILS ? TRAILS.fadeOf : null, colourOf: TRAILS ? TRAILS.trailColour : null }) : null;
    marks = MARKS ? MARKS.createMarkLayer({ THREE, quality: () => (profileOf().pbr ? "high" : "low") }) : null;
    // Under the roof while it shows is hidden too (a marker, a code).
    const hidden = (v) => blocked(v) || !!(storeyL && storeyL.hides(v.x, v.z, v.y));
    codes = MARKS ? MARKS.createCodeLayer({ THREE, behind: hidden }) : null;
    motionL = MOTION ? MOTION.createMotionLayer({ THREE, quality: () => (profileOf().pbr ? "high" : "low"), behind: hidden,
      dim: (eid) => dimOf(eid), dimK: MARKS ? MARKS.DIM_K : 0.22, floorAbove,
      built: () => { if (raisedL) raisedL.forget(); },
      floorTiles: () => floorsUi.filter(F => F.group.visible && F.tiles).map(F => F.tiles).concat(storeyL ? storeyL.roofs() : []) }) : null;
    storeyL = STOREY ? STOREY.createStoreyLayer({ THREE, lit: (g, spec, c, r) => lit(g, spec, c, r), slabT: HOUSE.SLAB_T,
      quality: () => (profileOf().pbr ? "high" : "low") }) : null;
    raisedL = RAISED ? RAISED.createRaisedLayer({ THREE, camera: () => camera, size: () => [canvas.clientWidth || 0, canvas.clientHeight || 0],
      any: () => !!((motionL && motionL.anyRaised()) || (tracked && tracked.tagCount))
        || floorsUi.reduce((n, F) => n + (F.group.visible ? F.labels.length : 0), chips.length) > 1,
      raised: raisedNow, texts: wordsNow, words: wordUnits, ready: shouldDraw,
      busy: () => !!cam.fly || !!quality.measuring || dirty, movedAt: () => camMovedAt, off: () => raisedOff,
      quality: () => (profileOf().pbr ? "high" : "low"), settled: recheckCovers,
      draw: () => { liveMs = liveRate(performance.now()); requestRender(); } }) : null;
    panel = PANEL ? makePanel() : null;
    director = DIRECTOR && panel ? makeDirector() : null;
    planCam = new THREE.OrthographicCamera(-1, 1, 1, -1, 0.1, 400);
    planCam.up.set(0, 0, -1);                                // the plan as drawn: its top up
    // The 3D editor: its page in this element, its marks in this scene, its
    // presses handed over by wirePointer while it is open.
    editor = EDIT.createEditor({
      THREE, HOUSE, DRAFT, root, canvas, bar, guard,
      camera: () => camera, scene: () => scene, floors: () => floorsUi, shellGen: () => shellGen,
      pick: (x, y) => pickAt(x, y), blocked: (v, own) => blocked(v, own), device: (eid) => deviceInfo(eid),
      // Heights' "Move it": the room floor under a point of the screen, and the host's write of a device's new spot
      // (its placement record: maps.js _laMovePut), where the host has one.
      floorAt: (x, y) => roomAtScreen(x, y), canMove: () => !!(lastP && typeof lastP.moves === "function"),
      move: (eid, x, y) => lastP.moves(eid, x, y), spotsOf: (l, kind, top) => HEIGHTS.spotsOf(l, kind, top), doorClass: (eid) => classOf(eid),
      // The file with the records' heights over it (what the draft edits).
      file: () => (file ? shownFile() : null), reload: () => reloadFile(), problem: () => fileErr, newer: () => setFileErr("house3d_newer"),
      // A scanned plan's furniture (house3d_get's scan_pieces), for Furnish's "Size to the scan".
      scan: () => scanPieces,
      count: (name) => { try { if (lastP && typeof lastP.telemetry === "function") lastP.telemetry(name); } catch (_) { /* the report is never the error */ } },
      saved: (data) => { fileRaw = data; file = DRAFT.ownedOf(data); setFileErr(DRAFT.writable(data) ? null : "house3d_newer"); },
      redraw: () => redraw(), preview: (t) => preview(t), render: () => requestRender(), topDown: (F) => topDownOn(F),
      clearUse: () => { if (use) use.clear(); closeRoomPanel(); if (roomChips) roomChips.sync(); },
      // P2 Furnish: its tool, the furniture drawn, and where on screen each view is.
      FURNISH, PIECES, FURN: () => FURN, layer, rect: () => view3Rect(), viewAt: (x, y) => viewAt(x, y),
      STRIP, RUNS,                                           // the Strip tool (lights laid out along their runs)
      // Add data via plans (live_aboard_plans.js, experimental): loaded only when the editor asks (the master switch on).
      loadPlans: () => import(`./live_aboard_plans.js${new URL(import.meta.url).search}`),
      // Its vetting map: stairs drawn at their real rise, a floor by the view's name for it, the flight to an item, north for "1.4 m east".
      recipeOf: (p) => stairRecipe(p), canon: (fid) => (house && house.canon ? house.canon(fid) : String(fid)), flySpot: (F, x, y, span, pad) => flySpot(F, x, y, span, pad),
      compass: () => HOUSE.fabricCompass(bearingNow()), quiet: (on) => setQuiet(on),
      STOREY,                                                // stairs in Furnish: the floor they reach, their rise
      lights: () => lights.map(L => ({ eid: L.eid, F: L.F, drawn: L.drawn, guess: L.guess, label: (deviceInfo(L.eid) || {}).label || L.eid })),
      // The plan alone (a narrow screen): its middle as it shows, not where the hidden 3D view looks.
      centre: () => { if (viewports().d3) return [cam.target.x, cam.target.z]; fitPlan(); return [plan.cx, plan.cy]; }, setTopFloor: (fid) => { if (topCb) topCb(fid); }, host: () => furnishP,
      base: new URL(import.meta.url).search,
      // The floor the stepper or the floor chips picked (its ids; null: All): the line tool draws there.
      selected: () => selIds,
    });
    wirePointer();
    wireKeys();
    wireObservers();
    return true;
  }
  /** While the view has the keyboard (a press on it gives it): PgUp and PgDn
   *  step a floor, Home is every floor, as the stepper's ▲ ▼ and All. */
  function wireKeys(){
    canvas.tabIndex = 0;
    canvas.setAttribute("aria-label", "Live Aboard: PgUp and PgDn change the floor, Home shows them all");
    canvas.addEventListener("keydown", guard((e) => {
      const d = { PageUp: 1, PageDown: -1, Home: 0 }[e.key];
      if (d === undefined || !floorSteps || e.altKey || e.ctrlKey || e.metaKey || e.defaultPrevented) return;
      e.preventDefault();
      stepFloor(d);
      flashCorner();
    }));
  }
  function makeShared(){
    const wallBox = new THREE.BoxGeometry(1, 1, 1).translate(0, 0.5, 0);    // its base on y = 0
    const n = wallBox.attributes.normal, col = new Float32Array(n.count * 3);
    // A dark wall top, as in the Sims.
    for (let i = 0; i < n.count; i++) { const v = n.getY(i) > 0.5 ? 0.24 : 1; col[i * 3] = col[i * 3 + 1] = col[i * 3 + 2] = v; }
    wallBox.setAttribute("color", new THREE.BufferAttribute(col, 3));
    // Which faces are wall tops: at night they glow light (topGlow), so the
    // rooms read from above as they do on the flat Atlas.
    const tops = new Float32Array(n.count);
    for (let i = 0; i < n.count; i++) tops[i] = n.getY(i) > 0.5 ? 1 : 0;
    wallBox.setAttribute("aTop", new THREE.BufferAttribute(tops, 1));
    const glowTex = radialTexture([[0, "rgba(255,255,255,1)"], [0.22, "rgba(255,255,255,0.6)"], [0.55, "rgba(255,255,255,0.16)"], [1, "rgba(255,255,255,0)"]]);
    shared = {
      wallBox, glassBox: new THREE.BoxGeometry(1, 1, 1).translate(0, 0.5, 0),
      prim: {
        puck: new THREE.CylinderGeometry(1, 1, 1, 18),
        dome: new THREE.CylinderGeometry(1, 0.62, 1, 20).translate(0, -0.5, 0),     // a closed drum hanging from y = 0
        box: new THREE.BoxGeometry(1, 1, 1),
        sphere: new THREE.SphereGeometry(1, 14, 10),
      },
      glowTex, aoTex: rampTexture(),
      // A soft round shadow under furniture on Low (live_aboard_furnish.js).
      blobTex: radialTexture([[0, "rgba(255,255,255,1)"], [0.55, "rgba(255,255,255,0.55)"], [1, "rgba(255,255,255,0)"]]),
      bulbMat: new THREE.MeshBasicMaterial({ color: 0xffffff }),
      // Part B: an unlocked lock's flash (every one in step, as on the
      // Atlas), the motion ring, and the air bars' stripe.
      flashMat: new THREE.MeshBasicMaterial({ color: HOUSE.LOCK_FLASH.to, transparent: true, opacity: 0.55, depthWrite: false }),
      // A lit room's windows at night, seen from outside (Walls: Up), as in the Sims.
      glowMat: new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.95, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.FrontSide }),
      // A window open while it rains or snows: a still rain-blue glow over it.
      wetMat: new THREE.MeshBasicMaterial({ color: WET_INK, transparent: true, opacity: 0.6, depthWrite: false }),
      // Walls: Glass. One unlit material for every floor: faint tinted glass,
      // each face's edges brighter (a line about 1.5 px wide, whatever the
      // wall's size), drawn after the house and writing no depth, so what is
      // behind it shows through. Nothing changes as the camera turns.
      ghostMat: ghostMaterial(),
      ringGeo: new THREE.RingGeometry(0.93, 1, 48).rotateX(-Math.PI / 2),
      barsTex: barsTexture(),
      poolGeo: new THREE.PlaneGeometry(2, 2).rotateX(-Math.PI / 2),
      poolMat: new THREE.MeshBasicMaterial({ map: glowTex, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending,
        side: THREE.DoubleSide, polygonOffset: true, polygonOffsetFactor: -1, polygonOffsetUnits: -4 }),
      haloMats: {},
      // A wash: a quad from its line (y = 0) out to y = 1.
      washGeo: new THREE.PlaneGeometry(1, 1).translate(0, 0.5, 0),
      washMats: {},
      mats: new Map(),
    };
    for (const [k, map] of [["fade", washTexture(false)], ["scallop", washTexture(true)], ["round", glowTex]]) {
      shared.washMats[k] = new THREE.MeshBasicMaterial({ map, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending,
        side: THREE.DoubleSide, polygonOffset: true, polygonOffsetFactor: -1, polygonOffsetUnits: -4 });
    }
    for (const k of Object.keys(HALO)) {
      shared.haloMats[k] = new THREE.PointsMaterial({ size: HALO[k] / Math.tan(FOV / 2 * D2R), map: glowTex, vertexColors: true,
        transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, sizeAttenuation: true });
    }
  }
  function ghostMaterial(){
    const m = new THREE.MeshBasicMaterial({ color: GHOST_COL, transparent: true, depthWrite: false, side: THREE.FrontSide });
    m.defines = { USE_UV: "" };
    m.onBeforeCompile = (sh) => {
      sh.fragmentShader = sh.fragmentShader.replace("#include <color_fragment>", `#include <color_fragment>
        vec2 la3dW = fwidth( vUv ) * 1.5;
        vec2 la3dIn = smoothstep( vec2( 0.0 ), la3dW, vUv ) * smoothstep( vec2( 0.0 ), la3dW, 1.0 - vUv );
        diffuseColor.a *= mix( ${GHOST_EDGE_OP.toFixed(3)}, ${GHOST_OP.toFixed(3)}, la3dIn.x * la3dIn.y );`);
    };
    m.customProgramCacheKey = () => "la3d-ghost";
    return m;
  }
  // One material per look and profile: flat colours on Low, PBR on High.
  function mat(spec){
    const key = (quality.profile || quality.measuring || "low") + JSON.stringify(spec);
    let m = shared.mats.get(key);
    if (!m) {
      const o = { color: spec.c || "#ffffff", vertexColors: !!spec.vc, transparent: !!spec.tr, opacity: spec.op ?? 1,
                  depthWrite: !spec.tr, side: spec.ds ? THREE.DoubleSide : THREE.FrontSide };
      m = profileOf().pbr ? new THREE.MeshStandardMaterial({ ...o, roughness: spec.r ?? 0.85, metalness: spec.m ?? 0 })
        : new THREE.MeshLambertMaterial(o);
      if (spec.top) {
        // The wall tops' night glow: one uniform, so dusk to night never rebuilds a shader.
        m.onBeforeCompile = (sh) => {
          sh.uniforms.uTopGlow = topGlow;
          sh.vertexShader = "attribute float aTop;\nvarying float vTop;\n"
            + sh.vertexShader.replace("#include <begin_vertex>", "#include <begin_vertex>\n  vTop = aTop;");
          sh.fragmentShader = "uniform float uTopGlow;\nvarying float vTop;\n"
            + sh.fragmentShader.replace("#include <emissivemap_fragment>", "#include <emissivemap_fragment>\n  totalEmissiveRadiance += vec3(vTop * uTopGlow);");
        };
        m.customProgramCacheKey = () => "la3d-walltop";
      }
      shared.mats.set(key, m);
    }
    return m;
  }
  const profileOf = () => HOUSE.QUALITY_PROFILES[quality.profile || quality.measuring || "low"];
  /** The ring under an off ceiling light on a covered patio: flat, faint, one material for all. */
  function floorMarkMat(){
    return shared.floorMark || (shared.floorMark = { geo: new THREE.RingGeometry(0.55, 1, 24).rotateX(-Math.PI / 2),
      mat: new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.85, depthWrite: false, side: THREE.DoubleSide,
                                         polygonOffset: true, polygonOffsetFactor: -1, polygonOffsetUnits: -4 }) });
  }
  /** The paving's joints and texture: one small repeating picture made here
   *  (nothing downloaded), clear but for a thin line along two edges of each
   *  tile and its flecks (outdoor_space.js PAVER_FLECKS), all in the joints'
   *  dark; one material for every paved room, made the first time one is drawn. */
  function pavingMat(){
    if (shared.pavingMat) return shared.pavingMat;
    const N = 128, c = document.createElement("canvas"); c.width = c.height = N;
    const g = c.getContext("2d");
    g.fillStyle = "#ffffff"; g.fillRect(0, 0, N, 4); g.fillRect(0, 0, 4, N);
    // v runs up a texture and down a canvas: flipped, so a tile's flecks lie as on the flat Map.
    for (const [u, v, sz, a] of SURF.PAVER_FLECKS) { g.globalAlpha = a; g.fillRect(u * N, (1 - v - sz) * N, sz * N, sz * N); }
    g.globalAlpha = 1;
    const t = new THREE.CanvasTexture(c);
    t.wrapS = t.wrapT = THREE.RepeatWrapping; t.anisotropy = 4;
    return (shared.pavingMat = new THREE.MeshLambertMaterial({ map: t, color: SURF.PAVER_JOINT, transparent: true, depthWrite: false,
      side: THREE.DoubleSide, polygonOffset: true, polygonOffsetFactor: -1, polygonOffsetUnits: -3 }));
  }

  // ── the house ─────────────────────────────────────────────────────────────
  function clearShell(){
    clearSensors();
    openings = [];
    if (use && !use.pressing) use.clear();            // what it marked is gone
    for (const F of floorsUi) scene.remove(F.group);
    if (ground) { scene.remove(ground); scene.remove(gridLines); ground = null; gridLines = null; }
    disposeList(shellRes); shellRes = [];
    clearLights();
    floorsUi = [];
  }
  // A room's name: upright on screen whatever the angle (a sprite), drawn
  // over everything on its floor (fixtures included), in its own words. Sized
  // per frame (sizeNames): never under or over NAME_PX, and hidden when its
  // room is too small on screen to hold it, or under a floor showing above.
  function labelSprite(text, ext, col){
    if (atlas) return atlasLabel(text, ext, col);
    const px = 44, c = document.createElement("canvas"), g = c.getContext("2d");
    const font = `650 ${px}px system-ui, "Segoe UI", Roboto, sans-serif`;
    g.font = font;
    c.width = Math.ceil(g.measureText(text).width) + 28; c.height = px + 24;
    g.font = font;
    g.textAlign = "center"; g.textBaseline = "middle"; g.lineJoin = "round";
    g.lineWidth = 10; g.strokeStyle = "rgba(8,12,10,0.86)"; g.strokeText(text, c.width / 2, c.height / 2 + 2);
    g.fillStyle = "#ffffff"; g.fillText(text, c.width / 2, c.height / 2 + 2);
    return labelOf(c, px, ext, 1);
  }
  /** A room's name as the Atlas writes it: in the room's colour with the
   *  Atlas's dark edge, UPPERCASE and spaced where the theme says. */
  function atlasLabel(text, ext, col){
    const A = atlas, px = 44, c = document.createElement("canvas"), g = c.getContext("2d");
    const word = A.upper ? String(text).toUpperCase() : String(text), sp = A.spacing * px, chars = [...word];
    const font = `650 ${px}px system-ui, "Segoe UI", Roboto, sans-serif`;
    g.font = font;
    const ws = chars.map(ch => g.measureText(ch).width), tw = sp ? ws.reduce((a, w) => a + w, 0) + sp * (chars.length - 1) : g.measureText(word).width;
    c.width = Math.ceil(tw) + 28; c.height = px + 24;
    g.font = font;
    g.textBaseline = "middle"; g.lineJoin = "round";
    const fill = "#" + colorOf(col).getHexString();
    g.lineWidth = 10; g.strokeStyle = A.nameEdge; g.fillStyle = fill;
    const y = c.height / 2 + 2;
    if (!sp) { g.textAlign = "center"; g.strokeText(word, c.width / 2, y); g.fillText(word, c.width / 2, y); }
    else {
      g.textAlign = "left";
      for (const pass of ["stroke", "fill"]) {
        let x = (c.width - tw) / 2;
        chars.forEach((ch, i) => { if (pass === "stroke") g.strokeText(ch, x, y); else g.fillText(ch, x, y); x += ws[i] + sp; });
      }
    }
    const sprite = labelOf(c, px, ext, A.nameOp);
    sprite.userData.text = word; sprite.userData.color = fill;
    return sprite;
  }
  function labelOf(c, px, ext, op){
    const tex = new THREE.CanvasTexture(c);
    tex.colorSpace = THREE.SRGBColorSpace;
    const m = new THREE.SpriteMaterial({ map: tex, transparent: true, depthTest: false, depthWrite: false, sizeAttenuation: false, opacity: op });
    shellRes.push(tex, m);
    const sp = new THREE.Sprite(m);
    sp.renderOrder = 31;                                     // over the chips too (an outdoor one may sit near a name)
    sp.userData = { aspect: c.width / c.height, letters: px / c.height, ext, covered: false, behind: false, px: 0, op };
    return sp;
  }
  function lit(geo, spec, cast = true, recv = true){
    const o = new THREE.Mesh(geo, mat(spec));
    o.userData.spec = spec; o.castShadow = cast; o.receiveShadow = recv;
    return o;
  }
  function buildShell(h){
    clearShell();
    shellGen++; work.shells++;
    house = h;
    let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity, z0 = Infinity, z1 = -Infinity;
    for (const r of h.rooms) {
      if (r.floor.outdoor) continue;
      for (const p of r.pts) { x0 = Math.min(x0, p[0]); y0 = Math.min(y0, p[1]); x1 = Math.max(x1, p[0]); y1 = Math.max(y1, p[1]); }
      z0 = Math.min(z0, r.floor.elev - HOUSE.SLAB_T); z1 = Math.max(z1, r.floor.elev + (r.h ?? r.floor.h) - HOUSE.SLAB_T);
    }
    houseBox = Number.isFinite(x0) ? { x0, y0, x1, y1, z0, z1 } : { x0: -5, y0: -5, x1: 5, y1: 5, z0: 0, z1: 3 };
    // Stairs cut their opening in the floor they reach: its tiles and its storey's floor.
    const cuts = STOREY ? STOREY.stairCuts(viewData().pieces, h.floors, h.canon) : null;
    const tileSum = { r: 0, g: 0, b: 0, n: 0 };              // the rooms' floors, for the storey's own (storeyLook)
    for (const fl of h.floors) {
      const group = new THREE.Group();
      group.name = "floor:" + fl.id;
      scene.add(group);
      const per = h.perFloor.get(fl) || { rooms: [], pieces: [] };
      const F = { fl, group, rooms: per.rooms, pieces: [], labels: [], tiles: null, solid: null, glass: null, ao: null };
      floorsUi.push(F);
      // Floor tiles: each room extruded down by its slab — the room's colour
      // on top, the Atlas's beige on the sides — merged into one per floor.
      const geos = [], paving = [], spans = [];
      per.rooms.forEach((r, i) => {
        const holes = cuts && cuts.get(fl.id);
        const shapes = (holes ? STOREY.minusAll(r.pts, holes) : [r.pts]).map(P => new THREE.Shape(P.map(p => new THREE.Vector2(p[0], p[1]))));
        const g = new THREE.ExtrudeGeometry(shapes, { depth: HOUSE.SLAB_T, bevelEnabled: false });
        g.rotateX(Math.PI / 2);                              // plan (x, y) -> world (x, ·, y); the extrusion goes down
        g.translate(0, (i % 8) * 0.0005, 0);                 // overlapping hand-drawn rooms must not z-fight
        const tm = theme3d ? theme3d.tile : 0.38;            // the Showcase look's mix (Classic: 0.38, a deck 0.5)
        // Paved (outdoor_space.js): the tiles' grey (the Atlas's look: half its floor's),
        // and their joints laid over it from the room's own corner (pavingGeometry).
        const paved = !!SURF && SURF.paved(r.outdoor, r.surface);
        if (paved) paving.push(pavingGeometry(shapes, SURF.paverFrame(r.pts)).translate(0, (i % 8) * 0.0005 + 0.002, 0));
        // The Atlas's look: the floor's own colour with the room's mixed in, faintly.
        const top = paved ? (atlas ? new THREE.Color(atlas.floor).lerp(new THREE.Color(SURF.PAVER_GREY), 0.5) : new THREE.Color(SURF.PAVER_GREY))
          : atlas ? new THREE.Color(atlas.floor).lerp(colorOf(r.color), r.outdoor ? atlas.floorMix * 0.7 : atlas.floorMix)
          : colorOf(r.color).lerp(new THREE.Color(TILE_MIX), r.outdoor ? tm + 0.12 : tm);
        const side = new THREE.Color(fl.outdoor ? EARTH_SIDE : atlas ? atlas.side : SLAB_SIDE);
        if (!r.outdoor) { tileSum.r += top.r; tileSum.g += top.g; tileSum.b += top.b; tileSum.n++; }
        const n = g.attributes.position.count, col = new Float32Array(n * 3);
        // Each shape's caps (group 0) the room's colour, its sides the slab's edge (stairs may cut a room in pieces).
        for (const gr of g.groups.length ? g.groups : [{ start: 0, count: n, materialIndex: 0 }]) {
          const cc = gr.materialIndex === 0 ? top : side;
          for (let v = gr.start; v < Math.min(n, gr.start + gr.count); v++) { col[v * 3] = cc.r; col[v * 3 + 1] = cc.g; col[v * 3 + 2] = cc.b; }
        }
        g.setAttribute("color", new THREE.BufferAttribute(col, 3));
        g.clearGroups();
        geos.push(g);
        spans.push(n);
        let bx0 = Infinity, bx1 = -Infinity, by0 = Infinity, by1 = -Infinity;
        for (const q of r.pts) { bx0 = Math.min(bx0, q[0]); bx1 = Math.max(bx1, q[0]); by0 = Math.min(by0, q[1]); by1 = Math.max(by1, q[1]); }
        const span = Math.max(bx1 - bx0, by1 - by0);              // how wide the room is, near enough
        const lbl = labelSprite(String(r.name), Math.max(Math.min(r.spot.r * 2, span), 0.75 * span), r.color);
        lbl.position.set(r.spot.x, fl.elev + 0.5, r.spot.y);          // just over what is left of a cut wall
        group.add(lbl);
        F.labels.push(lbl);
      });
      if (geos.length) {
        const merged = mergeGeometries(geos);
        geos.forEach(g => g.dispose());
        merged.translate(0, fl.elev, 0);
        shellRes.push(merged);
        F.tiles = lit(merged, { vc: true, r: 0.9 }, true, true);
        group.add(F.tiles);
        // Each room's run of the merged tiles' vertices (fadeRooms), in the rooms' order.
        if (!merged.index && merged.attributes.position.count === spans.reduce((a, n) => a + n, 0)) {
          let at = 0;
          F.tileSpans = spans.map(n => { const sp = [at, n]; at += n; return sp; });
        }
        // Readable night: an unlit copy of the tiles over them, as clear as
        // the dark is deep (paintNight), so each room keeps its colour.
        const liftMat = new THREE.MeshBasicMaterial({ vertexColors: true, transparent: true, opacity: 0, depthWrite: false,
                                                      polygonOffset: true, polygonOffsetFactor: -1, polygonOffsetUnits: -2 });
        shellRes.push(liftMat);
        F.lift = new THREE.Mesh(merged, liftMat);
        F.lift.visible = false;
        group.add(F.lift);
        // The paved rooms' joints: one mesh per floor, drawn after the tiles
        // and the night's lift (so they show by day and night), under snow.
        if (paving.length) {
          const pg = mergeGeometries(paving);
          paving.forEach(g => g.dispose());
          pg.translate(0, fl.elev, 0);
          shellRes.push(pg);
          F.paving = new THREE.Mesh(pg, pavingMat());
          F.paving.renderOrder = 1;
          group.add(F.paving);
        }
        // ...and each room's outline in its own colour, as the flat Atlas draws it
        // (at night; with the Atlas's look, always).
        const eg = edgeRibbons(per.rooms, fl.elev + 0.012, atlas);
        if (eg) {
          const edgeMat = new THREE.MeshBasicMaterial({ vertexColors: true, transparent: true, opacity: 0, depthWrite: false,
                                                        side: THREE.DoubleSide, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -6 });
          shellRes.push(eg, edgeMat);
          F.edges = new THREE.Mesh(eg, edgeMat);
          F.edges.visible = false;
          group.add(F.edges);
        }
      }
      // Walls: the derived pieces, each drawn bottom to top (wallElements).
      const solids = [], glasses = [];
      for (const pc of per.pieces) {
        if (Math.hypot(pc.x1 - pc.x0, pc.y1 - pc.y0) < 0.02) continue;
        // Lengthened only at its wall's own corners, so joints close and a
        // door, window or gap keeps its width (drawnSpan).
        const span = HOUSE.drawnSpan(pc);
        // The room a pane looks out of (either side of its wall): it glows at night while that room is lit.
        const paneRoom = () => {
          const nx = Number(pc.nx) || 0, ny = Number(pc.ny) || 0;
          return HOUSE.roomAt(per.rooms, span.mx + nx * 0.4, span.my + ny * 0.4) || HOUSE.roomAt(per.rooms, span.mx - nx * 0.4, span.my - ny * 0.4) || null;
        };
        const els = HOUSE.wallElements(pc, fl.h).map(e => ({ ...e, list: e.glass ? glasses : solids, room: e.glass ? paneRoom() : null }));
        for (const e of els) { e.i = e.list.length; e.list.push(e); }
        F.pieces.push({ pc, mx: span.mx, my: span.my, yaw: HOUSE.yawOf([pc.x1 - pc.x0, pc.y1 - pc.y0]),
                        len: span.len, els, cut: null, lights: [] });
      }
      const inst = (list, geo, spec, cast) => {
        if (!list.length) return null;
        const im = new THREE.InstancedMesh(geo, mat(spec), list.length);
        im.userData.spec = spec;
        im.castShadow = cast; im.receiveShadow = true; im.frustumCulled = false;
        list.forEach((e, i) => { e.mesh = im; im.setColorAt(i, _c.set(e.col)); });
        shellRes.push({ dispose: () => im.dispose() });
        group.add(im);
        return im;
      };
      F.solid = inst(solids, shared.wallBox, { vc: true, r: 0.92, top: 1 }, true);
      F.glass = inst(glasses, shared.glassBox, { tr: true, op: 0.32, r: 0.08 }, false);
      // Walls: Glass: what Cut takes off each solid piece, as glass (placePiece);
      // not drawn at all unless Glass is picked.
      if (solids.length) {
        const gh = new THREE.InstancedMesh(shared.glassBox, shared.ghostMat, solids.length);
        gh.frustumCulled = false; gh.renderOrder = 5; gh.castShadow = false; gh.receiveShadow = false;
        for (let i = 0; i < solids.length; i++) gh.setMatrixAt(i, ZERO);
        gh.visible = wallMode === "glass";
        shellRes.push({ dispose: () => gh.dispose() });
        group.add(gh);
        F.ghost = gh;
      }
      // Its night glow: the same panes (the glass's own matrices, shared, so a
      // window that swings carries it), warm where the room behind is lit.
      if (F.glass) {
        const gm = new THREE.InstancedMesh(shared.glassBox, shared.glowMat, glasses.length);
        gm.instanceMatrix = F.glass.instanceMatrix;
        gm.frustumCulled = false; gm.renderOrder = 3; gm.visible = false;
        glasses.forEach((e, i) => gm.setColorAt(i, _c.set(0x000000)));
        shellRes.push({ dispose: () => gm.dispose() });
        group.add(gm);
        F.glow = gm; F.panes = glasses.map(e => e.room);
      }
      // A door, window or lock linked to a sensor opens with it (part B).
      for (const P of F.pieces) setupOpening(F, P, per.rooms);
      if (STOREY) typedPanels(F);                            // doors of a type other than hinged: their own panels
      for (const P of F.pieces) placePiece(F, P, false);
      F.ao = aoMesh(F);
      if (F.ao) group.add(F.ao);
    }
    // A solid floor under each storey (halls never drawn as rooms are no
    // holes), and the roof over it (live_aboard_storey.js).
    if (storeyL) shellRes.push(...storeyL.build(h, floorsUi, cuts, storeyLook(tileSum)));
    // The opt-in report (closed words, once per page load): an open edge drawn
    // as a railing, and a floor inside a taller one (a mezzanine in a hall).
    if ([...h.perFloor.values()].some(per => per.pieces.some(pc => pc.loftRail))) HOUSE.countHouse3dOnce("house3d_loft_rail", send);
    if (HOUSE.hasNestedFloor(h)) HOUSE.countHouse3dOnce("house3d_mezzanine", send);
    if ([...h.perFloor.values()].some(per => per.pieces.some(pc => pc.capped))) HOUSE.countHouse3dOnce("house3d_wall_capped", send);
    countStairs(h);
    if (atlas) platesOf(h);
    // The ground and the sun, sized to the house.
    const cx = (houseBox.x0 + houseBox.x1) / 2, cy = (houseBox.y0 + houseBox.y1) / 2;
    const sx = houseBox.x1 - houseBox.x0, sy = houseBox.y1 - houseBox.y0;
    const groundY = h.ground - HOUSE.SLAB_T - 0.02;
    const gGeo = new THREE.CircleGeometry(420, 72).rotateX(-Math.PI / 2);
    // What the house stands on, and its grid: the Showcase look's (Classic: today's).
    const gc = theme3d ? theme3d.ground : "#18201c", today = !LOOKS || theme3d === LOOKS.SHOWCASE_LOOKS.classic;
    ground = lit(gGeo, { c: gc, r: 1 }, false, true);
    ground.position.set(cx, groundY, cy);
    const span = Math.ceil(Math.max(sx, sy) / 2 + 30) * 2;
    const toward = new THREE.Color(gc).getHSL({}).l > 0.5 ? 0x000000 : 0xffffff;
    gridLines = today ? new THREE.GridHelper(span, span / 2, 0x2b3730, 0x202a25)
      : new THREE.GridHelper(span, span / 2, new THREE.Color(gc).lerp(_c.set(toward), 0.09), new THREE.Color(gc).lerp(_c.set(toward), 0.04));
    gridLines.position.set(Math.round(cx), groundY + 0.004, Math.round(cy));
    gridLines.material.transparent = true;                   // it fades at night (paintNight)
    shellRes.push(gGeo, gridLines.geometry, gridLines.material);
    scene.add(ground, gridLines);
    stageNow = { box: houseBox, groundY, ground, grid: gridLines };   // Studio, coming on later, stands its stage here
    if (studio) studio.house(stageNow);
    placeSun();
    applyTop();
    paintNight();
    wallPivot = null;
    refindRoom();
    if (!cam.moved) cam.needsFit = true;
  }
  /** The storeys' floor and roof in the look's colours, muted (the Atlas's
   *  look, or Live Aboard's own): a neutral floor (the rooms' own floors
   *  averaged and greyed, so a hall reads as floor in any theme), a slate
   *  roof, a pale fascia. */
  function storeyLook(tiles){
    const side = atlas ? atlas.side : SLAB_SIDE, grey = new THREE.Color("#6b6b6b");
    const hex = (c) => "#" + c.getHexString();
    const avg = tiles && tiles.n ? new THREE.Color(tiles.r / tiles.n, tiles.g / tiles.n, tiles.b / tiles.n) : new THREE.Color(TILE_MIX);
    const lum = 0.2126 * avg.r + 0.7152 * avg.g + 0.0722 * avg.b;
    return { slab: hex(avg.lerp(new THREE.Color(lum, lum, lum), 0.65)), slabSide: side,
             roof: hex(new THREE.Color(atlas ? atlas.side : "#86776a").lerp(grey, 0.5)),
             fascia: hex(new THREE.Color(atlas ? atlas.floor : "#efe9df").lerp(new THREE.Color("#e2ddd4"), 0.5)) };
  }
  /** Stairs are drawn as high as the floor they reach is now (live_aboard_storey.js stairReach). */
  /** The opt-in report on stairs (closed words, once per page load): that the
   *  house has some, whether every flight lands in a room on the level it
   *  reaches (PIECES.stairOutcome, Furnish's own rule), whether one reaches a
   *  split level or is a few steps within a floor, and the shapes and styles
   *  in use. Never where, how many or which. */
  function countStairs(h){
    if (!STOREY || !FURN || !PIECES.stairOutcome) return;
    const list = Object.values((file && file.pieces) || {}).filter(q => STOREY.isStairs(q));
    if (!list.length) return;
    const floors = h.floors.map(f => ({ elev: f.elev, outdoor: f.outdoor, rooms: h.rooms.filter(r => r.floor === f) }));
    let landing = 0, nofloor = 0, split = false, within = false;
    for (const q of list) {
      const r = STOREY.stairReach(h.canon ? h.canon(q.floor_id) : q.floor_id, q.recipe.params && q.recipe.params.to_floor, h.floors, STOREY.footprint(q));
      const out = PIECES.stairOutcome(q, r, floors, FURN, HOUSE.inPoly);
      if (out === "landing") landing++;
      if (out === "nofloor") nofloor++;
      if (r.within) within = true;
      else if (r.to && r.to.parent) split = true;
      const params = q.recipe.params || {};
      if (HOUSE.STAIR_SHAPES.includes(params.shape)) HOUSE.countHouse3dOnce(`stairs_shape:${params.shape}`, send);
      if (HOUSE.STAIR_STYLES.includes(params.style)) HOUSE.countHouse3dOnce(`stairs_style:${params.style}`, send);
    }
    HOUSE.countHouse3dOnce("stairs_drawn", send);
    HOUSE.countHouse3dOnce(`stairs_outcome:${nofloor ? "some_nofloor" : landing ? "some_landing" : "all_ok"}`, send);
    if (split) HOUSE.countHouse3dOnce("stairs_reach:split_level", send);
    if (within) HOUSE.countHouse3dOnce("stairs_reach:within", send);
  }
  function stairRecipe(p){
    if (!STOREY || !STOREY.isStairs(p) || !house) return p.recipe;
    const r = STOREY.stairReach(house.canon ? house.canon(p.floor_id) : p.floor_id, p.recipe.params && p.recipe.params.to_floor, house.floors,
                                STOREY.footprint(p));
    // The ⋯ list's Railings hides a stair's rails too, its spindles and posts with them (the steps stay).
    if (!shownHere("railings")) return { ...p.recipe, height_m: r.rise, params: { ...(p.recipe.params || {}), rails_shown: false } };
    return { ...p.recipe, height_m: r.rise };
  }
  /** A band just inside each room's outline (EDGE_IN to EDGE_IN + EDGE_W in
   *  from it), in the room's colour: one geometry for the floor. */
  const EDGE_IN = 0.07, EDGE_W = 0.09;
  function edgeRibbons(rooms, y, A){
    const pos = [], col = [], W = A ? A.lineW : EDGE_W, ink = A ? new THREE.Color(A.ink) : null;
    for (const r of rooms) {
      const P = r.pts, n = P.length;
      if (n < 3) continue;
      let area = 0;
      for (let i = 0; i < n; i++) { const a = P[i], b = P[(i + 1) % n]; area += a[0] * b[1] - b[0] * a[1]; }
      // The Atlas's look: the room's own colour (inked a little on a light page, as Hygge draws it).
      const side = area > 0 ? 1 : -1, c = A ? (A.light ? colorOf(r.color).lerp(ink, 0.3) : colorOf(r.color)) : colorOf(r.color).lerp(_white, 0.3);
      for (let i = 0; i < n; i++) {
        const a = P[i], b = P[(i + 1) % n], dx = b[0] - a[0], dy = b[1] - a[1], len = Math.hypot(dx, dy);
        if (len < 0.05) continue;
        const nx = -dy / len * side, ny = dx / len * side;                 // into the room
        const q = (p, d) => [p[0] + nx * d, y, p[1] + ny * d];
        const a0 = q(a, EDGE_IN), b0 = q(b, EDGE_IN), a1 = q(a, EDGE_IN + W), b1 = q(b, EDGE_IN + W);
        for (const v of [a0, b0, b1, a0, b1, a1]) { pos.push(...v); col.push(c.r, c.g, c.b); }
      }
    }
    if (!pos.length) return null;
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.BufferAttribute(new Float32Array(pos), 3));
    g.setAttribute("color", new THREE.BufferAttribute(new Float32Array(col), 3));
    return g;
  }
  /** The Atlas's look: a faint line in each plate's colour round the plate,
   *  at its floor's level, as the Atlas outlines its plates (HOUSE.floorBadges:
   *  its colours). It follows the storey's own floor (its rooms, halls filled
   *  in: live_aboard_storey.js plateOutlines), a little way out past the
   *  outside walls. The flat plate's rectangle round all the rooms drew
   *  long lines in the air and out over the yard, well past the house (Garry,
   *  2026-11-06: "lines around floor, something not quite right"). */
  const PLATE_PAD = 0.3, PLATE_OP = 0.5;
  function platesOf(h){
    let badges = [];
    try { badges = HOUSE.floorBadges(lastP && lastP.model, lastP && lastP.floors, h); } catch (_) { badges = []; }
    for (const b of badges) {
      const F = floorsUi.find(q => q.fl === b.floor), loops = storeyL ? storeyL.plates(b.floor.id, PLATE_PAD) : [];
      if (!F || !loops.length) continue;
      const y = b.floor.elev + 0.006, pts = [];
      for (const L of loops) L.forEach((p, i) => { const q = L[(i + 1) % L.length]; pts.push(new THREE.Vector3(p[0], y, p[1]), new THREE.Vector3(q[0], y, q[1])); });
      const g = new THREE.BufferGeometry().setFromPoints(pts);
      const m = new THREE.LineBasicMaterial({ color: b.color, transparent: true, opacity: PLATE_OP, depthWrite: false });
      shellRes.push(g, m);
      F.plate = new THREE.LineSegments(g, m);
      F.plate.userData.n = b.n;
      F.plate.visible = shownHere("floor_outlines");
      F.group.add(F.plate);
    }
  }
  /** How dark it is (nightK), drawn: the floors' colour kept, the outlines,
   *  the wall tops' glow, and fixtures that are off darkened with the house. */
  function paintNight(){
    const k = nightK;
    for (const F of floorsUi) {
      if (F.lift) { F.lift.material.opacity = NIGHT_FLOOR * k; F.lift.visible = k > 0.01; }
      if (F.edges) { F.edges.material.opacity = atlas ? Math.max(atlas.lineOp, NIGHT_EDGE * k) : NIGHT_EDGE * k; F.edges.visible = (!!atlas || k > 0.01) && shownHere("room_outlines"); }
    }
    topGlow.value = NIGHT_TOP * k;
    if (shared && shared.ghostMat) shared.ghostMat.color.set(GHOST_COL).multiplyScalar(1 - 0.5 * k);   // Glass dims with the house
    if (storeyL) storeyL.night(k);                           // the roof keeps a little of its colour
    if (gridLines) gridLines.material.opacity = 1 - NIGHT_GRID * k;
    for (const L of lights) if (L.look) paintLight(L);
    paintWindows();
    requestRender();
  }
  /** At night with the walls up, a window glows warm while a light in the
   *  room behind it is on, stronger the darker it is; otherwise nothing. */
  function paintWindows(){
    // The walls stand: Up, or Cut or Glass while the roof shows (updateCutaway's own rule).
    const k = Math.min(1, Math.max(0, nightK)), on = k > 0.05 && (wallMode === "up" || ((wallMode === "cut" || wallMode === "glass") && !!roofWant));
    const lit = new Set();
    if (on) for (const L of lights) if (L.look && L.look.on && L.F) { const r = HOUSE.roomAt(L.F.rooms, L.x, L.y); if (r) lit.add(r); }
    for (const F of floorsUi) {
      if (!F.glow) continue;
      const key = on ? F.panes.map(r => (r && lit.has(r) ? 1 : 0)).join("") + "|" + k.toFixed(2) : "off";
      if (key === F.glowKey) continue;
      F.glowKey = key;
      F.glow.visible = on;
      if (!on) continue;
      F.panes.forEach((r, i) => F.glow.setColorAt(i, r && lit.has(r) ? _c.set(WINDOW_GLOW).multiplyScalar(k) : _c.set(0x000000)));
      F.glow.instanceColor.needsUpdate = true;
    }
  }
  // The sun's light sits out along the sun's direction from the middle of the
  // house, its shadow box (High) fitted round the house's bounds.
  function placeSun(){
    const b = houseBox, cx = (b.x0 + b.x1) / 2, cy = (b.y0 + b.y1) / 2, cz = (b.z0 + b.z1) / 2;
    const R = Math.hypot(b.x1 - b.x0, b.y1 - b.y0, b.z1 - b.z0) / 2 + 4, dist = R + 40;
    sun.target.position.set(cx, cz, cy);
    sun.target.updateMatrixWorld();
    sun.position.set(cx + sunDir.x * dist, cz + sunDir.y * dist, cy + sunDir.z * dist);
    Object.assign(sun.shadow.camera, { left: -R, right: R, top: R, bottom: -R, near: 1, far: dist + R + 20 });
    sun.shadow.camera.updateProjectionMatrix();
  }
  // The real sun (live_aboard_house.js readSun: sun.sun, else worked out from
  // hass.config, else due south): its direction in the house's own frame by
  // the bearing, its strength and colour by its height; off at night, with a
  // dim cool sky. Drawn again only when it has moved more than SUN_STEP, the
  // phase of the day changed, or north moved. The light's intensity changes,
  // never whether it is there (no shader rebuilds).
  function applySun(p){
    sunRead = HOUSE.readSun(p.states, p.config, Date.now());
    storedBearing = HOUSE.normBearing(p.bearing);
    if (northHold && (storedBearing === northHold.b || Date.now() > northHold.until)) northHold = null;
    if (wakeK > 0 && performance.now() >= wakeUntil) requestRender();   // lit up by a touch, its time up: the frame that fades it back
    return drawSun(bearingNow(), false);
  }
  function drawSun(b, force){
    const s = sunRead || { ...HOUSE.SUN_DEFAULT, source: "default" };
    // Lit up by a touch (wake): drawn as with the sun WAKE_ELEV up, by how far it has faded back.
    const elev = s.elevation + (Math.max(s.elevation, WAKE_ELEV) - s.elevation) * wakeK, look = HOUSE.sunLight(elev);
    nightReal = wakeK ? HOUSE.sunLight(s.elevation).night : look.night;
    const gap = sunNow ? Math.abs(((s.azimuth - sunNow.azimuth) % 360 + 540) % 360 - 180) : Infinity;
    if (!force && sunNow && b === sunNow.bearing && look.phase === sunNow.phase
        && gap <= SUN_STEP && Math.abs(s.elevation - sunNow.elevation) <= SUN_STEP) return false;
    sunNow = { azimuth: s.azimuth, elevation: s.elevation, source: s.source, bearing: b, phase: look.phase, night: look.night };
    bearing = b;
    if (Math.abs(look.night - nightK) > 1e-3) { nightK = look.night; paintNight(); }
    // A setting sun still lights from just above the horizon as it fades,
    // never from under the slabs.
    const d = HOUSE.sunDirection(s.azimuth, Math.max(elev, 2), b);
    sunDir.set(d.x, d.up, d.y).normalize();
    sun.intensity = SUN_I * look.sun;
    sun.color.set(SUN_HIGH).lerp(_c.set(SUN_LOW), look.warm);
    hemi.intensity = SKY_I_DAY + (SKY_I_NIGHT - SKY_I_DAY) * look.night;
    hemi.color.set(SKY_DAY).lerp(_c.set(SKY_NIGHT), look.night);
    hemi.groundColor.set(GROUND_DAY).lerp(_c.set(GROUND_NIGHT), look.night);
    // The Showcase look's sky (Classic: none, and today's brightness).
    if (theme3d) { if (theme3d.skyMix) hemi.color.lerp(_c.set(theme3d.sky), theme3d.skyMix); hemi.intensity *= theme3d.ambient; }
    placeSun();
    if (studio) studio.sun(look, sunDir);                    // Studio: its sky and light follow the sun
    roseDeg = null;
    requestRender();
    return true;
  }
  // The compass rose: where north shows on screen in this view (degrees,
  // clockwise from up, -180..180), the same arithmetic a spun needle is read
  // back through (live_aboard_house.js needleAngle / bearingFromNeedle).
  function paintCompass(){
    if (!rose) return;
    const a = HOUSE.needleAngle(bearing, cam.theta, cam.phi), deg = a > 180 ? a - 360 : a;
    if (roseDeg !== null && Math.abs(((deg - roseDeg) % 360 + 540) % 360 - 180) < 0.5) return;
    roseDeg = deg;
    rose.setAttribute("transform", `rotate(${deg.toFixed(1)})`);
  }

  // ── north: the compass you spin ───────────────────────────────────────────
  // Press the compass and drag round it, with a mouse or one finger: the
  // needle follows, and wherever it points on screen is where north is in this
  // view, in any view (the needle's angle and the camera give the bearing
  // through fabric_compass.js's inverse). The sun and its shadows follow as it
  // turns, so north can be lined up with the real shadows; nothing is saved.
  // On release a "Save north · Cancel" pill: Save writes the bearing alone
  // through the host (settings.fabric_bearing_deg, the GPS Bridge's own), then
  // "North saved · Undo"; Cancel, Escape or a tap anywhere else puts it all
  // back. A stray touch on the wall PC cannot move north. A tap, under
  // SPIN_SLOP of movement, turns the view north-up as before; a press while a
  // finger is on the house is that gesture's, never a spin.
  const bearingNow = () => (northPreview !== null ? northPreview : northHold ? northHold.b : storedBearing);
  function spinDown(e){
    e.stopPropagation();
    e.preventDefault();
    if (e.pointerType === "mouse" && e.button !== 0) return;
    if (spin) { endSpin(true); return; }                     // a second finger on the compass: no spin
    if (camPts.size) return;                                  // a finger on the house: its gesture
    const r = compassEl.getBoundingClientRect();
    spin = { id: e.pointerId, x0: e.clientX, y0: e.clientY, cx: r.left + r.width / 2, cy: r.top + r.height / 2,
             moved: false, before: northPreview, unhook: null };
    try { compassEl.setPointerCapture(e.pointerId); } catch (_) { /* the window listeners carry it anyway */ }
    // On the window, so a spin outlives a poll moving the view into a new card.
    const move = guard((ev) => spinMove(ev)), up = guard((ev) => spinUp(ev));
    const cancel = guard((ev) => { if (spin && ev.pointerId === spin.id) endSpin(true); });
    window.addEventListener("pointermove", move, true);
    window.addEventListener("pointerup", up, true);
    window.addEventListener("pointercancel", cancel, true);
    spin.unhook = () => {
      window.removeEventListener("pointermove", move, true);
      window.removeEventListener("pointerup", up, true);
      window.removeEventListener("pointercancel", cancel, true);
    };
  }
  function spinMove(ev){
    if (!spin || ev.pointerId !== spin.id) return;
    if (!spin.moved && Math.hypot(ev.clientX - spin.x0, ev.clientY - spin.y0) < SPIN_SLOP) return;
    if (!spin.moved && root) for (const t of root.querySelectorAll(".la3d-toast")) t.remove();   // an old Undo goes
    spin.moved = true;
    const a = Math.atan2(ev.clientX - spin.cx, -(ev.clientY - spin.cy)) * 180 / Math.PI;
    northPreview = HOUSE.normBearing(HOUSE.bearingFromNeedle(a, cam.theta, cam.phi));
    drawSun(northPreview, false);
  }
  function spinUp(ev){
    if (!spin || ev.pointerId !== spin.id) return;
    const moved = spin.moved;
    endSpin(false);
    if (moved) showPill();
    else {                                                     // a tap: north up
      cam.moved = true; cam.needsFit = false;
      turnBy(HOUSE.northUpTheta(bearingNow()) - cam.theta);
      cam.theta = HOUSE.northUpTheta(bearingNow());
      applyCam();
    }
  }
  /** The press is over; abort puts the needle back where this press found it. */
  function endSpin(abort){
    const s0 = spin;
    spin = null;
    if (!s0) return;
    if (s0.unhook) s0.unhook();
    try { if (compassEl && compassEl.hasPointerCapture && compassEl.hasPointerCapture(s0.id)) compassEl.releasePointerCapture(s0.id); }
    catch (_) { /* released already */ }
    if (abort && s0.moved) { northPreview = s0.before; drawSun(bearingNow(), true); }
  }
  function showPill(){
    if (!pill) return;
    pill.classList.add("on");
    for (const b of pillBtns) b.disabled = false;
    if (unhookNorth) return;
    const onKey = guard((e) => { if (e.key === "Escape") cancelNorth(); });
    const onDown = guard((e) => {
      const path = typeof e.composedPath === "function" ? e.composedPath() : [];
      // That touch only puts north back: on the house it presses nothing.
      if (!path.includes(pill) && !path.includes(compassEl)) { northDismissed = e; cancelNorth(); }
    });
    document.addEventListener("keydown", onKey, true);
    document.addEventListener("pointerdown", onDown, true);
    unhookNorth = () => {
      document.removeEventListener("keydown", onKey, true);
      document.removeEventListener("pointerdown", onDown, true);
      unhookNorth = null;
    };
  }
  function hidePill(){
    if (pill) pill.classList.remove("on");
    if (unhookNorth) unhookNorth();
  }
  function cancelNorth(){
    endSpin(false);
    hidePill();
    if (northPreview === null) return;
    northPreview = null;
    drawSun(bearingNow(), true);
  }
  function saveNorth(){
    if (northPreview === null) { hidePill(); return; }
    const b = northPreview, was = northHold ? northHold.b : storedBearing, save = saveNorthCb;
    if (typeof save !== "function") { cancelNorth(); toast("North can't be saved from here", null); return; }
    for (const x of pillBtns) x.disabled = true;
    Promise.resolve().then(() => save(b)).then(guard(() => {
      northHold = { b, until: Date.now() + NORTH_HOLD_MS };
      northPreview = null;
      hidePill();
      drawSun(bearingNow(), true);
      toast("North saved", () => undoNorth(was, save));
    }), guard(() => {
      for (const x of pillBtns) x.disabled = false;
      toast("Could not save north", null);
    }));
  }
  function undoNorth(was, save){
    Promise.resolve().then(() => save(was)).then(guard(() => {
      northHold = { b: was, until: Date.now() + NORTH_HOLD_MS };
      drawSun(bearingNow(), true);
      toast("North put back", null);
    }), guard(() => toast("Could not put north back", null)));
  }
  // A note over the view that fades out by itself (CSS), with an action.
  function toast(text, act, word = "Undo"){
    if (!root) return;
    for (const old of root.querySelectorAll(".la3d-toast")) old.remove();
    const t = document.createElement("div");
    t.className = "la3d-toast";
    t.setAttribute("role", "status");
    const span = document.createElement("span");
    span.textContent = text;
    t.appendChild(span);
    if (act) {
      const b = document.createElement("button");
      b.type = "button"; b.textContent = word;
      b.addEventListener("click", guard((e) => { e.stopPropagation(); t.remove(); act(); }));
      t.appendChild(b);
    }
    t.addEventListener("animationend", () => t.remove());
    root.appendChild(t);
  }
  // High's ambient occlusion, baked rather than a post-process pass: a soft
  // shade on the floor along the foot of every wall (both sides of an inside
  // wall, the inside of an outside one), one mesh per floor, shown on High.
  function aoMesh(F){
    const pos = [], uv = [], idx = [];
    const strip = (P, side) => {
      const pc = P.pc, dx = pc.x1 - pc.x0, dy = pc.y1 - pc.y0, L = Math.hypot(dx, dy);
      if (L < 0.1) return;
      const nx = pc.nx * side, ny = pc.ny * side, o = pc.thick / 2, y = F.fl.elev + 0.004;
      const a0 = [pc.x0 + nx * o, pc.y0 + ny * o], a1 = [pc.x1 + nx * o, pc.y1 + ny * o];
      const b0 = [a0[0] + nx * AO_W, a0[1] + ny * AO_W], b1 = [a1[0] + nx * AO_W, a1[1] + ny * AO_W];
      const base = pos.length / 3;
      pos.push(a0[0], y, a0[1], a1[0], y, a1[1], b1[0], y, b1[1], b0[0], y, b0[1]);
      uv.push(0, 1, 1, 1, 1, 0, 0, 0);
      idx.push(base, base + 1, base + 2, base, base + 2, base + 3);
    };
    for (const P of F.pieces) {
      const k = P.pc.kind;
      if (k === "rail" || k === "open" || k === "doorway") continue;
      if (P.pc.cls === "ext" && !P.pc.free) strip(P, -1);
      else { strip(P, 1); strip(P, -1); }
    }
    if (!idx.length) return null;
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3));
    g.setAttribute("uv", new THREE.Float32BufferAttribute(uv, 2));
    g.setIndex(idx);
    const m = new THREE.MeshBasicMaterial({ color: 0x000000, map: shared.aoTex, transparent: true, depthWrite: false,
      side: THREE.DoubleSide, polygonOffset: true, polygonOffsetFactor: -1, polygonOffsetUnits: -2 });
    shellRes.push(g, m);
    const mesh = new THREE.Mesh(g, m);
    mesh.renderOrder = 1;
    mesh.visible = !!profileOf().ao;
    return mesh;
  }
  // A wall piece's instances at full height, or cut down to CUT_H; a linked
  // leaf as open as its sensor has it.
  /** How many of an instanced mesh's slots are placed (not out of sight): the harness. */
  function countPlaced(im){ let n = 0; for (let i = 0; i < im.count; i++) { im.getMatrixAt(i, _m); if (_m.elements[0] || _m.elements[5] || _m.elements[10]) n++; } return n; }
  function placePiece(F, P, cut){
    const glass = wallMode === "glass";
    for (const e of P.els) {
      // Glass: a window's pane stays whole (the window still shows in the glass wall).
      const down = cut && e.cuttable && !(glass && e.glass);
      let z1 = down ? Math.min(e.z1, HOUSE.CUT_H) : e.z1, full = e.z1;
      if (F.clip !== undefined && F.clip !== null) {                   // applyTop: under the hidden floors
        if (z1 > F.clip + 0.3) z1 = Math.max(e.z0, F.clip);
        if (full > F.clip + 0.3) full = Math.max(e.z0, F.clip);
      }
      const hgt = z1 - e.z0;
      e.mesh.setMatrixAt(e.i, hgt < 0.005 || goneHere(P, e) ? ZERO : P.open && e === P.open.leaf ? (P.open.slots ? ZERO : leafMatrix(F, P, e.z0, hgt, e.thick))
        : compose(P.mx, F.fl.elev + e.z0, P.my, P.yaw, P.len, hgt, e.thick));
      e.mesh.instanceMatrix.needsUpdate = true;
      // What Cut took off a wall (never a door's leaf: its doorway stays open), as glass.
      if (F.ghost && e.mesh === F.solid) {
        const g0 = Math.max(e.z0, z1), gh = glass && down && !e.leaf ? full - g0 : 0;
        F.ghost.setMatrixAt(e.i, gh < 0.005 ? ZERO : compose(P.mx, F.fl.elev + g0, P.my, P.yaw, P.len, gh, e.thick));
        F.ghost.instanceMatrix.needsUpdate = true;
      }
    }
    if (P.open && P.open.wet) placeWet(F, P, cut && !glass);
    if (P.open && P.open.slots) placePanels(F, P, cut);
    if (P.open && P.open.flash) placeFlash(F, P, cut);
  }

  // ── doors, windows and locks with sensors (part B) ────────────────────────
  // A barrier linked to a sensor is an opening (live_aboard_house.js
  // openingKind): its leaf — a door's, or a window's pane — opens and shuts
  // with the sensor as the Atlas reads it (openingState), a door swinging
  // in about a hinge on the left, a window opening a little way, a garage
  // door rolling up into its head; no reading is the Atlas's grey, shut; an
  // unlocked lock flashes red. Hinge and swing are the defaults until the 3D
  // file says otherwise (part C hands its openings[<barrier id>] to
  // openingSwing; nothing here ever writes it).
  function setupOpening(F, P, rooms){
    const b = P.pc.barrier, k = P.pc.kind, len = Math.hypot(P.pc.x1 - P.pc.x0, P.pc.y1 - P.pc.y0);
    // What drives a door: the 3D file's own link (a cover or a contact
    // sensor, live_aboard_storey.js), else the map's.
    const link = STOREY && k === "door" && P.pc.override && typeof P.pc.override.link === "string" ? P.pc.override.link : null;
    if (!link && (!b || !b.linked_entity_id)) { if (STOREY && k === "door") standDoor(P, rooms, len); return; }
    const o = { bar: link ? { ...(b || {}), id: (b && b.id) || P.pc.added, linked_entity_id: link, invert_state: HOUSE.sensorInverted(lastP && lastP.model, link) } : b,
                eid: link || String(b.linked_entity_id), kind: k, leaf: null, len, hinge: null, side: null,
                garage: false, state: null, at: 0, to: 0, from: 0, t0: 0, flash: null };
    if (k === "open") {
      // A gap (material "open") has no leaf: it keeps its reading and its
      // tap target all the same, a doorway's height of it, and its
      // threshold reads as the Atlas's line does (closed grey, open
      // nothing, no reading the dashed grey).
      const sill = P.els[0];
      if (!sill) return;
      Object.assign(o, { sill, span: { z0: 0, z1: Math.min(HOUSE.DOOR_H, F.fl.h - HOUSE.SLAB_T), thick: P.pc.thick } });
    } else {
      const leaf = P.els.find(e => e.leaf);
      if (!leaf || (k !== "door" && k !== "window")) return;
      const sw = HOUSE.openingSwing(P.pc, rooms, P.pc.override || null);
      Object.assign(o, { leaf, hinge: sw.hinge, side: sw.side, garage: k === "door" && len > 1.8 });
      if (STOREY && k === "door") typeDoor(o, P, rooms);
    }
    P.open = o;
    openings.push({ F, P });
  }
  // A door's type (live_aboard_storey.js doorTypeOf: stored, else PadSpan's
  // guess, by the class of what it follows), what drives it (a cover
  // follows its position), and a lock linked to it. A type other than
  // hinged draws its own panels (typedPanels) instead of the wall's one leaf.
  function typeDoor(o, P, rooms){
    const t = STOREY.doorTypeOf(P.pc, rooms, classOf(o.eid));
    o.garage = false;
    o.t = t;
    o.cover = STOREY.linkKind(o.eid, lastP && lastP.states ? lastP.states[o.eid] : null) === "cover";
    o.lock = (P.pc.barrier && P.pc.barrier.linked_lock_entity_id) || null;
    o.lockState = null;
  }
  /** The device class of what a door follows (its guess goes by it; the
   *  door's sheet asks the same). */
  function classOf(eid){
    const dl = eid ? lbe[eid] : null, st = eid && lastP && lastP.states ? lastP.states[eid] : null;
    return (dl && dl.device_class) || (st && st.attributes && st.attributes.device_class) || null;
  }
  // A door with no sensor stands as its sheet says (live_aboard_storey.js
  // doorShown): ajar inside, shut on an outside wall or as a garage door,
  // unless set open, ajar or shut. It never moves, so it asks for no frame
  // (it is not one of `openings`).
  function standDoor(P, rooms, len){
    const leaf = P.els.find(e => e.leaf);
    if (!leaf) return;
    const shown = STOREY.doorShown(P.pc), sw = HOUSE.openingSwing(P.pc, rooms, P.pc.override || null), t = STOREY.doorTypeOf(P.pc, rooms);
    const at = STOREY.shownAt(t.type, shown);                // ajar: its swing at 70°, a slider half way, a garage door a quarter up
    P.open = { bar: P.pc.barrier, eid: null, kind: "door", leaf, len, hinge: sw.hinge, side: sw.side, garage: false, state: null, shown, t,
               at, to: at, max: STOREY.DOOR_ANGLE_DEG[shown] * D2R, from: 0, t0: 0, flash: null, still: true };
  }
  // ── doors of a type (live_aboard_storey.js doorPanels) ───────────────────
  // One instanced mesh per floor holds every typed door's panels; each door
  // keeps its own slots (slots: [first, count]) and moves them as it opens.
  function typedPanels(F){
    let n = 0;
    for (const P of F.pieces) {
      const o = P.open;
      if (!o || !o.t || o.t.type === "hinged" || !o.leaf) continue;
      o.slots = [n, panelsOf(F, P, 0).length];
      n += o.slots[1];
    }
    if (!n) return;
    const spec = { c: "#ffffff", r: 0.8 };
    const im = new THREE.InstancedMesh(shared.prim.box, mat(spec), n);
    im.userData.spec = spec;
    im.castShadow = true; im.receiveShadow = true; im.frustumCulled = false;
    shellRes.push({ dispose: () => im.dispose() });
    F.group.add(im);
    F.panels = im;
    for (const P of F.pieces) if (P.open && P.open.slots) tintPanels(F, P, P.open.state === "none");
  }
  function panelsOf(F, P, a){
    const o = P.open;
    return STOREY.doorPanels(o.t, a, o.len, Math.max(0.3, o.leaf.z1 - Math.max(0, o.leaf.z0)), P.pc.thick, o.max ?? DOOR_OPEN, o.hinge === "b",
                             F.fl.h - HOUSE.SLAB_T);
  }
  const _pq = new THREE.Quaternion(), _pq2 = new THREE.Quaternion(), _pp = new THREE.Vector3(), _ps = new THREE.Vector3(), _pm = new THREE.Matrix4();
  const X_AXIS = new THREE.Vector3(1, 0, 0);
  /** One panel in the world: the door's frame runs from its end a along to
   *  b (u), across toward the side it opens to (v), and up. Cut away, what
   *  stands keeps under CUT_H and what lies flat goes. */
  function panelMatrix(F, P, q, cut){
    const pc = P.pc, o = P.open, L = o.len || 1, ux = (pc.x1 - pc.x0) / L, uy = (pc.y1 - pc.y0) / L;
    const vx = pc.nx * o.side, vy = pc.ny * o.side, vs = Math.sign(vx * -uy + vy * ux) || 1;
    let z = q.c[2], h = q.size[1];
    if (cut) {
      if (q.pitch) return ZERO;
      const top = Math.min(z + h / 2, HOUSE.CUT_H), bot = z - h / 2;
      if (top - bot < 0.01) return ZERO;
      h = top - bot; z = (top + bot) / 2;
    }
    _pq.setFromAxisAngle(Y_AXIS, HOUSE.yawOf([ux, uy]) - vs * q.yaw).multiply(_pq2.setFromAxisAngle(X_AXIS, vs * q.pitch));
    _pp.set(pc.x0 + ux * q.c[0] + vx * q.c[1], F.fl.elev + z, pc.y0 + uy * q.c[0] + vy * q.c[1]);
    return _pm.compose(_pp, _pq, _ps.set(Math.max(0.005, q.size[0]), Math.max(0.005, h), Math.max(0.005, q.size[2])));
  }
  function placePanels(F, P, cut){
    const o = P.open, im = F.panels;
    if (!im || !o.slots) return;
    const a = o.at * o.at * (3 - 2 * o.at), list = panelsOf(F, P, a), gone = !!o.leaf && goneHere(P, o.leaf);
    for (let i = 0; i < o.slots[1]; i++) im.setMatrixAt(o.slots[0] + i, list[i] && !gone ? panelMatrix(F, P, list[i], cut) : ZERO);
    im.instanceMatrix.needsUpdate = true;
  }
  // A door linked to a cover follows it (live_aboard_storey.js coverAt): its
  // position, proportional (40 is 40% open), moving toward open or shut
  // while it says opening or closing. A tap never moves it.
  function paintCoverDoor(F, P){
    const o = P.open, st = lastP && lastP.states ? lastP.states[o.eid] : null, c = STOREY.coverAt(st);
    const key = `${c.at}|${c.moving}|${c.none}`;
    if (key === o.coverKey) return false;
    const first = o.coverKey === undefined;
    o.coverKey = key;
    o.state = c.none ? "none" : c.moving || c.at > 0.005 ? "open" : "closed";
    // No reading is neither open nor shut: it stays where it was, greyed.
    const to = c.none ? o.at : c.moving ? (c.moving > 0 ? 1 : 0) : c.at;
    if (first) { o.at = o.to = to; }
    else { o.from = o.at; o.to = to; o.t0 = performance.now(); o.ms = Math.max(300, Math.abs(to - o.at) * (c.moving ? STOREY.COVER_TRAVEL_MS : STOREY.COVER_STEP_MS)); }
    const e = o.leaf;
    if (o.slots) tintPanels(F, P, c.none);
    else if (e) { e.mesh.setColorAt(e.i, _c.set(c.none ? NO_READING : e.col)); e.mesh.instanceColor.needsUpdate = true; }
    placePiece(F, P, !!P.cut);
    return true;
  }
  // A door of a type draws its own panels in place of the leaf, so the
  // Atlas's grey for no reading goes on them (as on a hinged leaf), and
  // each panel's own colour comes back with a reading.
  function tintPanels(F, P, none){
    const o = P.open, im = F.panels;
    if (!im || !o.slots) return;
    const list = panelsOf(F, P, 0);
    for (let i = 0; i < o.slots[1]; i++) im.setColorAt(o.slots[0] + i, _c.set(none ? NO_READING : STOREY.panelColour(list[i] || {})));
    if (im.instanceColor) im.instanceColor.needsUpdate = true;
  }
  // The leaf at o.at (0 shut, 1 open), eased: about its hinge, or up into
  // its head for a garage door. Shut, it is exactly the piece's own place.
  function leafMatrix(F, P, z0, hgt, thick){
    const o = P.open, pc = P.pc, a = o.at * o.at * (3 - 2 * o.at);
    if (o.garage) {
      const up = a * Math.max(0, hgt - 0.2);
      return compose(P.mx, F.fl.elev + z0 + up, P.my, P.yaw, P.len, hgt - up, thick);
    }
    const hb = o.hinge === "b", hx = hb ? pc.x1 : pc.x0, hy = hb ? pc.y1 : pc.y0;
    const ux = ((hb ? pc.x0 : pc.x1) - hx) / o.len, uy = ((hb ? pc.y0 : pc.y1) - hy) / o.len;
    const ang = a * (o.kind === "window" ? WINDOW_OPEN : (o.max ?? DOOR_OPEN)), c = Math.cos(ang), s = Math.sin(ang);
    const dx = c * ux + s * pc.nx * o.side, dy = c * uy + s * pc.ny * o.side;
    return compose(hx + dx * o.len / 2, F.fl.elev + z0, hy + dy * o.len / 2, HOUSE.yawOf([dx, dy]), o.len, hgt, thick);
  }
  // An unlocked lock: a glow over its shut leaf, its colour and strength
  // set on the frame (animateLive); nothing while locked.
  function placeFlash(F, P, cut){
    const o = P.open, e = o.leaf || o.span, m = o.flash;
    if ((o.state !== "unlocked" && o.lockState !== "unlocked") || !shownHere("locks")) m.matrix.copy(ZERO);
    else {
      const z1 = cut ? Math.min(e.z1, HOUSE.CUT_H) : e.z1;
      m.matrix.copy(compose(P.mx, F.fl.elev + e.z0 - 0.01, P.my, P.yaw, P.len + 0.04, z1 - e.z0 + 0.03, e.thick + 0.05));
    }
    m.matrixWorldNeedsUpdate = true;
  }
  const OPEN_WORD = { open: "Open", closed: "Closed", locked: "Locked", unlocked: "Unlocked", none: "No reading" };
  /** A lock linked to a door (the barrier's linked_lock_entity_id) is shown
   *  on it: unlocked, the door glows as an unlocked lock does. */
  function paintLock(F, P){
    const o = P.open, ls = HOUSE.openingState(null, lbe[o.lock]);
    if (ls === o.lockState) return false;
    o.lockState = ls;
    if (ls === "unlocked") {
      o.liveUntil = performance.now() + LIVE_MS;
      if (!o.flash) { o.flash = new THREE.Mesh(shared.glassBox, shared.flashMat); o.flash.matrixAutoUpdate = false; o.flash.renderOrder = 4; F.group.add(o.flash); }
    }
    if (o.flash) placeFlash(F, P, !!P.cut);
    return true;
  }
  function paintOpenings(){
    let changed = false;
    for (const { F, P } of openings) {
      const o = P.open, dl = lbe[o.eid];
      if (o.lock && paintLock(F, P)) changed = true;           // a lock linked to the door, whatever drives it
      if (o.cover) { if (paintCoverDoor(F, P)) changed = true; continue; }
      if (o.kind === "door" && dl && dl.device_class === "garage_door" && !o.t) o.garage = true;
      const st = HOUSE.openingState(o.bar, dl);
      if (st === o.state) continue;
      const first = o.state === null;
      if (st === "unlocked") o.liveUntil = performance.now() + LIVE_MS;   // a flash just started
      o.state = st;
      // No reading: a door of a type stays where it was, greyed (a hinged
      // leaf still shuts grey, as it always has).
      o.to = st === "none" && o.slots ? o.at : st === "open" ? 1 : 0;
      if (first || !o.leaf) o.at = o.to;                   // the first look is how it is, not a swing (a gap never swings)
      else { o.from = o.at; o.t0 = performance.now(); o.ms = o.t && STOREY ? STOREY.moveMs(o.t.type) : SWING_MS; }   // a swing, timed on the clock (animateLive)
      if (o.slots) tintPanels(F, P, st === "none");
      const e = o.leaf || o.sill;
      e.mesh.setColorAt(e.i, _c.set(st === "none" ? NO_READING : !o.leaf && st !== "open" ? SHUT_LINE : e.col));
      e.mesh.instanceColor.needsUpdate = true;
      if (st === "unlocked" && !o.flash) {
        o.flash = new THREE.Mesh(shared.glassBox, shared.flashMat);
        o.flash.matrixAutoUpdate = false;
        o.flash.renderOrder = 4;
        F.group.add(o.flash);
      }
      placePiece(F, P, !!P.cut);
      changed = true;
    }
    return changed;
  }

  // ── the lights ────────────────────────────────────────────────────────────
  function clearLights(){
    for (const F of floorsUi) { if (F.lightGroup) F.group.remove(F.lightGroup); F.lightGroup = null; for (const P of F.pieces) P.lights = []; }
    disposeList(lightRes); lightRes = [];
    lights = [];
  }
  function buildLights(h){
    clearLights();
    work.lights++;
    for (const F of floorsUi) {
      // By id: a lights-only rebuild reads the floors afresh (same ids).
      const mine = h.lights.filter(L => L.floor.id === F.fl.id);
      if (!mine.length) continue;
      const lg = new THREE.Group();
      F.lightGroup = lg;
      F.group.add(lg);
      const bulbs = { puck: [], dome: [], box: [], sphere: [] }, houses = [], halos = { s: [], m: [], l: [] }, pools = [], floorMarks = [];
      const washes = { fade: [], scallop: [], round: [] };
      const vdP = viewData().pieces || {}, furniture = Object.values(vdP).filter(p => p && (h.canon ? h.canon(p.floor_id) : String(p.floor_id)) === F.fl.id);
      const ctx = { rooms: F.rooms, pieces: F.pieces.map(P => P.pc), ground: h.ground, furniture };
      const zs = viewData().lights;
      const pieceOf = (pc) => (pc ? F.pieces.find(q => q.pc === pc) || null : null);
      for (const L0 of mine) {
        // What it is: the kind set in Live Aboard (the 3D file), else PadSpan's guess.
        const guess = HOUSE.drawnKind(L0, ctx), set = HOUSE.storedKind(zs[L0.eid]);
        // Moved whole to its height in the 3D file, if it has one (part C).
        // Laid out with the Strip tool: drawn along its run (on a piece: where the piece stands now).
        const own = RUNS.readRun(zs[L0.eid]), run = RUNS.placed(own, vdP), on = run && own.piece ? vdP[own.piece] : null;
        // Under the ceiling of the room it is in (a tall room's own), else the floor's.
        const ceil0 = HOUSE.ceilAt(F.rooms, F.fl, L0.x, L0.y) - HOUSE.SLAB_T;
        const lift = run ? DRAFT.liftParts(HOUSE.fixtureParts({ ...L0, kind: set || L0.kind, run, pieceAt: on ? [on.x_m, on.y_m] : null }, ctx), null, ceil0)
          : DRAFT.liftParts(HOUSE.fixtureParts(set ? { ...L0, kind: set } : L0, ctx), zs[L0.eid], ceil0), parts = lift.parts;
        const L = { ...L0, F, kf: parts.kf, drawn: parts.kind, guess, wall: null, refs: { bulbs: [], houses: [], halos: [], washes: [], pools: [] },
                    key: null, look: null, z: lift.z, zDefault: lift.zDefault, spin: null };
        // A wall it hangs on (or a part of it does: a cove's sides) repaints it as it is cut.
        const onWall = (pc) => { const P = pieceOf(pc); if (P && !P.lights.includes(L)) P.lights.push(L); return P; };
        if (parts.wall) L.wall = onWall(parts.wall);
        let sx = 0, sy = 0, sh = 0;
        for (const b of parts.bulbs) {
          const sk = seenK(b, parts.bulbs.length);
          const m = b.mat ? lift3(b.mat, F.fl.elev) : compose(b.x, F.fl.elev + b.h, b.y, b.yaw, b.sx * sk, b.sy * sk, b.sz * sk).clone();
          L.refs.bulbs.push({ prim: b.prim, i: bulbs[b.prim].length, off: new THREE.Color(b.off), m, hideOff: !!b.hideOff, wall: onWall(b.wall) });
          bulbs[b.prim].push({ m, off: b.off, hideOff: !!b.hideOff });
          sx += b.x; sy += b.y; sh += b.h;
        }
        for (const hh of parts.housings) { L.refs.houses.push({ i: houses.length, hh }); houses.push(hh); }
        for (const hl of parts.halos) { L.refs.halos.push({ cls: hl.cls, i: halos[hl.cls].length }); halos[hl.cls].push(hl); }
        for (const w of parts.washes) { L.refs.washes.push({ tex: w.tex, i: washes[w.tex].length, w, wall: onWall(w.wall) }); washes[w.tex].push(w); }
        // Where a press finds it: every bulb and glow, and all along a run.
        L.pick = [...parts.bulbs, ...parts.halos, ...parts.picks].map(q => new THREE.Vector3(q.x, F.fl.elev + q.h, q.y));
        if (parts.poolH !== null) for (const pl of parts.pools) { L.refs.pools.push(pools.length); pools.push({ h: parts.poolH, ...pl }); }
        // On a cut-away wall its fixture is gone but its glow still lands on the floor: pressed there.
        L.poolPick = parts.poolH !== null ? parts.pools.map(pl => new THREE.Vector3(pl.at[0], F.fl.elev + parts.poolH, pl.at[1])) : [];
        // A ceiling light under a covered patio's cover (parts.under): from above it
        // shows only on its floor, past the cover's edge, so it is pressed there too
        // (under each bulb), its pool marking it while on and a small ring while off.
        if (parts.under) {
          L.floorPick = parts.bulbs.map(b => new THREE.Vector3(b.x, F.fl.elev + FLOOR_MARK_UP, b.y));
          L.refs.marks = parts.bulbs.map(b => floorMarks.push({ x: b.x, y: b.y, off: new THREE.Color(b.off) }) - 1);
        }
        // A ceiling fan's blades turn while it runs.
        if (parts.spin) L.spin = { x: parts.spin.x, y: parts.spin.y, angle: 0, rps: 0, blades: parts.spin.blades.map(b => ({ a: b.a, r: b.r, ref: L.refs.houses[b.i] })) };
        const n = Math.max(1, parts.bulbs.length), mh = sh / n;
        L.lamp = parts.lamp ? new THREE.Vector3(parts.lamp[0], F.fl.elev + parts.lamp[2], parts.lamp[1])   // a run: off its wall, into the room
          : new THREE.Vector3(sx / n, F.fl.elev + (mh > 1.5 ? mh - 0.3 : mh + 0.35), sy / n);
        // Where its button stands ("Lights as buttons"): the middle of its bulbs, else where it is pressed.
        L.at = parts.bulbs.length ? new THREE.Vector3(sx / n, F.fl.elev + mh, sy / n) : L.pick[0] || null;
        lights.push(L);
      }
      // Each bulb twice: lit (glowing whatever the room's light) and off
      // (shaded like the room, and half see-through so a trim or a dark
      // strip recedes at night); paintLight shows one.
      F.bulbs = {}; F.bulbsOff = {};
      for (const [prim, list] of Object.entries(bulbs)) {
        if (!list.length) continue;
        const spec = { r: 0.7, tr: true, op: OFF_OP };
        const im = new THREE.InstancedMesh(shared.prim[prim], shared.bulbMat, list.length);
        const dark = new THREE.InstancedMesh(shared.prim[prim], mat(spec), list.length);
        dark.userData.spec = spec;
        list.forEach((b, i) => {
          im.setMatrixAt(i, ZERO); im.setColorAt(i, offColour(_c.set(b.off)));
          dark.setMatrixAt(i, b.hideOff ? ZERO : b.m); dark.setColorAt(i, offColour(_c.set(b.off)));
        });
        for (const x of [im, dark]) { x.frustumCulled = false; lightRes.push({ dispose: () => x.dispose() }); lg.add(x); }   // instances come and go with their walls
        F.bulbs[prim] = im; F.bulbsOff[prim] = dark;
      }
      if (houses.length) {
        const spec = { r: 0.6 };
        const im = new THREE.InstancedMesh(shared.prim.box, mat(spec), houses.length);
        im.userData.spec = spec; im.castShadow = true;
        houses.forEach((b, i) => { im.setMatrixAt(i, b.mat ? lift3(b.mat, F.fl.elev) : compose(b.x, F.fl.elev + b.h, b.y, b.yaw, b.sx, b.sy, b.sz)); im.setColorAt(i, _c.set(b.col)); });
        lightRes.push({ dispose: () => im.dispose() });
        lg.add(F.houses = im);
      }
      F.halos = {};
      for (const [cls, list] of Object.entries(halos)) {
        if (!list.length) continue;
        const pos = new Float32Array(list.length * 3), col = new Float32Array(list.length * 3);
        list.forEach((hl, i) => pos.set([hl.x, F.fl.elev + hl.h, hl.y], i * 3));
        const g = new THREE.BufferGeometry();
        g.setAttribute("position", new THREE.BufferAttribute(pos, 3));
        g.setAttribute("color", new THREE.BufferAttribute(col, 3));
        const pts = new THREE.Points(g, shared.haloMats[cls]);
        pts.renderOrder = 5; pts.frustumCulled = false;
        lightRes.push(g);
        lg.add(F.halos[cls] = pts);
      }
      // Light on the walls, the counters and the deck: dark until painted.
      F.washes = {};
      for (const [tex, list] of Object.entries(washes)) {
        if (!list.length) continue;
        const im = new THREE.InstancedMesh(shared.washGeo, shared.washMats[tex], list.length);
        list.forEach((w, i) => { im.setMatrixAt(i, washMatrix(w, F.fl.elev)); im.setColorAt(i, _c.setRGB(0, 0, 0)); });
        im.renderOrder = 3; im.frustumCulled = false;
        lightRes.push({ dispose: () => im.dispose() });
        lg.add(F.washes[tex] = im);
      }
      F.marks = null;
      if (floorMarks.length) {
        const im = new THREE.InstancedMesh(floorMarkMat().geo, floorMarkMat().mat, floorMarks.length);
        floorMarks.forEach((fm, i) => { im.setMatrixAt(i, ZERO); im.setColorAt(i, offColour(_c.copy(fm.off))); fm.m = compose(fm.x, F.fl.elev + FLOOR_MARK_UP, fm.y, 0, FLOOR_MARK_R, 1, FLOOR_MARK_R).clone(); });
        im.renderOrder = 2; im.frustumCulled = false;
        lightRes.push({ dispose: () => im.dispose() });
        lg.add(F.marks = im);
        F.markList = floorMarks;
      }
      F.pool = null;
      if (pools.length) {
        const im = new THREE.InstancedMesh(shared.poolGeo, shared.poolMat, pools.length);
        pools.forEach((pl, i) => {
          _m.set(pl.a[0], 0, pl.b[0], pl.at[0], 0, 1, 0, F.fl.elev + pl.h, pl.a[1], 0, pl.b[1], pl.at[1], 0, 0, 0, 1);
          im.setMatrixAt(i, _m); im.setColorAt(i, _c.setRGB(0, 0, 0));
        });
        im.renderOrder = 2; im.frustumCulled = false;
        lightRes.push({ dispose: () => im.dispose() });
        lg.add(F.pool = im);
      }
    }
    lampsDirty = true;
  }
  /** A part's own matrix (a run's tape or wire, live_aboard_runs.js
   *  boxMatrix: the floor's frame), on its floor. */
  function lift3(mat, elev){
    const m = new THREE.Matrix4().fromArray(mat);
    m.elements[13] += elev;
    return m;
  }
  /** A wash's quad: from its line (w.x, w.h, w.y) along ±a, out along b
   *  (both [x, up, y], plan metres). */
  function washMatrix(w, elev){
    const a = w.a, b = w.b;
    _p.set(a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]).normalize();
    return _m.set(2 * a[0], b[0], _p.x, w.x, 2 * a[1], b[1], _p.y, elev + w.h, 2 * a[2], b[2], _p.z, w.y, 0, 0, 0, 1);
  }
  // One light's look, painted: the bulb lit or shaded, the glow, the washes,
  // the pools, a fan's speed. A switch changes these values only — what is
  // drawn never changes.
  const _white = new THREE.Color(1, 1, 1);
  /** A fixture that is off: with the Atlas's look, leaning to the theme's
   *  dark fixture (fixtureOffFill), its parts still told apart. */
  const OFF_LEAN = 0.35, _c2 = new THREE.Color();
  function offColour(c){ return atlas ? c.lerp(_c2.set(atlas.offFill), OFF_LEAN) : c; }
  function paintLight(L){
    // The ⋯ list's Light glow off: the bulbs only, no pool, glow or wash.
    const F = L.F, k = L.look, on = k.on, hidden = !!(L.wall && L.wall.cut) || !!L.swap, glow = (theme3d ? theme3d.glow : 1) * (shownHere("glow") ? 1 : 0);
    const c = new THREE.Color().setRGB(k.rgb[0], k.rgb[1], k.rgb[2], THREE.SRGBColorSpace);
    L.color = c; L.f = k.f;
    const core = on ? c.clone().lerp(_white, 0.35).multiplyScalar(0.55 + 0.45 * k.f) : null;
    // Another class picked on the chips (☰): it fades toward the ground, its glow with it.
    const dk = dimOf(L.eid) ? MARKS.DIM_K : 1;
    if (core && dk < 1) core.lerp(scene.background, 1 - dk);
    const gone = (r) => hidden || !!(r.wall && r.wall.cut);
    for (const r of L.refs.bulbs) {
      const lit = F.bulbs[r.prim], dark = F.bulbsOff[r.prim], show = !gone(r);
      lit.setMatrixAt(r.i, show && on ? r.m : ZERO);
      dark.setMatrixAt(r.i, show && !on && !r.hideOff ? r.m : ZERO);
      if (on) lit.setColorAt(r.i, core);
      else dark.setColorAt(r.i, offColour(_c.copy(r.off)).multiplyScalar(k.unavailable ? 0.55 : 1).lerp(scene.background, 1 - dk));   // lit like the room: at night it darkens with it
      for (const im of [lit, dark]) { im.instanceColor.needsUpdate = true; im.instanceMatrix.needsUpdate = true; }
    }
    // The fixture's body (a fan's blades too) fades with it while another class is picked.
    if (F.houses && L.refs.houses.length) {
      for (const r of L.refs.houses) F.houses.setColorAt(r.i, _c.set(r.hh.col).lerp(scene.background, 1 - dk));
      F.houses.instanceColor.needsUpdate = true;
    }
    for (const r of L.refs.halos) {
      const attr = F.halos[r.cls].geometry.attributes.color, g = on && !hidden ? k.f * 0.95 * glow * dk : 0;
      attr.setXYZ(r.i, c.r * g, c.g * g, c.b * g);
      attr.needsUpdate = true;
    }
    for (const r of L.refs.washes) {
      const g = on && !gone(r) ? k.f * WASH_K * glow * dk : 0;
      F.washes[r.tex].setColorAt(r.i, _c.setRGB(c.r * g, c.g * g, c.b * g));
      F.washes[r.tex].instanceColor.needsUpdate = true;
    }
    // Under a covered patio's cover: the small ring on its floor, while off.
    if (F.marks && L.refs.marks) {
      for (const i of L.refs.marks) {
        F.marks.setMatrixAt(i, on || hidden ? ZERO : F.markList[i].m);
        F.marks.setColorAt(i, offColour(_c.copy(F.markList[i].off)).multiplyScalar(k.unavailable ? 0.55 : 1).lerp(scene.background, 1 - dk));
      }
      F.marks.instanceMatrix.needsUpdate = true; F.marks.instanceColor.needsUpdate = true;
    }
    if (F.pool) {
      const g = on ? k.f * POOL_K * glow * dk : 0;
      for (const i of L.refs.pools) F.pool.setColorAt(i, _c.setRGB(c.r * g, c.g * g, c.b * g));
      F.pool.instanceColor.needsUpdate = true;
    }
    // A fan turns at its speed (the Furnish fan's), slower on Low.
    if (L.spin) {
      const look = on && !hidden && DEVICES ? DEVICES.deviceLook("spin", "fan", L.eid, { state: "on", attributes: {} }, lbe[L.eid] || L.l) : null;
      L.spin.base = look ? look.rps : 0;
      L.spin.rps = L.spin.base * fanK(quality.profile || quality.measuring);
    }
  }
  const fanK = (profile) => profile === "high" ? 1 : 0.5;
  /** Turn the fans that run, on the clock (t: performance.now()). */
  let fanLast = null;
  function turnFans(t){
    const now = lights.filter(L => L.spin && L.spin.rps > 0 && L.F.group.visible && L.F.houses);
    if (!now.length) { fanLast = null; return; }               // starting again: no leap for the time at rest
    const dt = fanLast === null ? 0 : Math.min(0.25, Math.max(0, (t - fanLast) / 1000));
    fanLast = t;
    for (const L of now) {
      const S = L.spin, F = L.F;
      S.angle = (S.angle + S.rps * 2 * Math.PI * dt) % (2 * Math.PI);
      for (const b of S.blades) {
        const hh = b.ref.hh, a = b.a + S.angle, d = [Math.cos(a), Math.sin(a)];
        F.houses.setMatrixAt(b.ref.i, compose(S.x + d[0] * b.r, F.fl.elev + hh.h, S.y + d[1] * b.r, HOUSE.yawOf(d), hh.sx, hh.sy, hh.sz));
      }
      F.houses.instanceMatrix.needsUpdate = true;
    }
  }
  /** The poll: repaint only the lights whose look changed. */
  function paintLights(lightsByEid){
    let changed = false;
    for (const L of lights) {
      const look = HOUSE.lightLook((lightsByEid && lightsByEid[L.eid]) || L.l);
      const key = HOUSE.lookKey(look);
      if (key === L.key) continue;
      L.key = key; L.look = look;
      paintLight(L);
      changed = true;
    }
    if (changed) { lampsDirty = true; requestRender(); }
    return changed;
  }
  function assignLamps(){
    lampsDirty = false;
    lampTarget.copy(cam.target);
    const n = shownHere("glow") ? profileOf().lamps : 0;    // Light glow off (the ⋯ list): no lamp lights the rooms
    // A fixture with a piece of its own (P5) lights from the piece's bulb.
    const cands = lights.filter(L => L.look && L.look.on && L.kf > 0 && L.F.group.visible && !L.swap)
      .map(L => ({ pos: L.lamp, color: L.color, k: L.f * L.kf * (dimOf(L.eid) ? MARKS.DIM_K : 1) }))
      .concat(devices ? devices.lamps() : [])
      .sort((a, b) => a.pos.distanceToSquared(cam.target) - b.pos.distanceToSquared(cam.target));
    lampPool.forEach((pl, i) => {
      const c = i < n ? cands[i] : null;
      if (!c) { pl.intensity = 0; return; }
      pl.position.copy(c.pos);
      pl.color.copy(c.color);
      pl.intensity = LAMP_I * c.k;
    });
  }

  // ── furniture that is a device (P5) ───────────────────────────────────────
  /** What each linked piece shows now (live_aboard_devices.js); a fixture
   *  whose device a piece is steps aside for it (in 3D only: where the light
   *  is placed is never touched); and while the Atlas's emergency lighting
   *  test runs (p.emergency: its lights), each one is outlined. */
  function syncDevices(p, vd){
    if (!devices) return;
    const em = Array.isArray(p.emergency) && p.emergency.length ? new Set(p.emergency.map(String)) : null;
    let changed = devices.sync(piecesNow(vd.pieces), { states: p.states || {}, regIds: p.regIds || null, entities: p.entities || null, lbe, emergency: em,
                                            dim: classF ? dimOf : null, dimK: MARKS ? MARKS.DIM_K : 1 });
    for (const L of lights) {
      const s = devices.has(L.eid, L.drawn === "fan" || (L.l && L.l.isFan) ? "spin" : "glow");
      if (s !== !!L.swap) { L.swap = s; L.key = null; changed = true; }
    }
    if (outlineFixtures(em)) changed = true;
    if (changed) { lampsDirty = true; requestRender(); }
  }
  function outlineFixtures(em){
    const want = em ? lights.filter(L => em.has(L.eid) && !L.swap && L.pick && L.pick.length && L.F.lightGroup) : [];
    const key = `${work.lights}:${want.map(L => L.eid).join(",")}`;
    if (key === emKey) return false;
    emKey = key;
    for (const o of emOutlines) if (o.parent) o.parent.remove(o);
    emOutlines = want.map(L => {
      const o = devices.outline(new THREE.Box3().setFromPoints(L.pick).expandByScalar(0.14));
      L.F.lightGroup.add(o);
      return o;
    });
    return true;
  }

  // ── beacons, scanners and people (P6) ─────────────────────────────────────
  /** p.people (only while Show people is on): {snapshot() (the live snapshot
   *  the host already holds, Mapping), or read() → Promise (through
   *  the host, the sidebar) with everyMs (never more often than Overview
   *  polls)}. A read happens on a card the Atlas builds, and by the view's
   *  own clock (peopleClock) while it shows: the same gate for both. */
  function syncTracked(p, vd, rebuilt){
    if (!tracked) return;
    // p.tags (only while Show tags & scanners is on) is the same reader: one
    // read serves both layers.
    const on = (x) => !!(x && typeof x === "object");
    const pp = on(p.people) ? p.people : on(p.tags) ? p.tags : null;
    if (!pp) { peopleSnap = null; peopleAt = 0; peopleLoad = null; }
    else if (typeof pp.snapshot === "function") { peopleSnap = pp.snapshot() || null; peopleReads++; }
    else if (typeof pp.read === "function") readPeople(pp);
    const tr = trailReader(p);
    if (!tr) { trailData = null; trailAt = 0; trailLoad = null; }
    else readTrails(tr);
    if (tracked.sync({ model: p.model, looks: vd.devices, figures: vd.figures, snapshot: pp ? peopleSnap : null,
                       states: p.states || {}, people: on(p.people), tags: on(p.tags), scanners: p.scanners,
                       carries: p.settings3d ? p.settings3d.atlas_3d_carries : null, trails: tr ? trailData : null }, rebuilt)) requestRender();
    if (panel) panel.peopleChanged();
    peopleClock();
  }
  /** One read of the live snapshot through the host, never sooner than
   *  everyMs (and never under PEOPLE_MS) after the last; drawn once it is in. */
  function readPeople(pp){
    if (peopleLoad || Date.now() - peopleAt < Math.max(PEOPLE_MS, Number(pp.everyMs) || 0)) return;
    peopleAt = Date.now();
    peopleReads++;
    const mine = peopleLoad = Promise.resolve().then(() => pp.read()).then((snap) => {
      if (peopleLoad !== mine) return;
      peopleLoad = null; peopleSnap = snap && typeof snap === "object" ? snap : null;
      if (lastP && renderer && !failed) syncTracked(lastP, viewData(), false);
    }, () => { if (peopleLoad === mine) peopleLoad = null; });
  }
  /** The host's Traceback reader (p.trails: {read(msg) → Promise}) while
   *  people or tags are drawn and this screen has Trails on, else null. */
  function trailReader(p){
    const on = (x) => !!(x && typeof x === "object");
    if (!TRAILS || !p || !(on(p.people) || on(p.tags)) || prefGet(PREF_TRAILS) !== "1") return null;
    return on(p.trails) && typeof p.trails.read === "function" ? p.trails : null;
  }
  /** Can this screen have Trails (a reader, and people or tags drawn)? */
  function trailsOffered(){
    const p = lastP, on = (x) => !!(x && typeof x === "object");
    return !!(TRAILS && p && (on(p.people) || on(p.tags)) && on(p.trails) && typeof p.trails.read === "function");
  }
  /** The last half hour from Traceback, never sooner than TRAIL_MS after the
   *  last read (it rides the people read's own clock); drawn once it is in. */
  function readTrails(tr){
    if (trailLoad || (trailAt && Date.now() - trailAt < TRAILS.TRAIL_MS)) return;
    trailAt = Date.now();
    trailReads++;
    const mine = trailLoad = Promise.resolve().then(() => tr.read(TRAILS.trailRequest(Date.now() / 1000))).then((r) => {
      if (trailLoad !== mine) return;
      trailLoad = null;
      trailData = TRAILS.trailsOf(r && Array.isArray(r.frames) ? r.frames : [], Date.now() / 1000);
      if (lastP && renderer && !failed) syncTracked(lastP, viewData(), false);
    }, () => { if (trailLoad === mine) trailLoad = null; });
  }
  function toggleTrails(){
    prefSet(PREF_TRAILS, prefGet(PREF_TRAILS) === "1" ? "0" : "1");
    trailAt = 0; trailLoad = null;
    if (lastP && renderer && !failed) syncTracked(lastP, viewData(), false);
  }
  /** The host's reader ({read(), everyMs}) while Show people or Show tags &
   *  scanners is on, else null (a {snapshot()} host has its own data). */
  function liveReader(){
    const p = lastP, on = (x) => !!(x && typeof x === "object");
    const pp = !p ? null : on(p.people) ? p.people : on(p.tags) ? p.tags : null;
    return pp && typeof pp.snapshot !== "function" && typeof pp.read === "function" ? pp : null;
  }
  /** The view's own clock for that read, so people and tags move in Mapping
   *  too, where no poll rebuilds the card: every everyMs, the sidebar's own
   *  interval, only while the view shows with a reader. Hidden (Map picked,
   *  the page or the panel out of sight), switched off, or the card gone: it
   *  stops, and starts again when the view shows. */
  function peopleClock(){
    if (peopleTimer !== null) { clearTimeout(peopleTimer); peopleTimer = null; }
    const pp = liveReader();
    if (!pp || !stage || !tracked || failed || !shouldDraw()) return;
    const wait = Math.max(0, Math.max(PEOPLE_MS, Number(pp.everyMs) || 0) - (Date.now() - peopleAt));
    peopleTimer = setTimeout(guard(() => {
      peopleTimer = null;
      const q = liveReader();
      if (q && stage && tracked && shouldDraw()) readPeople(q);
      peopleClock();
    }), wait + 25);
  }

  // ── sensors: motion, Motion · Air, the readouts (part B) ──────────────────
  // Placed sensors only, as on the Atlas. Motion is live_aboard_motion.js's
  // (a ring on a new trigger, the room's floor glowing in the Atlas's motion
  // colours, the sensor on its wall and its marker, its coverage); without
  // that file, a small sensor near the ceiling whose room pulses in the
  // Atlas's colours on its clocks (live_aboard_house.js motionLook), with the
  // ring sweeping out from under it. Poor air rises in bars across
  // its room's floor (airLook). Temperature, humidity and air float as
  // readouts, read-only. Each sits at its height above its floor: a default
  // by its type (deviceZ — part C's 3D file replaces it per device).
  function clearSensors(){
    for (const F of floorsUi) { if (F.sensorGroup) F.group.remove(F.sensorGroup); F.sensorGroup = null; }
    disposeList(sensorRes); sensorRes = [];
    sensorsUi = []; tints = []; readouts = []; chips = []; heats = [];
    if (motionL) motionL.clear();
  }
  function buildSensors(h){
    clearSensors();
    work.sensors++;
    for (const F of floorsUi) {
      const mine = (h.sensors || []).filter(S => S.floor.id === F.fl.id);
      if (!mine.length) continue;
      const g = new THREE.Group();
      F.sensorGroup = g;
      F.group.add(g);
      const motion = [], here = [], zs = viewData().devices;
      for (const S0 of mine) {
        const ceil = HOUSE.ceilAt(F.rooms, F.fl, S0.x, S0.y) - HOUSE.SLAB_T;
        const z = HOUSE.deviceZ(S0.kind, ceil, zs[S0.eid] || null);
        const S = { ...S0, F, z, zDefault: HOUSE.deviceZ(S0.kind, ceil, null), pos: new THREE.Vector3(S0.x, F.fl.elev + z, S0.y),
                    room: HOUSE.roomAt(F.rooms, S0.x, S0.y), shown: null,
                    lp: ((lastP && lastP.model && lastP.model.light_positions_m) || {})[S0.eid] || null };
        sensorsUi.push(S); here.push(S);
        if (S.kind === "motion") motion.push(S); else readouts.push(S);
      }
      if (motion.length && !motionL) {
        const im = new THREE.InstancedMesh(shared.prim.sphere, shared.bulbMat, motion.length);
        motion.forEach((S, i) => {
          im.setMatrixAt(i, compose(S.x, S.pos.y, S.y, 0, 0.055, 0.04, 0.055));
          im.setColorAt(i, _c.set(SENSOR_QUIET));
          S.mesh = im; S.i = i;
        });
        im.frustumCulled = false;
        sensorRes.push({ dispose: () => im.dispose() });
        g.add(im);
      }
      // One tint per room with motion or air in it; a motion sensor outside
      // every room pulses its own patch of floor. Air needs a room (as on
      // the Atlas: its bars fill the room the sensor is in).
      const byRoom = new Map();
      for (const S of here) {
        if (S.kind !== "motion" && S.kind !== "air") continue;
        if (S.kind === "motion" && motionL) continue;                  // drawn by live_aboard_motion.js
        if (S.kind === "air" && !S.room) continue;
        const key = S.room || S;
        if (!byRoom.has(key)) byRoom.set(key, { room: S.room, F, at: S, motion: [], air: [] });
        byRoom.get(key)[S.kind].push(S);
      }
      for (const T of byRoom.values()) tints.push(makeTint(T, g));
      // The heat map: one floor per room with a temperature in it, shown only with Temps picked.
      const warmRooms = new Map();
      for (const S of here) if (S.kind === "temp" && S.room) { if (!warmRooms.has(S.room)) warmRooms.set(S.room, []); warmRooms.get(S.room).push(S); }
      for (const [room, list] of warmRooms) heats.push(makeHeat(F, room, list, g));
      // One chip per room for what its sensors read; one each outside.
      const groups = new Map();
      for (const S of here) {
        if (S.kind === "motion") continue;
        const key = S.room || S;
        if (!groups.has(key)) groups.set(key, []);
        groups.get(key).push(S);
      }
      for (const [key, list] of groups) chips.push(makeChip(F, key === list[0] ? null : key, list, g));
    }
    if (motionL) motionL.build(sensorsUi.filter(S => S.kind === "motion"));
  }
  function makeHeat(F, room, list, g){
    const geo = new THREE.ShapeGeometry(new THREE.Shape(room.pts.map(p => new THREE.Vector2(p[0], p[1]))));
    geo.rotateX(Math.PI / 2).translate(0, F.fl.elev + 0.007, 0);
    const mat = new THREE.MeshBasicMaterial({ color: "#22c55e", transparent: true, opacity: HEAT_A, depthWrite: false, side: THREE.DoubleSide,
      polygonOffset: true, polygonOffsetFactor: -1, polygonOffsetUnits: -2 });
    const mesh = new THREE.Mesh(geo, mat);
    mesh.renderOrder = 1;
    mesh.visible = false;
    g.add(mesh);
    sensorRes.push(geo, mat);
    return { F, room, list, mat, mesh, key: null };
  }
  /** Temps picked: each room's floor in its fresh temperature (the mean of its
   *  readouts); a room with none fresh, or any other pick, shows nothing. */
  function paintHeat(){
    const on = classF === "temp", now = Date.now();
    let changed = false;
    for (const H of heats) {
      let sum = 0, n = 0;
      if (on) for (const S of H.list) {
        const l = lbe[S.eid] || S.l, r = l ? HOUSE.readoutOf(l, now) : null, c = r && r.live ? HOUSE.tempC(l) : null;
        if (c !== null) { sum += c; n++; }
      }
      const col = n ? HOUSE.heatColor(sum / n) : null;
      if (col === H.key) continue;
      H.key = col;
      H.mesh.visible = !!col;
      if (col) H.mat.color.set(col);
      changed = true;
    }
    if (changed) requestRender();
  }
  function makeTint(T, g){
    const y = T.F.fl.elev + 0.008;
    const geo = T.room ? new THREE.ShapeGeometry(new THREE.Shape(T.room.pts.map(p => new THREE.Vector2(p[0], p[1]))))
      : new THREE.CircleGeometry(1.2, 32).translate(T.at.x, T.at.y, 0);
    // The air bars run across the plan as they run up the Atlas's screen:
    // v along (x + y), a fifth of the room per bar.
    const pos = geo.attributes.position, uv = new Float32Array(pos.count * 2);
    let lo = Infinity, hi = -Infinity;
    for (let i = 0; i < pos.count; i++) { const s = (pos.getX(i) + pos.getY(i)) / Math.SQRT2; lo = Math.min(lo, s); hi = Math.max(hi, s); }
    const gap = Math.max(0.3, (hi - lo) / 5);
    for (let i = 0; i < pos.count; i++) uv[i * 2 + 1] = (pos.getX(i) + pos.getY(i)) / Math.SQRT2 / gap;
    geo.setAttribute("uv", new THREE.BufferAttribute(uv, 2));
    geo.rotateX(Math.PI / 2).translate(0, y, 0);                       // plan (x, y) -> world (x, ·, y)
    sensorRes.push(geo);
    const flat = { transparent: true, opacity: 0, depthWrite: false, side: THREE.DoubleSide, polygonOffset: true,
                   polygonOffsetFactor: -1, polygonOffsetUnits: -3 };
    T.fillMat = new THREE.MeshBasicMaterial({ ...flat, color: SENSOR_ON });
    const fill = new THREE.Mesh(geo, T.fillMat);
    fill.renderOrder = 1;
    g.add(fill);
    sensorRes.push(T.fillMat);
    T.rings = T.motion.map(S => {
      // The sweep is the active pulse's ring: its colour never changes.
      const mat = new THREE.MeshBasicMaterial({ ...flat, color: HOUSE.motionColor(HOUSE.MOTION_COLOR_STOPS[0][1]) });
      const mesh = new THREE.Mesh(shared.ringGeo, mat);
      mesh.position.set(S.x, y + 0.004, S.y);
      mesh.scale.setScalar(0);
      mesh.renderOrder = 1;
      g.add(mesh);
      sensorRes.push(mat);
      return { S, mesh, mat, on: false };
    });
    if (T.air.length) {
      T.barsTex = shared.barsTex.clone();
      T.barsTex.needsUpdate = true;
      T.barsMat = new THREE.MeshBasicMaterial({ ...flat, map: T.barsTex, color: 0xffffff });
      const bars = new THREE.Mesh(geo, T.barsMat);
      bars.renderOrder = 1;
      g.add(bars);
      sensorRes.push(T.barsTex, T.barsMat);
    }
    T.mLook = null; T.aLook = null; T.mKey = ""; T.aKey = "";
    return T;
  }
  // The readouts: one chip per room under the room's name ("22° · 45% ·
  // Air: Good"); a sensor outside every room has its own chip where it is,
  // with its name ("Deck 15°"). Stale or no reading shows a dash, never a
  // code. Drawn over everything, a size you can read; redrawn only when its
  // words change.
  function makeChip(F, room, sensors, g){
    const c = document.createElement("canvas");
    c.width = READ_W; c.height = READ_C;
    const tex = new THREE.CanvasTexture(c);
    tex.colorSpace = THREE.SRGBColorSpace;
    const mat = new THREE.SpriteMaterial({ map: tex, transparent: true, depthTest: false, depthWrite: false, sizeAttenuation: false });
    const sp = new THREE.Sprite(mat);
    sp.renderOrder = 30;
    g.add(sp);
    sensorRes.push(tex, mat);
    const C = { F, room, sensors, outdoor: !room, sprite: sp, tex, canvas: c, key: null, text: "", pillW: 0.5, px: 0,
                name: room ? null : sensors.map(S => chipName(S)).find(Boolean) || "Outside" };
    for (const S of sensors) S.chip = C;
    placeChip(C);
    return C;
  }
  /** Where a chip sits: under its room's name; outside, amid its sensors. */
  function placeChip(C){
    const i = C.room ? C.F.rooms.indexOf(C.room) : -1;
    if (i >= 0 && C.F.labels[i]) { C.sprite.position.copy(C.F.labels[i].position); C.label = C.F.labels[i]; return; }
    C.label = null;
    const v = new THREE.Vector3();
    for (const S of C.sensors) v.add(S.pos);
    C.sprite.position.copy(v.multiplyScalar(1 / Math.max(1, C.sensors.length)));
  }
  /** A sensor outside every room says where it is: its own name, without the "temperature". */
  function chipName(S){
    const l = lbe[S.eid] || S.l || {};
    const n = String(l.friendly_name || "").replace(/\b(temperature|temp|humidity|air quality|sensor)\b/gi, " ").replace(/\s+/g, " ").trim();
    return n && n.length <= 18 ? n : null;
  }
  const CHIP_ORDER = { temp: 0, humidity: 1, air: 2 };
  function chipParts(C){
    const parts = [];
    for (const S of [...C.sensors].sort((a, b) => (CHIP_ORDER[a.kind] ?? 3) - (CHIP_ORDER[b.kind] ?? 3))) {
      const r = S.shown;
      if (!r) continue;
      const dash = r.kind === "temp" ? "–°" : r.kind === "humidity" ? "–%" : "–";
      const text = r.live ? r.text : dash;
      // The Atlas's look: the air in the Atlas's words ("Air Good", its room sheet's).
      const air = atlas && r.live ? `Air ${airQualityWord(airQualityBadness(lbe[S.eid] || S.l || {}))}` : `Air: ${text}`;
      parts.push({ text: r.kind === "air" ? air : text, color: r.live ? r.color : HOUSE.STALE_INK, live: !!r.live });
    }
    return parts;
  }
  function drawChip(C){
    const parts = chipParts(C), sep = " · ";
    const words = [...(C.name ? [{ text: `${C.name} `, color: "#e2e8f0", live: true }] : [])];
    parts.forEach((q, i) => { if (i) words.push({ text: sep, color: "rgba(226,240,232,0.45)", live: true }); words.push(q); });
    const text = words.map(w => w.text).join("");
    C.text = text.trim();
    const c = C.canvas, g = c.getContext("2d"), A = atlas;
    let px = 38;
    // The Atlas's look: the Atlas's readout face (its digits: monospace, heavy, edged dark) on its chip.
    const font = () => (A ? `800 ${px}px ui-monospace, "Cascadia Mono", Consolas, monospace` : `700 ${px}px system-ui, "Segoe UI", Roboto, sans-serif`);
    const width = () => words.reduce((a, w) => a + g.measureText(w.text).width, 0);
    g.font = font();
    while (px > 22 && width() > READ_W - 40) { px -= 2; g.font = font(); }
    const tw = width(), w = Math.min(READ_W - 4, Math.ceil(tw) + 36), h = READ_C - 8, x0 = (READ_W - w) / 2, y0 = 4;
    g.clearRect(0, 0, READ_W, READ_C);
    if (!words.length) { C.pillW = 0; C.parts = 0; C.tex.needsUpdate = true; return; }
    g.beginPath();
    if (g.roundRect) g.roundRect(x0, y0, w, h, h / 2); else g.rect(x0, y0, w, h);
    if (A) { g.globalAlpha = A.chipOp; g.fillStyle = A.chipBg; g.fill(); g.globalAlpha = 1; }
    else { g.fillStyle = "rgba(6,14,9,0.86)"; g.fill(); }
    g.lineWidth = 2; g.strokeStyle = A ? "rgba(5,13,9,0.35)" : "rgba(226,240,232,0.2)"; g.stroke();
    g.textAlign = "left"; g.textBaseline = "middle"; g.lineJoin = "round";
    let x = (READ_W - tw) / 2;
    for (const q of words) {
      g.globalAlpha = q.live ? 1 : 0.8;
      if (A) { g.lineWidth = px * 0.24; g.strokeStyle = A.chipEdge; g.strokeText(q.text, x, READ_C / 2 + 2); }
      g.fillStyle = q.color;
      g.fillText(q.text, x, READ_C / 2 + 2);
      x += g.measureText(q.text).width;
    }
    g.globalAlpha = 1;
    C.pillW = w / READ_W;
    C.parts = parts.length;
    C.tex.needsUpdate = true;
  }
  /** The poll: what each sensor and opening shows now. */
  function paintLive(){
    let changed = paintOpenings();
    const now = Date.now();
    for (const S of sensorsUi) {
      const l = lbe[S.eid] || S.l;
      if (S.kind === "motion") {
        const look = HOUSE.motionLook(l, now, haStarted);
        S.look = look;
        if (motionL) continue;                                   // its own layer (below)
        // The sensor itself is lit as the Atlas lights its marker (motionActive).
        const col0 = HOUSE.motionActive(l, now, haStarted) ? SENSOR_ON : HOUSE.noReading(l) ? NO_READING : SENSOR_QUIET;
        const col = dimOf(S.eid) ? fadeHex(col0) : col0;
        if (col !== S.col) { S.col = col; S.mesh.setColorAt(S.i, _c.set(col)); S.mesh.instanceColor.needsUpdate = true; changed = true; }
      } else {
        const r = HOUSE.readoutOf(l, now);
        const key = r ? `${r.text}|${r.color}|${r.live}` : "";
        if (r && key !== S.key) { S.key = key; S.shown = r; if (S.chip) S.chip.key = null; changed = true; }
      }
      if (S.kind === "air") S.air = HOUSE.airLook(l);
    }
    for (const C of chips) if (C.key === null) { C.key = "drawn"; drawChip(C); }
    // Motion: the ring, the room's glow, the marker (live_aboard_motion.js).
    if (motionL && house && motionL.sync({ lbe, states: lastP && lastP.states, entities: lastP && lastP.entities, now, haStarted,
                                           t: performance.now(), cls: classF, night: nightK, ground: house.ground })) changed = true;
    // Another class picked on the chips: the Motion chip stands down with motion.
    if (mchip && motionL) mchip.update((classF && classF !== "motion") || !shownHere("motion_rooms") ? [] : motionL.rooms(narrow ? 2 : 3));
    for (const T of tints) {
      // The room shows its most telling sensor: active before quiet, the
      // latest quiet one; the worst air.
      let m = null;
      for (const S of T.motion) {
        const k = S.look;
        if (k && (!m || (k.active && !m.active) || (k.active === m.active && k.elapsed < m.elapsed))) m = k;
      }
      let a = null;
      for (const S of T.air) if (S.air && (!a || S.air.badness > a.badness)) a = S.air;
      const mKey = m ? `${m.active ? 1 : 0}|${m.hue}` : "", aKey = a ? `${a.hue}|${a.dur}|${a.op}` : "";
      const act = !!(m && m.active);
      if (act && !T.act) T.liveUntil = performance.now() + LIVE_MS;  // a pulse just started
      T.act = act;
      if (mKey !== T.mKey) {
        T.mKey = mKey;
        if (m) T.fillMat.color.set(HOUSE.motionFill(m));
        changed = true;
      }
      for (const R of T.rings) {
        const on = !!(R.S.look && R.S.look.active);
        if (on !== R.on) { R.on = on; changed = true; }
      }
      if (aKey !== T.aKey) { T.aKey = aKey; if (a && T.barsMat) T.barsMat.color.set(HOUSE.airColor(a.hue)); changed = true; }
      T.mLook = m; T.aLook = a;
    }
    // The box over the house says what is there now (a door just opened):
    // on the next frame, once the new card is on the page. What changed is
    // set at once, still or at the start of its pulse (animateLive).
    if (changed) { rehoverDue = true; animateLive(performance.now()); requestRender(); }
  }
  /** How often something moving by itself, on a floor that shows, is drawn
   *  (ms; 0: nothing, the view rests). Only while a door or window swings,
   *  and for a pulse's or a lock's flash's first LIVE_MS. A floor the chips
   *  hide costs no frames. */
  function liveRate(now){
    // Rain and snow draw on their own capped clock (live_aboard_weather.js frameMs).
    // A fan turning, a washer running (P5): on their own capped clock too.
    const wxMs = wx ? wx.frameMs() : 0, own = AMBIENT_MS[quality.profile || quality.measuring || "low"];
    // Someone walking (P6) too.
    // A ceiling fan turning, as a Furnish fan does.
    const fans = DEVICES && lights.some(L => L.spin && L.spin.rps > 0 && L.F.group.visible)
      ? DEVICES.DEVICE_MS[quality.profile === "high" ? "high" : "low"] : 0;
    const rates = [wxMs, devices ? devices.rate() : 0, tracked ? tracked.rate() : 0, fans, marks ? marks.rate() : 0,
                   motionL ? motionL.rate() : 0, panel ? panel.rate() : 0, raisedL ? raisedL.rate() : 0].filter(Boolean);
    const slow = rates.length ? Math.min(...rates) : 0;
    const fast = slow ? Math.min(own, slow) : own;
    if (storeyL && storeyL.moving) return fast;                // the roof lifting away or coming back
    for (const { F, P } of openings) {
      const o = P.open;
      if (F.group.visible && (o.at !== o.to || ((o.state === "unlocked" || o.lockState === "unlocked") && now < o.liveUntil))) return fast;
    }
    for (const T of tints) if (T.act && T.F.group.visible && now < T.liveUntil) return fast;
    return slow;
  }
  /** The frame: the Atlas's clocks, played (t: performance.now()). */
  function animateLive(t){
    let flashing = false, flashLive = false;
    for (const { F, P } of openings) {
      const o = P.open;
      if (o.state === "unlocked" || o.lockState === "unlocked") { flashing = true; if (t < o.liveUntil) flashLive = true; }
      if (o.at === o.to) continue;
      // On the clock, not by frames: a slow screen swings it as fast (a
      // door that lifts, or a cover travelling, takes its own time: o.ms).
      const k = Math.min(1, Math.max(0, (t - o.t0) / (o.ms || SWING_MS)));
      o.at = k >= 1 ? o.to : o.from + (o.to - o.from) * k;
      placePiece(F, P, !!P.cut);
    }
    if (flashing) {
      // After its start, a still glow halfway between the flash's dim and its peak.
      const k = flashLive ? HOUSE.lockFlashAt(t) : 0.5;
      shared.flashMat.color.set(HOUSE.LOCK_FLASH.from).lerp(_c.set(HOUSE.LOCK_FLASH.to), k);
      shared.flashMat.opacity = HOUSE.LOCK_FLASH.op[0] + (HOUSE.LOCK_FLASH.op[1] - HOUSE.LOCK_FLASH.op[0]) * k;
    }
    const P0 = HOUSE.MOTION_PULSE;
    for (const T of tints) {
      // A pulse plays for its first LIVE_MS, then shows still, as a room
      // breathing after motion does; the air's bars stand still.
      // A room open: the other rooms' motion and air colours fade with their floors.
      const m = T.mLook, play = !!(T.act && t < T.liveUntil), rk = level === "room" && !(openRoom && T.F === openRoom.F && T.room === openRoom.r) ? ROOM_FADE : 1;
      T.fillMat.opacity = (!m ? 0 : play ? HOUSE.cycleAt(P0.fill, P0.ms, t) * FILL_K
        : m.active ? STILL.active * FILL_K : STILL.recent * RECENT_K) * tintK(T.motion) * rk;
      for (const R of T.rings) {
        if (!R.on || !play) { R.mesh.scale.setScalar(0); R.mat.opacity = 0; continue; }
        const r = HOUSE.cycleAt(P0.ringR, P0.ms, t) * RING_R0;
        R.mesh.scale.set(r, 1, r);
        R.mat.opacity = HOUSE.cycleAt(P0.ringA, P0.ms, t) * tintK(T.motion);
      }
      if (T.barsMat) T.barsMat.opacity = T.aLook ? Math.min(1, T.aLook.op * AIR_K) * tintK(T.air) * rk : 0;
    }
    if (wx) wx.tick(t);                                       // rain and snow: the clock, to the GPU
    if (devices) devices.tick(t);                             // fans, washers, robots out
    if (marks) marks.tick(t);                                 // a leak's ripples
    if (motionL) motionL.tick(t);                             // a trigger's ring, its coverage's flash
    if (raisedL) raisedL.tick(t);                             // what stands on a line, moving clear of a word
    turnFans(t);                                              // ceiling fans that run
    if (tracked) tracked.tick(t);                             // people walking
    if (panel) panel.tick(t);                                 // the camera after someone followed
    liveMs = liveRate(t);
  }
  // Readouts keep to a size you can read, and so do the rooms' names, whatever the zoom.
  function sizeSprites(){
    sizeNames(camera, canvas.clientHeight || 600);
    sizeMarks();
  }
  /** The names (and each room's chip under its name) for camera `c` over a view `H` px high. */
  const _v2 = new THREE.Vector3();
  function sizeNames(c, H){
    const xGapNow = explodeGap();
    const persp = !!c.isPerspectiveCamera, k = persp ? 2 * Math.tan(FOV / 2 * D2R) / H : (c.top - c.bottom) / H;
    const mppAt = (v) => (persp ? c.position.distanceTo(v) * k : k);           // metres per px there
    // Drawn over the fixtures, a name must still not show through a wall
    // standing in front of it or a floor above it: one ray from the eye.
    // A split level's own floor never hides its names with its floor (open
    // over a sunken room), nor with its walls round the level's own rooms (a
    // sunken garage's name stands just under Main's floor, among them); the
    // floor's other walls still do (2026-10-29).
    const walled = persp ? floorsUi.filter(G => G.group.visible && G.solid) : [];
    const above = (F) => (persp ? walled.filter(G => G.fl.id !== F.fl.parent).map(G => G.solid)
      .concat(floorsUi.filter(G => G !== F && G.group.visible && !G.fl.outdoor && G.tiles
                              && G.fl.elev > F.fl.elev + 0.5 && G.fl.id !== F.fl.parent).map(G => G.tiles)) : []);
    const parentWalls = (F) => (persp && F && F.fl.parent ? walled.filter(G => G.fl.id === F.fl.parent).map(G => G.solid) : []);
    const ownEdge = (F, x, y) => F.rooms.some(r => Array.isArray(r.pts) && r.pts.some((a, i) => {
      const b = r.pts[(i + 1) % r.pts.length];
      return HOUSE.segDist(x, y, a[0], a[1], b[0], b[1])[0] <= OWN_WALL_M;
    }));
    const behind = (v, occ, F = null) => {
      const pw = parentWalls(F);
      if (!occ.length && !pw.length) return false;
      _v.copy(v).sub(c.position);
      const d = _v.length();
      _hit.set(c.position, _v.normalize());
      _hit.near = 0; _hit.far = Math.max(0, d - 0.05);
      if (occ.length && _hit.intersectObjects(occ, false).length > 0) return true;
      return pw.length > 0 && _hit.intersectObjects(pw, false).some(hp => !ownEdge(F, hp.point.x, hp.point.z));
    };
    const wallK = wallUiOf(root);
    for (const F of floorsUi) {
      if (!F.group.visible) continue;
      const occ = above(F);
      F.labels.forEach((lbl, li) => {
        const u = lbl.userData;
        if (!u.home) u.home = lbl.position.clone();
        lbl.position.copy(u.home);
        const mpp = mppAt(lbl.position), roomPx = u.ext / mpp;
        const letters = Math.max(NAME_PX[0] * wallK, Math.min(NAME_PX[1] * wallK, roomPx / 9)), hPx = letters / u.letters, wPx = hPx * u.aspect;
        if (persp) u.behind = !u.covered && (underRoof(F, lbl.position) || behind(lbl.position, occ, F));
        // Exploded, a storey above can hang over a room's middle while the
        // rest of it shows: the name moves toward a corner that is in view.
        if (persp && u.behind && xGapNow && F.rooms[li]) {
          for (const q of F.rooms[li].pts) {
            _v2.set(u.home.x + (q[0] - u.home.x) * 0.55, u.home.y, u.home.z + (q[1] - u.home.z) * 0.55);
            if (!underRoof(F, _v2) && !behind(_v2, occ, F)) { lbl.position.copy(_v2); u.behind = false; break; }
          }
        }
        lbl.visible = !quiet && level !== "house" && shownHere("room_names") && !u.covered && !(persp && u.behind) && wPx - 28 * hPx / 68 <= roomPx * 1.15;   // the plan: no wall stands in front
        // A room open: the other rooms' names fade with their floors.
        const op = (u.op ?? 1) * (level === "room" && !isOpen(F, li) ? ROOM_FADE : 1);
        if (lbl.material.opacity !== op) lbl.material.opacity = op;
        u.px = lbl.visible ? hPx : 0;
        lbl.scale.set(wPx * k, hPx * k, 1);
        lbl.center.set(0.5, 0.5 + (u.dy || 0) / hPx);         // moved clear of another word (wordUnits)
      });
    }
    for (const C of chips) {
      if (!C.F.group.visible) continue;
      if (C.label) C.sprite.position.copy(C.label.position);   // under its name, wherever the name went
      const mpp = mppAt(C.sprite.position);
      const hPx = Math.max(READ_PX[0] * wallK, Math.min(READ_PX[1] * wallK, READ_H / mpp)) * READ_C / (READ_C - 8);
      C.sprite.scale.set(hPx * READ_W / READ_C * k, hPx * k, 1);
      C.px = hPx;
      centreChip(C);
      if (persp && !C.label) C.behind = underRoof(C.F, C.sprite.position) || behind(C.sprite.position, above(C.F), C.F);
      C.sprite.visible = !quiet && level !== "house" && !!C.parts && !(C.label ? C.label.userData.covered || (persp && C.label.userData.behind) : persp && C.behind);
      // A room open: the other rooms' readouts fade (over what the class chips leave of them).
      C.fk = level === "room" && !(openRoom && C.F === openRoom.F && C.room === openRoom.r) ? ROOM_FADE : 1;
      const op = (C.clsOp ?? 1) * C.fk;
      if (C.sprite.material.opacity !== op) C.sprite.material.opacity = op;
    }
  }
  /** Where a chip sits on its spot: under its room's name (or where the name
   *  would be), clear of it; moved with its name, or alone where no name
   *  shows (wordUnits). */
  function centreChip(C){
    const hPx = C.px;
    if (!hPx) return;
    const nameH = C.label ? Math.max(C.label.userData.px, 18) : 0;
    const dy = (C.label && C.label.visible ? C.label.userData.dy : C.dy) || 0;
    C.sprite.center.set(0.5, (C.label ? 0.5 + (nameH / 2 + 2 + hPx / 2) / hPx : 0.5) + dy / hPx);
  }
  /** Does a floor show above this one? */
  function floorAbove(F){ return floorsUi.some(G => G !== F && G.group.visible && !G.fl.outdoor && G.fl.elev > F.fl.elev + 0.5); }
  /** What stands on a line (live_aboard_raised.js): a motion marker with its
   *  code under it, a tag with its name. */
  function raisedNow(){
    const out = [];
    for (const R of motionL ? motionL.raised() : []) {
      const code = codes ? codes.part(R.id) : null, set = R.set;
      if (code) { R.parts.push(code); R.code = true; }
      R.set = (x, y, z) => { set(x, y, z); if (codes) codes.follow(R.id); };
      out.push(R);
    }
    if (tracked) out.push(...tracked.raised());
    return out;
  }
  /** Every word showing in the house: the rooms' names and readouts, the
   *  codes, tags' names, a leak's alarm, "Unlinked". */
  function wordsNow(){
    const out = [];
    for (const F of floorsUi) {
      if (!F.group.visible) continue;
      F.labels.forEach((l, i) => { if (l.visible) out.push({ ...nameWord(l), owner: null, id: `name ${F.rooms[i].name}` }); });
    }
    for (const C of chips) if (C.F.group.visible && C.sprite.visible) out.push({ ...chipWord(C), owner: null, id: `chip ${C.text}` });
    for (const L of [codes, marks, tracked, devices]) if (L && L.texts) out.push(...L.texts());
    return out;
  }
  /** How much of a name's or a chip's sprite its words fill. */
  const nameWord = (l) => ({ sprite: l, tw: 1 - 28 / (l.userData.aspect * 68), th: l.userData.letters });
  const chipWord = (C) => ({ sprite: C.sprite, tw: C.pillW, th: (READ_C - 8) / READ_C });
  /** The rooms' names, each with the chip under it, then each chip with no
   *  name showing over it: on each other, they move apart on screen
   *  (live_aboard_raised.js spreadWords), the later one in this order moving. */
  function wordUnits(){
    const out = [];
    for (const F of floorsUi) {
      if (!F.group.visible) continue;
      F.labels.forEach((l, i) => {
        if (!l.visible) return;
        const C = chips.find(x => x.label === l && x.sprite.visible), u = l.userData;
        out.push({ id: `name ${F.fl.id} ${F.rooms[i].name}`, h: u.px, dy: u.dy || 0, parts: C ? [nameWord(l), chipWord(C)] : [nameWord(l)],
                   set: (dy) => { u.dy = dy; if (u.px) l.center.set(0.5, 0.5 + dy / u.px); if (C) centreChip(C); } });
      });
    }
    chips.forEach((C, i) => {
      if (!C.F.group.visible || !C.sprite.visible || (C.label && C.label.visible)) return;
      out.push({ id: `chip ${i} ${C.room ? C.room.name : C.name}`, h: C.px, dy: C.dy || 0, parts: [chipWord(C)],
                 set: (dy) => { C.dy = dy; centreChip(C); } });
    });
    return out;
  }
  /** Under the roof while it shows: a name, a chip (live_aboard_storey.js). */
  const underRoof = (F, v) => !!(storeyL && storeyL.covers(F, v.x, v.z));
  /** A name (and its room's chip) under a floor showing above it is hidden. */
  function coverNames(){
    const shown = floorsUi.filter(F => F.group.visible);
    for (const F of shown) {
      F.labels.forEach((lbl, i) => {
        const at = F.rooms[i].spot;
        // Exploded, the floors stand apart: what covers a name is only what the eye's ray meets.
        lbl.userData.covered = !explodeGap() && shown.some(G => G !== F && !G.fl.outdoor && G.fl.elev > F.fl.elev + 0.5
          && G.fl.id !== F.fl.parent && G.rooms.some(r => HOUSE.inPoly(at.x, at.y, r.pts)));
      });
    }
  }

  // ── labels by zoom level ──────────────────────────────────────────────────
  // The whole house (every floor, not zoomed in) shows one tag per floor beside
  // it: its name, the lights on, the doors and windows open, the people; no
  // room names, readouts, motion markers, receivers, tags or codes. One floor
  // shows its rooms' names, readouts and markers. A room open (flown into with
  // a double-tap, or zoomed into at room scale) shows its devices' codes, and
  // the other rooms fade. Alarms always show; Edit, Furnish and the Plans
  // tool's map show everything, as ever. Worked out on the frame, only when
  // the level or the room changes.
  function zoomLevel(){
    if (!house || showSuspended()) return "floor";
    if (openRoom) return "room";
    const s = floorSteps;
    return s && s.all && s.names.length > 1 && !SCREEN.pastSolo(cam.radius, fitR) ? "house" : "floor";
  }
  /** Open the room at {F, r} (r0: the camera's distance it opens at). */
  function openRoomOf(at, r0){
    if (!at || !at.F || !at.r) return;
    openRoom = { F: at.F, r: at.r, i: at.F.rooms.indexOf(at.r), name: at.r.name, fid: at.F.fl.id, r0: Math.max(MIN_R, r0), tx: null, tz: null };
    requestRender();
  }
  function closeRoom(){ if (openRoom) { openRoom = null; requestRender(); } }
  /** Zoomed in by hand to room scale with no room open: the room the view is centred on opens. */
  function roomByZoom(){
    if (openRoom || !camera || !house || !MARKS || showSuspended() || !MARKS.codesAt(cam.radius, camera.aspect, FOV, fitR)) return;
    const rc = view3Rect();
    if (rc.width && rc.height) openRoomOf(roomAtScreen(rc.left + rc.width / 2, rc.top + rc.height / 2), cam.radius);
  }
  /** On the frame: the room open closes when zoomed back out or its floor
   *  hides; panned over another room of its floor, that one is open. */
  function checkRoom(){
    const o = openRoom;
    if (!o) return;
    if (showSuspended() || !floorsUi.includes(o.F) || !o.F.group.visible) { openRoom = null; return; }
    if (cam.fly) return;                                   // flying in to it (a double-tap, a chip): open all the way
    if (cam.radius > o.r0 * ROOM_OUT) { openRoom = null; return; }
    if (o.tx === null || Math.hypot(cam.target.x - o.tx, cam.target.z - o.tz) >= 0.5) {
      const first = o.tx === null;
      o.tx = cam.target.x; o.tz = cam.target.z;
      if (first || HOUSE.inPoly(o.tx, o.tz, o.r.pts)) return;
      const r = HOUSE.roomAt(o.F.rooms, o.tx, o.tz);
      if (r && r !== o.r) { o.r = r; o.i = o.F.rooms.indexOf(r); o.name = r.name; }
    }
  }
  /** The house was built again: the room open is found again on the new floors, or closes. */
  function refindRoom(){
    levelKey = null;
    if (!openRoom) return;
    const F = floorsUi.find(G => G.fl.id === openRoom.fid), i = F ? F.rooms.findIndex(r => r.name === openRoom.name) : -1;
    openRoom = i >= 0 ? { ...openRoom, F, r: F.rooms[i], i } : null;
  }
  /** Is this room (F, its index) the one open? */
  const isOpen = (F, i) => !!openRoom && openRoom.F === F && openRoom.i === i;
  /** Motion's markers as this screen and the zoom level show them. */
  const motionShow = () => ({ sensor: shownHere("motion_sensors") && level !== "house", room: shownHere("motion_rooms"), reach: shownHere("motion_reach") });
  /** The level now, and what it shows (only when it or the room open changed). */
  function syncLevel(){
    checkRoom();
    const lv = zoomLevel(), key = `${lv}|${openRoom ? `${openRoom.fid}|${openRoom.i}` : ""}`;
    if (key === levelKey) return;
    levelKey = key; level = lv;
    if (roomChips) roomChips.sync();                         // the open room's chip marked
    if (motionL && motionL.show) motionL.show(motionShow());
    if (tracked && tracked.hideKinds) tracked.hideKinds(lv === "house" ? ["scanner", "beacon"] : []);
    fadeRooms();
    if (motionL && motionL.fade) motionL.fade(lv === "room" && openRoom ? { F: openRoom.F, room: openRoom.r, k: ROOM_FADE } : null);
    if (codes && codes.recheck) codes.recheck();
    if (raisedL) raisedL.touch();
  }
  /** A room open: every other room's floor fades toward the background, and
   *  its own is tinted (one colour upload per floor, on opening and closing;
   *  nothing per frame). */
  function fadeRooms(){
    const bg = scene && scene.background && scene.background.isColor ? _fadeBg.copy(scene.background) : _fadeBg.set(BG);
    for (const F of floorsUi) {
      const a = F.tiles && F.tileSpans ? F.tiles.geometry.attributes.color : null;
      if (!a) continue;
      const want = openRoom ? (openRoom.F === F ? openRoom.i : -1) : null;
      if (want === (F.fadeOf ?? null)) continue;
      if (!F.tileCols) F.tileCols = a.array.slice();
      const arr = a.array, k = 1 - ROOM_FADE;
      arr.set(F.tileCols);
      if (want !== null) {
        F.tileSpans.forEach(([s0, n], i) => {
          const c = i === want ? _tint : bg, m = i === want ? ROOM_TINT_K : k;
          for (let v = s0 * 3; v < (s0 + n) * 3; v += 3) { arr[v] += (c.r - arr[v]) * m; arr[v + 1] += (c.g - arr[v + 1]) * m; arr[v + 2] += (c.b - arr[v + 2]) * m; }
        });
      }
      a.needsUpdate = true;
      F.fadeOf = want;
    }
  }
  /** A floor's tag: its name, and what is on, open and who is there. */
  function tagWords(F, byId){
    const mine = (G) => !!G && (G === F || G.fl.parent === F.fl.id);
    let on = 0, open = 0, ppl = 0;
    for (const L of lights) if (mine(L.F) && L.look && L.look.on && !L.spin) on++;
    for (const { F: G, P } of openings) if (mine(G) && (P.open.kind === "door" || P.open.kind === "window") && P.open.state === "open") open++;
    if (tracked && shownHere("people")) for (const q of tracked.people()) if (mine(byId.get(q.floor))) ppl++;
    const parts = [];
    if (on) parts.push(`${on} ${on === 1 ? "light" : "lights"} on`);
    if (open) parts.push(`${open} open`);
    if (ppl) parts.push(`${ppl} ${ppl === 1 ? "person" : "people"}`);
    return { name: String(F.fl.name || F.fl.id), line: parts.join(" · ") || "Nothing on" };
  }
  /** The whole house: a tag beside each floor, top floor first, never on each
   *  other (each lower one keeps below the one over it). A tap shows that floor
   *  alone. Placed only on a frame drawn, written only when it moved. */
  function paintTags(){
    if (!tagsEl) return;
    if (level !== "house" || !camera) {
      if (tagsOn) { tagsEl.style.display = "none"; tagsOn = false; }
      return;
    }
    if (!tagsOn) { tagsEl.style.display = ""; tagsOn = true; }
    const W = canvas.clientWidth || 0, H = canvas.clientHeight || 0, k = wallUiOf(root), byId = new Map(floorsUi.map(G => [G.fl.id, G]));
    const placed = [], seen = new Set();
    for (const F of floorsUi) {
      if (!F.group.visible || F.fl.outdoor || F.fl.parent) continue;
      // The floor and its split levels (a raised or sunken room is a level of its own, splitLevels).
      let x0 = Infinity, x1 = -Infinity, y0 = Infinity, y1 = -Infinity;
      for (const G of floorsUi) {
        if (G !== F && G.fl.parent !== F.fl.id) continue;
        for (const r of G.rooms) if (!r.outdoor) for (const q of r.pts) { x0 = Math.min(x0, q[0]); x1 = Math.max(x1, q[0]); y0 = Math.min(y0, q[1]); y1 = Math.max(y1, q[1]); }
      }
      if (!Number.isFinite(x0)) continue;
      const fid = F.fl.id, w = tagWords(F, byId), key = `${w.name}|${w.line}|${k}`;
      seen.add(fid);
      let T = floorTags.get(fid);
      if (!T) {
        const el = document.createElement("button");
        el.type = "button"; el.className = "la3d-ftag";
        el.setAttribute("data-la3d-ftag", fid);
        for (const ev of ["pointerdown", "pointerup", "wheel", "dblclick"]) el.addEventListener(ev, (e) => e.stopPropagation());
        el.addEventListener("click", guard((e) => {
          e.stopPropagation();
          if (lastP && typeof lastP.setTopFloor === "function") lastP.setTopFloor(fid);
        }));
        tagsEl.appendChild(el);
        T = { el, key: null, w: 0, h: 0, at: "" };
        floorTags.set(fid, T);
      }
      if (T.key !== key) {
        T.key = key;
        const b = document.createElement("b"), sp = document.createElement("span");
        b.textContent = w.name; sp.textContent = w.line;
        T.el.replaceChildren(b, sp);
        T.el.style.fontSize = `${Math.round(12 * k * 10) / 10}px`;
        T.el.title = `${w.name}: ${w.line}. Tap to show this floor alone`;
        T.el.setAttribute("aria-label", `${w.name}: ${w.line}. Show this floor alone`);
        T.w = T.el.offsetWidth || 0; T.h = T.el.offsetHeight || 0;
      }
      // Beside the floor: left of its leftmost corner on screen (else right of its rightmost), level with it.
      let left = null, right = null;
      for (const [x, y] of [[x0, y0], [x1, y0], [x1, y1], [x0, y1]]) {
        for (const z of [F.fl.elev, F.fl.elev + Math.min(1.2, F.fl.h)]) {
          _v.set(x, z, y).project(camera);
          if (!(_v.z < 1)) continue;
          const sx = (_v.x + 1) / 2 * W, sy = (1 - _v.y) / 2 * H;
          if (!left || sx < left.x) left = { x: sx, y: sy };
          if (!right || sx > right.x) right = { x: sx, y: sy };
        }
      }
      if (!left) { T.el.style.display = "none"; continue; }
      T.el.style.display = "";
      let lx = left.x - T.w - 14, ly = left.y;
      if (lx < 8) { lx = right.x + 14; ly = right.y; }
      placed.push({ T, elev: F.fl.elev, x: Math.max(8, Math.min(W - T.w - 8, lx)), y: ly });
    }
    placed.sort((a, b) => b.elev - a.elev);
    const top = bare ? 12 : 66;
    for (let i = 0; i < placed.length; i++) {
      const p = placed[i], above = placed[i - 1];
      p.y = Math.max(p.y, top + p.T.h / 2);
      if (above) p.y = Math.max(p.y, above.y + (above.T.h + p.T.h) / 2 + 6);
      const at = `translate(${Math.round(p.x)}px, ${Math.round(p.y - p.T.h / 2)}px)`;
      if (at !== p.T.at) { p.T.at = at; p.T.el.style.transform = at; }
    }
    for (const [fid, T] of [...floorTags]) if (!seen.has(fid)) { T.el.remove(); floorTags.delete(fid); }
  }

  // ── floors, walls, quality ────────────────────────────────────────────────
  function applyTop(){
    // (The Plans tool's vetting map: this floor alone, so nothing from below shows through round its plan.)
    for (const F of floorsUi) F.group.visible = HOUSE.floorShown(F.fl, topElev) && (!quiet || topElev === null || (F.fl.chipElev ?? F.fl.elev) >= topElev - 1e-3);
    // With the floors above hidden, a tall room's walls stop where they
    // start (under that floor's slab), as the rest of the house does.
    const hid = floorsUi.filter(F => !F.fl.outdoor && !F.group.visible).map(F => F.fl.elev);
    for (const F of floorsUi) {
      const over = hid.filter(e => e > F.fl.elev + 1e-3), clip = over.length ? Math.min(...over) - F.fl.elev - HOUSE.SLAB_T : null;
      if (clip === (F.clip === undefined ? null : F.clip)) continue;
      F.clip = clip;
      for (const P of F.pieces) placePiece(F, P, P.cut);
    }
    coverNames();
    lampsDirty = true;
    liveMs = liveRate(performance.now());                    // a floor shown again may be swinging or flashing
    recheckCovers();
    if (raisedL) raisedL.touch();
  }
  /** Walls or floors changed: what covers a motion marker or a code is worked out again. */
  function recheckCovers(){ if (motionL && motionL.recheck) motionL.recheck(); if (codes && codes.recheck) codes.recheck(); }
  function setWalls(m, byHand = false){
    if (!HOUSE.WALL_MODES.includes(m)) return;
    const was = wallMode;
    wallMode = m;
    // Cut or Glass picked by hand: this screen keeps it (the ⋯ list's Glass walls line, the same choice).
    if (byHand && (m === "glass" || m === "cut") && SHOW) {
      glassPick = m === "glass";
      prefSet(SHOW.prefKey(slotKey), JSON.stringify(SHOW.withTick(showOver(), "glass_walls", glassPick, SHOW.houseOn(showHouse, "glass_walls"))));
      if (showMenu) showMenu.mark();
    }
    // To or from Glass: every piece is placed again (Cut and Glass take away the same walls).
    if ((was === "glass") !== (m === "glass")) {
      for (const F of floorsUi) { if (F.ghost) F.ghost.visible = m === "glass"; for (const P of F.pieces) placePiece(F, P, !!P.cut); }
    }
    paintWallButtons();
    paintWindows();
    recheckCovers();
    requestRender();
    if (raisedL) raisedL.touch();
  }
  function updateCutaway(){
    const topDown = cam.phi < 0.2;
    // Under the roof the walls stand (Cut is Up while it shows).
    const mode = roofTick() && (wallMode === "cut" || wallMode === "glass") ? "up" : wallMode;
    for (const F of floorsUi) {
      if (!F.group.visible) continue;
      // Glass with a room open: that room's floor's inside walls are glass too.
      const rooms = !!openRoom && openRoom.F === F;
      for (const P of F.pieces) {
        const cut = HOUSE.wallCut(P.pc, camera.position.x, camera.position.z, mode, topDown, rooms);
        if (cut === P.cut) continue;
        P.cut = cut;
        placePiece(F, P, cut);
        for (const L of P.lights) if (L.look) paintLight(L);     // wall lights go with their wall
      }
    }
  }
  // ── the roof (live_aboard_storey.js) ──────────────────────────────────────
  // It shows from outside: Roof on Auto, zoomed out past the whole house,
  // every floor showing, walls Up or Cut, not from straight above, and not in
  // Edit or Furnish; otherwise it lifts away. It fades over ROOF_FADE_MS on
  // the view's live clock (liveRate), so at rest it asks for no frame.
  const roofPick = () => (STOREY ? STOREY.roofSetting(prefGet(PREF_ROOF + slotKey)) : "off");
  function roofTick(){
    if (!storeyL) return false;
    const want = STOREY.roofShown({ setting: roofPick(), editing: !!(editor && editor.active), furnish: furnishOn, topElev,
                                    topStorey: storeyL.topElev(), wallMode, phi: cam.phi, radius: cam.radius, fitR });
    const f = storeyL.fade(want, performance.now());
    const was = roofWant;
    roofWant = want;
    if (!!was !== !!want) paintWindows();                    // Cut stands the walls up under the roof: lit windows show
    if (f.crossed) recheckCovers();                          // markers and codes under it hide, or show again
    return want;
  }
  function setRoof(v){
    prefSet(PREF_ROOF + slotKey, STOREY ? STOREY.roofSetting(v) : "auto");
    paintWallButtons();
    requestRender();
  }
  // A wall on High draws every pixel its screen has. What a modest GPU can't
  // do at that size is turn the house smoothly, so decideQuality times it, and
  // one that falls short (wallMoves) draws about 720p's worth only while the
  // camera moves: every pixel again as soon as it stops. One too slow even to
  // draw every pixel (wallCapped) stays at about 1440p's worth, the browser
  // scaling it up, and so does a wall that ends up on Low. Anywhere else, the
  // quality profile's ratio as before.
  const WALL_PX = 2560 * 1440, WALL_MOVE_PX = 1280 * 720, WALL_SETTLE_MS = 200;
  let profileDpr = 1, wallMoves = false, wallCapped = false, camMovedAt = -Infinity;
  const wallMoving = () => !!quality.measuring || !!cam.fly || performance.now() - camMovedAt < WALL_SETTLE_MS;
  /** Drawn at less just now: the frame clock keeps looking until it can go sharp again. */
  const wallSoft = () => wallMoves && !quality.measuring && renderer.getPixelRatio() !== profileDpr;
  function ratioFor(w, h){
    if (!onWallPage(root) || !w || !h) return profileDpr;
    const px = profileOf().dpr !== "device" || wallCapped ? WALL_PX : wallMoves && wallMoving() ? WALL_MOVE_PX : 0;
    return px ? Math.max(0.5, Math.min(profileDpr, Math.sqrt(px / (w * h)))) : profileDpr;
  }
  function applyProfile(name){
    const Q = HOUSE.QUALITY_PROFILES[name];
    if (!Q || !renderer) return;
    profileDpr = Q.dpr === "device" ? Math.min(window.devicePixelRatio || 1, 3) : 1;
    renderer.setPixelRatio(ratioFor(root ? root.clientWidth : 0, root ? root.clientHeight : 0));
    renderer.shadowMap.enabled = !!Q.shadows;
    sun.castShadow = !!Q.shadows;
    lampPool.forEach((l, i) => { l.visible = i < Q.lamps; });
    scene.traverse((o) => {
      if (o.userData && o.userData.spec) o.material = mat(o.userData.spec);
    });
    for (const F of floorsUi) if (F.ao) F.ao.visible = !!Q.ao;
    if (layer) layer.sync(piecesNow(viewData().pieces));              // furniture's finishes and shadows go with the profile
    if (lastP) { syncDevices(lastP, viewData()); syncTracked(lastP, viewData(), false); }
    for (const L of lights) if (L.spin) L.spin.rps = (L.spin.base || 0) * fanK(name);   // a running fan's speed goes with the profile
    if (studio) studio.profile();
    lampsDirty = true;
    resize();
  }
  /** One step of the Auto / Low / High pick (live_aboard_house.js qualityStep). */
  function decideQuality(){
    // A wall that can't keep up at every pixel: High timed once more at what it would draw (HOUSE.wallNextTry).
    if (!wallMoves && !wallCapped && onWallPage(root)) {
      const next = HOUSE.wallNextTry(quality.setting, quality.measured);
      if (next === "moves") wallMoves = true;
      else if (next === "budget" && drawnW * drawnH * profileDpr * profileDpr > WALL_PX) wallCapped = true;
      if (wallMoves || wallCapped) delete quality.measured.high;
    }
    const step = HOUSE.qualityStep(quality.setting, true, quality.measured);
    // Too slow with the trees: the trees go, and it is timed again without them.
    if (step.fallback && forest) { dropForest(true); quality.measured = {}; decideQuality(); return; }
    if (step.fallback) { fail(step.fallback); return; }
    if (step.measure) {
      quality.measuring = step.measure; quality.intervals = []; quality.t0 = 0; quality.last = 0;
      applyProfile(step.measure);
      // Shaders compile now, not inside the timed frames.
      try { renderer.compile(scene, camera); } catch (_) { /* compiled on first draw instead */ }
      requestRender();
      return;
    }
    quality.measuring = null;
    quality.profile = step.use;
    if (step.use !== "high") wallMoves = wallCapped = false; // it went to Low after all: that has its own budget
    applyProfile(step.use);
    HOUSE.countHouse3dOnce("house3d_opened", send);
    if (onWallPage(root)) HOUSE.countHouse3dOnce(`house3d_wall_draw:${step.use !== "high" ? "low" : wallMoves ? "high_still" : wallCapped ? "high_capped" : "high"}`, send);
    requestRender();
  }

  // ── the camera: PadSpan's own orbit ───────────────────────────────────────
  // Spherical about a target: theta turns about the vertical (0 = from plan
  // +y), phi tilts down from straight above. Drag turns it; right-drag, or
  // two fingers, pans along the ground; the wheel, or a pinch, zooms about the
  // point under the cursor or between the fingers.
  /** Turn the camera. A wall (or a short screen) framed whole fills its band with the camera's
   *  middle off the house's (frameFor), so unless it is zoomed in it turns
   *  about the middle of what shows, however it got there (a saved home, a
   *  floor, Whole house), or the house would swing off the screen. */
  function turnBy(d){
    if (!wallPivot || wallPivot.top !== topElev) {
      const pts = onWallPage(root) || banded(uiPad()) ? visiblePoints() : null, m = pts ? new THREE.Box3().setFromPoints(pts).getCenter(new THREE.Vector3()) : null;
      wallPivot = pts ? { top: topElev, x: m.x, z: m.z, r: frameFor(cam.theta, cam.phi, pts).radius } : { top: topElev, r: null };
    }
    cam.theta += d;
    if (wallPivot.r === null || cam.radius < wallPivot.r * 0.9) return;
    const c = Math.cos(d), s = Math.sin(d), x = cam.target.x - wallPivot.x, z = cam.target.z - wallPivot.z;
    cam.target.x = wallPivot.x + x * c + z * s;
    cam.target.z = wallPivot.z - x * s + z * c;
  }
  function applyCam(){
    const s = Math.sin(cam.phi);
    camera.position.set(cam.target.x + cam.radius * s * Math.sin(cam.theta), cam.target.y + cam.radius * Math.cos(cam.phi),
                        cam.target.z + cam.radius * s * Math.cos(cam.theta));
    camera.lookAt(cam.target);
    camera.updateMatrixWorld();
    if (lampTarget.distanceToSquared(cam.target) > 1) lampsDirty = true;
    camMovedAt = performance.now();
    tellZoom();
    requestRender();
    if (raisedL) raisedL.touch();
  }
  const _ray = new THREE.Raycaster(), _ndc = new THREE.Vector2(), _plane = new THREE.Plane();
  /** The world point on the plane y = h under a screen point, or null. */
  function groundAt(clientX, clientY, h){
    const r = view3Rect();
    if (!r.width || !r.height) return null;
    _ndc.set((clientX - r.left) / r.width * 2 - 1, -((clientY - r.top) / r.height) * 2 + 1);
    camera.updateMatrixWorld();
    _ray.setFromCamera(_ndc, camera);
    _plane.set(Y_AXIS, -h);
    const hit = _ray.ray.intersectPlane(_plane, new THREE.Vector3());
    if (!hit || hit.distanceTo(camera.position) > Math.max(40, cam.radius * 4)) return null;
    return hit;
  }
  // Every one of these is a person moving the camera: no more auto-fit.
  const moved = () => { cam.moved = true; cam.needsFit = false; };
  function orbitBy(dx, dy){
    moved();
    const h = canvas.clientHeight || 600;
    turnBy(-2 * Math.PI * dx / h);
    cam.phi = Math.max(MIN_PHI, Math.min(MAX_PHI, cam.phi - 2 * Math.PI * dy / h));
    applyCam();
  }
  function panBy(x0, y0, x1, y1){
    moved();
    const a = groundAt(x0, y0, cam.target.y), b = groundAt(x1, y1, cam.target.y);
    if (a && b) cam.target.add(a.sub(b));
    else {                                                   // looking at the horizon: pan in screen space
      const k = cam.radius / Math.max(200, canvas.clientHeight || 600);
      _v.setFromMatrixColumn(camera.matrixWorld, 0).setY(0).normalize().multiplyScalar(-(x1 - x0) * k);
      _v2.set(Math.sin(cam.theta), 0, Math.cos(cam.theta)).multiplyScalar(-(y1 - y0) * k);
      cam.target.add(_v).add(_v2);
    }
    applyCam();
  }
  function zoomAt(clientX, clientY, k){
    moved();
    const r0 = cam.radius, r1 = Math.max(MIN_R, Math.min(MAX_R, r0 * k));
    const f = r1 / r0;
    if (Math.abs(f - 1) < 1e-4) return;
    const p = groundAt(clientX, clientY, cam.target.y);
    if (p) cam.target.sub(p).multiplyScalar(f).add(p);     // the point under the fingers stays put
    cam.radius = r1;
    applyCam();
  }
  function wirePointer(){
    const pts = camPts;
    let mode = null, last = null, pinch = null, press = null, unfollow = null;
    // A pinch's distance at its start (zoomed in or out, once the fingers
    // lift); a press on nothing (a tap there, twice: fly to that room).
    let pinchR0 = null, tap = null;
    const mid = () => { const [a, b] = [...pts.values()]; return { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2, d: Math.hypot(a.x - b.x, a.y - b.y) }; };
    // Every finger and button down on the house is followed on the window
    // (capture) until it lifts, as a spin is. A poll moving the view into a
    // new card takes the canvas's pointer capture with it, and a lift off
    // the canvas then never reaches the canvas: the pointer would stay down
    // here, every later press a pinch, and a mouse would turn the house with
    // no button held. Each event counts once, heard first on the window or
    // on the canvas itself (one sent to the canvas alone, never composed out
    // of its shadow root, reaches no window).
    const heard = new WeakSet();
    const once = (fn) => guard((e) => { if (heard.has(e)) return; heard.add(e); fn(e); });
    const follow = () => {
      if (unfollow) return;
      window.addEventListener("pointermove", moved, true);
      window.addEventListener("pointerup", lift, true);
      window.addEventListener("pointercancel", lift, true);
      unfollow = () => {
        window.removeEventListener("pointermove", moved, true);
        window.removeEventListener("pointerup", lift, true);
        window.removeEventListener("pointercancel", lift, true);
        unfollow = null;
      };
    };
    canvas.addEventListener("pointerdown", guard((e) => {
      if (spin) endSpin(true);                               // a finger on the house: no spin
      if (typeof touchCb === "function") { try { touchCb(); } catch (_) { /* the card's, not ours */ } }
      const onlyNorth = e === northDismissed;                // this tap put north back, nothing more
      const woke = wake();                                   // "Rooms as light switches": a dark house lit up, nothing more
      cam.fly = null;                                        // a hand on the house stops a flight
      flashCorner();                                         // the map alone: which floor this is
      pts.set(e.pointerId, { x: e.clientX, y: e.clientY });
      follow();
      try { canvas.setPointerCapture(e.pointerId); } catch (_) { /* followed on the window anyway */ }
      if (pts.size === 2) {
        if (press) { press = null; use.cancel(); }           // a second finger: a pinch, never a press
        if (mode === "edit" || mode === "editTap") editor.cancel();   // ...and never a line
        mode = "pinch"; pinch = mid(); pinch.plan = planHere(pinch.x, pinch.y); tap = null;
        if (pinchR0 === null) pinchR0 = cam.radius;
        return;
      }
      mode = e.pointerType === "mouse" && (e.button === 2 || e.button === 1 || e.shiftKey || e.ctrlKey || e.metaKey) ? "pan" : "orbit";
      last = { x: e.clientX, y: e.clientY };
      // In Edit, one finger or the left button draws a line, drags an end
      // or picks what to change (the editor says which); a press never
      // switches a light there. Anything else turns the house as ever.
      if (editor && editor.active && mode === "orbit" && pts.size === 1 && !onlyNorth) {
        const g = editor.down(e);
        if (g === "line" || g === "drag" || g === "swallow") mode = "edit";
        else if (g === "tap") mode = "editTap";
        else if (g === "pan") mode = "pan";                  // the Plans tool: a press on nothing moves the plan under the mouse, never turns it
        return;
      }
      // Furnish's plan: one finger or the mouse moves the plan (it never turns).
      if ((mode === "orbit" || mode === "pan") && planHere(e.clientX, e.clientY)) { mode = "planPan"; return; }
      // A press on something in the house (live_aboard_use.js). Moved
      // before it is held, it is no press: the drag turns the house, from
      // where it began.
      if (mode === "orbit" && pts.size === 1 && !onlyNorth && use && !woke && use.down(e)) {
        mode = "press";
        press = { id: e.pointerId, x0: e.clientX, y0: e.clientY };
      }
      tap = mode === "orbit" && pts.size === 1 && !onlyNorth && (e.pointerType !== "mouse" || e.button === 0)
        ? { id: e.pointerId, x: e.clientX, y: e.clientY, t: performance.now() } : null;
    }));
    canvas.addEventListener("pointermove", guard((e) => {
      if (pts.has(e.pointerId)) { moved(e); return; }
      // No button down: a mouse or pen over the house — what a click would land on.
      if (pts.size || e.pointerType === "touch") return;
      if (editor && editor.active) editor.hover(e);
      else if (use) use.hover(e);
    }));
    const moved = once((e) => {
      if (!pts.has(e.pointerId)) return;
      pts.set(e.pointerId, { x: e.clientX, y: e.clientY });
      if (tap && Math.hypot(e.clientX - tap.x, e.clientY - tap.y) > TAP_PX) tap = null;
      if (mode === "press") {
        if (use.move(e) !== "cancel") return;
        const p0 = press;
        press = null;
        mode = "orbit";
        orbitBy(e.clientX - p0.x0, e.clientY - p0.y0);
        last = { x: e.clientX, y: e.clientY };
        return;
      }
      if (mode === "edit") { editor.move(e); return; }
      if (mode === "editTap") {
        if (Math.hypot(e.clientX - last.x, e.clientY - last.y) <= 6) return;
        editor.cancel();                                     // moved: no pick, the drag turns the house from where it began
        mode = planHere(last.x, last.y) ? "planPan" : "orbit";   // (or moves Furnish's plan)
      }
      if (mode === "planPan") {
        planPanBy(e.clientX - last.x, e.clientY - last.y);
        last = { x: e.clientX, y: e.clientY };
        return;
      }
      if (mode === "pinch" && pts.size === 2) {
        const now = mid();
        now.plan = pinch.plan;
        if (now.plan) { if (pinch.d > 0 && now.d > 0) planZoomAt(now.x, now.y, pinch.d / now.d); planPanBy(now.x - pinch.x, now.y - pinch.y); }
        else { if (pinch.d > 0 && now.d > 0) zoomAt(now.x, now.y, pinch.d / now.d); panBy(pinch.x, pinch.y, now.x, now.y); }
        pinch = now;
        e.preventDefault();
        return;
      }
      if (!last) return;
      if (mode === "orbit") orbitBy(e.clientX - last.x, e.clientY - last.y);
      else if (mode === "pan") panBy(last.x, last.y, e.clientX, e.clientY);
      last = { x: e.clientX, y: e.clientY };
    });
    const lift = once((e) => {
      if (!pts.has(e.pointerId)) return;
      const cancelled = e.type === "pointercancel";
      if (mode === "press") { press = null; if (cancelled) use.cancel(); else use.up(e); }
      else if ((mode === "edit" || mode === "editTap") && editor) {
        if (cancelled) editor.cancel();
        else if (mode === "edit") editor.up(e);
        else editor.tap(e);
      }
      // A short press on nothing: a tap; two close together, the room flies in.
      if (tap && tap.id === e.pointerId && !cancelled && mode === "orbit" && pts.size === 1
          && performance.now() - tap.t <= TAP_MS && Math.hypot(e.clientX - tap.x, e.clientY - tap.y) <= TAP_PX) {
        const t = performance.now(), prev = tapAt;
        tapAt = { x: e.clientX, y: e.clientY, t };
        if (prev && t - prev.t <= TAP2_MS && Math.hypot(e.clientX - prev.x, e.clientY - prev.y) <= TAP2_PX && flyToRoomAt(e.clientX, e.clientY)) tapAt = null;
        else dimmedNote(e.clientX, e.clientY);
      }
      tap = null;
      pts.delete(e.pointerId);
      try { canvas.releasePointerCapture(e.pointerId); } catch (_) { /* fine */ }
      if (pts.size === 1) {                                  // one finger left of a pinch: carry on turning from it
        const [p] = [...pts.values()];
        mode = planHere(p.x, p.y) ? "planPan" : "orbit"; last = { x: p.x, y: p.y }; pinch = null;
      } else if (!pts.size) {
        mode = null; last = null; pinch = null;
        if (unfollow) unfollow();
        // A pinch ended: zoomed in past the fit, the map alone; out to it, the bars.
        if (pinchR0 !== null) { const r0 = pinchR0; pinchR0 = null; if (!cancelled) afterZoom(cam.radius < r0 - 1e-3); }
      }
    });
    canvas.addEventListener("pointerup", lift);
    canvas.addEventListener("pointercancel", lift);
    // The capture went (a poll moved the view): taken back while the
    // pointer is down. One the browser says is gone ends here, as a cancel.
    canvas.addEventListener("lostpointercapture", guard((e) => {
      if (!pts.has(e.pointerId)) return;
      try { canvas.setPointerCapture(e.pointerId); } catch (_) { lift({ type: "pointercancel", pointerId: e.pointerId }); }
    }));
    // The view leaves (Map, or switched off): whatever is down ends, as a cancel.
    dropPointers = () => { for (const id of [...pts.keys()]) lift({ type: "pointercancel", pointerId: id }); };
    canvas.addEventListener("pointerleave", guard((e) => { if (use && !pts.size) use.leave(e); }));
    canvas.addEventListener("contextmenu", (e) => e.preventDefault());
    canvas.addEventListener("wheel", guard((e) => {
      e.preventDefault();
      const dy = e.deltaMode === 1 ? e.deltaY * 16 : e.deltaMode === 2 ? e.deltaY * 400 : e.deltaY;
      const f = Math.exp(Math.max(-200, Math.min(200, dy)) * 0.0015);
      if (planHere(e.clientX, e.clientY)) planZoomAt(e.clientX, e.clientY, f); else { cam.fly = null; zoomAt(e.clientX, e.clientY, f); afterZoom(f < 1); }
      if (use && !pts.size && !(editor && editor.active)) use.hover(e);   // what is under the cursor now
    }), { passive: false });
  }
  /** The corners of every room on a showing indoor floor, at floor and wall-top height. */
  function visiblePoints(){
    const pts = [];
    for (const r of (house && house.rooms) || []) {
      if (r.floor.outdoor || !HOUSE.floorShown(r.floor, topElev)) continue;
      for (const p of r.pts) pts.push(new THREE.Vector3(p[0], r.floor.elev - HOUSE.SLAB_T, p[1]),
                                      new THREE.Vector3(p[0], r.floor.elev + (r.h ?? r.floor.h) - HOUSE.SLAB_T, p[1]));
    }
    if (!pts.length) {
      const b = houseBox;
      pts.push(new THREE.Vector3(b.x0, b.z0, b.y0), new THREE.Vector3(b.x1, b.z1, b.y1));
    }
    return pts;
  }
  /** Frame the showing floors from the camera's direction (or `dir`); with
   *  no points of its own, the whole house — the fit level the map-alone
   *  screen measures zooming against. */
  function fit(theta = cam.theta, phi = cam.phi, pts = null){
    const g = frameFor(theta, phi, pts || visiblePoints());
    cam.target.copy(g.target); cam.theta = g.theta; cam.phi = g.phi; cam.radius = g.radius;
    if (!pts) { fitR = g.radius; wallPivot = null; }
    applyCam();
  }
  /** Where the camera frames `pts` from (theta, phi): {target, radius, theta, phi}. */
  /** How much of the view's top and bottom (px) the bars, the hint line and
   *  the chips cover now: a framed house keeps clear of them. */
  function uiPad(){
    const out = { top: 0, bottom: 0, H: (canvas && canvas.clientHeight) || 0 };
    if (!root || !out.H || typeof root.getBoundingClientRect !== "function") return out;
    const r0 = root.getBoundingClientRect();
    // A wall's bars fade when nobody is there: they don't get to shrink the house.
    const wall = onWallPage(root), rot = wall ? root.getRootNode().host.getAttribute("data-wall-rotate") : null;
    // The map alone: the bar, the tip and the chips are stepping aside (their fade may not have ended): only the rain line stays.
    for (const el of root.querySelectorAll(wall ? ".la3d-tip, .la3d-mchip, .la3d-wet, .la3d-pchip, .psc-row" : bare ? ".la3d-wet" : ".la3d-tip, .la3d-mchip, .la3d-wet, .la3d-bar, .la3d-rchips:not(.la3d-rcompact)")) {
      const r = el.getBoundingClientRect && el.getBoundingClientRect();
      if (!r || !(r.height > 0) || !(r.width > 0) || getComputedStyle(el).visibility === "hidden") continue;
      // A wall turned by its link: these are the turned boxes, the page's top along a side of the screen.
      const t = rot === "90" ? r0.right - r.right : rot === "270" ? r.left - r0.left : r.top - r0.top, b = t + (rot ? r.width : r.height);
      if ((t + b) / 2 < out.H / 2) out.top = Math.max(out.top, b + 6); else out.bottom = Math.max(out.bottom, out.H - t + 6);
    }
    // The chips come and go with motion: a wall keeps their room either way, so its framing doesn't depend on the moment.
    if (wall && !narrow) out.top = Math.max(out.top, WALL_CHIPS_PX * wallUiOf(root));
    // Never more than 40% of the view between them (a very short screen).
    const k = Math.min(1, (out.H * 0.4) / Math.max(1, out.top + out.bottom));
    out.top *= k; out.bottom *= k;
    return out;
  }
  const WALL_CLEAR = 0.05;                                   // a wall's house keeps this clear of the screen's edge (of half the screen)
  const WALL_CHIPS_PX = 82;                                  // the chip row's room at the top of a wall, before --wall-ui
  let wallPivot = null;                                      // a wall (or a short screen's band): the middle of what shows, and its whole-house radius (turnBy)
  /** The house fits the band between what covers the top and the bottom,
   *  moved into it: on a wall, and on a short screen with the scene row on
   *  the bar, where the band the larger of the two leaves on both sides is
   *  under 60% of the view (held at 60%, the house's front ran under the
   *  row). Else it stays in the middle of the view, as ever. */
  const banded = (pad) => !!pad.H && (onWallPage(root)
    || (!!bar && bar.classList.contains("psc-has") && 1 - 2 * Math.max(pad.top, pad.bottom) / pad.H < 0.6));
  /** side: {right, bottom} px a room's panel covers: the room fits what is left (flyToRoom moves it there). */
  function frameFor(theta, phi, pts, side = null){
    const keep = { p: camera.position.clone(), q: camera.quaternion.clone() };
    const dir = new THREE.Vector3(Math.sin(phi) * Math.sin(theta), Math.cos(phi), Math.sin(phi) * Math.cos(theta));
    const box = new THREE.Box3().setFromPoints(pts), c = box.getCenter(new THREE.Vector3());
    camera.position.copy(c).addScaledVector(dir, 50);
    camera.lookAt(c);
    camera.updateMatrixWorld();
    const right = new THREE.Vector3().setFromMatrixColumn(camera.matrixWorld, 0), up = new THREE.Vector3().setFromMatrixColumn(camera.matrixWorld, 1);
    const W = (canvas && canvas.clientWidth) || 0, kx = side && W ? Math.max(0.35, 1 - side.right / W) : 1;
    const tv = Math.tan(FOV / 2 * D2R), th = tv * camera.aspect * kx;
    // Centre on the projected extent, then back off until every corner fits.
    let x0 = Infinity, x1 = -Infinity, y0 = Infinity, y1 = -Infinity;
    for (const q of pts) { const o = q.clone().sub(c); x0 = Math.min(x0, o.dot(right)); x1 = Math.max(x1, o.dot(right)); y0 = Math.min(y0, o.dot(up)); y1 = Math.max(y1, o.dot(up)); }
    c.addScaledVector(right, (x0 + x1) / 2).addScaledVector(up, (y0 + y1) / 2);
    // Clear of what covers the top and the bottom: the house fits the band
    // the larger of the two leaves on both sides (6% clear), so it stays
    // in the middle of the view and the camera still turns about it.
    const pad = uiPad(), ky = side && pad.H ? Math.max(0.35, 1 - side.bottom / pad.H) : 1;
    const fr = (pad.H ? Math.max(0.6, 1 - 2 * Math.max(pad.top, pad.bottom) / pad.H) : 1) * ky, vk = pad.H ? 1.06 : 1.12;
    let need = 2;
    for (const q of pts) {
      const o = q.clone().sub(c), z = o.dot(dir);
      need = Math.max(need, z + Math.abs(o.dot(right)) / th * 1.08, z + Math.abs(o.dot(up)) / (tv * fr) * vk);   // sides: 8% clear (4% ran a narrow screen's house to its edge)
    }
    // A wall, or a short screen: the house as large as the screen lets it be, in the band what stays on show leaves.
    if (!side && banded(pad)) {
      const f = HOUSE.fillBand(pts.map((q) => { const o = q.clone().sub(c); return [o.dot(right), o.dot(up), o.dot(dir)]; }), th, tv,
                               1 - 2 * pad.top / pad.H - WALL_CLEAR, -1 + 2 * pad.bottom / pad.H + WALL_CLEAR,
                               onWallPage(root) ? 1 - WALL_CLEAR : 1 / 1.08);   // sides as above, off a wall
      if (Number.isFinite(f.x + f.y + f.r)) {
        c.addScaledVector(right, f.x).addScaledVector(up, f.y);
        need = Math.max(2, f.r);
      }
    }
    camera.position.copy(keep.p); camera.quaternion.copy(keep.q);
    camera.updateMatrixWorld();
    return { target: c, theta, phi: Math.max(MIN_PHI, Math.min(MAX_PHI, phi)), radius: Math.max(MIN_R, Math.min(MAX_R, need)) };
  }
  /** The Atlas's angle (plan x down-right, plan y down-left). A portrait
   *  screen turns it so the long side of the house runs up the screen. */
  function isoAngle(){
    if (camera.aspect >= 0.8) return { theta: Math.PI / 4, phi: 0.98 };
    // The walls' run, sampled along every showing room's outline (corners
    // alone let one small room tilt it).
    let n = 0, mx = 0, my = 0, xx = 0, yy = 0, xy = 0;
    const add = (x, y) => { n++; mx += x; my += y; xx += x * x; yy += y * y; xy += x * y; };
    for (const r of (house && house.rooms) || []) {
      if (r.floor.outdoor || !HOUSE.floorShown(r.floor, topElev)) continue;
      r.pts.forEach((q, i) => {
        const e = r.pts[(i + 1) % r.pts.length], k = Math.max(1, Math.ceil(Math.hypot(e[0] - q[0], e[1] - q[1]) / 0.5));
        for (let j = 0; j < k; j++) add(q[0] + (e[0] - q[0]) * j / k, q[1] + (e[1] - q[1]) * j / k);
      });
    }
    if (!n) return { theta: 0.35, phi: 0.85 };
    mx /= n; my /= n;
    const a = 0.5 * Math.atan2(2 * (xy / n - mx * my), (xx / n - mx * mx) - (yy / n - my * my));   // the long axis
    // Looking along the long axis puts it up the screen; of its two ends, the one nearer the old turn.
    const near = (t) => Math.abs(((t - 0.35) % (2 * Math.PI) + 3 * Math.PI) % (2 * Math.PI) - Math.PI);
    const t1 = Math.PI / 2 - a, t2 = t1 + Math.PI;
    return { theta: near(t1) <= near(t2) ? t1 : t2, phi: 0.85 };
  }
  function preset(name, byHand = false){
    if (byHand) cam.moved = true;
    if (name !== "turn") closeRoom();                        // framed whole again: no room is open
    cam.needsFit = false;
    cam.fly = null;
    if (name === "iso") { const a = isoAngle(); fit(a.theta, a.phi); }
    else if (name === "top") fit(0, MIN_PHI);
    else if (name === "turn") {
      // Not zoomed in: framed again at the new angle as Fit frames it (zoomed
      // out, as far out again), or a corner turns in under the scene row.
      const pts = visiblePoints(), k = cam.radius / frameFor(cam.theta, cam.phi, pts).radius;
      turnBy(Math.PI / 2);
      if (k >= 0.9) { const g = frameFor(cam.theta, cam.phi, pts); cam.target.copy(g.target); cam.radius = Math.min(MAX_R, g.radius * Math.max(1, k)); }
      applyCam();
    }
    else fit();
    if (byHand && bare) setBare(false, false);
  }
  /** The first view: the Atlas's angle, the whole house; on a phone held
   *  upright (not a portrait wall), room scale (about ROOM_SPAN across) at
   *  the middle of the house. */
  const ROOM_SPAN = 9;
  function openView(){
    if (panel && panel.open()) return;                      // the sidebar opens on its home view
    preset("iso");
    if (camera.aspect >= 0.8 || onWallPage(root)) return;   // a portrait wall is not a phone: the whole house
    if (explodeGap()) return;                               // every floor pulled apart: the whole house, on a phone too
    const r = ROOM_SPAN / (2 * Math.tan(FOV / 2 * D2R) * camera.aspect);
    if (r < cam.radius) { cam.radius = Math.max(MIN_R, r); applyCam(); }
  }
  /** Studio's arrival, once a view: the camera glides in to the view it just
   *  opened on, from a little farther out and round. Not with reduced motion,
   *  and the camera still counts as untouched (the house is fitted again as before). */
  function arrive(){
    if (!studio || !studio.takeArrival()) return;
    if (typeof matchMedia === "function" && matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const to = { target: cam.target.clone(), radius: cam.radius, theta: cam.theta, phi: cam.phi };
    const A = STUDIO.STUDIO_ARRIVAL;
    const from = { target: cam.target.clone(), radius: cam.radius * A.radius, theta: cam.theta - A.turn, phi: Math.max(MIN_PHI, cam.phi - A.rise) };
    cam.fly = { t0: performance.now(), from, to, dTh: A.turn, inward: false, ms: A.ms };
    requestRender();
  }
  // ── flying the camera (a double-tap on a room, a saved view) ──────────────
  function flyTo(goal, inward){
    closeRoom();                                             // flown elsewhere: no room is open (flyToRoomAt opens its own)
    const from = { target: cam.target.clone(), radius: cam.radius, theta: cam.theta, phi: cam.phi };
    const dTh = ((goal.theta - from.theta) % (2 * Math.PI) + 3 * Math.PI) % (2 * Math.PI) - Math.PI;
    cam.moved = true; cam.needsFit = false;
    cam.fly = { t0: performance.now(), from, to: goal, dTh, inward: !!inward };
    requestRender();
  }
  function stepFly(now){
    const f = cam.fly;
    if (!f) return;
    const u = Math.min(1, Math.max(0, (now - f.t0) / (f.ms || FLY_MS))), k = u < 0.5 ? 2 * u * u : 1 - Math.pow(-2 * u + 2, 2) / 2;
    cam.target.lerpVectors(f.from.target, f.to.target, k);
    cam.radius = f.from.radius + (f.to.radius - f.from.radius) * k;
    cam.theta = f.from.theta + f.dTh * k;
    cam.phi = f.from.phi + (f.to.phi - f.from.phi) * k;
    if (u >= 1) cam.fly = null;
    applyCam();
    if (u >= 1 && f.inward) afterZoom(true);
  }
  /** The Plans tool: fly to a plan point on floor F, `span` metres of it filling
   *  what the card and the bars leave clear (pad: {top, right, bottom} px they
   *  cover), that point in the middle of it, from straight above as the view is. */
  function flySpot(F, x, y, span, pad){
    if (!renderer || failed || !camera || !F) return;
    const H = (canvas && canvas.clientHeight) || 1, W = (canvas && canvas.clientWidth) || 1, top = (pad && pad.top) || 0, right = (pad && pad.right) || 0, bottom = (pad && pad.bottom) || 0;
    const perPx = span / Math.max(1, Math.min(W - right, H - top - bottom));
    const radius = Math.max(MIN_R, Math.min(MAX_R, perPx * H / (2 * Math.tan(FOV / 2 * D2R))));
    const sx = right / 2 * perPx, sy = (bottom - top) / 2 * perPx;
    const target = new THREE.Vector3(x + Math.cos(cam.theta) * sx + Math.sin(cam.theta) * sy, F.fl.elev, y - Math.sin(cam.theta) * sx + Math.cos(cam.theta) * sy);
    flyTo({ target, radius, theta: cam.theta, phi: cam.phi }, false);
  }
  /** A double-tap on a room's floor: fly in to frame it, from the same side. */
  /** The room whose floor shows at client (x, y): {F, r}, or null. */
  function roomAtScreen(x, y){
    const rect = view3Rect();
    if (!rect.width || !rect.height) return null;
    _ndc.set((x - rect.left) / rect.width * 2 - 1, 1 - (y - rect.top) / rect.height * 2);
    camera.updateMatrixWorld();
    _hit.setFromCamera(_ndc, camera);
    _hit.near = 0; _hit.far = Infinity;
    const tiles = floorsUi.filter(F => F.group.visible && F.tiles).map(F => F.tiles);
    const h = _hit.intersectObjects(tiles, false)[0];
    const F = h && floorsUi.find(q => q.tiles === h.object);
    const r = F && HOUSE.roomAt(F.rooms, h.point.x, h.point.z);
    return r ? { F, r, x: h.point.x, y: h.point.z } : null;
  }
  function flyToRoomAt(x, y){
    const at = roomAtScreen(x, y);
    if (!at) return false;
    const { F, r } = at, pts = [];
    for (const p of r.pts) pts.push(new THREE.Vector3(p[0], F.fl.elev, p[1]), new THREE.Vector3(p[0], F.fl.elev + Math.min(1.2, F.fl.h), p[1]));
    const g = frameFor(cam.theta, Math.max(0.35, Math.min(cam.phi, 1.05)), pts);
    g.radius = Math.max(MIN_R, g.radius * 1.12);
    flyTo(g, true);
    openRoomOf(at, g.radius);                                // the room open: its codes, the others faded
    return true;
  }

  // ── the rooms by name: the chips and a room's panel (live_aboard_rooms.js) ──
  /** The chips for the house as it is drawn: every floor's named rooms (a
   *  split level's under its storey); none while Edit, Furnish or the Plans
   *  tool's map has the view. */
  function chipGroups(){
    if (!house || showSuspended()) return [];
    return ROOMS.roomChipGroups(floorsUi.map(F => ({ id: F.fl.id, name: F.fl.name, elev: F.fl.elev, outdoor: !!F.fl.outdoor,
                                                     parent: F.fl.parent || null, rooms: F.rooms })));
  }
  /** A chip: its room's floor shows (as that floor's tag shows it) and, once
   *  it is drawn, the camera flies to the room and its panel opens. */
  function goRoom(fid, top, name){
    const s = floorSteps;
    const change = !!(s && s.names.length > 1 && (s.all || !(selIds && selIds.has(String(top)))) && lastP && typeof lastP.setTopFloor === "function");
    roomGo = { fid: String(fid), name, at: performance.now(), wait: change };
    closeMenu();
    if (change) { keepCam = true; try { lastP.setTopFloor(String(top)); } finally { keepCam = false; } }
    else landRoom();
  }
  /** A chip's room, once its floor shows (put together again, not pulled
   *  apart): flown to, its panel open. Given up after a moment. */
  function landRoom(){
    const g = roomGo;
    if (!g || !house) return;
    const late = performance.now() - g.at > 1500;
    if (g.wait && !late) return;
    const F = floorsUi.find(q => q.fl.id === g.fid && q.group.visible), r = F && F.rooms.find(q => q.name === g.name);
    if ((!F || !r || readGap) && !late) return;
    roomGo = null;
    if (F && r && !openRoomPanel(g.name, F, r)) flyToRoom({ F, r });
  }
  /** The room drawn with this name on the floors showing, the top one first. */
  function roomByName(name){
    for (const F of floorsUi.filter(G => G.group.visible).sort((a, b) => b.fl.elev - a.fl.elev)) {
      const r = F.rooms.find(q => q.name === name);
      if (r) return { F, r };
    }
    return null;
  }
  const lightsOf = (api) => (Array.isArray(api.lights) ? api.lights : Object.values(api.lightsByEid || {}).filter(Boolean));
  /** A room's panel beside the house (a bottom sheet on a narrow screen): the
   *  Atlas's room sheet drawn in it, the room flown to in what it leaves
   *  clear, tinted. False: no panel here (the host's own room sheet opens). */
  function openRoomPanel(name, F0 = null, r0 = null){
    const api = apiNow || (apiOf ? (apiNow = apiOf()) : null);
    if (!roomPanel || !root || !api || typeof api.toggle !== "function" || showSuspended()) return false;
    const at = F0 && r0 ? { F: F0, r: r0 } : roomByName(name);
    closeMenu();
    const into = roomPanel.open(name);
    if (!roomSheet) roomSheet = openRoomSheet(panelApi(api, name), lightsOf(api), name, null, { into, stay: true, onClose: () => roomPanel.close() });
    paintRoomMore(api);
    fitRoomPanel();
    if (roomChips) roomChips.sync();
    if (at) flyToRoom(at);
    return true;
  }
  function closeRoomPanel(){ if (roomPanel) roomPanel.close(); }
  /** Beside the house the panel stops above the bar (and its scene row), whatever their height. */
  function fitRoomPanel(){
    const el = roomPanel && roomPanel.el;
    if (!el || !bar || !root || typeof bar.getBoundingClientRect !== "function") return;
    const rr = root.getBoundingClientRect(), br = bar.getBoundingClientRect(), k = wallUiOf(root, "--wall-ctl");
    const h = br.height > 0 && !narrow ? (br.top - rr.top - 8) / k - 10 : 0;
    if (h > 120) el.style.setProperty("--la3d-roomh", `${Math.round(h)}px`); else el.style.removeProperty("--la3d-roomh");
  }
  /** The panel's "More devices of the area (n)": what Home Assistant puts in the room's area that the sheet doesn't list. */
  function paintRoomMore(api){
    if (!roomPanel || !roomPanel.isOpen || !api) return;
    const room = roomPanel.room;
    roomPanel.more(ROOMS.areaExtras(api.hass, room, roomAggregate(lightsOf(api), room).all.map(l => l.entity_id)));
  }
  /** The card's data came in: the panel's sheet and list as the house is now; gone once its room no longer shows. */
  function syncRoomPanel(){
    if (!roomPanel || !roomPanel.isOpen) return;
    if (showSuspended() || (!roomByName(roomPanel.room) && !roomGo)) { closeRoomPanel(); return; }
    const api = apiNow || (apiOf ? (apiNow = apiOf()) : null);
    if (!api) return;
    if (roomSheet && !roomSheet.update(panelApi(api, roomPanel.room), lightsOf(api))) roomSheet = null;
    paintRoomMore(api);
    fitRoomPanel();
  }
  /** The host's api as the panel uses it: a switch it makes is said over the
   *  view with Undo, as a tap's is (a lock's never: unlocking asks first). */
  function panelApi(api, room){
    const lb = api.lightsByEid || {};
    return { ...api,
      toggle: (eid) => {
        const l = lb[eid], was = !!(l && l.state === "on");
        return Promise.resolve(api.toggle(eid)).then((ok) => {
          if (ok === true && l && !l.isLock) toast(`${l.friendly_name || eid} ${was ? "off" : "on"}`, () => api.toggle(eid), "Undo");
          return ok;
        });
      },
      setMany: (eids, on) => {
        const r = api.setMany(eids, on), n = eids.length, fans = eids.every(e => String(e).startsWith("fan."));
        toast(`${room}: ${n} ${fans ? (n === 1 ? "fan" : "fans") : (n === 1 ? "light" : "lights")} ${on ? "on" : "off"}`, () => api.setMany(eids, !on), "Undo");
        return r;
      } };
  }
  /** What the room panel covers: {right, bottom} px (beside the house; on a narrow screen, under it). */
  function panelSide(){
    const el = roomPanel && roomPanel.el;
    if (!el || !root || typeof el.getBoundingClientRect !== "function") return null;
    const rr = root.getBoundingClientRect(), pr = el.getBoundingClientRect();
    if (!(pr.width > 0) || !(pr.height > 0)) return null;
    return narrow ? { right: 0, bottom: Math.max(0, rr.bottom - pr.top) } : { right: Math.max(0, rr.right - pr.left), bottom: 0 };
  }
  /** Fly to a room as a double-tap does, framed in what the panel leaves
   *  clear, and open it: tinted, the other rooms faded, its codes. */
  function flyToRoom(at){
    const { F, r } = at, pts = [], side = panelSide();
    for (const p of r.pts) pts.push(new THREE.Vector3(p[0], F.fl.elev, p[1]), new THREE.Vector3(p[0], F.fl.elev + Math.min(1.2, F.fl.h), p[1]));
    const g = frameFor(cam.theta, Math.max(0.35, Math.min(cam.phi, 1.05)), pts, side);
    g.radius = Math.max(MIN_R, g.radius * 1.12);
    const H = (canvas && canvas.clientHeight) || 0;
    if (side && H) {
      // The room in the middle of what is left: the camera's middle moved right of it (a panel at the
      // side) or under it (a sheet at the bottom), by half of what is covered, at the room's distance.
      const perPx = 2 * Math.tan(FOV / 2 * D2R) * g.radius / H, th = g.theta, ph = g.phi;
      g.target.add(new THREE.Vector3(Math.cos(th), 0, -Math.sin(th)).multiplyScalar(side.right / 2 * perPx))
        .add(new THREE.Vector3(-Math.cos(ph) * Math.sin(th), Math.sin(ph), -Math.cos(ph) * Math.cos(th)).multiplyScalar(-side.bottom / 2 * perPx));
    }
    flyTo(g, false);
    openRoomOf(at, g.radius);
  }

  // ── picking: what a press lands on (PadSpan's own) ────────────────────────
  // Small things by how near they are on screen: a light within PICK_R of
  // any point it is drawn at (its bulbs and its glow, so a strip is pressed
  // anywhere along it), a sensor or a readout by its spot or its label —
  // the Atlas's 44 px target round every marker; the nearest wins, and the
  // others there are "under" it. Surfaces by the shape they cover on screen:
  // a room's name on its floor, a door's or window's opening; the nearest
  // along the ray wins. A floor badge is on top of everything, as on the
  // Atlas. Nothing hidden is pressed: a floor above the top one, a wall light
  // on a cut-away wall, or anything a ray from the eye meets a wall or a
  // floor before (the merged floor tiles included).
  const _hit = new THREE.Raycaster(), _sp = new THREE.Vector3();
  function screenPt(v, rect){
    _sp.copy(v).project(camera);
    if (!(_sp.z > -1 && _sp.z < 1)) return null;
    return [rect.left + (_sp.x + 1) / 2 * rect.width, rect.top + (1 - _sp.y) / 2 * rect.height];
  }
  /** Is v behind a wall or under a floor? own: "meshId:instance" keys of the
   *  thing itself (a door's own leaf and lintel never hide its opening).
   *  roof: the roof while it shows hides what is under it too — a press
   *  never lands on anything through it (the roof itself is never pressed). */
  function blocked(v, own, roof = false){
    const occ = [];
    for (const F of floorsUi) if (F.group.visible) { if (F.tiles) occ.push(F.tiles); if (F.solid) occ.push(F.solid); }
    if (roof && storeyL) occ.push(...storeyL.roofs());
    _v.copy(v).sub(camera.position);
    const d = _v.length();
    if (d < 0.2) return false;
    _hit.set(camera.position, _v.normalize());
    _hit.near = 0; _hit.far = d - 0.15;
    for (const h of _hit.intersectObjects(occ, false)) if (!(own && own.has(`${h.object.id}:${h.instanceId}`))) return true;
    return false;
  }
  /** The harness: a fixture that is off, its colour as drawn and as lit by day. */
  function offBulb(){
    const L = lights.find(x => x.look && !x.look.on && x.refs.bulbs.length);
    if (!L) return { offBulb: null, offLit: null };
    // Off fixtures are drawn by their own instanced set (bulbsOff, the room's shading).
    const r = L.refs.bulbs[0], a = (L.F.bulbsOff || L.F.bulbs)[r.prim].instanceColor.array;
    const o = offColour(new THREE.Color().copy(r.off));
    return { offBulb: [a[r.i * 3], a[r.i * 3 + 1], a[r.i * 3 + 2]], offLit: [o.r, o.g, o.b].map(v => v * (L.look.unavailable ? 0.55 : 1)) };
  }
  /** A sprite's corners in the world as it shows now (a name, a chip):
   *  its size on screen at its depth, its centre where sprite.center puts it. */
  function labelQuad(sp){
    const right = new THREE.Vector3().setFromMatrixColumn(camera.matrixWorld, 0), up = new THREE.Vector3().setFromMatrixColumn(camera.matrixWorld, 1);
    const depth = Math.max(0.01, -sp.position.clone().applyMatrix4(camera.matrixWorldInverse).z);
    const w = sp.scale.x * depth, h = sp.scale.y * depth, cx = sp.center.x, cy = sp.center.y;
    return [[-cx, -cy], [1 - cx, -cy], [1 - cx, 1 - cy], [-cx, 1 - cy]]
      .map(([x, y]) => sp.position.clone().addScaledVector(right, x * w).addScaledVector(up, y * h));
  }
  function openingQuad(F, P){
    const e = P.open.leaf || P.open.span, pc = P.pc, z0 = F.fl.elev + Math.max(0, e.z0);
    const z1 = F.fl.elev + (P.cut ? Math.min(e.z1, HOUSE.CUT_H) : e.z1);
    return [[pc.x0, z0, pc.y0], [pc.x1, z0, pc.y1], [pc.x1, z1, pc.y1], [pc.x0, z1, pc.y0]].map(a => new THREE.Vector3(...a));
  }
  // The ⋯ list's "Tap a light to switch it" (on unless this screen unticks it), on the
  // Atlas tab and its walls (mapOnly); Mapping's builder does not offer it, and switches as ever.
  const lightTapsOn = () => !mapOnly || !(showOn && showOn.light_taps === false);
  // The ⋯ list's "Lights as buttons" (off unless this screen ticks it; the Atlas tab and its walls, while a tap switches
  // lights). Research 2026-11-13: a fixture that is off is drawn its real size, a few pixels from across a room, and the
  // nearest device within reach took the tap, so a tap meant for a light found the sensor beside it. With this on, every
  // light of the floors showing is a button of one size on screen, drawn over the walls (live_aboard_use.js paints
  // them); the button is what a tap lands on. Buttons that would overlap are one, with their count: a tap on it lists
  // its lights. Anywhere else in a room, a tap opens the room's sheet.
  // Where a button stands (Garry, 2026-11-13: on the fixture, a ceiling light's button hung in the air over another
  // room once the ceiling was cut away, "not clearly visible where the light actually exists"): on the FLOOR, at the
  // spot it was placed on the map, where a spot in a picture of a house is one place only (a point up in the air is anywhere along
  // the line of sight: the ground is what places it, as a pin's line to the ground does in Google Earth and a drop
  // line in a 3D chart), with a plumb line up to the fixture itself and a dot on it.
  const BTN_JOIN = 28;                       // buttons nearer than this on screen are one, px
  const FOOT_UP = 0.03, _foot = new THREE.Vector3();   // a button's place: this far over its floor, under its fixture
  const buttonsOn = () => mapOnly && !!showOn && showOn.light_buttons === true && !showSuspended() && lightTapsOn();
  // The ⋯ list's "Rooms as light switches" (off unless this screen ticks it; the Atlas tab and its walls, while a tap
  // switches lights). Garry, 2026-11-14 (lights "close to useless" in the 3D look): a room's floor is the switch for
  // its lights (a tap: all on, or all off if any is on; a hold: its sheet; a hold then a drag: dims them), a target
  // metres wide; a single light is on the room's sheet. And the house lights up at a touch (wake): at night the 3D
  // look is as dark as the house, so nothing that is off can be found; a touch draws it as by day for WAKE_MS, as
  // The Sims lights a house evenly while it is being built. The first touch on a dark house only lights it up.
  const roomSwitchOn = () => mapOnly && !!showOn && showOn.room_switch === true && !showSuspended() && lightTapsOn();
  const WAKE_MS = 20000, WAKE_FADE_MS = 1500, WAKE_ELEV = 30, WAKE_DARK = 0.3;
  /** A touch on the house: true when it only lit the house up (it was dark: the press is nothing more). */
  function wake(){
    if (!roomSwitchOn() || (wakeK === 0 && nightReal < 0.01)) return false;   // by day there is nothing to light up
    const only = wakeK === 0 && nightReal > WAKE_DARK;
    wakeUntil = performance.now() + WAKE_MS;
    if (wakeK !== 1) { wakeK = 1; drawSun(bearingNow(), true); }
    return only;
  }
  /** On a frame once its time is up (no timer: the next poll's applySun asks for that frame, so it is lit WAKE_MS and
   *  up to a poll more): back to the real night in ten steps (and at once when the line is unticked). */
  function stepWake(t){
    const k = roomSwitchOn() ? Math.round(Math.max(0, 1 - (t - wakeUntil) / WAKE_FADE_MS) * 10) / 10 : 0;
    if (k !== wakeK) { wakeK = k; drawSun(bearingNow(), true); }
  }
  /** Is v under the floor of a storey that shows above it, seen from the eye? (No button shows through a floor.) */
  function underFloor(v, own){
    const c = camera.position;
    for (const G of floorsUi) {
      const e = G.fl.elev;
      if (G === own || !G.group.visible || !(e > v.y + 0.05) || !(c.y > e)) continue;
      const t = (c.y - e) / (c.y - v.y), x = c.x + (v.x - c.x) * t, y = c.z + (v.z - c.z) * t;
      if (G.rooms.some(r => HOUSE.inPoly(x, y, r.pts))) return true;
    }
    return false;
  }
  /** The buttons as they stand now: [{x, y (client px), v (its place in the house: on the floor), lights: [L, …],
   *  tops: [each fixture's own place on screen, or null]}]. */
  function buttonsNow(rect){
    const out = [];
    if (!buttonsOn() || !house || !rect.width || !rect.height) return out;
    for (const L of lights) {
      if (!L.at || !L.F.group.visible || L.swap || dimOf(L.eid)) continue;
      // Where it was PLACED (its spot on the map), not the middle of what is drawn for it: a ring of pots round a room
      // has its middle nowhere near any of them, and a strip drawn on a wall is metres from its spot (his house,
      // 2026-11-13: 15 of 58 lights drawn over 0.3 m from their spot, up to 3.4 m). The line goes to the nearest of
      // what is drawn for it.
      const foot = _foot.set(L.x, L.F.fl.elev + FOOT_UP, L.y);
      if (underFloor(foot, L.F)) continue;
      const s = screenPt(foot, rect);
      if (!s) continue;
      const flat = (v) => Math.hypot(v.x - L.x, v.z - L.y);
      const near = L.pick && L.pick.length ? L.pick.reduce((a, v) => (flat(v) < flat(a) ? v : a)) : L.at;
      const top = screenPt(near, rect), b = out.find(q => Math.hypot(q.x - s[0], q.y - s[1]) < BTN_JOIN);
      if (!b) { out.push({ x: s[0], y: s[1], v: foot.clone(), lights: [L], tops: [top] }); continue; }
      const n = b.lights.push(L);
      b.tops.push(top);
      b.x += (s[0] - b.x) / n; b.y += (s[1] - b.y) / n; b.v.lerp(foot, 1 / n);
    }
    return out;
  }
  /** The buttons for the overlay: [{x, y (px from the view's own corner), n, on: "all" | "some" | "none" | "gone",
   *  stems: [[dx, dy] from the button to each fixture, px]}]. */
  function buttonsUi(){
    if (!buttonsOn() || !renderer || !root || failed) return [];
    const rect = view3Rect(), r0 = root.getBoundingClientRect();
    const ox = r0.left + (root.clientLeft || 0), oy = r0.top + (root.clientTop || 0);
    camera.updateMatrixWorld();
    return buttonsNow(rect).map(b => {
      const lit = b.lights.filter(L => L.look && L.look.on).length;
      const on = lit === b.lights.length ? "all" : lit ? "some" : b.lights.every(L => L.look && L.look.unavailable) ? "gone" : "none";
      return { x: b.x - ox, y: b.y - oy, n: b.lights.length, on, stems: b.tops.filter(Boolean).map(t => [t[0] - b.x, t[1] - b.y]) };
    });
  }
  /** What a press on a button lands on: its light, or the several it stands for. */
  function buttonTarget(b){
    if (b.lights.length === 1) return { ...deviceTarget({ eid: b.lights[0].eid, v: b.v }), btn: "light" };
    const eids = b.lights.map(L => L.eid);
    return { kind: "lights", key: "lights:" + eids.join(","), eids, anchor: b.v, btn: "several", label: `${eids.length} lights here — lists them` };
  }
  const roomWords = (room) => { const n = Object.values(lbe).filter(l => l && l.area_name === room).length; return n ? `${room} — opens its ${n} device${n === 1 ? "" : "s"}` : null; };
  /** With the buttons on, a room's floor is pressed anywhere: its sheet (a room with nothing in it is no target). */
  function roomTarget(x, y){
    const sw = roomSwitchOn();
    const at = buttonsOn() || sw ? roomAtScreen(x, y) : null, label = at && at.r.name ? roomWords(at.r.name) : null;
    if (!label) return null;
    const quad = at.r.pts.map(p => new THREE.Vector3(p[0], at.F.fl.elev + 0.02, p[1]));
    // "Rooms as light switches": a room with lights is their switch (live_aboard_use.js act); one with none opens its sheet.
    const agg = sw ? roomAggregate(Object.values(lbe).filter(Boolean), at.r.name) : null;
    if (agg && agg.lightsTotal) {
      return { kind: "room", key: "room:" + at.r.name, room: at.r.name, quad, sw: true,
               label: `${at.r.name} — ${agg.lightsOn ? `${agg.lightsOn} of ${agg.lightsTotal} on: tap for off` : `${agg.lightsTotal} light${agg.lightsTotal === 1 ? "" : "s"}: tap for on`} · hold for its list` };
    }
    return { kind: "room", key: "room:" + at.r.name, room: at.r.name, quad, btn: "room", label };
  }
  /** Where a light shows: its bulbs, glow and run, or on a cut-away wall the glow on its floor. */
  const lightPoints = (L) => ((L.wall && L.wall.cut) ? L.poolPick : L.floorPick ? L.pick.concat(L.floorPick) : L.pick) || [];
  const nearPoly = (x, y, poly, slop) => HOUSE.inPoly(x, y, poly)
    || poly.some((a, i) => { const b = poly[(i + 1) % poly.length]; return HOUSE.segDist(x, y, a[0], a[1], b[0], b[1])[0] <= slop; });
  function deviceTarget(c){
    const l = lbe[c.eid];
    // A piece linked to a device the Atlas has no marker for (a TV, a
    // washer, a robot): Home Assistant's own controls for it (P5).
    if (!l && c.piece) {
      const st = lastP && lastP.states ? lastP.states[c.eid] : null;
      return { kind: "entity", key: "entity:" + c.eid, eid: c.eid, anchor: c.v,
               label: (st && st.attributes && st.attributes.friendly_name) || c.eid };
    }
    const said = motionL ? motionL.label(c.eid) : null;           // "Motion · Kitchen · 3 min ago"
    return { kind: "device", key: "device:" + c.eid, eid: c.eid, anchor: c.v,
             label: said || (l ? `${l.code ? l.code + " · " : ""}${l.friendly_name || c.eid}` : c.eid) };
  }
  function pickAt(clientX, clientY, noLights = false){
    if (!renderer || failed || !house) return null;
    const rect = view3Rect();
    if (!rect.width || !rect.height) return null;
    camera.updateMatrixWorld();
    // "Lights as buttons", a tap that was no button's (live_aboard_use up): the room there, and nothing else.
    if (noLights === "room") { const t = roomTarget(clientX, clientY); return t ? { hit: t, under: [] } : null; }
    const btnOn = buttonsOn();
    const rsOn = roomSwitchOn();
    const dist = (v) => { const s = screenPt(v, rect); return s ? Math.hypot(s[0] - clientX, s[1] - clientY) : Infinity; };
    // A tag or a scanner (P6): on it, or anywhere on a tag's name (names
    // show over everything, so a press there is the tag's).
    let tagHit = null;
    for (const T of tracked ? tracked.pickable() : []) {
      let d = dist(T.at);
      if (T.pts) d = Math.min(d, ...T.pts.map(dist));        // a person: anywhere from their feet to their head
      const s = T.name && T.namePx ? screenPt(T.name, rect) : null;
      if (s && Math.abs(clientX - s[0]) <= T.namePx[0] / 2 && clientY <= s[1] + 2 && clientY >= s[1] - T.namePx[1] - 2) d = 0;
      else if (d > PICK_R || blocked(T.at, null, true)) continue;
      if (!tagHit || d < tagHit.d) tagHit = { d, hit: { kind: T.kind, key: T.key, anchor: T.at, live: T.live, label: T.label,
                                                        card: T.kind === "person" && panel ? panel.cardOf(T.key, T.card) : T.card } };
    }
    // "Lights as buttons": a button within reach is the target (a tag or a person nearer still wins); a light is
    // pressed by its button alone.
    if (btnOn) {
      let best = null;
      for (const b of buttonsNow(rect)) { const d = Math.hypot(b.x - clientX, b.y - clientY); if (d <= PICK_R && (!best || d < best.d)) best = { d, b }; }
      if (best && !(tagHit && tagHit.d < best.d)) return { hit: buttonTarget(best.b), under: [] };
    }
    const devs = [];
    // On the Atlas tab (mapOnly) a light by what of it shows: the nearest of
    // its points (bulbs, glow, a run; on a cut-away wall the glow on the
    // floor) that no wall or floor hides from here, not merely the nearest
    // one. Mapping's builder picks as it always has.
    // `noLights`: a tap while "Tap a light to switch it" is unticked (live_aboard_use up): a light is no target for it at
    // all (review 2026-11-11: its glow on a cut-away wall took a tap a door or a room's name answered); a hold still is.
    for (const L of lights) {
      if (btnOn || rsOn || !L.F.group.visible || L.swap || dimOf(L.eid) || !L.pick || (!mapOnly && L.wall && L.wall.cut)) continue;   // a light is its button's, or its room's
      if (noLights && isTapLight(L.eid, lbe[L.eid])) continue;
      const near = (mapOnly ? lightPoints(L) : L.pick).map(v => ({ v, d: dist(v) })).filter(c => c.d <= PICK_R).sort((a, b) => a.d - b.d);
      const seen = mapOnly ? near.find(c => !blocked(c.v, null, true)) : near[0];
      if (seen) devs.push({ eid: L.eid, ...seen, light: L, clear: mapOnly });
    }
    for (const S of sensorsUi) {
      if (!S.F.group.visible || S.chip || dimOf(S.eid) || (motionL && S.kind === "motion")) continue;
      const d = dist(S.pos);
      if (d <= PICK_R) devs.push({ eid: S.eid, d, v: S.pos });
    }
    // A motion sensor: on its marker, drawn over everything where it shows.
    for (const M of motionL ? motionL.pickable() : []) {
      const d = dist(M.v);
      if (d <= PICK_R) devs.push({ eid: M.eid, d, v: M.v, top: true });
    }
    // A leak sensor or a lock (live_aboard_marks.js): by its spot, as a sensor.
    for (const M of marks ? marks.pickable() : []) {
      const d = dist(M.v);
      if (d <= PICK_R) devs.push({ eid: M.eid, d, v: M.v });
    }
    // A chip is pressed anywhere on its pill: its sensors, the first on top
    // (the rest "under" it). It is drawn over everything, so nothing hides it.
    for (const C of chips) {
      if (!C.F.group.visible || !C.sprite.visible) continue;
      const q = labelQuad(C.sprite).map(v => screenPt(v, rect));
      if (!q.every(Boolean)) continue;
      const cx = (q[0][0] + q[1][0]) / 2, half = Math.abs(q[1][0] - q[0][0]) * C.pillW / 2 + 4;
      const y0 = Math.min(q[0][1], q[2][1]) - 4, y1 = Math.max(q[0][1], q[2][1]) + 4;
      if (Math.abs(clientX - cx) <= half && clientY >= y0 && clientY <= y1) {
        [...C.sensors].filter(S => !dimOf(S.eid)).sort((a, b) => (CHIP_ORDER[a.kind] ?? 3) - (CHIP_ORDER[b.kind] ?? 3))
          .forEach((S, i) => devs.push({ eid: S.eid, d: i * 1e-3, v: C.sprite.position, top: true, chip: true }));
      }
    }
    // A piece that is a device (P5): anywhere on it, its device. A marker
    // nearer the press than PIECE_D still wins.
    const linked = devices ? devices.pickable() : [];
    if (linked.length) {
      _ndc.set((clientX - rect.left) / rect.width * 2 - 1, 1 - (clientY - rect.top) / rect.height * 2);
      _hit.setFromCamera(_ndc, camera);
      _hit.near = 0; _hit.far = Infinity;
      for (const c of linked) {
        if (dimOf(c.eid)) continue;
        const h = _hit.intersectObject(c.root, true).find(x => x.object.isMesh);
        if (h) devs.push({ eid: c.eid, d: PIECE_D, v: h.point.clone(), piece: c.id });
      }
    }
    devs.sort((a, b) => a.d - b.d);
    const ok = [];
    for (const c of devs.filter((c, i) => i < 8 || (mapOnly && c.light))) if (!ok.some(x => x.eid === c.eid) && (c.top || c.clear || !blocked(c.v, null, true))) ok.push(c);
    // The nearest under the finger wins, as before this build: a tag, a person, a motion marker, an alarm, a lock, a
    // device piece. One exception (review 2026-11-11), while a tap switches lights (the ⋯ line): a LIGHT (not a fan)
    // within its reach beats a code chip pressed over it (and a room's name, which is looked at only when no device is
    // in reach). A light winning: of the lights of other floors about as near (CLOSE_PX), the chosen floor's, else the
    // floor in front.
    const taps = mapOnly && lightTapsOn();
    const aLight = (c) => !!c.light && !(c.light.drawn === "fan" || (c.light.l && c.light.l.isFan));
    let win = ok[0];
    // Garry, 2026-11-13 ("make use more intuitive", proposal 1): while a tap switches lights, a LIGHT in reach beats
    // whatever else is in reach (a sensor, a readout's chip, a lock, a leak mark, a motion marker): a tap meant for a
    // light found the sensor beside it. A tag or a person nearer still wins (below).
    if (win && taps && !aLight(win)) win = ok.find(aLight) || win;
    if (win && aLight(win) && taps) {
      const lit = ok.filter(aLight), near = lit.filter(c => c.d <= win.d + CLOSE_PX), cam2 = (c) => camera.position.distanceToSquared(c.v);
      const mine = (c) => (selIds && selIds.has(String(c.light.F.fl.id)) ? 0 : 1);
      if (near.some(c => c.light.F !== win.light.F)) win = [...near].sort((a, b) => mine(a) - mine(b) || cam2(a) - cam2(b))[0];
    } else if (ok.length > 1 && !ok[0].top && !ok[1].top && ok[1].d - ok[0].d <= TIE_PX
        && camera.position.distanceToSquared(ok[1].v) < camera.position.distanceToSquared(ok[0].v)) win = ok[1];   // two as near: the one in front
    if (tagHit && (!win || tagHit.d <= win.d)) return { hit: tagHit.hit, under: ok.map(deviceTarget) };
    if (win) return { hit: deviceTarget(win), under: ok.filter(c => c !== win).map(deviceTarget) };
    const surf = [];
    for (const F of floorsUi) {
      if (!F.group.visible) continue;
      F.labels.forEach((lbl, i) => {
        if (!lbl.visible) return;
        const q = labelQuad(lbl), poly = q.map(v => screenPt(v, rect));
        // A name is drawn over everything: pressed where it shows, first.
        if (poly.every(Boolean) && HOUSE.inPoly(clientX, clientY, poly)) {
          surf.push({ kind: "room", room: F.rooms[i].name, quad: q, at: lbl.position, depth: -1 });
        }
      });
    }
    openings.forEach(({ F, P }, i) => {
      if (!F.group.visible || (P.open.leaf && goneHere(P, P.open.leaf))
          || !(P.open.cover ? !!(lastP && lastP.states && lastP.states[P.open.eid]) : HOUSE.openingPressable(lbe[P.open.eid]))) return;
      const q = openingQuad(F, P), poly = q.map(v => screenPt(v, rect));
      if (!poly.every(Boolean) || !nearPoly(clientX, clientY, poly, 6)) return;
      const at = q[0].clone().add(q[2]).multiplyScalar(0.5);
      surf.push({ kind: "door", F, P, i, quad: q, at, depth: camera.position.distanceTo(at) });
    });
    surf.sort((a, b) => a.depth - b.depth);
    for (const s of surf) {
      const own = s.kind === "door" ? new Set(s.P.els.map(e => `${e.mesh.id}:${e.i}`)) : null;
      if (s.kind !== "room" && blocked(s.at, own, true)) continue;
      if (s.kind === "room") {
        return { hit: { kind: "room", key: "room:" + s.room, room: s.room, quad: s.quad,
                        label: roomWords(s.room) || `${s.room} — opens its 0 devices` }, under: [] };
      }
      const o = s.P.open, b = o.bar, l = lbe[o.eid], st = lastP && lastP.states ? lastP.states[o.eid] : null, bar = HOUSE.barrierCardOf(b);
      const name = b.name || (l && l.friendly_name) || (st && st.attributes && st.attributes.friendly_name) || o.eid;
      const said = o.cover && STOREY ? STOREY.coverWords(st) : OPEN_WORD[o.state] || OPEN_WORD.none;
      // A door something moves (a garage door, a gate): a tap shows its card
      // of what it reads, a hold Home Assistant's own controls
      // (live_aboard_use.js doorMover), and nothing ever moves it here.
      const card = USE.doorMover(bar) ? { title: name, lines: [said, STOREY && st ? STOREY.movedWords(st.last_changed, Date.now()) : ""].filter(Boolean) } : null;
      return { hit: { kind: "door", key: `door:${o.eid}@${b.id || s.i}`, eid: o.eid, bar, quad: s.quad, card,
                      label: `${name} · ${said}` }, under: [] };
    }
    if (btnOn || rsOn) { const t = roomTarget(clientX, clientY); if (t) return { hit: t, under: [] }; }
    // Nothing under the finger (proposal 2): the nearest light within MAGNET_R that nothing hides takes the press, so
    // a fixture a few pixels across need not be hit exactly. Only while a tap switches lights, and never a fan.
    if (taps && !noLights && !btnOn && !rsOn) {
      let best = null;
      for (const L of lights) {
        if (!L.F.group.visible || L.swap || dimOf(L.eid) || !L.pick || L.drawn === "fan" || (L.l && L.l.isFan)) continue;
        for (const v of lightPoints(L)) { const d = dist(v); if (d <= MAGNET_R && (!best || d < best.d)) best = { d, v, L }; }
      }
      if (best && !blocked(best.v, null, true)) return { hit: { ...deviceTarget({ eid: best.L.eid, v: best.v }), near: true }, under: [] };
    }
    return null;
  }
  /** Where a target is, in px from the view's own corner (for its marks). */
  function screenOf(t){
    if (!renderer || !root) return null;
    const rect = view3Rect(), r0 = root.getBoundingClientRect();
    const ox = r0.left + (root.clientLeft || 0), oy = r0.top + (root.clientTop || 0);
    if (t.anchor) { const s = screenPt((typeof t.live === "function" && t.live()) || t.anchor, rect); return s ? { x: s[0] - ox, y: s[1] - oy } : null; }
    if (t.quad) {
      const ps = t.quad.map(v => screenPt(v, rect));
      return ps.every(Boolean) ? { poly: ps.map(p => [p[0] - ox, p[1] - oy]) } : null;
    }
    return null;
  }

  // ── drawing, on demand ────────────────────────────────────────────────────
  function shouldDraw(){
    return !!(renderer && root && root.isConnected !== false && visible
      && !(typeof document !== "undefined" && document.visibilityState === "hidden"));
  }
  function requestRender(){
    dirty = true;
    if (pending || failed || !renderer) return;
    pending = true;
    requestAnimationFrame(frame);
  }
  const frame = guard((t) => {
    pending = false;
    if (failed || !renderer) return;
    if (!shouldDraw()) {                                     // drawn again when it shows
      // A check cut short by hiding starts again: the gap is not a frame.
      quality.last = 0; quality.t0 = 0; quality.intervals = [];
      if (liveMs || wallSoft()) dirty = true;                // what moves carries on when it shows
      return;
    }
    // A camera flight moves on every frame until it lands.
    if (cam.fly) { stepFly(performance.now()); dirty = true; }
    if (wakeK > 0 && (performance.now() >= wakeUntil || !roomSwitchOn())) { stepWake(performance.now()); if (wakeK > 0) requestRender(); }
    // A press's ring and hold, the hover box's grace: timed on frames.
    const more = use ? use.tick(performance.now()) : false;
    if (wallSoft() && !wallMoving()) dirty = true;           // a wall that moved at less: every pixel again
    // Something moving by itself draws on its own clock (liveRate).
    const due = dirty || !!quality.measuring || (liveMs > 0 && t - lastAmbient >= liveMs - 4);
    if (due) {
      if (freshShow) openBare();
      if (cam.needsFit && (canvas.clientWidth || 0) > 0) { openView(); if (studio) arrive(); }
      if (wallMoves) { const pr = ratioFor(drawnW, drawnH); if (renderer.getPixelRatio() !== pr) renderer.setPixelRatio(pr); }
      syncLevel();                                           // labels by zoom level: the whole house, a floor, a room
      updateCutaway();
      // Editing, or the plan beside it: what stands on a line stands at its real height.
      const off = furnishOn || !!(editor && editor.active);
      if (off !== raisedOff) { raisedOff = off; if (raisedL) raisedL.touch(); }
      animateLive(performance.now());                        // and how often it moves now (liveMs)
      lastAmbient = t;
      sizeSprites();
      paintTags();                                           // the whole house: a tag beside each floor
      if (lampsDirty || lampTarget.distanceToSquared(cam.target) > 1) assignLamps();
      const vp = viewports();
      if (studio) studio.prepare(camera);
      if (forest) forestFrame();
      if (!vp.plan) renderer.render(scene, camera);
      else {
        // Furnish: the 3D view and the plan, each in its own part of the one canvas.
        fitPlan();
        renderer.setScissorTest(true);
        for (const [r, c] of [[vp.d3, camera], [vp.plan, planCam]]) {
          if (!r) continue;
          renderer.setViewport(r[0], drawnH - r[1] - r[3], r[2], r[3]);
          renderer.setScissor(r[0], drawnH - r[1] - r[3], r[2], r[3]);
          if (c === planCam) sizeNames(planCam, r[3]);         // the names, upright and sized for the plan
          if (studio) studio.prepare(c);                     // the plan keeps the view's own ground
          renderer.render(scene, c);
        }
        renderer.setScissorTest(false);
        renderer.setViewport(0, 0, drawnW, drawnH);
      }
      paintCompass();
      if (use) { if (rehoverDue) { rehoverDue = false; use.rehover(); } use.layout(); }
      if (editor) editor.layout();
      frames++;
      dirty = false;
      if (quality.measuring) {
        if (quality.last) quality.intervals.push(t - quality.last);
        quality.last = t;
        if (!quality.t0) quality.t0 = t;
        const n = quality.intervals.length, el = t - quality.t0;
        if (n >= MEASURE_FRAMES || (el > MEASURE_MS && n >= MEASURE_MIN) || el > MEASURE_GIVE_UP_MS) {
          quality.measured[quality.measuring] = HOUSE.frameMs(quality.intervals);
          decideQuality();
        } else requestRender();
      }
    }
    if ((liveMs || more || wallSoft()) && !pending) { pending = true; requestAnimationFrame(frame); }
  });
  // ── Furnish: the plan beside the 3D view (P2) ─────────────────────────────
  // Wide enough, the canvas is two views from the one renderer: the house in
  // 3D on the left, the plan of the top floor showing on the right. Narrower,
  // one of them, picked with Plan / 3D. Everything else draws, picks and
  // turns the 3D view in its own part (view3Rect).
  const SPLIT_MIN_W = 820, SPLIT_K = 0.58;
  /** Each view's part of the canvas, in CSS px from its top left [x, y, w, h], or null. */
  function viewports(){
    const w = drawnW, h = drawnH;
    if (!furnishOn || !w) return { d3: [0, 0, w, h], plan: null };
    if (w >= SPLIT_MIN_W) { const w3 = Math.round(w * SPLIT_K); return { d3: [0, 0, w3, h], plan: [w3, 0, w - w3, h] }; }
    return planOnly ? { d3: null, plan: [0, 0, w, h] } : { d3: [0, 0, w, h], plan: null };
  }
  function rectOf(vp){
    const r = canvas.getBoundingClientRect(), v = vp || [0, 0, 0, 0];
    return { left: r.left + v[0], top: r.top + v[1], width: v[2], height: v[3], right: r.left + v[0] + v[2], bottom: r.top + v[1] + v[3] };
  }
  /** The 3D view's own part of the canvas: all of it, except beside Furnish's plan. */
  const view3Rect = () => (furnishOn ? rectOf(viewports().d3) : canvas.getBoundingClientRect());
  /** The view under a screen point, with its camera (the editor's Furnish tool picks through it). */
  function viewAt(x, y){
    const vp = viewports(), inR = (r) => x >= r.left && x <= r.right && y >= r.top && y <= r.bottom;
    if (vp.plan) { const r = rectOf(vp.plan); if (inR(r)) { fitPlan(); return { camera: planCam, rect: r, plan: true }; } }
    if (vp.d3) { const r = rectOf(vp.d3); if (inR(r)) return { camera, rect: r, plan: false }; }
    return null;
  }
  const planHere = (x, y) => { const v = viewAt(x, y); return !!(v && v.plan); };
  /** The top floor showing, indoors (the editor's currentFloor). */
  const topFloorUi = () => floorsUi.filter(F => F.group.visible && !F.fl.outdoor && F.rooms.length).sort((a, b) => b.fl.elev - a.fl.elev)[0] || null;
  /** The plan's camera: straight down on the top floor showing, fitted to
   *  its rooms until someone pans or zooms it. */
  function fitPlan(){
    const vp = viewports().plan;
    if (!vp || !planCam || !vp[3]) return;
    const F = topFloorUi(), a = vp[2] / vp[3];
    if (plan.fit && F) {
      let x0 = Infinity, y0 = Infinity, x1 = -Infinity, y1 = -Infinity;
      for (const r of F.rooms) for (const p of r.pts) { x0 = Math.min(x0, p[0]); y0 = Math.min(y0, p[1]); x1 = Math.max(x1, p[0]); y1 = Math.max(y1, p[1]); }
      if (Number.isFinite(x0)) { plan.cx = (x0 + x1) / 2; plan.cy = (y0 + y1) / 2; plan.half = Math.max(1.5, (y1 - y0) / 2, (x1 - x0) / 2 / a) * 1.1; }
    }
    const top = (F ? F.fl.elev + F.fl.h : houseBox.z1) + 30;
    planCam.left = -plan.half * a; planCam.right = plan.half * a; planCam.top = plan.half; planCam.bottom = -plan.half;
    planCam.near = 1; planCam.far = top - houseBox.z0 + 10;
    planCam.position.set(plan.cx, top, plan.cy);
    planCam.lookAt(plan.cx, top - 10, plan.cy);
    planCam.updateProjectionMatrix();
    planCam.updateMatrixWorld();
  }
  function planPanBy(dx, dy){
    const vp = viewports().plan;
    if (!vp || !vp[3]) return;
    const k = 2 * plan.half / vp[3];
    plan.fit = false; plan.cx -= dx * k; plan.cy -= dy * k;
    requestRender();
  }
  function planZoomAt(x, y, f){
    const vp = viewports().plan;
    if (!vp || !vp[3]) return;
    const r = rectOf(vp), k = 2 * plan.half / vp[3];
    const px = plan.cx + (x - (r.left + r.width / 2)) * k, py = plan.cy + (y - (r.top + r.height / 2)) * k;
    const h = Math.max(1, Math.min(200, plan.half * f)), s = h / plan.half;
    plan.fit = false; plan.cx = px + (plan.cx - px) * s; plan.cy = py + (plan.cy - py) * s; plan.half = h;
    requestRender();
  }
  /** Mapping → Furnish on or off (attach): the plan comes or goes. */
  function setFurnishView(on){
    if (furnishOn === on) return;
    furnishOn = on; planOnly = false; plan.fit = true;
    if (tipEl) tipEl.style.display = on ? "none" : "";       // Furnish has its own words
    if (on) closeRoomPanel();
    resize(true);
  }
  function setPlanOnly(on){
    if (planOnly === !!on) return;
    planOnly = !!on; plan.fit = true;
    resize(true);
  }
  function paintPlan(){
    if (!planSeg) return;
    const narrow = furnishOn && drawnW > 0 && drawnW < SPLIT_MIN_W, vp = viewports();
    // Furnish's panel keeps to the 3D side, clear of the plan (live_aboard_furnish.js).
    root.style.setProperty("--la3d-plan-w", `${vp.plan && vp.d3 ? vp.plan[2] : 0}px`);
    planSeg.style.display = narrow ? "" : "none";
    const bs = planSeg.querySelectorAll("button");
    if (bs[0]) bs[0].setAttribute("aria-pressed", String(!planOnly));
    if (bs[1]) bs[1].setAttribute("aria-pressed", String(planOnly));
  }
  function resize(force = false){
    if (!renderer || !root) return;
    const w = root.clientWidth, h = root.clientHeight;
    if (!w || !h) return;                                    // detached for a moment between two cards
    if (!force && w === drawnW && h === drawnH) return;      // moved into a new card at the same size: nothing to draw
    drawnW = w; drawnH = h;
    narrow = w < NARROW_W;
    root.classList.toggle("la3d-narrow", narrow);
    if (roomChips) roomChips.sync();                         // a narrow screen: one Rooms ▾
    const pr = ratioFor(w, h);
    if (renderer.getPixelRatio() !== pr) renderer.setPixelRatio(pr);
    renderer.setSize(w, h, false);
    const d3 = viewports().d3;                               // Furnish's plan may take part of it
    camera.aspect = (d3 ? d3[2] : w) / h;
    camera.updateProjectionMatrix();
    paintPlan();
    requestRender();
    if (raisedL) raisedL.touch();
  }
  function wireObservers(){
    if (typeof ResizeObserver !== "undefined") {
      const ro = new ResizeObserver(guard(() => resize()));
      ro.observe(root);
      observers.push(() => ro.disconnect());
    }
    if (typeof IntersectionObserver !== "undefined") {
      const io = new IntersectionObserver(guard((entries) => {
        const e = entries[entries.length - 1];
        visible = !!(e && e.isIntersecting);
        if (visible && dirty) requestRender();
        peopleClock();
      }));
      io.observe(root);
      observers.push(() => io.disconnect());
    }
    if (typeof document !== "undefined" && document.addEventListener) {
      const onVis = guard(() => { if (document.visibilityState !== "hidden" && dirty) requestRender(); peopleClock(); });
      document.addEventListener("visibilitychange", onVis);
      observers.push(() => document.removeEventListener("visibilitychange", onVis));
      // Full screen came or went (Escape, or the browser's own way out).
      const onFull = guard(() => onFullChange());
      document.addEventListener("fullscreenchange", onFull);
      document.addEventListener("webkitfullscreenchange", onFull);
      observers.push(() => { document.removeEventListener("fullscreenchange", onFull); document.removeEventListener("webkitfullscreenchange", onFull); });
    }
  }

  // ── the 3D file (part C) ──────────────────────────────────────────────────
  /** What is drawn on top of the map: the editor's draft while editing,
   *  else the 3D file as read. */
  const viewData = () => (editor && editor.view()) || shownFile();
  // ── heights on the placement records (Garry, 2026-10-05) ──────────────────
  // A placed device's height lives on its placement record (z_m,
  // fabric_light_height_set), the map's own data: the record's height first,
  // then the 3D file's (an older install's, or a device with no record), then
  // its kind's default. The house is drawn from the file with the records'
  // heights laid over it (DRAFT.withRecordHeights), so every reader of a
  // height (lights, sensors, the marks, the motion mount, the Strip tool's
  // default) takes the record's without knowing where it came from.
  /** The placement records as saved: the host's own (Mapping draws its
   *  unsaved placements and heights over them, and a device dropped there
   *  and not yet saved has no record), else the map's. */
  const savedRecords = () => (lastP && typeof lastP.records === "function" ? lastP.records()
    : lastP && lastP.model && lastP.model.light_positions_m) || {};
  /** {entity id: z_m or null}: the heights as the map draws them: each
   *  record's, and in Mapping its unsaved Height-row value over the record,
   *  for a device dropped there and not yet saved too (as its Height row,
   *  Heights list and hover box say it); never written to the file for one
   *  with no record (splitSave). A height just written to the file for one
   *  with no record (fileZ) is drawn over Mapping's unsaved one, older, while
   *  the map still says that one (maps.js drops it). A height just saved
   *  stands in until the saved record changes at all (it has it now, or
   *  another was saved over it since, say Mapping's Save placements): never
   *  measured against Mapping's draft, so it never outlives the record it
   *  was saved to. */
  function recordsNow(){
    const saved = savedRecords(), savedZ = DRAFT.recordHeights({ light_positions_m: saved });
    const recs = DRAFT.recordHeights(lastP && lastP.model);
    for (const k of Object.keys(fileZ)) {
      const f = fileZ[k];
      if (f.over !== null && f.over !== overSig(recs, k)) f.over = null;
      if (f.over !== null) delete recs[k];
    }
    for (const k of Object.keys(recZ)) {
      const now = k in savedZ ? savedZ[k] : undefined;
      if (!saved[k] || now !== recZ[k].was) { delete recZ[k]; continue; }
      recs[k] = recZ[k].z;
    }
    return recs;
  }
  /** The devices with a placement record (the ones whose height lives there). */
  const placedNow = () => new Set(Object.keys(savedRecords()));
  // What the map says of a height: Mapping's (or the record's) for one
  // device, and which heights in the file are out of date (the model's
  // light_heights_gone: a record's decided height removed since).
  const overSig = (recs, k) => JSON.stringify(Object.prototype.hasOwnProperty.call(recs, k) ? recs[k] : "none");
  const goneOf = () => { const g = lastP && lastP.model && lastP.model.light_heights_gone; return Array.isArray(g) ? g : []; };
  const goneSig = () => JSON.stringify([...goneOf()].sort());
  /** The devices whose height in the file no view reads (the model's
   *  light_heights_gone), but for one just written there (fileZ), while the
   *  model still says what it said then (the server has taken it off). */
  function goneNow(){
    const g = new Set(goneOf()), sig = goneSig();
    for (const k of Object.keys(fileZ)) {
      const f = fileZ[k];
      if (f.gone !== null && f.gone !== sig) f.gone = null;
      if (f.gone !== null) g.delete(k);
      if (f.over === null && f.gone === null) delete fileZ[k];
    }
    return g;
  }
  /** Which of the file's sections the view reads a device's height from. */
  const sectionOf = (eid) => (HOUSE.isFixture(lbe[eid]) ? "lights" : "devices");
  /** The file as drawn: the records' heights over it, without the ones out
   *  of date (goneNow) (the same object while none changed; the file itself
   *  while no record has a height and none is out of date). */
  function shownFile(){
    const f = file || NO_FILE, recs = recordsNow(), gone = [...goneNow()].sort();
    const sig = JSON.stringify([gone, Object.keys(recs).sort().map(k => [k, recs[k], sectionOf(k)])]);
    if (!shownMemo || shownMemo.f !== f || shownMemo.sig !== sig) shownMemo = { f, sig, out: DRAFT.withRecordHeights(withoutGone(f, gone), recs, sectionOf) };
    return shownMemo.out;
  }
  // What a part of Save that failed was, said plainly (the rest was saved).
  const PART_FAILED = {
    read_failed: "Live Aboard's file couldn't be read", save_failed: "Live Aboard's file couldn't be written",
    house3d_newer: "a newer PadSpan saved Live Aboard's file, and this version never changes it",
    house3d_sample: "this is the sample house; switch to Live to edit your own",
  };
  const why = (err) => PART_FAILED[err && err.code] || String((err && (err.message || err.code)) || err);
  /** Edit's Save: one Save, two writes. The heights the draft changed (from
   *  `base`, where it started) of devices with a placement record go to
   *  their records first, all in one command (the host's heights:
   *  fabric_light_height_set, the Atlas's own permission); everything else
   *  goes to the 3D file (the host's edit: house3d_edit). A refused height
   *  command changes nothing at all; a file write that fails after the
   *  heights went in says so, and hands the editor the heights saved (it
   *  starts from them: live_aboard_edit.js). A height written to the file
   *  for a device with no record is the newest it has from then on (fileZ).
   *  A host with no height command: all to the file, as before. A Save that
   *  went through brings the railings from before over (stampEdgeRails). */
  async function editSave(ch0, base){
    const r = await saveEdit(ch0, base);
    stampEdgeRails();
    return r;
  }
  async function saveEdit(ch0, base){
    // A split level (HOUSE.splitLevels) is drawn, never stored: its floor's id goes to the file.
    const ch = HOUSE.wholeFloors ? HOUSE.wholeFloors(ch0) : ch0;
    const p = lastP || {}, edit = p.edit, put = typeof p.heights === "function" ? p.heights : null;
    if (!put) return edit(ch);
    const split = DRAFT.splitSave(file || NO_FILE, ch, base, placedNow());
    if (split.heights) {
      const before = DRAFT.recordHeights({ light_positions_m: savedRecords() });
      try { await put(split.heights); }
      catch (err) {
        throw Object.assign(new Error(`the heights couldn't be saved (${why(err)}). Nothing was changed; your changes are still here: Save to try again.`),
          { code: "heights_failed" });
      }
      for (const [k, z] of Object.entries(split.heights)) recZ[k] = { z, was: k in before ? before[k] : undefined };
      shownMemo = null;
    }
    if (!split.file) return { data: fileRaw || file || NO_FILE };
    const mine = split.file.heights_set || [], said = mine.length ? { recs: recordsNow(), gone: goneSig() } : null;
    try {
      const r = await edit(split.file);
      for (const k of mine) fileZ[k] = { over: overSig(said.recs, k), gone: said.gone };
      if (mine.length) shownMemo = null;
      return r;
    }
    catch (err) {
      if (!split.heights) throw err;
      throw Object.assign(new Error(`Heights saved. The rest wasn't: ${why(err)}. Your other changes are still here: Save to try again.`),
        { code: err && err.code, partial: true, heights: split.heights });
    }
  }
  // Read through the host (the view calls nothing itself), once per showing:
  // a failed read leaves the house as the map draws it, with no retry until
  // the screen comes back to 3D. Drawn as soon as it arrives.
  function loadFile(p){
    if (fileLoad || typeof p.load !== "function") return;
    const mine = fileLoad = Promise.resolve().then(() => p.load()).then((r) => {
      if (fileLoad !== mine) return false;
      fileRaw = (r && r.data) || null;
      file = DRAFT.ownedOf(r && r.data);
      scanPieces = r && r.scan_pieces && typeof r.scan_pieces === "object" ? r.scan_pieces : null;
      // Sample mode's house is read-only for its own reason (sample_house.js), not a newer file.
      setFileErr(DRAFT.writable(r && r.data, r && r.writable) ? null : (r && r.sample ? "house3d_sample" : "house3d_newer"));
      if (editor) editor.fileChanged();                   // an open draft follows what was removed elsewhere
      redraw();
      return true;
    }, (err) => {
      // There but unreadable: the house draws from the map, and Edit says why.
      if (fileLoad === mine && err && err.code === "read_failed") setFileErr("read_failed");
      return false;
    });
  }
  const redraw = guard(() => { if (rawP && renderer && !failed) update(rawP); });   // rawP: while quiet, lastP is the quiet copy, and update(lastP) would make that the real data
  /** After a Save of the person's own, never on opening: each Open (Loft)
   *  edge with no rail word gets the word for what the drop rule draws
   *  (HOUSE.edgeRailsToStamp: glass or none, so nothing changes to look at).
   *  Only the words go to the host (barrierRail: the view calls nothing
   *  itself); the server puts each on the record it holds. Then a file from
   *  before says its railings are chosen. Quiet: a failure leaves everything
   *  as it was and the next Save tries again. A home with no 3D file, whose
   *  file says "chosen" from its first Save, has its edges brought over the
   *  same way. */
  async function stampEdgeRails(){
    const p = lastP;
    if (railsStamping || !p || !reading || fileErr || typeof p.edit !== "function" || typeof p.barrierRail !== "function") return;
    railsStamping = true;
    try {
      const todo = HOUSE.edgeRailsToStamp(reading, (p.model && p.model.rf_barriers_m) || []);
      if (todo.length) await p.barrierRail(Object.fromEntries(todo.map(({ id, rail }) => [id, rail])));
      if (fileRaw && fileRaw.rails_chosen !== true) {
        const r = await p.edit({ rails_chosen: true });
        if (r && r.data) { fileRaw = r.data; file = DRAFT.ownedOf(r.data); }
      }
    } catch (err) {
      console.warn("PadSpan Live Aboard: the railings could not be made choices on this screen:", why(err));
    } finally { railsStamping = false; }
  }
  // Why the file cannot be edited, changed: Edit says so.
  function setFileErr(code){
    if (((fileErr && fileErr.code) || null) === (code || null)) return;
    fileErr = code ? { code } : null;
    if (editor) editor.refresh();
  }
  /** Read the file again (the editor opening before the first read came). */
  function reloadFile(){
    fileLoad = null;
    if (lastP) loadFile(lastP);
    return fileLoad || Promise.resolve(false);
  }
  /** A drawn light or sensor, for the editor's Heights: its height now and
   *  by default, its floor, where it is. Scanners are never drawn here: the
   *  map keeps their heights (presence uses them). */
  function deviceInfo(eid){
    const L = lights.find(x => x.eid === eid), S = L ? null : sensorsUi.find(x => x.eid === eid), X = L || S;
    if (!X || typeof X.z !== "number") return markInfo(eid);
    const l = lbe[eid];
    return { section: L ? "lights" : "devices", eid, F: X.F, z: X.z, zDefault: X.zDefault, l: l || X.l || null, x: X.x, y: X.y,
             kind: L ? L.drawn : null, guess: L ? L.guess : null,
             label: l ? `${l.code ? l.code + " · " : ""}${l.friendly_name || eid}` : eid,
             at: new THREE.Vector3(X.x, X.F.fl.elev + X.z, X.y), drawn: L && L.at ? L.at : null };
  }
  // The line tool traces the plan: straight down on the floor it draws on.
  function topDownOn(F){
    const pts = [];
    for (const r of F.rooms) for (const p of r.pts) pts.push(new THREE.Vector3(p[0], F.fl.elev, p[1]), new THREE.Vector3(p[0], F.fl.elev + F.fl.h - HOUSE.SLAB_T, p[1]));
    cam.moved = true; cam.needsFit = false; cam.fly = null;      // (the Plans tool may have a flight on the way)
    fit(0, MIN_PHI, pts.length ? pts : undefined);
  }
  // ── a slider being dragged (the editor's Height, Sill, Head) ──────────────
  /** Only what the slider moves, moved in place from the draft: a door's or
   *  window's heights, or a light or sensor up or down. Nothing is read
   *  again or rebuilt; false when it is not drawn (the editor then draws the
   *  house again). Let go, the editor draws the house whole (update). */
  function preview(t){
    if (!renderer || failed || !t) return false;
    const vd = viewData();
    const ok = t.opening ? moveOpening(String(t.opening), vd) : t.eid ? moveDevice(String(t.eid), vd)
      : t.piece && layer ? layer.move(String(t.piece), (vd.pieces || {})[String(t.piece)]) : false;
    if (ok) { work.moves++; requestRender(); }
    return ok;
  }
  function moveOpening(id, vd){
    const o = vd.openings[id] || null, moves = [];
    // Every wall piece it is drawn in (one split over two walls or more moves
    // whole), each checked before any moves.
    for (const F of floorsUi) for (const P of F.pieces) {
      const pc = P.pc;
      if ((pc.kind !== "door" && pc.kind !== "window") || (pc.added ? pc.added !== id : !(pc.barrier && pc.barrier.id === id))) continue;
      // Its heights as the draft gives them (spliceOpening, applyOpenings).
      const bare = { ...pc, sill_m: undefined, head_m: undefined };
      const next = pc.added ? (o ? { ...pc, sill_m: o.sill_m, head_m: o.head_m } : null) : o ? DRAFT.overrideOpening(bare, o) : bare;
      if (!next) return false;
      const els = HOUSE.wallElements(next, F.fl.h);
      if (els.length !== P.els.length || els.some((e, i) => e.glass !== P.els[i].glass)) return false;
      moves.push({ F, P, next, els });
    }
    for (const { F, P, next, els } of moves) {
      els.forEach((e, i) => { P.els[i].z0 = e.z0; P.els[i].z1 = e.z1; });
      P.pc.sill_m = next.sill_m; P.pc.head_m = next.head_m;
      placePiece(F, P, !!P.cut);
    }
    return moves.length > 0;
  }
  function moveDevice(eid, vd){
    const L = lights.find(x => x.eid === eid);
    if (L) {
      // Moved whole, as liftParts moves it: bulbs, housings, glows, where a
      // press finds it and where its lamp hangs.
      if (typeof L.z !== "number" || !L.look) return false;
      const F = L.F, st = vd.lights[eid], want = st && typeof st.z_m === "number" && Number.isFinite(st.z_m) ? st.z_m : null;
      const z = want === null ? L.zDefault : DRAFT.clampHeight(want, HOUSE.ceilAt(F.rooms, F.fl, L.x, L.y) - HOUSE.SLAB_T), d = z - L.z;
      for (const r of L.refs.bulbs) r.m.elements[13] += d;
      for (const r of L.refs.houses) {
        r.hh.h += d;
        F.houses.setMatrixAt(r.i, compose(r.hh.x, F.fl.elev + r.hh.h, r.hh.y, r.hh.yaw, r.hh.sx, r.hh.sy, r.hh.sz));
        F.houses.instanceMatrix.needsUpdate = true;
      }
      for (const r of L.refs.halos) {
        const a = F.halos[r.cls].geometry.attributes.position;
        a.setY(r.i, a.getY(r.i) + d);
        a.needsUpdate = true;
      }
      for (const r of L.refs.washes) {
        if (r.w.fixed) continue;                            // where it lands stays (a counter, the floor)
        r.w.h += d;
        F.washes[r.tex].setMatrixAt(r.i, washMatrix(r.w, F.fl.elev));
        F.washes[r.tex].instanceMatrix.needsUpdate = true;
      }
      for (const v of L.pick) v.y += d;
      L.lamp.y += d; L.z = z; lampsDirty = true;
      paintLight(L);
      return true;
    }
    const S = sensorsUi.find(x => x.eid === eid);
    if (!S) return marks ? marks.move(eid, vd.devices[eid] || null) : false;
    S.z = HOUSE.deviceZ(S.kind, HOUSE.ceilAt(S.F.rooms, S.F.fl, S.x, S.y) - HOUSE.SLAB_T, vd.devices[eid] || null);
    S.pos.y = S.F.fl.elev + S.z;
    if (S.mesh) { S.mesh.setMatrixAt(S.i, compose(S.x, S.pos.y, S.y, 0, 0.055, 0.04, 0.055)); S.mesh.instanceMatrix.needsUpdate = true; }
    if (motionL && S.kind === "motion") motionL.move(eid, S.z);
    if (S.chip && S.chip.outdoor) placeChip(S.chip);
    return true;
  }

  // ── the Atlas's drawers and its other devices (live_aboard_marks.js) ──────
  // ☰'s class chips: a device of another class fades toward the ground (its
  // glow, its pool, its readout chip with it) and takes no taps, by the
  // Atlas's own class test; a door's or a lock's wall never fades (as on the
  // Atlas: "any setting should not negate a door showing up properly").
  // Leak sensors and locks are drawn where they are placed; each device's
  // code shows under it at room scale unless codes are hidden. ⚙'s Zoom,
  // ◎ Find active, Save view and Reset view drive this camera while it shows.
  let clsDrawn = null;
  // seeDim: one pick that also finds what the class chips dim (dimmedNote).
  let seeDim = false, classCb = null, classWord = null;
  const dimOf = (eid) => !seeDim && !!(classF && MARKS && MARKS.dimmed(lbe[eid], classF));
  /** A tap on nothing, while ☰'s class chips dim the rest: if a dimmed device is under it, say why it did nothing
   *  (his wall, 2026-11-12: left on Motion, no light answered a tap and nothing said so), with the way back. */
  function dimmedNote(x, y){
    if (!classF || !mapOnly) return;
    let f = null;
    seeDim = true;
    try { f = pickAt(x, y); } finally { seeDim = false; }
    const h = f && f.hit;
    if (!h || h.kind !== "device" || !MARKS.dimmed(lbe[h.eid], classF)) return;
    toast(`Only ${classWord || "one kind of device"} takes taps now: the rest is dimmed.`, classCb ? () => classCb("all") : null, "Show all");
  }
  const fadeHex = (hex) => "#" + new THREE.Color(hex).lerp(scene.background, 1 - MARKS.DIM_K).getHexString();
  /** A room tint's strength: faded while every sensor in it is another class. */
  const tintK = (list) => (classF && list.length && list.every(S => dimOf(S.eid)) ? MARKS.DIM_K : 1);
  /** The card's drawers: the class picked (a change repaints every light),
   *  and the zoom label to keep up to date. */
  function takeDrawers(p){
    const cls = MARKS && p.classFilter && p.classFilter !== "all" ? String(p.classFilter) : null;
    if (cls !== classF) { classF = cls; for (const L of lights) L.key = null; }
    classCb = typeof p.onClassFilter === "function" ? p.onClassFilter : null;
    classWord = typeof p.classLabel === "string" && p.classLabel ? p.classLabel : null;
    zoomCb = typeof p.onZoom === "function" ? p.onZoom : null;
    zoomShown = null;
  }
  function syncMarks(p, vd){
    let changed = false;
    if (marks && reading) {
      changed = marks.sync({ model: p.model, floors: floorsUi, F: reading, lbe, hidden: p.hidden, devices: vd.devices, gen: shellGen,
                             cls: classF, latches: p.floodLatches || {}, now: Date.now(), bg: scene.background }) || changed;
    }
    if (codes) changed = codes.sync(codeList(p)) || changed;
    for (const C of chips) {
      // A room's readout chip fades while every sensor in it is another class.
      const op = classF && C.sensors.every(S => dimOf(S.eid)) ? MARKS.DIM_K + 0.1 : 1;
      if (C.clsOp !== op || C.sprite.material.opacity !== op * (C.fk ?? 1)) { C.clsOp = op; C.sprite.material.opacity = op * (C.fk ?? 1); changed = true; }
    }
    if (classF !== clsDrawn) { clsDrawn = classF; changed = true; }
    if (changed) { animateLive(performance.now()); requestRender(); }
  }
  /** A press finds a fixture anywhere it is drawn; its code hangs under the
   *  point of it nearest its middle. */
  function middleOf(pts){
    const c = pts.reduce((a, v) => a.add(v), new THREE.Vector3()).multiplyScalar(1 / pts.length);
    return pts.reduce((b, v) => (v.distanceTo(c) < b.distanceTo(c) ? v : b));
  }
  /** Every drawn device with a code, for its chip (p.codes: shown unless
   *  "Hide device codes" is on; the chip colours are the Atlas's theme's). */
  function codeList(p){
    if (!MARKS || !p.codes || typeof p.codes !== "object") return [];
    // The theme the flat map's chips use (stored, whether Showcase is on or not).
    const theme = (p.atlasLook && p.atlasLook.theme) || (p.showcase && p.showcase.theme) || null, sc = !!p.codes.showcase, out = [];
    const add = (eid, F, v, lit, gap) => { const look = MARKS.chipLook(lbe[eid], theme, sc, lit); if (look) out.push({ eid, F, v, look, dim: dimOf(eid), gap }); };
    for (const L of lights) {
      if (!L.pick || !L.pick.length || L.swap) continue;
      add(L.eid, L.F, middleOf(L.pick), sc && L.look && L.look.on && L.color ? "#" + L.color.getHexString() : null);
    }
    // A motion sensor's code hangs below its marker (lit, it is the biggest thing there).
    const mGap = MOTION ? Math.ceil(MOTION.MARK_PX.lit / 0.72 / 2) + 4 : 10;
    for (const S of sensorsUi) if (S.kind === "motion") add(S.eid, S.F, S.pos, null, mGap);
    for (const M of marks ? marks.places() : []) add(M.eid, M.F, M.v, null);
    return out;
  }
  /** Codes at room scale; the leak alarms' words a size you can read. */
  function sizeMarks(){
    const H = canvas.clientHeight || 600, near = MARKS ? MARKS.codesAt(cam.radius, camera.aspect, FOV, fitR) : true;
    // Codes in the room open only (labels by zoom level); while Edit, Furnish or the Plans tool's map has the view, at room scale as ever.
    const pref = !!(lastP && lastP.codes && typeof lastP.codes === "object"), o = openRoom;
    const keep = level === "room" && o ? Object.assign((C) => C.F === o.F && HOUSE.inPoly(C.v.x, C.v.z, o.r.pts), { key: `${o.fid}|${o.i}` }) : null;
    if (codes) codes.size(camera, H, pref && (showSuspended() ? near : level === "room"), keep);
    if (marks) marks.size(camera, H);
    if (motionL) motionL.size(camera, H, near || level === "room");
  }
  /** A leak sensor or a lock, for the editor's Heights (as deviceInfo). */
  // A device hovered or pressed, up off its floor (a ceiling light, a fan, a
  // sensor on the wall), drops a dashed line to a ring on its floor: under a
  // cut-away ceiling it reads as over its spot, not stuck to the far wall.
  // A motion sensor has its own (live_aboard_motion.js).
  function makePlumb(){
    const lm = new THREE.LineDashedMaterial({ color: "#fbbf24", transparent: true, opacity: 0.85, dashSize: 0.08, gapSize: 0.06, depthWrite: false });
    const lg = new THREE.BufferGeometry();
    lg.setAttribute("position", new THREE.BufferAttribute(new Float32Array(6), 3));
    const line = new THREE.Line(lg, lm);
    const rg = new THREE.RingGeometry(0.08, 0.13, 32).rotateX(-Math.PI / 2);
    const rm = new THREE.MeshBasicMaterial({ color: "#fbbf24", transparent: true, opacity: 0.85, depthWrite: false, side: THREE.DoubleSide,
      polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -6 });
    const ring = new THREE.Mesh(rg, rm);
    line.renderOrder = 4; ring.renderOrder = 4; line.frustumCulled = false;
    line.visible = false; ring.visible = false;
    scene.add(line, ring);
    return { line, ring, dispose(){ for (const r of [lg, lm, rg, rm]) r.dispose(); } };
  }
  /** Point the drop line at eid (or put it away). True when that changed what is drawn. */
  function plumbTo(eid){
    if (!scene) return false;
    if (!plumb) plumb = makePlumb();
    const S = eid ? sensorsUi.find(x => x.eid === eid) : null;
    const info = eid && !(S && S.kind === "motion") ? deviceInfo(eid) : null;
    const up = info && info.at ? info.at.y - info.F.fl.elev : 0;
    const on = !!info && up > 0.3 && !!(info.F.group && info.F.group.visible);
    const was = plumb.line.visible;
    if (on) {
      const at = info.at, y0 = info.F.fl.elev + 0.012, a = plumb.line.geometry.attributes.position;
      a.setXYZ(0, at.x, at.y, at.z); a.setXYZ(1, at.x, y0, at.z); a.needsUpdate = true;
      plumb.line.computeLineDistances();
      plumb.ring.position.set(at.x, y0, at.z);
    }
    plumb.line.visible = on; plumb.ring.visible = on;
    return on || was;
  }
  function markInfo(eid){
    const M = marks ? marks.info(eid) : null;
    if (!M) return null;
    const l = lbe[eid];
    return { section: "devices", eid, F: M.F, x: M.x, y: M.y, z: M.z, zDefault: M.zDefault, l: l || null, kind: null, guess: null,
             label: l ? `${l.code ? l.code + " · " : ""}${l.friendly_name || eid}` : eid, at: new THREE.Vector3(M.x, M.F.fl.elev + M.z, M.y) };
  }
  // ⚙'s Zoom: − and + step out and in about the view's middle, 100% is the
  // whole-house fit, and the label says how far in against that fit.
  const ZOOM_STEP = 1.25;
  const zoomPctNow = () => (fitR && cam.radius > 0 ? Math.round(fitR / cam.radius * 100) : 100);
  function tellZoom(){
    if (!zoomCb || !fitR) return;
    const z = zoomPctNow();
    if (z === zoomShown) return;
    zoomShown = z;
    try { zoomCb(z); } catch (_) { /* the card is gone */ }
  }
  function zoomStep(how){
    if (!renderer || failed || !camera) return false;
    cam.fly = null;
    if (how === "fit") { preset("fit", true); return true; }
    if (how !== "in" && how !== "out") return false;
    // The bars stay as they are: these buttons are on them.
    moved();
    cam.radius = Math.max(MIN_R, Math.min(MAX_R, cam.radius * (how === "in" ? 1 / ZOOM_STEP : ZOOM_STEP)));
    applyCam();
    return true;
  }
  /** Where a device is drawn: {F, v}; one the map has not placed, its room ({F, room}). */
  function placeOf(eid){
    const L = lights.find(x => x.eid === eid);
    if (L && L.pick && L.pick.length) return { F: L.F, v: middleOf(L.pick) };
    const S = sensorsUi.find(x => x.eid === eid);
    if (S) return { F: S.F, v: S.pos };
    const M = marks ? marks.places().find(x => x.eid === eid) : null;
    if (M) return { F: M.F, v: M.v };
    const area = lbe[eid] && lbe[eid].area_name;
    for (const F of area ? floorsUi : []) { const room = F.rooms.find(r => r.name === area); if (room) return { F, room }; }
    return null;
  }
  /** ◎ Find active: fly to the device the Atlas picked; on a floor the chips
   *  hide, that floor shows first, as its floor chip would. */
  function findDevice(eid){
    if (!renderer || failed || !house || !camera) return false;
    let w = placeOf(eid);
    if (!w) return false;
    if (!w.F.group.visible && lastP && typeof lastP.setTopFloor === "function") {
      lastP.setTopFloor(w.F.fl.id);
      w = placeOf(eid) || w;
    }
    const F = w.F, room = w.room || HOUSE.roomAt(F.rooms, w.v.x, w.v.z), pts = [];
    if (room) for (const q of room.pts) pts.push(new THREE.Vector3(q[0], F.fl.elev, q[1]), new THREE.Vector3(q[0], F.fl.elev + Math.min(1.2, F.fl.h), q[1]));
    else for (const d of [-2.5, 2.5]) pts.push(new THREE.Vector3(w.v.x + d, F.fl.elev, w.v.z + d), new THREE.Vector3(w.v.x - d, F.fl.elev + 1.2, w.v.z + d));
    const g = frameFor(cam.theta, Math.max(0.35, Math.min(cam.phi, 1.05)), pts);
    g.radius = Math.max(MIN_R, g.radius * 1.12);
    flyTo(g, false);                                         // the bars stay: the button is on them
    return true;
  }

  // ── the wall panel and the people in it (live_aboard_panel.js) ────────────
  // What the panel needs of the view: the camera, the floors, the people
  // drawn, and what may hold it off (Edit, Furnish, full screen, a card).
  function makePanel(){
    return PANEL.createPanel({
      root, guard, slotKey, prefGet, prefSet,
      host: () => lastP,
      sidebar: () => mapOnly && !!stage && !failed,
      busy: () => (editor && editor.active ? "edit" : furnishOn ? "furnish" : fsOn ? "full" : PANEL.hostCardOpen(root) || (roomPanel && roomPanel.isOpen) ? "card"
        : director && director.showing() ? "director" : null),
      cam: () => ({ theta: cam.theta, phi: cam.phi, radius: cam.radius, target: cam.target.toArray() }),
      floorNow: () => (selIds && selIds.size ? [...selIds].sort()[0] : null),
      onFloor: (fid) => (fid === null ? !selIds : !!(selIds && selIds.has(fid))),
      setFloor: (fid) => setFloor(fid),
      homeFloor: () => (house ? PANEL.homeStartOf(house.rooms, explodeOn()) : null),
      wholeGoal: () => homeGoal(),
      go: (g, smooth) => goTo(g, smooth),
      flying: () => !!cam.fly,
      closeAll: (bars) => { closeMenu(); if (use) use.clear(); if (bars && bare) setBare(false, false); },
      tracked: () => tracked,
      toPerson: (key) => flyToPerson(key),
      showCard: (key) => { const T = tracked && tracked.pickable().find(x => x.key === key); if (T && use) use.show({ kind: T.kind, key: T.key, anchor: T.at, live: T.live, label: T.label, card: panel ? panel.cardOf(T.key, T.card) : T.card }); },
      onTop: (w) => onTop(w),
      target: () => cam.target.toArray(),
      setTarget: (a) => { cam.target.fromArray(a); applyCam(); },
      quality: () => (profileOf().pbr ? "high" : "low"),
      toast: (t) => toast(t), render: () => requestRender(),
    });
  }
  /** The director: what it needs of the view and of the panel. */
  function makeDirector(){
    return DIRECTOR.createDirector({
      root, guard,
      settings: () => (lastP && lastP.settings3d && typeof lastP.settings3d === "object" ? lastP.settings3d : null),
      // The host's states as they are now (the card's own are from its last draw).
      states: () => (lastP && typeof lastP.liveStates === "function" ? lastP.liveStates() : lastP && lastP.states) || {},
      sidebar: () => mapOnly && !!stage && !failed,
      busy: () => (editor && editor.active ? "edit" : furnishOn ? "furnish" : fsOn ? "full" : PANEL.hostCardOpen(root) || (roomPanel && roomPanel.isOpen) ? "card" : null),
      following: () => panel.following(),
      touchedAt: () => panel.touchedAt(),
      fly: (eid) => panel.moveQuietly(() => findDevice(String(eid))),
      // People and tags (settings.atlas_3d_director_people): the rooms the tracked layer already has, and Follow's own flight.
      rooms: () => (tracked ? tracked.rooms() : []),
      // "Arrived home": the one rule, with the map's and the snapshot's rooms and Home Assistant's zones.
      isHome: PERSON_HOME ? (st) => PERSON_HOME.personIsHome(st, {
        rooms: PERSON_HOME.knownRooms(lastP && lastP.model, peopleSnap),
        zones: PERSON_HOME.homeZones((lastP && typeof lastP.liveStates === "function" ? lastP.liveStates() : lastP && lastP.states) || {}) }) : null,
      flyTo: (key) => panel.moveQuietly(() => flyToPerson(String(key))),
      goHome: () => panel.goHome(),
    });
  }
  /** That floor at the top (null: All), the camera left where it is. */
  function setFloor(fid){
    if (fid === null) { if (floorSteps && !floorSteps.all) { keepCam = true; try { floorSteps.go(-1); } finally { keepCam = false; } } }
    else if (topCb) topCb(fid);
  }
  /** Does `w` (a person where they are) stand on the floor at the top? */
  function onTop(w){
    if (!house) return true;
    const top = topElev !== null ? topElev : Math.max(...house.floors.filter(f => !f.outdoor).map(f => f.elev));
    return Math.abs(w.elev - top) < 1e-3;
  }
  /** The whole house from the Atlas's angle on the floor showing, as the view opens. */
  function homeGoal(){
    const a = isoAngle(), g = frameFor(a.theta, a.phi, visiblePoints());
    fitR = g.radius;
    // A phone held upright: room scale at the middle of its floor (every floor pulled apart has no middle room: whole).
    if (camera.aspect < 0.8 && !onWallPage(root) && !explodeGap()) g.radius = Math.max(MIN_R, Math.min(g.radius, ROOM_SPAN / (2 * Math.tan(FOV / 2 * D2R) * camera.aspect)));
    return { theta: g.theta, phi: g.phi, radius: g.radius, target: g.target.toArray() };
  }
  /** The camera to g ({theta, phi, radius, target: [x, y, z]}): flown, or at once. */
  function goTo(g, smooth){
    const goal = { target: new THREE.Vector3().fromArray(g.target), radius: g.radius, theta: g.theta, phi: g.phi };
    if (smooth) { flyTo(goal, false); return; }
    closeRoom();
    cam.fly = null; cam.needsFit = false;
    cam.target.copy(goal.target); cam.radius = goal.radius; cam.theta = goal.theta; cam.phi = goal.phi;
    applyCam();
  }
  /** Fly to someone drawn, framing the room they are in; their floor at the top. */
  function flyToPerson(key){
    let w = tracked ? tracked.whereOf(key) : null;
    if (!w || !house || !camera) return false;
    if (!onTop(w)) { setFloor(w.floor); w = tracked.whereOf(key) || w; }
    const F = floorsUi.find(q => q.fl.id === w.floor), room = F ? HOUSE.roomAt(F.rooms, w.x, w.z) : null, pts = [];
    if (room) for (const q of room.pts) pts.push(new THREE.Vector3(q[0], w.elev, q[1]), new THREE.Vector3(q[0], w.elev + Math.min(1.2, F.fl.h), q[1]));
    else for (const d of [-2.5, 2.5]) pts.push(new THREE.Vector3(w.x + d, w.elev, w.z + d), new THREE.Vector3(w.x - d, w.elev + 1.2, w.z + d));
    const g = frameFor(cam.theta, Math.max(0.35, Math.min(cam.phi, 1.05)), pts);
    g.radius = Math.max(MIN_R, g.radius * 1.12);
    flyTo(g, false);
    return true;
  }

  // ── P8 atmosphere: the Showcase look, rain and snow ───────────────────────
  /** The Atlas's Showcase look as this view's lighting: the background and
   *  its haze, the sky, the tiles' colour and the lights' glow
   *  (live_aboard_showcase.js; Classic is today's look). A change draws the
   *  tiles, the sky and the glow again. */
  function applyLook(p){
    // The same look as the Atlas (p.look3d "atlas", the host's default): its
    // page and light (the row above for its theme, Classic's with Showcase
    // off), its rooms, floor numbers and readouts. Otherwise Live Aboard's own.
    let A = null;
    try { A = LOOKS && p.look3d === "atlas" ? LOOKS.atlasLook(p.atlasLook) : null; } catch (_) { A = null; }
    // Studio (p.look3d "studio"): Live Aboard's own colours, its sky, stage and light round them.
    let wantStudio = !!STUDIO && p.look3d === "studio" && !studioFailed;
    if (wantStudio !== !!studio) syncStudio(wantStudio);
    if (studioFailed) wantStudio = false;
    const key = wantStudio ? "studio" : A ? A.key : LOOKS && p.showcase3d === true && p.showcase && p.showcase.key ? String(p.showcase.key) : "classic";
    if (key === lookKey) return;
    const was = { theme: theme3d, atlas: atlas ? atlas.key : null };
    lookKey = key;
    atlas = A;
    theme3d = A ? A.page : LOOKS ? LOOKS.lookOf(key) : null;
    const bg = theme3d ? theme3d.bg : BG;
    renderer.setClearColor(bg, 1);
    scene.background.set(bg);
    scene.fog.color.set(bg);
    // The tiles and the lights, built again with it: only when what they are
    // built from changed (Classic and Studio share Live Aboard's own colours,
    // so a screen's Look switching between them builds nothing).
    if (theme3d !== was.theme || (A ? A.key : null) !== was.atlas) shellSig = null;
    if (studio) studio.profile();                            // Studio paints its own sky over the page's
    if (sunNow) drawSun(bearingNow(), true);
    requestRender();
  }
  /** Studio made or let go of (it puts back all it changed). */
  function syncStudio(on){
    try {
      if (!on) { if (studio) studio.dispose(); studio = null; }
      else if (!studio && renderer) {
        studio = STUDIO.createStudio({ THREE, renderer, scene, root, canvas, hemi, sun, wallBox: shared.wallBox,
                                       profile: () => (profileOf().pbr ? "high" : "low") });
        if (stageNow) studio.house(stageNow);                // its stage under the house as it stands (built again, it goes under the new one)
        if (sunNow) drawSun(bearingNow(), true);             // and its light over the sun's
      }
    } catch (err) {
      console.warn("PadSpan: Studio look failed", err);
      if (on) studioFailed = true;
      try { if (studio) studio.dispose(); } catch (_) { /* best effort */ }
      studio = null;
    }
    requestRender();
  }
  /** West Coast Forest's trees (live_aboard_forest.js): only with the Atlas's
   *  look, Showcase on and that theme (below Pro, Showcase is off). Never the
   *  view's failure: trees that cannot be drawn are simply not drawn. */
  function syncForest(){
    const want = !!atlas && atlas.on && atlas.theme === "west_coast_forest" && !forestFailed;
    if (!shownHere("forest")) { dropForest(false); return; }   // hidden on this screen (the ⋯ list)
    if (!want) { dropForest(false); return; }
    if (!FOREST) {
      if (!forestImport) {
        forestImport = import(`./live_aboard_forest.js${new URL(import.meta.url).search}`)
          .then((m) => { FOREST = m; }, (err) => { console.warn("PadSpan: live_aboard_forest failed to load", err); });
      }
      forestImport.then(() => { if (FOREST) redraw(); else forestFailed = true; });
      return;
    }
    try {
      if (!forest) {
        forest = FOREST.createForest({ THREE, scene, renderer });
        // The frame-time check timed the house without the trees: timed again with them.
        quality.measured = {}; if (!quality.measuring) quality.profile = null;
        wallMoves = wallCapped = false;
        requestRender();
      }
      forest.house({ rooms: house.rooms, ground: house.ground - HOUSE.SLAB_T - 0.02, seed: FOREST.forestSeed(lastP && lastP.model) });
      const day = FOREST.niceDay(...skyNow(lastP), nightK);
      if (day !== forestDay) { forestDay = day; requestRender(); }
    } catch (err) { console.warn("PadSpan: the forest failed", err); dropForest(true); }
  }
  /** The sky as the flat Atlas reads it: [the weather's condition, is it raining or snowing]. */
  function skyNow(p){
    const w = p && p.weather, st = (w && w.states) || (p && p.states) || {}, cfg = w && w.settings;
    const eid = (cfg && cfg.conditionEntity) || (AW ? AW.firstWeatherEntity(st) : null);
    const cond = eid && st[eid] ? String(st[eid].state).toLowerCase() : null;
    return [cond, !!(AW && cfg && AW.decideAtlasWeather(cfg, st, w.entities, Date.now()).kind !== "off")];
  }
  function dropForest(failedToo){
    if (failedToo) forestFailed = true;
    if (!forest) return;
    try { forest.dispose(); } catch (_) { /* best effort */ }
    forest = null;
    if (ground) ground.visible = true;
    if (gridLines) gridLines.visible = true;
    requestRender();
  }
  /** Before a frame: the trees take over from the ground and its grid, except
   *  in the Plans tool's quiet view, Edit and Furnish, where the house is on its
   *  plain ground as ever. */
  function forestFrame(){
    try {
      const on = !quiet && !furnishOn && !(editor && editor.active);
      forest.prepare(camera, cam.target, { on, night: nightK, day: forestDay, sun: sunDir, profile: quality.profile || quality.measuring || "low" });
      if (ground) ground.visible = !on;
      if (gridLines) gridLines.visible = !on;
    } catch (err) { console.warn("PadSpan: the forest failed", err); dropForest(true); }
  }
  /** Rain and snow (live_aboard_weather.js): the flat Atlas's own decision,
   *  from the host's own weather inputs, only while Rain and snow is on
   *  (settings.atlas_3d_weather: on unless false). Off, none of it is made,
   *  and what was showing is let go of. Never the view's failure: weather
   *  that cannot be drawn is simply not drawn. */
  const plainSky = () => lookKey === "classic" || lookKey === "studio" || (!!atlas && !atlas.on);
  /** How the house is drawn this frame, for what the rain keeps off: the
   *  roof closing the house (wanted and at least half in, as it covers and
   *  hides: coming, from halfway; going, at once, as the walls are cut the
   *  moment it lifts away; and not over floors pulled apart: exploded, it is
   *  only over the top floor and the floors under it show through the
   *  gaps), and every wall down. Explode as the house was drawn, not as the
   *  setting now says: another view can change that before this one draws
   *  again. */
  function rainShell(){ return { roof: !!roofWant && !!(storeyL && storeyL.covering) && !readGap, down: wallMode === "down" }; }
  function applyWeather(p){
    const w = WEATHER && p.weather3d !== false && p.weather && p.weather.settings ? p.weather : null;
    if (!w) { if (wx) { wx.dispose(); wx = null; requestRender(); } return; }
    try {
      if (!wx) wx = WEATHER.createWeather(THREE, { scene, renderer, camera, shell: rainShell });
      const changed = wx.update({ settings: w.settings, states: w.states, entities: w.entities, telemetry: w.telemetry,
        // What falls: the flat Atlas's colour for the Showcase theme this view
        // wears (Classic: white), or the look's own where that would not show
        // on its ground (a light theme); what settles: the flat Atlas's.
        colour: studio ? studio.rain() : plainSky() ? "#ffffff" : (theme3d && theme3d.weather) || WEATHER.colourOf(p.showcase && p.showcase.theme),
        snowColour: plainSky() ? "#ffffff" : WEATHER.colourOf(p.showcase && p.showcase.theme),
        profile: quality.profile || quality.measuring || "low", nowMs: Date.now(),
        house: { key: `${shellGen}|${topElev}${forest ? "|forest" : ""}`, ...(forest ? FOREST.RAIN_REACH : {}), rooms: house.rooms, ground: house.ground - HOUSE.SLAB_T - 0.02,
                 shown: (fl) => HOUSE.floorShown(fl, topElev), minus: STOREY ? STOREY.minusPolys : null,   // a covered patio's open part
                 walls: () => floorsUi.filter(F => F.group.visible).flatMap(F => F.pieces.map(P => ({ P, F }))) } });
      if (changed) requestRender();
    } catch (_) {
      try { if (wx) wx.dispose(); } catch (__) { /* best effort */ }
      wx = null;
    }
  }

  // ── the ⋯ list: what this screen shows (live_aboard_show.js) ──────────────
  // Each line is this screen's (prefs), over the house's own; hidden is not
  // drawn at all. Most of it is a filter over the card's data, as the Plans
  // tool's quietOf is: a light, strip, fan, readout or lock left out the way
  // the Atlas's hidden lights are (built again once, when the list changes,
  // never on a poll), rain and snow, the theme, the codes, people and tags.
  // The rest is drawn by its own layer and asked of it as it draws (shownHere):
  // the glow, motion's parts, doors and windows, railings, names, outlines,
  // the trees, furniture. Edit and Furnish show everything (they work on it).
  const shownHere = (key) => !showOn || showSuspended() || showOn[key] !== false;
  const showSuspended = () => !!((editor && editor.active) || furnishOn || quiet);
  const showOver = () => (SHOW ? SHOW.readShown(prefGet(SHOW.prefKey(slotKey))) : {});
  const onObj = (x) => !!(x && typeof x === "object");
  /** The ⋯ list's Glass walls line, followed: ticked, Cut becomes Glass;
   *  unticked, Glass becomes Cut (Up and Down stay as they are). */
  function syncGlass(){
    const want = !!(showOn && showOn.glass_walls === true);
    if (want === glassPick) return;
    glassPick = want;
    if (want && wallMode === "cut") setWalls("glass");
    else if (!want && wallMode === "glass") setWalls("cut");
  }
  /** The house's own for each line, from the card's data before the list. */
  function showHouseOf(p){
    const s = p.settings3d && typeof p.settings3d === "object" ? p.settings3d : null;
    const vd = viewData(), looks = (vd && vd.devices) || {}, sp = (p.model && p.model.scanner_positions_m) || {};
    const looked = Object.keys(sp).some(a => looks[a] && looks[a].recipe && typeof looks[a].recipe === "object");
    const people = s ? s.atlas_3d_people === true && onObj(p.people) : onObj(p.people);
    const tags = s ? s.atlas_3d_tags === true && onObj(p.tags) : onObj(p.tags);
    return { people, tags, radios: tags || looked, rain: p.weather3d !== false, codes: onObj(p.codes),
             trails: prefGet(PREF_TRAILS) === "1", roof: roofPick() !== "off" };
  }
  /** The eids the list leaves out (lights, strips, fans, readouts, locks: never an alarm). */
  function showHidden(p, on){
    const out = new Set();
    if (on.lights && on.strips && on.fans && on.readouts && on.locks) return out;
    const pos = (p.model && p.model.light_positions_m) || {}, lb = p.lightsByEid || {}, zs = (viewData() || {}).lights || {};
    const shapes = (p.shapeOverrides && typeof p.shapeOverrides === "object") ? p.shapeOverrides : {};
    const LINE = { light: "lights", strip: "strips", fan: "fans", readout: "readouts", lock: "locks" };
    for (const eid of Object.keys(pos)) {
      const k = HOUSE.showKindOf(lb[eid], pos[eid], zs[eid], shapes[eid]);
      if (k && LINE[k] && !on[LINE[k]]) out.add(eid);
    }
    return out;
  }
  /** The card's data as this screen shows it. */
  function showP(p){
    showHouse = showHouseOf(p);
    showOn = SHOW.resolveShown(showOver(), showHouse);
    if (showSuspended()) return p;
    const on = showOn, q = { ...p }, hide = showHidden(p, on);
    if (hide.size) { const h0 = p.hidden; q.hidden = { has: (eid) => hide.has(eid) || !!(h0 && typeof h0.has === "function" && h0.has(eid)) }; }
    q.weather3d = on.rain;
    q.codes = on.codes ? (onObj(p.codes) ? p.codes : { showcase: !!(p.atlasLook && p.atlasLook.on) }) : null;
    if (!on.theme) { q.look3d = "own"; q.showcase3d = false; }
    if (!on.people) q.people = null;
    if (!on.tags) q.tags = null;
    // Receivers: as the house draws them until this screen says (then every placed one, or none).
    const over = showOver();
    if (typeof over.radios === "boolean") q.scanners = over.radios;
    return q;
  }
  /** The scan's pieces no placed piece stands on (Furnish's "Place the scan's guess" puts copies exactly on them: one
   *  thing in one place is drawn once). The rule Furnish's own guess uses: a centre inside the other's footprint. */
  function scanLeft(pieces){
    const P = PIECES;
    if (!scanPieces) return scanPieces;
    const inBox = (pt, b) => { const dx = pt[0] - b.c[0], dy = pt[1] - b.c[1];
      return Math.abs(dx * b.u[0] + dy * b.u[1]) <= b.hu && Math.abs(dx * b.v[0] + dy * b.v[1]) <= b.hv; };
    const placed = Object.values(pieces || {}).filter(q => q && q.recipe).map(q => [String(q.floor_id || "main"), P.boxOf(q)]);
    const out = {};
    for (const [id, q] of Object.entries(scanPieces)) {
      const b = P.boxOf(q), fid = String(q.floor_id || "main");
      if (!placed.some(([f, pb]) => f === fid && (inBox(b.c, pb) || inBox(pb.c, b)))) out[id] = q;
    }
    return out;
  }
  /** The furniture as this screen shows it: furniture, devices in it, stairs (their opening stays). */
  function piecesNow(pieces){
    // A scan's furniture joins what is drawn, never what is edited: not while the list is suspended (Edit, Furnish).
    const scan = showOn && !showSuspended() && showOn.scan_furniture === true && scanPieces ? scanLeft(pieces) : null;
    if (!showOn || showSuspended() || (showOn.furniture && showOn.devices && showOn.stairs)) return scan ? { ...(pieces || {}), ...scan } : pieces;
    const out = {};
    for (const [id, q] of Object.entries(pieces || {})) {
      const stairs = !!(STOREY && STOREY.isStairs(q)), dev = !!(q && typeof q.entity_id === "string" && q.entity_id);
      if (stairs ? showOn.stairs : dev ? showOn.devices : showOn.furniture) out[id] = q;
    }
    return scan ? { ...out, ...scan } : out;
  }
  /** A wall piece's part the list hides: a door's or a window's leaf, a garage door's, a railing. */
  function goneHere(P, e){
    if (!showOn || showSuspended()) return false;
    const k = P.pc.kind, cover = !!(P.open && P.open.cover);
    if (e.leaf) return k === "door" ? !shownHere(cover ? "covers" : "doors") : k === "window" ? !shownHere("windows") : false;
    return !e.cuttable && (k === "rail" || k === "open") && !shownHere("railings");
  }
  /** Is a weather source set up (Settings → Atlas → Outdoor weather, and something to read)? */
  function weatherReady(p){
    const w = p && p.weather && p.weather.settings ? p.weather : null;
    if (!w || !AW) return false;
    const s = AW.weatherSettingsFrom(w.settings);
    return s.enabled && !!(s.rainEntity || s.conditionEntity || s.warningEntity || AW.firstWeatherEntity(w.states || (p && p.states) || {}));
  }
  /** What this house has ready, line by line: {key: setupLine} for each that is not. */
  function showReady(){
    const p = houseP, out = {};
    if (!p || !SHOW) return out;
    const s = p.settings3d && typeof p.settings3d === "object" ? p.settings3d : null;
    const pos = (p.model && p.model.light_positions_m) || {}, lb = p.lightsByEid || {}, vd = viewData() || {}, zs = vd.lights || {};
    const n = {};
    for (const eid of Object.keys(pos)) { const k = HOUSE.showKindOf(lb[eid], pos[eid], zs[eid], (p.shapeOverrides || {})[eid]); if (k) n[k] = (n[k] || 0) + 1; }
    const pieces = Object.values(vd.pieces || {}).filter(q => q && q.recipe);
    const stairs = pieces.filter(q => STOREY && STOREY.isStairs(q)).length, dev = pieces.filter(q => !(STOREY && STOREY.isStairs(q)) && typeof q.entity_id === "string" && q.entity_id).length;
    const walls = floorsUi.flatMap(F => F.pieces);
    const has = (kind) => walls.some(P => P.pc.kind === kind);
    const look = p.look3d === "atlas" ? (LOOKS ? LOOKS.atlasLook(p.atlasLook) : null) : null;
    const admin = p.admin === true;
    const not = {
      lights: !n.light, light_taps: !n.light && !n.strip, light_buttons: !n.light && !n.strip, room_switch: !n.light && !n.strip, strips: !n.strip, fans: !n.fan, motion_sensors: !n.motion, motion_rooms: !n.motion, motion_reach: !n.motion,
      readouts: !n.readout, locks: !n.lock && !openings.some(({ P }) => P.open && P.open.lock),
      doors: !has("door"), windows: !has("window"), covers: !openings.some(({ P }) => P.open && P.open.cover),
      railings: !walls.some(P => P.els.some(e => !e.cuttable))
        && !pieces.some(q => STOREY && STOREY.isStairs(q) && q.recipe.params && q.recipe.params.rail && q.recipe.params.rail !== "none"),
      radios: !Object.keys((p.model && p.model.scanner_positions_m) || {}).length,
      tags: s ? s.atlas_3d_tags !== true : !onObj(p.tags), people: s ? s.atlas_3d_people !== true : !onObj(p.people),
      trails: !(TRAILS && (onObj(p.people) || onObj(p.tags)) && onObj(p.trails) && typeof p.trails.read === "function"),
      furniture: !(pieces.length - stairs - dev), devices: !dev, stairs: !stairs,
      // Said only while the line is off: ticked with no scan to draw, it stays a line a press can untick.
      scan_furniture: !(scanPieces && Object.keys(scanPieces).length) && !(showOn && showOn.scan_furniture === true),
      room_names: !(house && house.rooms.length), room_outlines: !(house && house.rooms.length),
      floor_outlines: !look, roof: !STOREY, rain: !weatherReady(p),
      theme: !(p.look3d === "atlas" || p.look3d === "studio" || (LOOKS && p.showcase3d === true && p.showcase && p.showcase.key && p.showcase.key !== "classic")),
      forest: !(look && look.on && look.theme === "west_coast_forest"),
      scenes: !scenesOf(p).tiles.length,
    };
    const canGo = typeof p.goTo === "function", kiosk = p.kiosk === true;
    for (const [k, v] of Object.entries(not)) {
      // A new scene is made in Home Assistant, through the row's own way there (an administrator's, never a wall's).
      if (v) out[k] = SHOW.setupLine(k, admin, k === "scenes" ? typeof scenesOf(p).add === "function" : canGo, null, kiosk);
    }
    // People or tags on with no history to read (sample data): trails wait on that, not on them.
    if (out.trails && (onObj(p.people) || onObj(p.tags))) out.trails = SHOW.setupLine("trails", admin, canGo, SHOW.setupLine("trails_live", admin).text);
    return out;
  }
  /** The list's lines now: ticks, set-up lines, and a line waiting on another. */
  function showRows(){
    const on = { ...(showOn || {}) }, ready = showReady();
    for (const k of Object.keys(ready)) on[k] = false;              // not set up: never ticked
    const groups = SHOW.rowsOf(on, ready);
    // The scene row only where the host hands in scenes (the sidebar's Atlas), and its link only to make the first one.
    for (const g of groups) g.rows = g.rows.filter(r => r.key !== "scenes" || !!(houseP && houseP.scenes));
    // "Tap a light to switch it" only on the Atlas tab and its walls (the host's mapOnly), never in Mapping's builder.
    for (const g of groups) g.rows = g.rows.filter(r => r.key !== "light_taps" || mapOnly);
    for (const g of groups) g.rows = g.rows.filter(r => r.key !== "light_buttons" || mapOnly);
    for (const g of groups) g.rows = g.rows.filter(r => r.key !== "room_switch" || mapOnly);
    for (const g of groups) for (const r of g.rows) {
      if (r.key === "scenes" && !ready.scenes) r.link = null;
      if (ready[r.key]) continue;
      if ((r.key === "forest" || r.key === "floor_outlines") && on[r.key] && !on.theme) r.hint = "Comes back with Theme colours";
      if (r.key === "trails" && on.trails && !on.people && !on.tags) r.hint = "Comes back with People or Beacons and tags";
    }
    return groups;
  }
  const showSend = (name, once) => (once ? HOUSE.countHouse3dOnce(name, send) : HOUSE.countHouse3d ? HOUSE.countHouse3d(name, send) : false);
  /** A line ticked or unticked. Trails and the roof keep their own prefs (the Views menu's and the Roof button's). */
  function toggleShow(key){
    const ready = showReady();
    if (ready[key]) {
      // People or tags off for the house: the way to their switch (Garry: "send them to the screen where they can get permission").
      if (ready[key].perm) { showSetup(key, ready[key]); return; }
      if (showMenu) showMenu.paint();
      return;
    }
    const was = shownHere(key);
    if (key === "trails") toggleTrails();
    else if (key === "roof") setRoof(was ? "off" : "auto");
    else prefSet(SHOW.prefKey(slotKey), JSON.stringify(SHOW.withTick(showOver(), key, !was, SHOW.houseOn(showHouse, key))));
    showSend(`house3d_show:${was ? "hide" : "show"}:${key}`);
    applyShow();
  }
  /** Back to house defaults, on this screen. */
  function resetShow(){
    prefSet(SHOW.prefKey(slotKey), "{}");
    if (prefGet(PREF_TRAILS) === "1") toggleTrails();
    if (roofPick() === "off") setRoof("auto");
    showSend("house3d_show:reset");
    applyShow();
  }
  /** Has this screen changed anything from the house's own? */
  function showChanged(){ return Object.keys(showOver()).length > 0 || prefGet(PREF_TRAILS) === "1" || roofPick() === "off"; }
  /** A "not set up" line's button: where it is set up, or (people, tags) their switch. */
  function showSetup(key, line){
    if (line.perm) {
      showSend(`house3d_show:permission:${line.perm}`);
      if (showMenu) showMenu.close();
      if (houseP && houseP.admin === true) {
        // The switch is Views ▾ → Show people (or tags) while Live Aboard is on (settings.js says so too).
        const seg = bar ? bar.querySelector(narrow ? "[data-la3d-view]" : "[data-la3d-saved]") : null, b = seg ? seg.querySelector("button") : null;
        if (b) {
          if (typeof b.click === "function") b.click(); else b.dispatchEvent({ type: "click", detail: 1, stopPropagation(){}, preventDefault(){} });
          markSwitch(line.perm);
        }
      } else toast(line.text);
      return;
    }
    if (!line.go) return;
    showSend(`house3d_show:setup_go:${key}`);
    showGo(line.go);
  }
  /** What the host hands in for the scene row (p.scenes: lights_map.js), or nothing. */
  function scenesOf(p){
    const sc = p && p.scenes && typeof p.scenes === "object" ? p.scenes : null;
    return sc && Array.isArray(sc.tiles) ? sc : { tiles: [] };
  }
  /** The scene row as this screen shows it: hidden from the ⋯ list, or while
   *  Edit, Furnish or the Plans tool's map has the view. A preset's ✎ opens
   *  the Atlas's Whole house bar, so the map alone gives way to it first. */
  function syncScenes(){
    if (!sceneRow) return;
    const sc = scenesOf(houseP);
    sceneRow.update({ ...sc,
      count: (name, once) => showSend(name, once),
      edit: (t, row) => {
        if (t && t.kind === "preset") { if (fsOn) leaveFull(); if (bare) setBare(false, true); }
        if (typeof sc.edit === "function") sc.edit(t, row);
      } });
    sceneRow.hide(!(showOn ? showOn.scenes !== false : true) || showSuspended());
  }
  /** In the Views menu just opened, the people or tags switch stands out. */
  function markSwitch(which){
    const words = which === "people" ? "Show people" : "Show tags & scanners";
    const b = menuEl ? [...menuEl.querySelectorAll("button")].find(x => x.textContent.startsWith(words)) : null;
    if (!b) return;
    b.style.outline = "2px solid #fbbf24"; b.style.background = "rgba(251,191,36,.14)";
    try { b.focus({ preventScroll: true }); } catch (_) { /* no focus here */ }
  }
  /** The host's way to Settings or Mapping (p.goTo(where)); false where it has none.
   *  A new scene: the scene row's own way to Home Assistant's editor. */
  function showGo(where){
    return SHOW.goShow(where, houseP && houseP.goTo, where === "scene_new" ? scenesOf(houseP) : null);   // the flat Map's ⋯ goes the same way
  }
  function makeShowMenu(){
    return SHOW.createShowMenu({
      root, guard,
      rows: () => showRows(),
      changed: () => showChanged(),
      toggle: (key) => toggleShow(key),
      setup: (r) => showSetup(r.key, r.setup),
      go: (where) => showGo(where),
      // Settings and Mapping are an administrator's: anyone else gets no links (each line says who sets it up).
      canGo: () => !!(houseP && typeof houseP.goTo === "function" && houseP.admin === true),
      reset: () => resetShow(),
      opened: () => { showSend("house3d_show:opened"); layCover(); },   // drawn now: the banner cut round it
      seen: (groups) => { for (const g of groups) for (const r of g.rows) if (r.setup && !r.setup.perm) showSend(`house3d_show:setup_seen:${r.key}`, true); },
      onOpen: () => { closeMenu(); if (use) use.clear(); markMenus(true); },
      onClose: () => markMenus(),
    });
  }
  /** The list changed: drawn again from the card's data (only what it touches
   *  is built again), and what each layer asks as it draws, asked again. */
  function applyShow(){
    for (const L of lights) L.key = null;
    lampsDirty = true;
    // A line that builds the house again (the theme) keeps the camera where it is:
    // no fit back to the home view, which would close the list under the finger.
    const fitting = cam.needsFit;
    redraw();
    if (!fitting) cam.needsFit = false;
    for (const F of floorsUi) {
      for (const P of F.pieces) placePiece(F, P, !!P.cut);
      if (F.plate) F.plate.visible = shownHere("floor_outlines");
    }
    paintNight();
    if (motionL) motionL.recheck();
    if (codes && codes.recheck) codes.recheck();
    if (showMenu) showMenu.mark();
    syncScenes();
    requestRender();
  }

  // ── the slot ──────────────────────────────────────────────────────────────
  // The Plans tool's vetting map: only the plan, the house and its pins. Nothing
  // live is drawn (no lights, sensors, readouts, names, people or weather, and
  // their frames with them) and the walls are down, so the plan reads between
  // them. All of that comes back when the tool closes; the floor and the camera
  // stay where the tool left them (in memory, until a page load or Save view).
  // A real alarm stays: a smoke, gas, CO or leak alarm going off or still latched
  // is drawn as ever, and named over the view, as it may be on another floor.
  let quiet = false, quietWalls = null, rawP = null, quietAlarmEl = null;
  const alarmOf = (p, l) => (MARKS && MARKS.markKindOf(l) === "flood" ? MARKS.floodLook(l, p.floodLatches, Date.now()) : null);
  function quietOf(p){
    const lbe = p.lightsByEid || {};
    return { ...p, hidden: { has: (eid) => { const k = alarmOf(p, lbe[eid]); return !(k && k.alarm); } }, weather: null, emergency: null, people: null, tags: null, classFilter: null };
  }
  const quietWords = (p) => Object.values(p.lightsByEid || {}).flatMap((l) => { const k = alarmOf(p, l); return k && k.alarm ? [`${k.word} · ${l.area_name || l.friendly_name || l.entity_id}`] : []; });
  /** The alarms' words over the view while it is quiet: nothing to say, no element. */
  function sayQuietAlarms(p){
    const words = !quiet || !p ? [] : quietWords(p);
    if (!words.length) { if (quietAlarmEl) { quietAlarmEl.remove(); quietAlarmEl = null; } return; }
    if (!quietAlarmEl) {
      quietAlarmEl = document.createElement("div");
      quietAlarmEl.className = "la3d-quiet-alarm";
      quietAlarmEl.setAttribute("role", "alert");
      quietAlarmEl.style.cssText = "position:absolute;left:50%;top:56px;transform:translateX(-50%);z-index:6;max-width:80%;padding:6px 14px;border-radius:999px;background:#b91c1c;color:#fff;font-weight:700;font-size:14px;text-align:center;pointer-events:none";
      root.appendChild(quietAlarmEl);
    }
    quietAlarmEl.textContent = words.join(", ");
  }
  /** Mapping has no poll, so while quiet its tick brings the leak, smoke, gas and CO
   *  sensors' states and the latches here, and nothing else moves: the view is
   *  gone through again only when what it says would change. False when not quiet. */
  function quietAlarmsNow(states, latches){
    if (!quiet || !rawP) return false;
    const lightsByEid = { ...rawP.lightsByEid };
    for (const [eid, l] of Object.entries(lightsByEid)) {
      const s = states && states[eid];
      if (s && s.state !== l.state && alarmOf(rawP, l)) lightsByEid[eid] = { ...l, state: s.state };
    }
    const next = { ...rawP, lightsByEid, floodLatches: latches || rawP.floodLatches };
    if (renderer && !failed && quietWords(next).join(", ") !== (quietAlarmEl ? quietAlarmEl.textContent : "")) { update(next); requestRender(); }
    else rawP = next;
    return true;
  }
  function setQuiet(on){
    on = !!on;
    if (on === quiet) return;
    quiet = on;
    if (on) { quietWalls = wallMode; setWalls("down"); } else if (quietWalls) { setWalls(quietWalls); quietWalls = null; }
    if (rawP && renderer && !failed) update(rawP); else sayQuietAlarms(null);
    if (house) applyTop();
    requestRender();
  }
  function update(p){
    rawP = p;
    sayQuietAlarms(p);
    if (quiet && p) p = quietOf(p);
    // A room raised above its floor is drawn as a level of its own (HOUSE.splitLevels).
    if (p && p.model && HOUSE.splitLevels) p = { ...p, model: HOUSE.splitLevels(p.model) };
    // This screen's Look (Views ▾ → Look) over Settings' own: the day's, or after sunset the night's.
    if (LOOKPICK && p) p = LOOKPICK.lookP(p, lookPickNow(p), themesOf(p));
    // The ⋯ list: what this screen shows (showP), from the house's own (houseP).
    houseP = p;
    if (SHOW && p) p = showP(p);
    if (showMenu) showMenu.mark();                         // the dot from the first draw (a screen opened with ticks of its own)
    syncGlass();
    lastP = p;
    syncScenes();
    applyLook(p);
    const setting = HOUSE.qualitySetting(p.quality);
    // This card's records and api: a press acts through the newest.
    lbe = p.lightsByEid || {};
    apiOf = typeof p.useApi === "function" ? p.useApi : null;
    apiNow = null;
    haStarted = Number(p.haStartedMs) || 0;
    takeDrawers(p);
    // The map, and what the 3D file adds to it (its doors and windows, its
    // heights): either changing redraws what it touches.
    // A record's height changed on the map (the Atlas's Height): an open
    // draft with nothing unsaved follows it.
    shownFile();
    if (shownMemo.sig !== shownSig) { shownSig = shownMemo.sig; if (editor && file) editor.fileChanged(); }
    const vd = viewData();
    const xGap = explodeGap(), gapWas = readGap, refit = refitFloor;
    refitFloor = false;
    const mSig = HOUSE.shellSignature(p.model, p.floors, p.lightsByEid) + (xGap ? `|explode:${xGap}` : "");
    const mlSig = HOUSE.lightsSignature(p.model, p.lightsByEid, p.hidden, p.shapeOverrides), mxSig = HOUSE.sensorsSignature(p.model, p.lightsByEid, p.hidden);
    const sSig = mSig + DRAFT.openingsSignature(vd) + (STOREY ? STOREY.stairsSignature(vd.pieces) : "");
    const lSig = mlSig + DRAFT.heightsSignature(vd, "lights") + RUNS.runsSignature(vd);
    const xSig = mxSig + DRAFT.heightsSignature(vd, "devices");
    let rebuilt = false;
    if (sSig !== shellSig || lSig !== lightsSig || xSig !== sensorsSig) {
      // The map is read again only when it changed; the 3D file's doors and
      // windows are cut into a copy of its walls.
      const rSig = [mSig, mlSig, mxSig].join("|");
      if (rSig !== readSig) { reading = HOUSE.readHouse(p.model, p.floors, p.lightsByEid, p.hidden, p.shapeOverrides, xGap); readGap = xGap; readSig = rSig; work.reads++; }
      const shell = sSig !== shellSig;
      rebuilt = shell;
      if (shell) { buildShell(DRAFT.applyOpenings(HOUSE.readingCopy(reading), vd.openings)); shellSig = sSig; }
      else house = { ...house, lights: reading.lights, sensors: reading.sensors };
      if (shell || lSig !== lightsSig) {
        buildLights(house);
        lightsSig = lSig;
        for (const L of lights) L.key = null;
      }
      if (shell || xSig !== sensorsSig) { buildSensors(house); sensorsSig = xSig; }
      requestRender();
    }
    // Furniture (P2): each piece on its floor, from the draft while editing.
    if (layer && layer.sync(piecesNow(vd.pieces), rebuilt)) requestRender();
    syncDevices(p, vd);
    if (motionL && motionL.show && motionL.show(motionShow())) requestRender();
    syncTracked(p, vd, rebuilt);
    paintLights(p.lightsByEid);
    paintWindows();
    paintLive();
    paintWet(p);
    paintHeat();
    syncMarks(p, vd);
    if (raisedL) raisedL.touch();                            // what shows may have changed
    selIds = p.topFloorIds ? new Set([...(p.topFloorIds instanceof Set ? p.topFloorIds : [].concat(p.topFloorIds))].map(String)) : null;
    const t = HOUSE.topFloorElev(house.floors, p.topFloorIds || null);
    if (t !== topElev) { topElev = t; plan.fit = true; applyTop(); if (use && !use.pressing) use.clear(); requestRender(); }
    // A floor chosen from every floor pulled apart (or All chosen, pulled
    // apart): the floors moved, so those showing are framed again from where
    // the camera looks (untouched, the view's own opening frames them).
    if (refit && readGap !== gapWas && !cam.needsFit && !cam.fly && camera) fit(cam.theta, cam.phi);
    applySun(p);
    syncForest();
    if (setting !== quality.setting || (!quality.profile && !quality.measuring)) {
      quality.setting = setting; quality.measured = {}; quality.profile = null; wallMoves = wallCapped = false;
      decideQuality();
    }
    // The rooms by name: the chips as the house is drawn, a room's panel as the house is now, a chip's room once its floor shows.
    if (roomChips) roomChips.sync();
    syncRoomPanel();
    landRoom();
    applyWeather(p);
  }
  function place(s){
    if (stage && stage !== s) { try { stage.style.display = ""; } catch (_) { /* the old card is gone */ } }
    stage = s;
    s.style.display = "none";
    // Covering a panel that has since been rebuilt whole (the page left and
    // came back): the screen ends, and the view goes back beside the stage.
    if (cover && root.isConnected === false) endScreen();
    // Covering the panel (the map alone, full screen), it stays where it is.
    if (!cover && (root.parentNode !== s.parentNode || root.previousSibling !== s)) s.parentNode.insertBefore(root, s.nextSibling);
    resize();
    if (dirty) requestRender();
  }

  return {
    get element(){ return root; },
    get failed(){ return failed; },
    quietAlarmsNow,
    /** Show the 3D house in place of the flat stage `s` (a fresh card's
     *  .lv-stage, already in its card). Never throws: false means the flat
     *  Atlas is showing (and why is in .failed). p = {model, floors,
     *  lightsByEid, hidden, topFloorIds, quality, telemetry, onTouch,
     *  states (hass.states, for sun.sun), config (hass.config), bearing
     *  (settings.fabric_bearing_deg), saveNorth(b) → Promise (the compass's
     *  Save: the host writes fabric_bearing_deg alone), useApi() → the
     *  host's use api (what a press acts through), haStartedMs (when Home
     *  Assistant came up: a restart's motion timestamps are no motion),
     *  load() → Promise (house3d_get: the 3D file, part C), edit(changes) →
     *  Promise (house3d_edit: the editor's Save; given only where lights may
     *  be placed, else null and there is no Edit), weather (the host's
     *  {settings, states, entities, telemetry}: the flat Atlas's own weather
     *  inputs), weather3d (settings.atlas_3d_weather: rain and snow unless
     *  false), showcase3d (settings.atlas_3d_showcase: the Showcase look when
     *  true), showcase ({key, theme}: the Showcase theme the flat Atlas
     *  shows, SHOWCASE_THEMES' own entry, only ever read), entities
     *  (hass.entities) and regIds ({registry id: entity id}, the registry
     *  the Atlas already reads): a linked piece follows its renamed entity;
     *  emergency (the Atlas's emergency lights while its test runs, else
     *  null) (P5), people (only while Show people is on: {snapshot()} or
     *  {read(), everyMs}, the live snapshot through the host) (P6), tags
     *  (the same, only while Show tags & scanners is on), classFilter (☰'s
     *  class chips' pick, or "all"/null), floodLatches ({entity id:
     *  {triggered_at}}, flood_latch.py's), codes ({showcase}: codes shown,
     *  or null while "Hide device codes" is on), onZoom(pct) (the ⚙ zoom
     *  label: the zoom against the whole-house fit, on every change),
     *  settings3d (the settings: who carries what, going back home), admin
     *  and saveSetting(key, value) → Promise (Show people / Show tags &
     *  scanners from Views ▾; live_aboard_panel.js), goTo(where) (the ⋯
     *  list's links: a key of live_aboard_show.js LINK_WORDS, opened by the
     *  host; none, no links)}. */
    attach(s, p){
      send = p && p.telemetry;
      touchCb = p && p.onTouch;
      saveNorthCb = p && typeof p.saveNorth === "function" ? p.saveNorth : null;
      try {
        if (failed) { showFlat(); return false; }
        if (!s || !s.parentNode || !p) return false;
        if (!renderer && !start(HOUSE.qualitySetting(p.quality))) return false;
        loadFile(p);
        if (editor) editor.setEdit(typeof p.edit === "function" ? editSave : null);
        // Mapping → Furnish (P2): the plan beside the 3D view and the Furnish
        // tool open. p.furnish is the host's own for the tool (its flows and
        // "This is a device…"), handed through: the view calls nothing itself.
        furnishP = p.furnish && typeof p.furnish === "object" ? { ...p.furnish, states: p.states || null } : null;
        plansP = p.plans && typeof p.plans === "object" ? p.plans : null;
        // A piece moved a floor: its floor shows, and the camera stays where it is.
        topCb = typeof p.setTopFloor === "function" ? (fid) => { keepCam = true; try { p.setTopFloor(fid); } finally { keepCam = false; } } : null;
        setFurnishView(!!furnishP);
        // The sidebar: the map alone when zoomed in, and full screen.
        mapOnly = p.mapOnly === true;
        if (panelCss) panelCss.textContent = mapOnly ? CSS_PANEL : "";
        if (!mapOnly) endScreen();
        floorSteps = stepsOf(p.floorSteps);
        followFloor();
        prefs = p.prefs && typeof p.prefs.get === "function" && typeof p.prefs.set === "function" ? p.prefs : null;
        update(p);
        if (editor) editor.setFurnish(!!furnishP);           // after update: a file read needs the card's data
        if (editor) editor.setPlans(plansP);                 // the Plans tool only while the host hands it
        // A tool asked for on the way in (the setup wizard's "Open Live
        // Aboard (Edit → Heights)"), taken once: {tool, eid}. Taken even with
        // no editor (no WebGL), or it would open that tool on a later visit.
        const want = p.openTool && typeof p.openTool.take === "function" ? p.openTool.take() : null;
        if (editor && want && want.tool) Promise.resolve(editor.startTool(want.tool, want.eid || null)).catch(() => {});
        if (failed) return false;
        place(s);
        if (want && want.tool) freshShow = false;            // a tool asked for (the setup wizard): its bars stay
        paintFloors(); paintFull(); showHint(); peopleClock(); syncFps();
        if (panel) panel.attach();
        if (director) director.attach();
        return !failed;
      } catch (_) {
        fail("error");
        return false;
      }
    },
    /** Back to the flat Atlas (Map picked, or the feature switched off).
     *  The camera and the GL context stay for a quick return. */
    /** The 3D file changed elsewhere (Settings → Remove all furniture): read
     *  again now while showing, else when the screen is next shown. */
    reload(){ try { fileLoad = null; if (stage && lastP && !failed) loadFile(lastP); } catch (_) { /* read when next shown */ } },
    detach(){ try { fileLoad = null; freshShow = true; dirty = true; cam.fly = null; roomGo = null; dropPointers(); cancelNorth(); endScreen(); closeRoomPanel(); if (use) use.clear(); if (editor) editor.leave(); showFlat(); peopleClock(); if (fpsUi) fpsUi.sync(false); if (panel) panel.detach(); if (director) director.detach(); } catch (_) { /* nothing to undo */ } },
    /** Something wants this screen to leave 3D (Map picked): with unsaved
     *  3D edits the editor asks first, in the view, and holds (true); `go`
     *  runs once they are saved or discarded. */
    holdLeave(go){ try { return !!(editor && !failed && editor.holdLeave(go)); } catch (_) { return false; } },
    /** The Atlas's ⚙ Zoom while this shows: "in" or "out" a step about the
     *  view's middle, "fit" the whole-house fit (100%). False: not drawn. */
    zoom(how){ try { return zoomStep(how); } catch (_) { return false; } },
    /** The zoom against the whole-house fit, in % (the ⚙ label). */
    zoomPct(){ try { return zoomPctNow(); } catch (_) { return 100; } },
    /** The bar's Save view while this shows: the camera into Views. */
    saveView(){ try { if (renderer && !failed) { saveView(); return true; } } catch (_) { /* nothing saved */ } return false; },
    /** The bar's Reset view while this shows: every floor, framed whole. */
    wholeHouse(){ try { if (renderer && !failed && camera) { wholeHouse(); return true; } } catch (_) { /* stays where it is */ } return false; },
    /** ☰'s ◎ Find active while this shows: fly to the Atlas's pick. */
    findDevice(eid){ try { return findDevice(String(eid)); } catch (_) { return false; } },
    /** The feature is off: the flat Atlas back and the GL context given up. */
    release(){ try { cancelNorth(); endScreen(); showFlat(); teardown(); } catch (_) { /* best effort */ } },
    // A window on it, for the harness and for poking at it from the console.
    _state(){
      return { failed, profile: quality.profile, measuring: quality.measuring, measured: { ...quality.measured }, wallMoves, wallCapped, frames, wallMode, topElev,
               cam: { theta: cam.theta, phi: cam.phi, radius: cam.radius, target: cam.target.toArray(), moved: cam.moved },
               sun: sunNow ? { ...sunNow, intensity: sun.intensity, sky: hemi.intensity, dir: sunDir.toArray() } : null, bearing, rose: roseDeg,
               north: { stored: storedBearing, preview: northPreview, hold: northHold ? northHold.b : null,
                        pill: !!(pill && pill.classList.contains("on")), spinning: !!spin },
               canvas, gl: renderer ? renderer.getContext() : null, lights: lights.length, floors: floorsUi.length,
               fixtures: lights.map(L => ({ eid: L.eid, kind: L.drawn, guess: L.guess, bulbs: L.refs.bulbs.length, washes: L.refs.washes.length,
                                            house: L.F.houses && L.refs.houses.length ? ((c) => { L.F.houses.getColorAt(L.refs.houses[0].i, c); return "#" + c.getHexString(); })(new THREE.Color()) : null,
                                            pools: L.refs.pools.length, halos: L.refs.halos.length, rps: L.spin ? L.spin.rps : null,
                                            angle: L.spin ? L.spin.angle : null, cut: !!(L.wall && L.wall.cut),
                                            // Under a covered patio's cover: its rings on the floor, each shown or not.
                                            ...(L.refs.marks ? { marks: L.refs.marks.map(i => { L.F.marks.getMatrixAt(i, _m); return _m.elements[0] > 0; }),
                                                                 bulbH: L.refs.bulbs.map(r => r.m.elements[13] - L.F.fl.elev) } : {}) })),
               walls: floorsUi.reduce((a, F) => a + F.pieces.length, 0),
               // The house itself: each storey's floor and roof, the roof's pick, the doors with no sensor.
               house: storeyL ? { ...storeyL.state(), roofPick: roofPick(), roofWant, rainShell: rainShell() } : null,
               doors: floorsUi.flatMap(F => F.pieces.filter(P => P.open && P.open.still).map(P => ({ id: P.pc.added || (P.pc.barrier && P.pc.barrier.id) || null,
                                                                                                     floor: F.fl.id, shown: P.open.shown, at: P.open.at, deg: Math.round(P.open.max / D2R),
                                                                                                     type: P.open.t ? P.open.t.type : null, guessed: !!(P.open.t && P.open.t.guessed),
                                                                                                     panels: P.open.slots ? P.open.slots[1] : 0 }))),
               // Part B: the live parts and the taps.
               openings: openings.map(({ F, P }) => ({ eid: P.open.eid, kind: P.open.kind, state: P.open.state, at: P.open.at, to: P.open.to,
                                                     // a door of a type: its panels' colours as drawn
                                                     panelCols: P.open.slots && F.panels && F.panels.instanceColor
                                                       ? Array.from({ length: P.open.slots[1] }, (_, i) => "#" + _c.fromArray(F.panels.instanceColor.array, (P.open.slots[0] + i) * 3).getHexString()) : null,
                                                     garage: P.open.garage, hinge: P.open.hinge, side: P.open.side, cut: !!P.cut,
                                                     type: P.open.t ? P.open.t.type : null, cover: !!P.open.cover, panels: P.open.slots ? P.open.slots[1] : 0,
                                                     ms: P.open.ms || null, lock: P.open.lockState || null })),
               tints: tints.map(T => ({ room: T.room ? T.room.name : null, motion: T.mLook, air: T.aLook,
                                        fill: T.fillMat.opacity, bars: T.barsMat ? T.barsMat.opacity : null, rings: T.rings.filter(R => R.on).length,
                                        ringsShown: T.rings.filter(R => R.mesh.scale.x > 0).length })),
               readouts: readouts.map(R => ({ eid: R.eid, kind: R.kind, ...(R.shown || {}) })),
               motion: sensorsUi.filter(S => S.kind === "motion").map(S => ({ eid: S.eid, look: S.look || null, col: S.col })),
               motionLayer: motionL ? motionL.state() : null, motionChip: mchip ? mchip.state() : null,
               raised: raisedL ? raisedL.state() : null,
               names: floorsUi.flatMap(F => F.labels.map((l, i) => ({ room: F.rooms[i].name, shown: F.group.visible && l.visible,
                                                                       text: l.userData.text || String(F.rooms[i].name), color: l.userData.color || "#ffffff",
                                                                       opacity: l.material.opacity,
                                                                       covered: !!l.userData.covered, px: l.userData.px,
                                                                       onTop: !l.material.depthTest && l.renderOrder >= 30, upright: !!l.isSprite,
                                                                       ext: l.userData.ext, aspect: l.userData.aspect }))),
               chips: chips.map(C => ({ room: C.room ? C.room.name : null, text: C.text, eids: C.sensors.map(S => S.eid),
                                        shown: C.F.group.visible && C.sprite.visible, opacity: C.sprite.material.opacity })),
               // Labels by zoom level: the level, the room open, the floors' tags, the floors' tiles faded or not, Explode.
               levels: { level, room: openRoom ? { name: openRoom.name, floor: openRoom.fid } : null, explode: readGap, explodeOn: explodeOn(),
                         // The open room's first tile colour as drawn now, and as built (its tint).
                         roomTile: (() => { const o = openRoom, F = o && o.F; if (!F || !F.tiles || !F.tileSpans || !F.tileCols || !F.tileSpans[o.i]) return null;
                                            const v = F.tileSpans[o.i][0] * 3, a = F.tiles.geometry.attributes.color.array;
                                            return { now: [a[v], a[v + 1], a[v + 2]], was: [F.tileCols[v], F.tileCols[v + 1], F.tileCols[v + 2]] }; })(),
                         tags: [...floorTags].map(([fid, T]) => ({ floor: fid, text: T.el.textContent, shown: tagsOn && T.el.style.display !== "none", at: T.at })),
                         faded: floorsUi.map(F => (F.fadeOf === undefined ? null : F.fadeOf)) },
               // Walls: Glass: each floor's glass pieces placed (not out of sight), and whether the floor's glass is drawn at all.
               ghost: floorsUi.map(F => ({ floor: F.fl.id, drawn: !!(F.ghost && F.ghost.visible), placed: F.ghost ? countPlaced(F.ghost) : 0,
                                           solid: F.solid ? countPlaced(F.solid) : 0, order: F.ghost ? F.ghost.renderOrder : null,
                                           depthWrite: F.ghost ? F.ghost.material.depthWrite : null, transparent: F.ghost ? F.ghost.material.transparent : null })),
               screen: { mapOnly, bare, cover, full: fsOn, fitR, narrow, floors: floorSteps ? { names: floorSteps.names, at: floorSteps.at, all: floorSteps.all,
                                                                                               counts: floorSteps.counts } : null,
                         flying: !!cam.fly, menu: !!menuEl, hint: !!hintCard,
                         // The floors: a camera kept for each one left, the corner's name.
                         floorKey, floorCams: [...floorCams.keys()], corner: { on: cornerOn && bare, text: cornerEl ? cornerEl.textContent : "" } },
               peopleClock: peopleTimer !== null, fps: fpsUi ? fpsUi.state() : null,
               night: { k: nightK, top: topGlow.value, floor: floorsUi.map(F => (F.lift ? F.lift.material.opacity : 0)),
                        edges: floorsUi.map(F => (F.edges ? F.edges.material.opacity : 0)), grid: gridLines ? gridLines.material.opacity : null,
                        ...offBulb() },
               wallMat: (floorsUi.find(F => F.solid) || { solid: null }).solid ? floorsUi.find(F => F.solid).solid.material : null,
               // Paved rooms' joints as drawn, per floor: points (x, y, z), uv (tiles), the one material.
               paving: floorsUi.filter(F => F.paving).map(F => ({ floor: F.fl.id, inGroup: F.paving.parent === F.group, order: F.paving.renderOrder,
                 pos: Array.from(F.paving.geometry.attributes.position.array), uv: Array.from(F.paving.geometry.attributes.uv.array),
                 mat: F.paving.material })),
               flash: shared ? { color: "#" + shared.flashMat.color.getHexString(), opacity: shared.flashMat.opacity } : null,
               animating: liveMs > 0, liveMs, use: use ? use.state() : null, work: { ...work },
               // What of the host's it still holds (nothing, once switched off).
               held: { card: !!lastP, api: !!(apiOf || apiNow), stage: !!stage, send: !!send, touch: !!touchCb, north: !!saveNorthCb },
               // Part C: the 3D file as drawn.
               file: file ? { openings: Object.keys(file.openings).length, lights: Object.keys(file.lights).length,
                              devices: Object.keys(file.devices).length } : null,
               added: floorsUi.reduce((a, F) => a + F.pieces.filter(P => P.pc.added).length, 0),
               heights: { lights: lights.filter(L => L.z !== L.zDefault).map(L => ({ eid: L.eid, z: L.z, zDefault: L.zDefault })),
                          devices: sensorsUi.filter(S => S.z !== S.zDefault).map(S => ({ eid: S.eid, z: S.z, zDefault: S.zDefault })) },
               edit: editor ? editor.state() : null,
               // The rooms by name: the chips, a room's panel, a chip's room waiting on its floor.
               rooms: { chips: roomChips ? roomChips.state() : null, panel: roomPanel ? roomPanel.state() : null, go: roomGo ? { ...roomGo } : null },
               // P8: the look as drawn (and this screen's Look: {day, night}, and the pick now), and rain and snow.
               look: scene ? { key: lookKey, pick: LOOKPICK ? { ...lookHere(), now: rawP ? lookPickNow(rawP) : null, menuFor: lookFor } : null, atlas: atlas ? { on: atlas.on, theme: atlas.theme, plates: floorsUi.filter(F => F.plate).map(F => F.plate.userData.n),
                                                         // Each plate's line as drawn: its floor, whether it hides with it, its points (x, y, z).
                                                         plateLines: floorsUi.filter(F => F.plate).map(F => ({ n: F.plate.userData.n, floor: F.fl.id,
                                                           withFloor: F.plate.parent === F.group, pts: Array.from(F.plate.geometry.attributes.position.array) })),
                                                         edges: floorsUi.filter(F => F.edges).map(F => (F.edges.visible ? F.edges.material.opacity : 0)) } : null,
                               bg: "#" + scene.background.getHexString(), fog: "#" + scene.fog.color.getHexString(),
                               sky: "#" + hemi.color.getHexString(), skyI: hemi.intensity, glow: theme3d ? theme3d.glow : 1,
                               ground: ground ? "#" + ground.material.color.getHexString() : null,
                               // Sums the harness compares: every tile's colour, every glow's.
                               tiles: floorsUi.reduce((a, F) => a + (F.tiles ? F.tiles.geometry.attributes.color.array.reduce((s, v) => s + v, 0) : 0), 0),
                               halos: floorsUi.reduce((a, F) => a + Object.values(F.halos || {})
                                 .reduce((s, h) => s + h.geometry.attributes.color.array.reduce((u, v) => u + v, 0), 0), 0) } : null,
               weather: wx ? wx._state() : null, studio: studio ? studio.state() : null,
               // P2 Furnish: the furniture as drawn, and the views.
               pieces: layer ? layer.state() : [], furnish: furnishOn,
               // P5: what each linked piece shows, the fixtures that stepped
               // aside for one, the emergency lights outlined, the real lamps lit.
               devices: devices ? devices.state() : [], swapped: lights.filter(L => L.swap).map(L => L.eid),
               outlined: emOutlines.length, lamps: lampPool.filter(l => l.intensity > 0).map(l => l.position.toArray().map(v => Math.round(v * 100) / 100)),
               // P6: scanners, beacons and people as drawn, and how often the snapshot was read.
               tracked: tracked ? tracked.state() : [], peopleReads, trails: tracked && tracked.trails ? tracked.trails() : [], trailReads, panel: panel ? panel.state() : null,
               director: director ? director.state() : null,
               // The ⋯ list: each line on this screen, the house's own, the list as drawn,
               // and each door's, window's and rail's parts: drawn or not.
               show: SHOW ? { on: showOn ? { ...showOn } : null, house: { ...showHouse }, menu: showMenu ? showMenu.state() : null,
                              walls: floorsUi.flatMap(F => F.pieces.filter(P => P.els.some(e => e.leaf || !e.cuttable)).map(P => ({ kind: P.pc.kind, cover: !!(P.open && P.open.cover),
                                drawn: P.els.filter(e => e.leaf || !e.cuttable).some(e => { e.mesh.getMatrixAt(e.i, _m); return _m.elements.slice(0, 11).some(v => v !== 0); }) }))),
                              plates: floorsUi.filter(F => F.plate).map(F => F.plate.visible), edges: floorsUi.filter(F => F.edges).map(F => F.edges.visible) } : null,
               // The scene row: shown or not, its tiles ([key, state, kind]), its ✎s, + New scene, its note.
               scenes: sceneRow ? sceneRow.state() : null,
               // The Atlas's drawers and its other devices (live_aboard_marks.js).
               marks: marks ? marks.state() : [], codes: codes ? codes.state() : null, classF, zoomPct: zoomPctNow(),
               chipsFaded: chips.filter(C => C.sprite.material.opacity < 1).map(C => (C.room ? C.room.name : null)),
               dimmed: lights.filter(L => dimOf(L.eid)).map(L => L.eid),
               split: furnishOn ? (viewports().plan ? (viewports().d3 ? "both" : "plan") : "3d") : null, plan: { ...plan } };
    },
    /** The wall panel (live_aboard_panel.js: the harness drives it). */
    _panel(){ return panel; },
    /** The director (live_aboard_director.js: the harness drives it). */
    _director(){ return director; },
    /** The Furnish tool (the harness builds a piece of any kind through it). */
    _furnish(){ return editor ? editor.furnish : null; },
    /** The Strip tool (the harness lays out a light through it). */
    _strip(){ return editor ? editor.strip : null; },
    /** The Plans tool (the harness reads its vetting map). */
    _plans(){ return editor ? editor.plans : null; },
    /** A piece's middle (dz metres above its bottom) on screen, in the 3D view or the plan. */
    _wherePiece(id, dz = 0.3, inPlan = false){
      const r = layer && layer.rootOf(id), vp = inPlan ? viewports().plan : viewports().d3;
      if (!r || !vp) return null;
      if (inPlan) fitPlan();
      const c = inPlan ? planCam : camera, rect = rectOf(vp), v = r.position.clone();
      v.y += dz;
      c.updateMatrixWorld();
      v.project(c);
      return [rect.left + (v.x + 1) / 2 * rect.width, rect.top + (1 - v.y) / 2 * rect.height];
    },
    /** The weather (the harness reads its drops). */
    _weather(){ return wx; },
    /** A door or window as drawn (its barrier's id, or a 3D one's): its parts, bottom to top. */
    _piece(id){
      for (const F of floorsUi) for (const P of F.pieces) {
        if (P.pc.added === id || (!P.pc.added && P.pc.barrier && P.pc.barrier.id === id)) {
          return { kind: P.pc.kind, els: P.els.map(e => [e.z0, e.z1, !!e.glass]) };
        }
      }
      return null;
    },
    /** The same, for every wall piece it is drawn in (split over two walls: two). */
    _pieces(id){
      return floorsUi.flatMap(F => F.pieces.filter(P => P.pc.added === id || (!P.pc.added && P.pc.barrier && P.pc.barrier.id === id))
        .map(P => ({ kind: P.pc.kind, els: P.els.map(e => [e.z0, e.z1, !!e.glass]) })));
    },
    /** A plan point on floor `fid`, z metres up, in client px (the harness draws there). */
    _whereOf(fid, x, y, z = 1, inPlan = false){
      if (!inPlan) return editor ? editor.whereOf(fid, x, y, z) : null;
      const F = floorsUi.find(q => q.fl.id === fid), vp = viewports().plan;
      if (!F || !vp) return null;
      fitPlan();
      const rect = rectOf(vp), v = new THREE.Vector3(x, F.fl.elev + z, y).project(planCam);
      return [rect.left + (v.x + 1) / 2 * rect.width, rect.top + (1 - v.y) / 2 * rect.height];
    },
    /** Is there floor at plan (x, y) on floor fid: its rooms' tiles, its
     *  storey's own floor (the harness; stairs cut both). */
    _floorAt(fid, x, y){
      const F = floorsUi.find(q => q.fl.id === fid);
      if (!F) return null;
      const r = new THREE.Raycaster(new THREE.Vector3(x, F.fl.elev + 1, y), new THREE.Vector3(0, -1, 0), 0, 1.3);
      const slabs = F.group.children.filter(o => o.name === "storey-floor");
      return { tile: !!(F.tiles && r.intersectObject(F.tiles, false).length), slab: slabs.some(o => r.intersectObject(o, false).length > 0) };
    },
    /** The harness counts what covers what, and asks for every real height. */
    _raised: { overlaps: () => (raisedL ? raisedL.overlaps() : null), disable: (on) => { if (raisedL) raisedL.disable(on); } },
    /** The forest as drawn, and the draws of the last frame (the harness reads them). */
    _forest(){ return { forest: forest ? forest.state() : null, calls: renderer ? renderer.info.render.calls : 0, triangles: renderer ? renderer.info.render.triangles : 0, frames, profile: quality.profile, measuring: quality.measuring, measured: { ...quality.measured } }; },
    /** Put the camera somewhere (the harness frames a shot). */
    _look(theta, phi, target, radius){
      cam.moved = true; cam.needsFit = false;
      cam.theta = theta; cam.phi = Math.max(MIN_PHI, Math.min(MAX_PHI, phi)); cam.target.fromArray(target); cam.radius = radius;
      applyCam();
    },
    /** Where something is on screen, in client px (the harness presses it):
     *  {eid} a device's nearest point, {floorOf: eid} a covered patio's light's floor spot, {room}, {door: eid}, {floor: z},
     *  {tracked: key} a tag or a scanner (P6). */
    _where(q){
      if (!renderer || !camera) return null;
      const rect = view3Rect(), at = (v) => screenPt(v, rect);
      camera.updateMatrixWorld();
      if (q.room) {
        for (const F of floorsUi) {
          const i = F.rooms.findIndex(r => r.name === q.room);
          if (i >= 0) return at(F.labels[i].position);
        }
        return null;
      }
      if (q.door) {
        const o = openings.find(x => x.P.open.eid === q.door);
        if (!o) return null;
        const v = openingQuad(o.F, o.P);
        return at(v[0].clone().add(v[2]).multiplyScalar(0.5));
      }
      if (q.button) { const b = buttonsNow(rect).find(k => k.lights.some(L => L.eid === q.button)); return b ? [b.x, b.y] : null; }   // "Lights as buttons": its button
      if (q.floorOf) { const U = lights.find(x => x.eid === q.floorOf); return U && U.floorPick ? at(U.floorPick[0]) : null; }   // under a covered patio's cover: its floor spot
      const L = lights.find(x => x.eid === q.eid);
      if (L && L.pick && L.pick.length) {
        // Where it shows: of its points (lightPoints), those nothing hides, nearest their middle.
        const all = lightPoints(L).length ? lightPoints(L) : L.pick, shows = all.filter(v => !blocked(v, null, true)), pts = shows.length ? shows : all;
        const c = pts.reduce((a, v) => a.add(v), new THREE.Vector3()).multiplyScalar(1 / pts.length);
        return at(pts.reduce((b, v) => (v.distanceTo(c) < b.distanceTo(c) ? v : b)));
      }
      if (q.tracked) { const T = (tracked ? tracked.pickable() : []).find(x => x.key === q.tracked); return T ? at(T.at) : null; }
      const S = sensorsUi.find(x => x.eid === q.eid);
      if (S && S.chip) { const p = labelQuad(S.chip.sprite).map(at); return p.every(Boolean) ? [(p[0][0] + p[1][0]) / 2, (p[0][1] + p[2][1]) / 2] : null; }
      if (S) return at(S.pos);
      const M = marks ? marks.places().find(x => x.eid === q.eid) : null;
      return M ? at(M.v) : null;
    },
    _pick(x, y){
      const r = pickAt(x, y);
      return r && { hit: r.hit.key, under: r.under.map(u => u.key) };
    },
  };
}
