// PadSpan HA — BLE Room-Presence Tracking for Home Assistant
// Copyright (C) 2026 Garry Broeckling
// Licensed under the GNU General Public License v3.0
// See LICENSE file or https://www.gnu.org/licenses/gpl-3.0.html
/**
 * Health view — system status summary + Phase 4 System Critics.
 *
 * Top section: quick system info (version, build, data mode, refresh timing).
 * Scanner Health: Phase 3 per-scanner reliability table.
 * System Critics: Phase 4 unified self-diagnosis — room confusion, map quality,
 *   scanner issues, calibration status, and propagation health.  Fetched via
 *   the padspan_ha/system_critics WS handler on each render.
 */

// Cache for critics data — refreshed when view is active
let _criticsCache = null;
let _criticsFetchTs = 0;
// The data mode the caches below were read in: Sample mode's sample house is never shown as Live's.
let _cacheMode = null;
const _CRITICS_TTL_MS = 30000; // refresh every 30s

export function render(ctx){
  const { el } = ctx.helpers;
  const root = el("section",{id:"health"});
  root.className = ctx.state.view==="health" ? "" : "hidden";

  const snap = ctx.state.live.snapshot;
  const rooms = snap?.rooms?.length ?? Object.keys(ctx.state.roomTagMap||{}).length;
  const tags = snap?.tags?.length ?? Object.values(ctx.state.roomTagMap||{}).reduce((a,b)=>a+(b?.length||0),0);
  // The server copies ble.radios to the top level (snapshot_builder.py); the
  // sample house's snapshot has only ble.radios, so Sample read 0 without this.
  const radios = snap?.radios?.length ?? snap?.ble?.radios?.length ?? 0;

  // Header
  root.appendChild(el("div",{class:"row",style:"align-items:center;gap:8px;margin-bottom:14px"},[
    el("h2",{},"Health"),
    ctx.helpers.helpBtn("health"),
  ]));

  root.appendChild(el("div",{class:"grid grid-wide"},[
    el("div",{class:"card"},[
      el("div",{style:"font-weight:700"},"System"),
      el("div",{class:"mono"}, `UI v${ctx.state.version} • build ${ctx.state.buildId}`),
      el("div",{class:"mono"}, `Data mode: ${ctx.state._dataModeKnown ? ctx.state.dataMode.toUpperCase() : "…"}`),
      el("div",{class:"mono"}, `Refresh: ${ctx.state.timing.lastRefreshMs ?? "\u2014"}ms`),
    ]),
    el("div",{class:"card"},[
      el("div",{style:"font-weight:700"},"Live Discovery (best-effort)"),
      el("div",{class:"mono"}, `Rooms: ${rooms}`),
      el("div",{class:"mono"}, `Radios: ${radios}`),
      el("div",{class:"mono"}, `Tags/Objects: ${tags}`),
      el("div",{class:"muted", style:"margin-top:8px"},"To send details to support, open Diagnostics (QA \u2192 Go to Diagnostics) and email its report to hello@traks.ca, or attach it to a GitHub issue (issues are public: remove personal details first)."),
    ]),
  ]));

  // ── A proxy that suddenly hears much less than it usually does ──────────
  // (proxy_health.py). Drawn only while a drop is on; nothing otherwise.
  const deaf = ((snap?.ble?.radios) || []).filter(r => r && r.adv_rate_low === true);
  if (deaf.length) {
    root.appendChild(el("div",{class:"card",style:"margin-top:12px;font-size:11px"},[
      el("div",{style:"font-weight:700;margin-bottom:4px"},"Hearing less than usual"),
      el("div",{}, deaf.map(r => r.display_name || r.name || r.source).join(", ")),
      el("div",{class:"muted",style:"margin-top:4px"},
        "For over 10 minutes this scanner has heard far fewer Bluetooth advertisements than it usually does, while the others are normal. Rooms near it can be wrong. Restarting it often helps; on ESPHome, check its version and Wi-Fi."),
    ]));
  }

  // ── PadSpan Bright → PadSpan HA import ──────────────────────────────────
  // Offered only while a Bright house exists on this HA and has not been
  // imported; a receipt afterwards; nothing at all otherwise.
  const brightContainer = el("div",{id:"health-bright-import"});
  root.appendChild(brightContainer);
  _fetchAndRenderBrightImport(ctx, brightContainer);

  // ── Scanner Health (Phase 3) ────────────────────────────────────────────
  const sh = snap?.scanner_health;
  if (sh && Object.keys(sh).length) {
    const _sid = ctx.helpers.radioShortId;
    const liveRadios = (snap?.ble?.radios) || [];
    const nameMap = {};
    for (const r of liveRadios) { if(r.source && (r.display_name || r.name)) nameMap[r.source] = r.display_name || r.name; }
    const entries = Object.entries(sh).sort((a,b) => a[1].reliability - b[1].reliability);
    const shCard = el("div",{class:"card",style:"margin-top:12px"});
    shCard.appendChild(el("div",{style:"display:flex;align-items:center;gap:8px;margin-bottom:8px"},[
      el("div",{style:"font-weight:700"},"Scanner Health"),
      ctx.actions.openReceivers && (!ctx.actions.canOpen || ctx.actions.canOpen("receivers")) ? el("button",{class:"btn inline","data-all-receivers":"health",style:"font-size:11px;padding:2px 10px;margin:0",onclick:()=>ctx.actions.openReceivers()},"All receivers") : null,
    ].filter(Boolean)));
    const tbl = el("div",{style:"display:grid;grid-template-columns:auto 1fr auto auto auto;gap:4px 10px;font-size:11px;align-items:center"});
    // Header
    for(const h of ["","Scanner","Room","Agreement","Weight"]){
      tbl.appendChild(el("div",{style:"font-weight:600;color:#94a3b8;font-size:10px;text-transform:uppercase"},h));
    }
    for(const [src, d] of entries){
      const rel = d.reliability;
      const dotColor = rel >= 0.9 ? "#52b788" : rel >= 0.7 ? "#f59e0b" : "#f87171";
      const sid = _sid ? _sid(src) : "";
      const name = nameMap[src] || src;
      tbl.appendChild(el("div",{style:`display:flex;align-items:center;gap:4px`},[
        el("span",{style:`display:inline-block;width:8px;height:8px;border-radius:50%;background:${dotColor}`}),
        sid ? el("span",{class:"pill",style:"font-family:monospace;font-size:10px;padding:0 4px"},sid) : null,
      ].filter(Boolean)));
      tbl.appendChild(el("div",{style:"overflow:hidden;text-overflow:ellipsis;white-space:nowrap"},name));
      tbl.appendChild(el("div",{class:"muted"},d.room || "\u2014"));
      tbl.appendChild(el("div",{style:`color:${dotColor}`},`${d.agree_pct}%`));
      tbl.appendChild(el("div",{class:"mono"},String(rel)));
    }
    shCard.appendChild(tbl);
    // Flag scanners with low reliability — but only once a scanner has had
    // a fair number of polls to be judged on (>= 12): a scanner that just
    // came online has an unstable, low-sample reliability score that says
    // more about "not enough data yet" than "this scanner disagrees with
    // consensus," and would otherwise show as a false alarm on every fresh
    // install or newly-added scanner.
    const bad = entries.filter(([,d]) => d.reliability < 0.7 && d.polls >= 12);
    if(bad.length){
      const warn = el("div",{style:"margin-top:8px;padding:8px;background:rgba(248,113,113,.08);border:1px solid rgba(248,113,113,.2);border-radius:6px;font-size:11px;color:#fca5a5"});
      warn.innerHTML = `<b>\u26a0 ${bad.length} scanner(s) below 70% reliability</b><br>` +
        bad.map(([src,d]) => `${_escHtml(nameMap[src]||src)} (${_escHtml(d.agree_pct)}% agreement)`).join(", ") +
        `<br><span style="color:#94a3b8;font-size:10px">These scanners frequently disagree with consensus room assignments. Check placement, antenna orientation, or RSSI offset.</span>`;
      shCard.appendChild(warn);
    }
    root.appendChild(shCard);
  }

  // ── Fabric Health (Phase 1-3 decoupling) ────────────────────────────────
  root.appendChild(el("div",{style:"display:flex;align-items:center;gap:8px;margin-top:16px"},[
    el("div",{style:"font-weight:700;font-size:14px;color:#52b788"},"Room and receiver layout"),
  ]));
  const fabricContainer = el("div",{id:"health-fabric",style:"margin-top:8px"});
  root.appendChild(fabricContainer);
  _fetchAndRenderFabric(ctx, fabricContainer);

  // ── Phase 4: System Critics ─────────────────────────────────────────────
  root.appendChild(el("div",{style:"display:flex;align-items:center;gap:8px;margin-top:16px"},[
    el("div",{style:"font-weight:700;font-size:14px;color:#52b788"},"Problems found"),
    ctx.helpers.helpBtn("health_critics"),
  ]));
  const criticsContainer = el("div",{id:"health-critics",style:"margin-top:8px"});
  root.appendChild(criticsContainer);

  // Fetch critics data (async, updates the container when ready)
  _fetchAndRenderCritics(ctx, criticsContainer);

  return root;
}


// ── PadSpan Bright import ─────────────────────────────────────────────────
// The rules are the backend's (bright_import.py): back up first, refuse a
// non-empty house, never merge, reload after. This card only says what the
// backend will do and shows what it said.

// A floor as people know it: Home Assistant's name, not the id behind it.
function _floorLabel(ctx, fid) {
  if (fid === "__outside__") return "Outside";
  const f = (ctx.state.model?.floors || []).find(x => String(x.id) === String(fid));
  return f ? (f.name || f.id) : fid;
}

async function _fetchAndRenderBrightImport(ctx, container) {
  const { el } = ctx.helpers;
  let st;
  try { st = await ctx.actions.callWS({ type: "padspan_ha/bright_import_status" }); }
  catch (e) { return; }                       // an old backend: no card
  if (!st || !st.available) return;
  container.innerHTML = "";
  const card = el("div",{class:"card",style:"margin-top:12px;border:1px solid #b8860b"});
  card.appendChild(el("div",{style:"font-weight:700"},"PadSpan Bright found on this Home Assistant"));
  const srcHas = (st.source && st.source.has) || [];
  card.appendChild(el("div",{class:"muted",style:"margin-top:4px;font-size:12px"},
    srcHas.length
      ? `Bright holds ${srcHas.join(", ")} (stores: ${st.files.join(", ")}).`
      : `Bright's stores are here (${st.files.join(", ")}) but hold no house yet.`));
  if (st.done_at) {
    card.appendChild(el("div",{style:"margin-top:8px;font-size:12px;color:#52b788"},
      `Imported into PadSpan HA on ${new Date(st.done_at).toLocaleString()}. When the house looks right here, remove PadSpan Bright.`));
    container.appendChild(card);
    return;
  }
  const blocked = (st.target_has || []).length ? st.target_has : null;
  card.appendChild(el("div",{class:"muted",style:"margin-top:8px;font-size:12px"},
    "Import copies Bright's floors, rooms, walls, placed lights, maps and settings into PadSpan HA. "
    + "A backup of this install's stores is taken first (Backup / Restore). "
    + "It only runs into an empty house and never merges. PadSpan HA reloads when it is done; "
    + "Bright's own data is left untouched."));
  if (blocked) {
    card.appendChild(el("div",{style:"margin-top:8px;font-size:12px;color:#fca5a5"},
      `Not offered: this install already holds ${blocked.join(", ")}. Import only runs into an empty house.`));
    container.appendChild(card);
    return;
  }
  const status = el("div",{style:"margin-top:8px;font-size:12px;color:#94a3b8"},"");
  const btn = el("button",{class:"btn inline primary",style:"margin-top:8px",onclick: async () => {
    btn.disabled = true; status.textContent = "Backing up, importing…";
    try {
      const r = await ctx.actions.callWS({ type: "padspan_ha/bright_import" });
      status.style.color = "#52b788";
      status.textContent = `Imported ${r.imported.join(", ")}${r.images ? ` and ${r.images} map image(s)` : ""} — backup ${r.backup_id}. PadSpan HA is reloading; refresh in a moment.`;
    } catch (e) {
      btn.disabled = false; status.style.color = "#fca5a5";
      status.textContent = "Import did not run: " + (e.message || e);
    }
  }}, "Import from PadSpan Bright");
  card.appendChild(btn);
  card.appendChild(status);
  container.appendChild(card);
}


// ── Fabric Health fetch & render ──────────────────────────────────────────

let _fabricCache = null;
let _fabricFetchTs = 0;
const _FABRIC_TTL_MS = 15000;

async function _fetchAndRenderFabric(ctx, container) {
  const { el } = ctx.helpers;
  const now = Date.now();
  if (_cacheMode !== ctx.state.dataMode) { _cacheMode = ctx.state.dataMode; _fabricCache = null; _criticsCache = null; }
  if (_fabricCache && (now - _fabricFetchTs) < _FABRIC_TTL_MS) {
    _renderFabric(ctx, container, _fabricCache);
    return;
  }
  container.innerHTML = "";
  container.appendChild(el("div",{class:"card",style:"text-align:center;color:#94a3b8;padding:16px"},"Loading layout checks\u2026"));
  try {
    const res = await ctx.actions.callWS({ type: "padspan_ha/fabric_health" });
    _fabricCache = res;
    _fabricFetchTs = Date.now();
    _renderFabric(ctx, container, res);
  } catch (err) {
    container.innerHTML = "";
    container.appendChild(el("div",{class:"card",style:"color:#fca5a5"},`Failed: ${err.message || err}`));
  }
}

function _renderFabric(ctx, container, data) {
  const { el } = ctx.helpers;
  container.innerHTML = "";
  const { summary, checks, scanners, scanner_positions_m, room_geometry_m, adjacency } = data;

  // ── Fabric status ────────────────────────────────────────────────────────
  // (The old "Migrate to Fabric" button is gone deliberately: it re-derived
  // room shapes from per-photo calibration — the exact operation that
  // corrupted live data. Rooms are built once in Mapping → Rooms instead.)
  if (scanner_positions_m?.length || room_geometry_m?.length) {
    container.appendChild(el("div",{style:"display:flex;align-items:center;gap:8px;margin-bottom:8px;padding:6px 10px;background:rgba(82,183,136,.06);border:1px solid #52b78833;border-radius:8px"},[
      el("span",{style:"color:#52b788;font-size:13px"},"✅"),
      el("span",{style:"font-size:12px;color:#52b788;font-weight:600"},"Layout active"),
      el("span",{style:"font-size:11px;color:#94a3b8"},
        `${scanner_positions_m?.length || 0} scanners · ${room_geometry_m?.length || 0} rooms`),
    ]));
  }

  // ── Per-floor room fabric: committed state + coherence ─────────────────
  const _fabricFloors = data.fabric_floors || {};
  if (Object.keys(_fabricFloors).length) {
    const _ffCard = el("div",{class:"card",style:"margin-bottom:8px;padding:12px"});
    _ffCard.appendChild(el("div",{style:"font-weight:700;font-size:12px;color:#94a3b8;text-transform:uppercase;letter-spacing:.5px;margin-bottom:8px"},
      "Room layout by floor"));
    const _ffTbl = el("div",{style:"display:grid;grid-template-columns:1fr auto auto auto auto;gap:3px 10px;font-size:10px;align-items:center"});
    for (const h of ["Floor","Rooms","Footprint","Clusters","Status"]) {
      _ffTbl.appendChild(el("div",{style:"font-weight:600;color:#64748b;text-transform:uppercase"},h));
    }
    for (const [fid, f] of Object.entries(_fabricFloors).sort()) {
      const _cl = f.clusters;
      const _clBad = typeof _cl === "number" && _cl > 1;
      _ffTbl.appendChild(el("div",{style:"color:#e2e8f0;font-weight:600"},_floorLabel(ctx, fid)));
      _ffTbl.appendChild(el("div",{class:"mono",style:"text-align:right"},String(f.rooms ?? 0)));
      _ffTbl.appendChild(el("div",{class:"mono",style:"color:#94a3b8"},
        f.bbox_w_m != null ? `${f.bbox_w_m}m × ${f.bbox_h_m}m` : "—"));
      _ffTbl.appendChild(el("div",{class:"mono",style:`color:${_clBad?"#f87171":"#52b788"};font-weight:${_clBad?"700":"400"}`},
        _clBad ? `⚠ ${_cl}` : String(_cl ?? "—")));
      _ffTbl.appendChild(el("div",{style:`color:${f.committed?"#52b788":"#f59e0b"};font-weight:600`},
        f.committed ? "🔒 committed" : "not committed"));
    }
    _ffCard.appendChild(_ffTbl);
    container.appendChild(_ffCard);
  }

  // ── Summary banner ─────────────────────────────────────────────────────
  const color = summary.healthy ? "#52b788" : summary.failed > 2 ? "#f87171" : "#f59e0b";
  const bg = summary.healthy ? "rgba(82,183,136,.08)" : "rgba(248,113,113,.08)";
  container.appendChild(el("div",{class:"card",style:`border:1px solid ${color}33;background:${bg};margin-bottom:12px`},[
    el("div",{style:`display:flex;align-items:center;gap:8px`},[
      el("div",{style:`font-weight:800;font-size:14px;color:${color}`},"Layout status"),
      el("div",{class:"pill",style:`background:${color}22;color:${color};font-size:10px;padding:2px 8px`},
        summary.healthy ? "ALL PASS" : `${summary.failed} ISSUE${summary.failed!==1?"S":""}`),
    ]),
    el("div",{style:`font-size:11px;color:#94a3b8;margin-top:4px`},
      `${summary.passed}/${summary.total} checks passed`),
  ]));

  // ── Check results by group ─────────────────────────────────────────────
  const groups = [
    { key: "fabric_sync", label: "Phase 1 \u2014 Receiver layout" },
    { key: "spatial", label: "Phase 2 \u2014 Spatial Model (metres)" },
    { key: "calibration", label: "Phase 3 \u2014 Calibration" },
    { key: "identity", label: "Device Identity Registry" },
    { key: "multifloor", label: "Multi-Floor Accuracy" },
    { key: "occupancy", label: "Occupancy Estimator" },
    { key: "recorder", label: "Phase 4 — HA Recorder Health" },
  ];
  for (const g of groups) {
    const gc = checks.filter(c => c.group === g.key);
    if (!gc.length) continue;
    const card = el("div",{class:"card",style:"margin-bottom:8px;padding:12px"});
    card.appendChild(el("div",{style:"font-weight:700;font-size:12px;color:#94a3b8;text-transform:uppercase;letter-spacing:.5px;margin-bottom:8px"},g.label));
    const tbl = el("div",{class:"health-checks"});
    for (const c of gc) {
      const dot = c.ok ? "\u2705" : "\u274c";
      tbl.appendChild(el("div",{style:"font-size:13px;line-height:1"},dot));
      tbl.appendChild(el("div",{},[
        el("span",{style:"font-weight:600;color:#e2e8f0"},c.name),
        el("span",{style:"color:#64748b;margin-left:6px"},c.detail),
      ]));
      tbl.appendChild(el("div",{class:"mono",style:`color:${c.ok?"#52b788":"#fca5a5"};font-weight:600`},String(c.value)));
    }
    card.appendChild(tbl);
    container.appendChild(card);
  }

  // ── Scanner positions (metres) ─────────────────────────────────────────
  if (scanner_positions_m && scanner_positions_m.length) {
    const card = el("div",{class:"card",style:"margin-bottom:8px;padding:12px"});
    card.appendChild(el("div",{style:"font-weight:700;font-size:12px;color:#94a3b8;text-transform:uppercase;letter-spacing:.5px;margin-bottom:8px"},
      `Scanner Positions in Metres (${scanner_positions_m.length})`));
    const tbl = el("div",{style:"display:grid;grid-template-columns:1fr auto auto auto auto auto;gap:3px 8px;font-size:10px;align-items:center"});
    for (const h of ["Source","X","Y","Z","Floor","Origin"]) {
      tbl.appendChild(el("div",{style:"font-weight:600;color:#64748b;text-transform:uppercase"},h));
    }
    for (const p of scanner_positions_m) {
      tbl.appendChild(el("div",{style:"overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:#e2e8f0"},p.source));
      tbl.appendChild(el("div",{class:"mono",style:"text-align:right"},p.x_m != null ? p.x_m.toFixed(2) : "\u2014"));
      tbl.appendChild(el("div",{class:"mono",style:"text-align:right"},p.y_m != null ? p.y_m.toFixed(2) : "\u2014"));
      tbl.appendChild(el("div",{class:"mono",style:"text-align:right"},p.z_m != null ? p.z_m.toFixed(1) : "\u2014"));
      tbl.appendChild(el("div",{class:"mono",style:"color:#64748b"},_floorLabel(ctx, p.floor_id)));
      tbl.appendChild(el("div",{style:`color:${p.origin==="manual"?"#f59e0b":"#52b788"}`},p.origin));
    }
    card.appendChild(tbl);
    container.appendChild(card);
  }

  // ── Room geometry (metres) ─────────────────────────────────────────────
  if (room_geometry_m && room_geometry_m.length) {
    const card = el("div",{class:"card",style:"margin-bottom:8px;padding:12px"});
    card.appendChild(el("div",{style:"font-weight:700;font-size:12px;color:#94a3b8;text-transform:uppercase;letter-spacing:.5px;margin-bottom:8px"},
      `Room Geometry in Metres (${room_geometry_m.length})`));
    const tbl = el("div",{style:"display:grid;grid-template-columns:1fr auto auto auto auto;gap:3px 8px;font-size:10px;align-items:center"});
    for (const h of ["Room","Type","Centroid","Floor","Origin"]) {
      tbl.appendChild(el("div",{style:"font-weight:600;color:#64748b;text-transform:uppercase"},h));
    }
    for (const g of room_geometry_m) {
      const cStr = g.centroid_m ? `(${g.centroid_m[0]}, ${g.centroid_m[1]})` : "\u2014";
      tbl.appendChild(el("div",{style:"color:#e2e8f0;font-weight:600"},g.room));
      tbl.appendChild(el("div",{class:"mono"},g.type));
      tbl.appendChild(el("div",{class:"mono",style:"color:#94a3b8"},cStr));
      tbl.appendChild(el("div",{class:"mono",style:"color:#64748b"},_floorLabel(ctx, g.floor_id)));
      tbl.appendChild(el("div",{style:`color:${g.origin==="manual"?"#f59e0b":"#52b788"}`},g.origin));
    }
    card.appendChild(tbl);
    container.appendChild(card);
  }

  // ── Adjacency map ──────────────────────────────────────────────────────
  if (adjacency && Object.keys(adjacency).length) {
    const card = el("div",{class:"card",style:"margin-bottom:8px;padding:12px"});
    card.appendChild(el("div",{style:"font-weight:700;font-size:12px;color:#94a3b8;text-transform:uppercase;letter-spacing:.5px;margin-bottom:8px"},
      `Room Adjacency (${Object.keys(adjacency).length} rooms)`));
    const list = el("div",{style:"font-size:11px;line-height:1.8"});
    for (const [room, neighbors] of Object.entries(adjacency).sort()) {
      list.appendChild(el("div",{},[
        el("span",{style:"font-weight:600;color:#e2e8f0"},room),
        el("span",{style:"color:#64748b"}," \u2192 "),
        el("span",{style:"color:#94a3b8"},neighbors.length ? neighbors.join(", ") : "(none)"),
      ]));
    }
    card.appendChild(list);
    container.appendChild(card);
  }

  // ── Scanner mappings table ─────────────────────────────────────────────
  if (scanners && scanners.length) {
    const card = el("div",{class:"card",style:"margin-bottom:8px;padding:12px"});
    card.appendChild(el("div",{style:"font-weight:700;font-size:12px;color:#94a3b8;text-transform:uppercase;letter-spacing:.5px;margin-bottom:8px"},
      `Scanner \u2192 Room Mappings (${scanners.length})`));
    const tbl = el("div",{style:"display:grid;grid-template-columns:1fr 1fr auto auto;gap:3px 8px;font-size:10px;align-items:center"});
    for (const h of ["Source","Room","Floor","Type"]) {
      tbl.appendChild(el("div",{style:"font-weight:600;color:#64748b;text-transform:uppercase"},h));
    }
    for (const s of scanners) {
      const typeColor = s.source_type === "manual" ? "#f59e0b" : "#52b788";
      tbl.appendChild(el("div",{style:"overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:#e2e8f0"},s.source));
      tbl.appendChild(el("div",{style:"color:#94a3b8"},s.room));
      tbl.appendChild(el("div",{class:"mono",style:"color:#64748b"},_floorLabel(ctx, s.floor_id)));
      tbl.appendChild(el("div",{style:`color:${typeColor};font-weight:600`},s.source_type));
    }
    card.appendChild(tbl);
    container.appendChild(card);
  }

  // ── Quick actions ───────────────────────────────────────────────────────
  {
    const actCard = el("div",{style:"display:flex;gap:8px;margin-bottom:8px;flex-wrap:wrap"});

    // Retrain RF
    const rfCheck = checks.find(c => c.name === "RF Model");
    if (rfCheck) {
      const rfBtn = el("button",{class:"btn",style:"width:auto;padding:4px 14px;font-size:11px"},
        `Retrain learned model (${rfCheck.value})`);
      rfBtn.addEventListener("click", async () => {
        rfBtn.disabled = true; rfBtn.textContent = "Retraining\u2026";
        try {
          const r = await ctx.actions.callWS({type:"padspan_ha/calibration_retrain_rf"});
          ctx.toast(`Learned model retrained: ${r.use_metres ? "metres" : "fractions"}, ${r.point_count} pts`);
          _fabricCache = null; _fabricFetchTs = 0; _fetchAndRenderFabric(ctx, container);
        } catch(e) { ctx.toast(`Failed: ${e.message||e}`); rfBtn.disabled = false; rfBtn.textContent = "Retrain learned model"; }
      });
      actCard.appendChild(rfBtn);
    }

    // Resync scanners (fix room/floor assignments)
    const resyncBtn = el("button",{class:"btn",style:"width:auto;padding:4px 14px;font-size:11px"},
      "Resync Scanners");
    resyncBtn.addEventListener("click", async () => {
      resyncBtn.disabled = true; resyncBtn.textContent = "Resyncing\u2026";
      try {
        const r = await ctx.actions.callWS({type:"padspan_ha/fabric_resync"});
        ctx.toast(`Resync: removed ${r.removed}, added ${r.added}, pruned ${r.pruned} \u2192 ${r.final_count} scanners`);
        _fabricCache = null; _fabricFetchTs = 0; _fetchAndRenderFabric(ctx, container);
      } catch(e) { ctx.toast(`Failed: ${e.message||e}`); resyncBtn.disabled = false; resyncBtn.textContent = "Resync Scanners"; }
    });
    actCard.appendChild(resyncBtn);

    // Reset spatial model (nuclear option)
    const resetBtn = el("button",{class:"btn",style:"width:auto;padding:4px 14px;font-size:11px;border-color:#f8717144;color:#fca5a5"},
      "Reset Spatial Model");
    resetBtn.addEventListener("click", async () => {
      if (!confirm("Clear every scanner position, beacon position and barrier? A backup is taken first (Manage → Backup & Restore). Room shapes, lights, map placements and calibration points are NOT touched.")) return;
      resetBtn.disabled = true; resetBtn.textContent = "Resetting\u2026";
      try {
        const r = await ctx.actions.callWS({type:"padspan_ha/fabric_reset_spatial"});
        ctx.toast(r.backup_id
          ? `Reset: ${r.removed} scanner/beacon positions and barriers cleared (backup taken first)`
          : "Nothing to reset: no scanner/beacon positions or barriers");
        _fabricCache = null; _fabricFetchTs = 0; _fetchAndRenderFabric(ctx, container);
      } catch(e) { ctx.toast(`Failed: ${e.message||e}`); resetBtn.disabled = false; resetBtn.textContent = "Reset Spatial Model"; }
    });
    actCard.appendChild(resetBtn);

    // Migrate Device Identity Registry (if needed)
    const _idCheck = (checks||[]).find(c => c.group === "identity" && c.name === "Identity Migration");
    if (_idCheck && _idCheck.value === "needed") {
      const idBtn = el("button",{class:"btn save-pulse",style:"width:auto;padding:4px 14px;font-size:11px;background:#92400e;border-color:#f59e0b;color:#fbbf24;font-weight:700"},
        "\ud83d\udd11 Migrate Device Identity");
      idBtn.addEventListener("click", async () => {
        idBtn.disabled = true; idBtn.textContent = "Migrating\u2026"; idBtn.classList.remove("save-pulse");
        try {
          const r = await ctx.actions.callWS({type:"padspan_ha/device_registry_migrate"});
          ctx.toast(`Identity: ${r.migrated} devices migrated, ${r.merged} merged \u2192 ${r.total_devices} total`);
          _fabricCache = null; _fabricFetchTs = 0; _fetchAndRenderFabric(ctx, container);
        } catch(e) { ctx.toast(`Failed: ${e.message||e}`); idBtn.disabled=false; idBtn.textContent="\ud83d\udd11 Migrate Device Identity"; idBtn.classList.add("save-pulse"); }
      });
      actCard.appendChild(idBtn);
    }

    container.appendChild(actCard);
  }

  // ── RSSI vector capture ─────────────────────────────────────────────────
  // Opt-in, so it only exists on the page once the feature is switched on.
  if (ctx.state.settings?.rssi_capture_enabled === true) {
    _renderCapture(ctx, container);
  }

  // ── Maps diagnostic table ───────────────────────────────────────────────
  const maps = data.maps || [];
  if (maps.length) {
    const card = el("div",{class:"card",style:"margin-bottom:8px;padding:12px"});
    card.appendChild(el("div",{style:"font-weight:700;font-size:12px;color:#94a3b8;text-transform:uppercase;letter-spacing:.5px;margin-bottom:8px"},
      `Maps (${maps.length})`));
    const tbl = el("div",{style:"display:grid;grid-template-columns:1fr auto auto auto auto auto auto;gap:3px 8px;font-size:10px;align-items:center"});
    for (const h of ["Name","Size","px/m","Receivers","Rooms","Barriers","Floor"]) {
      tbl.appendChild(el("div",{style:"font-weight:600;color:#64748b;text-transform:uppercase"},h));
    }
    for (const m of maps) {
      const ppm = m.px_per_meter;
      const ppmColor = ppm ? "#52b788" : "#f87171";
      tbl.appendChild(el("div",{style:"overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:#e2e8f0"},m.name));
      tbl.appendChild(el("div",{class:"mono",style:"white-space:nowrap"},`${m.width}\u00d7${m.height}`));
      tbl.appendChild(el("div",{class:"mono",style:`color:${ppmColor}`},ppm ? String(Math.round(ppm)) : "none"));
      tbl.appendChild(el("div",{class:"mono",style:"text-align:center"},String(m.has_receivers)));
      tbl.appendChild(el("div",{class:"mono",style:"text-align:center"},String(m.has_room_bounds)));
      tbl.appendChild(el("div",{class:"mono",style:"text-align:center"},String(m.has_rf_barriers)));
      tbl.appendChild(el("div",{class:"mono",style:"color:#64748b"},_floorLabel(ctx, m.floor_id)));
    }
    card.appendChild(tbl);
    container.appendChild(card);
  }

  // ── Radio Audit ─────────────────────────────────────────────────────────
  const auditContainer = el("div",{id:"health-radio-audit"});
  container.appendChild(auditContainer);
  const auditBtn = el("button",{class:"btn",style:"margin-top:8px;width:auto;padding:6px 16px"},"Run Radio Audit");
  auditBtn.addEventListener("click", async () => {
    auditBtn.disabled = true; auditBtn.textContent = "Auditing\u2026";
    try {
      const res = await ctx.actions.callWS({type:"padspan_ha/radio_audit"});
      _renderRadioAudit(ctx, auditContainer, res);
      auditBtn.textContent = "Run Radio Audit";
      auditBtn.disabled = false;
    } catch(e) {
      auditContainer.innerHTML = "";
      auditContainer.appendChild(el("div",{class:"card",style:"color:#fca5a5"},`Audit failed: ${e.message||e}`));
      auditBtn.textContent = "Run Radio Audit"; auditBtn.disabled = false;
    }
  });
  container.appendChild(auditBtn);

  // ── Refresh button ─────────────────────────────────────────────────────
  const btn = el("button",{class:"btn",style:"margin-top:8px;margin-left:8px;width:auto;padding:6px 16px"},"Refresh layout");
  btn.addEventListener("click", () => { _fabricCache = null; _fabricFetchTs = 0; _fetchAndRenderFabric(ctx, container); });
  container.appendChild(btn);
}


// ── Radio Audit render ───────────────────────────────────────────────────

function _renderRadioAudit(ctx, container, data) {
  const { el } = ctx.helpers;
  container.innerHTML = "";
  const { total_radios, total_mismatches, radios } = data;

  // Summary
  const color = total_mismatches === 0 ? "#52b788" : "#f87171";
  const card = el("div",{class:"card",style:`margin-top:12px;border:1px solid ${color}33;padding:12px`});
  card.appendChild(el("div",{style:`display:flex;align-items:center;gap:8px;margin-bottom:8px`},[
    el("div",{style:`font-weight:800;font-size:14px;color:${color}`},"Radio Audit"),
    el("div",{class:"pill",style:`background:${color}22;color:${color};font-size:10px;padding:2px 8px`},
      total_mismatches === 0 ? `${total_radios} RADIOS OK` : `${total_mismatches} MISMATCH${total_mismatches!==1?"ES":""}`),
  ]));

  // Per-radio detail
  for (const r of radios) {
    const rCard = el("div",{style:`padding:10px;margin-bottom:6px;border-radius:6px;border:1px solid ${r.ok?"#33415533":"#f8717133"};background:${r.ok?"transparent":"rgba(248,113,113,.04)"}`});

    // Header: source + status
    const hdr = el("div",{style:"display:flex;align-items:center;gap:8px;margin-bottom:6px"});
    hdr.appendChild(el("span",{style:"font-size:13px"},r.ok ? "\u2705" : "\u274c"));
    hdr.appendChild(el("span",{style:"font-weight:700;color:#e2e8f0;font-size:12px"},r.source));
    if (r.radio_name && r.radio_name !== r.source) {
      hdr.appendChild(el("span",{style:"color:#64748b;font-size:11px"},r.radio_name));
    }
    const age = r.last_heard_s;
    if (age != null) {
      const ageColor = age < 30 ? "#52b788" : age < 120 ? "#f59e0b" : "#f87171";
      hdr.appendChild(el("span",{style:`color:${ageColor};font-size:10px;margin-left:auto`},`${Math.round(age)}s ago`));
    }
    rCard.appendChild(hdr);

    // Device info
    const d = r.device;
    if (d) {
      const grid = el("div",{style:"display:grid;grid-template-columns:auto 1fr;gap:2px 10px;font-size:10px;margin-bottom:4px"});
      const _row = (label, val, color) => {
        grid.appendChild(el("div",{style:"color:#64748b;font-weight:600;text-transform:uppercase"},label));
        grid.appendChild(el("div",{style:`color:${color||"#94a3b8"}`},String(val || "\u2014")));
      };
      _row("HA Name", d.name_by_user || d.name);
      _row("Manufacturer", d.manufacturer);
      _row("Model", d.model);
      _row("SW Version", d.sw_version);
      if (d.hw_version) _row("HW Version", d.hw_version);
      _row("ESPHome", d.is_esphome ? `Yes (${(d.esphome_names||[]).join(", ")||"?"})` : "No",
        d.is_esphome ? "#52b788" : "#64748b");
      _row("HA Area", d.ha_area || "(none)", d.ha_area ? "#e2e8f0" : "#f87171");
      _row("HA Floor", d.ha_floor ? _floorLabel(ctx, d.ha_floor) : "(none)", d.ha_floor ? "#e2e8f0" : "#f87171");

      // MACs
      if (d.macs && d.macs.length) {
        for (const m of d.macs) {
          _row(`MAC (${m.type})`, m.address, "#5eead4");
        }
      }

      // Identifiers
      if (d.identifiers && d.identifiers.length) {
        for (const i of d.identifiers) {
          _row(`ID (${i.domain})`, i.id, "#94a3b8");
        }
      }
      rCard.appendChild(grid);
    } else {
      rCard.appendChild(el("div",{style:"font-size:10px;color:#f87171;margin-bottom:4px"},
        "No matching HA device found for this radio source"));
    }

    // Fabric info
    const f = r.fabric;
    if (f) {
      rCard.appendChild(el("div",{style:"font-size:10px;color:#64748b;margin-top:2px"},
        `Layout: ${f.room} (${_floorLabel(ctx, f.floor_id)}) [${f.source_type}]`));
    }

    // Position
    const p = r.position_m;
    if (p) {
      rCard.appendChild(el("div",{style:"font-size:10px;color:#64748b"},
        `Position: (${p.x_m?.toFixed(1)}, ${p.y_m?.toFixed(1)}, z=${p.z_m?.toFixed(1)}) [${_floorLabel(ctx, p.floor_id)}]`));
    }

    // Mismatches
    if (r.mismatches && r.mismatches.length) {
      for (const m of r.mismatches) {
        rCard.appendChild(el("div",{style:"font-size:10px;color:#fca5a5;font-weight:600;margin-top:2px"},
          `\u26a0 ${m}`));
      }
    }

    card.appendChild(rCard);
  }

  container.appendChild(card);
}


// ── Critics fetch & render ────────────────────────────────────────────────

async function _fetchAndRenderCritics(ctx, container) {
  const { el } = ctx.helpers;
  const now = Date.now();

  // Use cache if fresh enough
  if (_cacheMode !== ctx.state.dataMode) { _cacheMode = ctx.state.dataMode; _fabricCache = null; _criticsCache = null; }
  if (_criticsCache && (now - _criticsFetchTs) < _CRITICS_TTL_MS) {
    _renderCritics(ctx, container, _criticsCache);
    return;
  }

  // Loading state
  container.innerHTML = "";
  container.appendChild(el("div",{class:"card",style:"text-align:center;color:#94a3b8;padding:20px"},
    "Loading system diagnostics\u2026"
  ));

  try {
    const res = await ctx.actions.callWS({ type: "padspan_ha/system_critics" });
    _criticsCache = res;
    _criticsFetchTs = Date.now();
    _renderCritics(ctx, container, res);
  } catch (err) {
    container.innerHTML = "";
    container.appendChild(el("div",{class:"card",style:"color:#fca5a5"},
      `Could not check for problems: ${err.message || err}`
    ));
  }
}

function _renderCritics(ctx, container, data) {
  const { el } = ctx.helpers;
  container.innerHTML = "";

  const { summary, critics, confusion_matrix, per_map_quality } = data;

  // ── Summary Banner ──────────────────────────────────────────────────────
  const bannerColor = summary.healthy ? "#52b788" :
    summary.critical > 0 ? "#f87171" :
    summary.warning > 0 ? "#f59e0b" : "#52b788";
  const bannerBg = summary.healthy ? "rgba(82,183,136,.08)" :
    summary.critical > 0 ? "rgba(248,113,113,.08)" :
    summary.warning > 0 ? "rgba(245,158,11,.08)" : "rgba(82,183,136,.08)";
  const bannerText = summary.healthy
    ? "All systems healthy \u2014 no issues detected."
    : `${summary.total} issue${summary.total !== 1 ? "s" : ""} found: ` +
      [
        summary.critical > 0 ? `${summary.critical} critical` : "",
        summary.warning > 0 ? `${summary.warning} warning` : "",
        summary.info > 0 ? `${summary.info} info` : "",
      ].filter(Boolean).join(", ");

  container.appendChild(el("div",{
    class:"card",
    style:`border:1px solid ${bannerColor}33;background:${bannerBg};margin-bottom:12px`
  },[
    el("div",{style:`display:flex;align-items:center;gap:8px`},[
      el("div",{class:"pill",style:`background:${bannerColor}22;color:${bannerColor};font-size:10px;padding:2px 8px`},
        summary.healthy ? "HEALTHY" : `${summary.total} ISSUE${summary.total !== 1 ? "S" : ""}`
      ),
    ]),
    el("div",{style:`font-size:12px;color:${bannerColor};margin-top:4px`}, bannerText),
  ]));

  // ── Critic Cards ────────────────────────────────────────────────────────
  if (critics.length) {
    const sevColors = {
      critical: { bg: "rgba(248,113,113,.06)", border: "#f8717133", text: "#fca5a5", icon: "\u26d4" },
      warning:  { bg: "rgba(245,158,11,.06)",  border: "#f59e0b33", text: "#fbbf24", icon: "\u26a0" },
      info:     { bg: "rgba(148,163,184,.06)", border: "#94a3b833", text: "#94a3b8", icon: "\u2139" },
    };

    for (const critic of critics) {
      const sev = sevColors[critic.severity] || sevColors.info;
      const card = el("div",{
        class:"card",
        style:`border:1px solid ${sev.border};background:${sev.bg};margin-bottom:8px;padding:12px`
      });
      card.innerHTML = `
        <div style="display:flex;align-items:flex-start;gap:8px">
          <span style="font-size:14px;line-height:1">${sev.icon}</span>
          <div style="flex:1;min-width:0">
            <div style="font-weight:700;font-size:12px;color:${sev.text};text-transform:uppercase;letter-spacing:.5px;margin-bottom:2px">
              ${_escHtml(critic.category.replace(/_/g, " "))} \u2022 ${_escHtml(critic.severity)}
            </div>
            <div style="font-weight:600;font-size:13px;color:#e2e8f0;margin-bottom:4px">${_escHtml(critic.title)}</div>
            <div style="font-size:11px;color:#94a3b8;line-height:1.5">${_escHtml(critic.message)}</div>
            <div style="font-size:11px;color:#5eead4;margin-top:6px;line-height:1.4"><b>Action:</b> ${_escHtml(critic.action)}</div>
          </div>
        </div>
      `;
      container.appendChild(card);
    }
  }

  // ── Room Confusion Matrix ───────────────────────────────────────────────
  if (confusion_matrix && confusion_matrix.length) {
    const cmCard = el("div",{class:"card",style:"margin-top:12px"});
    cmCard.appendChild(el("div",{style:"font-weight:700;margin-bottom:8px"},"Room mix-ups"));
    cmCard.appendChild(el("div",{class:"muted",style:"font-size:11px;margin-bottom:8px"},
      "Bidirectional transitions between room pairs. High counts suggest the system oscillates between these rooms."
    ));

    const tbl = el("div",{style:"display:grid;grid-template-columns:1fr 1fr auto auto;gap:4px 10px;font-size:11px;align-items:center"});
    // Header
    for (const h of ["Room A","Room B","Transitions","Rate"]) {
      tbl.appendChild(el("div",{style:"font-weight:600;color:#94a3b8;font-size:10px;text-transform:uppercase"},h));
    }
    // Find max count for heat coloring
    const maxCount = confusion_matrix.length ? confusion_matrix[0].count : 1;
    for (const entry of confusion_matrix.slice(0, 15)) {
      const heat = Math.min(1, entry.count / Math.max(maxCount, 1));
      const heatColor = heat > 0.6 ? "#f87171" : heat > 0.3 ? "#f59e0b" : "#52b788";
      tbl.appendChild(el("div",{style:"overflow:hidden;text-overflow:ellipsis;white-space:nowrap"}, entry.room_a));
      tbl.appendChild(el("div",{style:"overflow:hidden;text-overflow:ellipsis;white-space:nowrap"}, entry.room_b));
      tbl.appendChild(el("div",{style:`color:${heatColor};font-weight:600;text-align:right`}, String(entry.count)));
      tbl.appendChild(el("div",{class:"muted",style:"text-align:right"}, `${(entry.rate * 100).toFixed(1)}%`));
    }
    cmCard.appendChild(tbl);
    container.appendChild(cmCard);
  }

  // ── Per-Map Quality ─────────────────────────────────────────────────────
  if (per_map_quality && per_map_quality.length) {
    const mqCard = el("div",{class:"card",style:"margin-top:12px"});
    mqCard.appendChild(el("div",{style:"font-weight:700;margin-bottom:8px"},"Map Calibration Quality"));
    mqCard.appendChild(el("div",{class:"muted",style:"font-size:11px;margin-bottom:8px"},
      "Leave-one-out cross-validation error per map. Lower is better."
    ));

    const tbl = el("div",{style:"display:grid;grid-template-columns:1fr auto auto auto;gap:4px 10px;font-size:11px;align-items:center"});
    for (const h of ["Map","Points","Mean Error","Max Error"]) {
      tbl.appendChild(el("div",{style:"font-weight:600;color:#94a3b8;font-size:10px;text-transform:uppercase"},h));
    }
    for (const m of per_map_quality) {
      // Thresholds in metres, matching CRITIC_*_ERROR_M in const.py.
      const errM = m.mean_error_m;
      const errColor = errM == null ? "#94a3b8" :
        errM >= 2.25 ? "#f87171" : errM >= 1.2 ? "#f59e0b" : "#52b788";
      tbl.appendChild(el("div",{style:"overflow:hidden;text-overflow:ellipsis;white-space:nowrap"}, m.map_name || m.map_id));
      tbl.appendChild(el("div",{style:"text-align:right"}, String(m.point_count)));
      tbl.appendChild(el("div",{style:`color:${errColor};text-align:right`},
        errM != null ? `${errM.toFixed(2)}m` : "\u2014"
      ));
      tbl.appendChild(el("div",{class:"muted",style:"text-align:right"},
        m.max_error_m != null ? `${m.max_error_m.toFixed(2)}m` : "\u2014"
      ));
    }
    mqCard.appendChild(tbl);
    container.appendChild(mqCard);
  }

  // ── Refresh button ──────────────────────────────────────────────────────
  const refreshBtn = el("button",{class:"btn",style:"margin-top:12px;width:auto;padding:6px 16px"}, "Check again");
  refreshBtn.addEventListener("click", () => {
    _criticsCache = null;
    _criticsFetchTs = 0;
    _fetchAndRenderCritics(ctx, container);
  });
  container.appendChild(refreshBtn);
}

function _escHtml(str) {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

// ── RSSI vector capture ───────────────────────────────────────────────────
// Record a session, mark where the device really is, export the trace —
// and now (gap #13, best-in-class roadmap) replay a finished session and
// score it, and A/B a settings change against the SAME recorded walk.
// Replay runs against an ISOLATED coordinator built fresh from the
// capture's own header (capture_replay.py) — it never touches the live
// coordinator's own filter/vote state.

let _capTimer = null;

function _capFmt(bytes) {
  return bytes > 1048576 ? `${(bytes / 1048576).toFixed(1)} MB`
       : bytes > 1024    ? `${Math.round(bytes / 1024)} KB`
       : `${bytes} B`;
}

function _capClock(secs) {
  const s = Math.max(0, Math.round(secs));
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
}

function _renderCapture(ctx, container) {
  const { el } = ctx.helpers;
  const card = el("div", {class:"card", style:"margin-bottom:8px;padding:12px"});
  card.appendChild(el("div", {style:"font-weight:700;font-size:12px;color:#94a3b8;text-transform:uppercase;letter-spacing:.5px;margin-bottom:8px"},
    "RSSI Vector Capture"));
  card.appendChild(el("div", {style:"font-size:11px;color:#64748b;margin-bottom:10px"},
    "Record what every scanner heard, walk the house marking the room you are actually in, "
    + "then export the trace. Nothing is recorded until you press Record."));

  const status = el("div", {style:"font-size:11px;color:#94a3b8;margin-bottom:8px"}, "…");
  const row = el("div", {style:"display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-bottom:8px"});
  const sessions = el("div", {style:"font-size:11px"});
  card.appendChild(status); card.appendChild(row); card.appendChild(sessions);
  container.appendChild(card);

  const recBtn = el("button", {class:"btn", style:"width:auto;padding:4px 14px;font-size:11px"}, "⏺ Record");
  const markSel = el("select", {class:"input", style:"width:auto;padding:3px 8px;font-size:11px"});
  const markBtn = el("button", {class:"btn", style:"width:auto;padding:4px 14px;font-size:11px"}, "Mark room");
  // Optional precise position alongside the room (gap #13, best-in-class
  // roadmap) — numeric metre entry, not a draggable map pin: it always
  // works regardless of whether a map is anchored to the fabric's world
  // gauge, which a click-on-image picker would depend on. Left blank, the
  // mark behaves exactly as before (room label only).
  const markX = el("input", {class:"input", type:"number", step:"0.1", placeholder:"x (m)",
    style:"width:64px;box-sizing:content-box;padding:3px 6px;font-size:11px"});
  const markY = el("input", {class:"input", type:"number", step:"0.1", placeholder:"y (m)",
    style:"width:64px;box-sizing:content-box;padding:3px 6px;font-size:11px"});
  row.appendChild(recBtn); row.appendChild(markSel); row.appendChild(markX); row.appendChild(markY);
  row.appendChild(markBtn);

  const roomNames = (ctx.state.live.snapshot?.rooms || []).map(r => r.name || r).filter(Boolean);
  for (const r of roomNames) markSel.appendChild(el("option", {value:r}, r));
  markSel.disabled = markBtn.disabled = markX.disabled = markY.disabled = true;

  // One interval, cleared before it is ever replaced. A record button that
  // leaves a 5 s poll behind on every tab change is a leak nobody notices
  // until the panel has been open all day.
  if (_capTimer) { clearInterval(_capTimer); _capTimer = null; }

  const refresh = async () => {
    if (!document.body.contains(card)) { clearInterval(_capTimer); _capTimer = null; return; }
    let st;
    try { st = await ctx.actions.callWS({type:"padspan_ha/capture_status"}); }
    catch { return; }
    if (st.recording) {
      const left = (st.ends_ts || 0) - Date.now() / 1000;
      status.textContent = `Recording — ${_capClock(left)} left · ${st.frames} frames · `
        + `${st.objects} objects · ${_capFmt(st.bytes)}`
        + (st.gt_room ? ` · marked "${st.gt_room}"` : "")
        + (st.truncated ? ` · ${st.truncated} objects dropped` : "");
      status.style.color = "#fbbf24";
      recBtn.textContent = "⏹ Stop";
      markSel.disabled = markBtn.disabled = markX.disabled = markY.disabled = false;
    } else {
      status.textContent = "Not recording.";
      status.style.color = "#94a3b8";
      recBtn.textContent = "⏺ Record";
      markSel.disabled = markBtn.disabled = markX.disabled = markY.disabled = true;
    }
    recBtn.disabled = false;
    await _capList(ctx, sessions);
  };

  recBtn.addEventListener("click", async () => {
    recBtn.disabled = true;
    try {
      const st = await ctx.actions.callWS({type:"padspan_ha/capture_status"});
      if (st.recording) {
        const r = await ctx.actions.callWS({type:"padspan_ha/capture_stop"});
        ctx.toast(r.ok ? `Stopped: ${r.frames} frames, ${_capFmt(r.bytes)}` : r.error);
      } else {
        const mins = parseInt(prompt("Record for how many minutes? (1–60)", "5") || "0", 10);
        if (!mins) { recBtn.disabled = false; return; }
        const label = prompt("Label for this session (optional)", "") || "";
        const r = await ctx.actions.callWS({type:"padspan_ha/capture_start", minutes:mins, label});
        ctx.toast(`Recording ${r.session_id} — ${r.minutes} min, ${r.sources} scanners`);
      }
    } catch(e) { ctx.toast(`Failed: ${e.message||e}`, true); }
    await refresh();
  });

  markBtn.addEventListener("click", async () => {
    try {
      const msg = {type:"padspan_ha/capture_mark", room:markSel.value};
      const x = parseFloat(markX.value), y = parseFloat(markY.value);
      if (isFinite(x) && isFinite(y)) { msg.x_m = x; msg.y_m = y; }
      const r = await ctx.actions.callWS(msg);
      ctx.toast(r.ok ? `Marked ${r.room}` + (msg.x_m != null ? ` @ (${x}, ${y})` : "") : r.error);
    } catch(e) { ctx.toast(`Failed: ${e.message||e}`, true); }
    await refresh();
  });

  refresh();
  _capTimer = setInterval(refresh, 5000);
}

async function _capList(ctx, host) {
  const { el } = ctx.helpers;
  let list;
  try { list = (await ctx.actions.callWS({type:"padspan_ha/capture_list"})).sessions || []; }
  catch { return; }
  host.replaceChildren();
  if (!list.length) { host.appendChild(el("div",{style:"color:#64748b"},"No recorded sessions.")); return; }

  for (const s of list) {
    const rowEl = el("div", {style:"display:flex;gap:8px;align-items:center;padding:3px 0;border-top:1px solid #1b3526"});
    const when = new Date((s.t0 || 0) * 1000).toLocaleString();
    rowEl.appendChild(el("div", {style:"flex:1;color:#cbd5e1"},
      `${s.label || s.id} · ${when} · ${s.frames} frames · ${_capFmt(s.bytes || 0)}`
      + (s.stop_reason && s.stop_reason !== "manual" ? ` · ${s.stop_reason}` : "")
      // A truncated session sampled its site rather than describing it, and
      // the export gives no hint of that on its own.
      + (s.truncated ? ` · ⚠ ${s.truncated} objects dropped` : "")));

    const dl = el("button", {class:"btn", style:"width:auto;padding:2px 10px;font-size:10px"}, "Export .jsonl");
    dl.addEventListener("click", async () => {
      dl.disabled = true; dl.textContent = "Exporting…";
      try {
        // Paged: one response is byte-capped at ~1.5 MB, so a 25 MB session
        // arrives in pieces rather than taking the browser down with it.
        const out = [];
        for (let off = 0; ; ) {
          const p = await ctx.actions.callWS({type:"padspan_ha/capture_get", session_id:s.id, offset:off, limit:2000});
          out.push(...p.lines);
          off += p.lines.length;
          if (p.eof || !p.lines.length) break;
        }
        const url = URL.createObjectURL(new Blob([out.join("\n") + "\n"], {type:"application/x-ndjson"}));
        const a = document.createElement("a");
        a.href = url; a.download = `padspan-capture-${s.id}.jsonl`; a.click();
        URL.revokeObjectURL(url);
        ctx.toast(`Exported ${out.length} lines.`);
      } catch(e) { ctx.toast(`Failed: ${e.message||e}`, true); }
      dl.disabled = false; dl.textContent = "Export .jsonl";
    });
    rowEl.appendChild(dl);

    const replayBtn = el("button", {class:"btn", style:"width:auto;padding:2px 10px;font-size:10px"}, "Replay & Score");
    const replayPanel = el("div", {style:"display:none;margin:6px 0 4px;padding:8px;background:#0a150e;border:1px solid #1b3526;border-radius:8px;font-size:11px"});
    replayBtn.addEventListener("click", async () => {
      const open = replayPanel.style.display !== "none";
      if (open) { replayPanel.style.display = "none"; return; }
      replayPanel.style.display = "block";
      await _renderReplayPanel(ctx, replayPanel, s.id);
    });
    rowEl.appendChild(replayBtn);

    const del = el("button", {class:"btn", style:"width:auto;padding:2px 10px;font-size:10px;border-color:#f8717144;color:#fca5a5"}, "Delete");
    del.addEventListener("click", async () => {
      if (!confirm(`Delete capture session ${s.id}?`)) return;
      try {
        await ctx.actions.callWS({type:"padspan_ha/capture_delete", session_id:s.id});
        await _capList(ctx, host);
      } catch(e) { ctx.toast(`Failed: ${e.message||e}`, true); }
    });
    rowEl.appendChild(del);

    const wrap = el("div", {style:"display:flex;flex-direction:column;width:100%"});
    wrap.appendChild(rowEl);
    wrap.appendChild(replayPanel);
    host.appendChild(wrap);
  }
}

// Replay & Score panel for one finished session (gap #13, best-in-class
// roadmap). Fetches padspan_ha/capture_replay, shows room accuracy + metre
// error, and offers a small A/B: tweak a couple of the settings the replay
// loop actually reads (kalman_q/r, room_change_delay_s) and re-run against
// the SAME recorded frames. Position accuracy never moves in the variant —
// see capture_replay.py's module docstring for why — so only the room
// accuracy row is shown twice.
async function _renderReplayPanel(ctx, panel, sessionId) {
  const { el } = ctx.helpers;
  panel.replaceChildren(el("div", {style:"color:#78909c"}, "Replaying…"));

  let res;
  try {
    res = await ctx.actions.callWS({type:"padspan_ha/capture_replay", session_id: sessionId});
  } catch(e) {
    panel.replaceChildren(el("div", {style:"color:#fca5a5"}, `Replay failed: ${e.message || e}`));
    return;
  }

  const scoreRow = (label, score) => el("div", {style:"margin-bottom:4px"}, [
    el("span", {style:"color:#94a3b8"}, label + ": "),
    score.room_accuracy != null
      ? el("span", {style:"color:#e0e0e0"},
          `${Math.round(score.room_accuracy * 100)}% room (${score.room_scored_count} labelled)`)
      : el("span", {style:"color:#64748b"}, "no room labels"),
    score.mean_error_m != null
      ? el("span", {style:"color:#e0e0e0"},
          ` · ${score.mean_error_m}m mean / ${score.max_error_m}m max position error (${score.position_scored_count} marked)`)
      : el("span", {style:"color:#64748b"}, " · no position marks"),
  ]);

  panel.replaceChildren();
  panel.appendChild(scoreRow("Baseline (recorded settings)", res.baseline));

  const abRow = el("div", {style:"display:flex;gap:6px;align-items:center;margin-top:6px;flex-wrap:wrap"});
  const qIn = el("input", {class:"input", type:"number", step:"0.01", placeholder:"kalman_q",
    style:"width:80px;box-sizing:content-box;padding:2px 6px;font-size:10px"});
  const rIn = el("input", {class:"input", type:"number", step:"0.5", placeholder:"kalman_r",
    style:"width:80px;box-sizing:content-box;padding:2px 6px;font-size:10px"});
  const dIn = el("input", {class:"input", type:"number", step:"1", placeholder:"room_change_delay_s",
    style:"width:120px;box-sizing:content-box;padding:2px 6px;font-size:10px"});
  const abBtn = el("button", {class:"btn", style:"width:auto;padding:2px 10px;font-size:10px"}, "Run A/B");
  abRow.appendChild(qIn); abRow.appendChild(rIn); abRow.appendChild(dIn); abRow.appendChild(abBtn);
  panel.appendChild(abRow);

  const abResult = el("div", {style:"margin-top:6px"});
  panel.appendChild(abResult);

  abBtn.addEventListener("click", async () => {
    const settings = {};
    for (const [inp, key] of [[qIn, "kalman_q"], [rIn, "kalman_r"], [dIn, "room_change_delay_s"]]) {
      const v = parseFloat(inp.value);
      if (isFinite(v)) settings[key] = v;
    }
    if (!Object.keys(settings).length) { ctx.toast("Enter at least one setting to compare."); return; }
    abResult.replaceChildren(el("div", {style:"color:#78909c"}, "Replaying variant…"));
    try {
      const ab = await ctx.actions.callWS({
        type:"padspan_ha/capture_replay", session_id: sessionId, settings});
      abResult.replaceChildren(scoreRow("Variant (" + Object.entries(settings).map(([k,v]) => `${k}=${v}`).join(", ") + ")", ab.variant));
    } catch(e) {
      abResult.replaceChildren(el("div", {style:"color:#fca5a5"}, `A/B failed: ${e.message || e}`));
    }
  });
}
