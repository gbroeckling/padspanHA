// PadSpan HA — BLE Room-Presence Tracking for Home Assistant
// Copyright (C) 2026 Garry Broeckling
// Licensed under the GNU General Public License v3.0
// See LICENSE file or https://www.gnu.org/licenses/gpl-3.0.html
//
// Add data via plans (experimental, off by default; 2026-11): Live Aboard's
// Plans tool, Edit → Plans, beside Door, Window, Heights and Strip. Present
// only while Settings → AI's master switch is on and an AI Task is chosen
// (live_aboard_edit.js setPlans). The vetting map, and the list view as its
// fallback (no WebGL: openPlansList, from Mapping → Furnish).
//
//   The map     the plan as a textured plane on the floor showing (one texture
//               at a time, 1024 px at most, released on a floor change), what
//               the AI found as ghosts through the real builders, dashed and
//               at 45 %, NEVER in the draft until accepted, so a ghost can't
//               cut a floor; a pin per item, one card. A pin or the queue picks
//               an item and the camera flies there. New, Correction, Failure,
//               Looks right, Later; Move by hand is accept-then-drag. No accept
//               all: the one bulk action is Dismiss the rest (Later, never wrong).
//               Nothing here costs a frame at rest: pins and ghosts move only
//               in the view's own layout, which runs when it draws.
//   The sheet   which placed plans to read (grouped by floor, all ticked),
//               which kinds (stairs; railings beside them; lights, each plan
//               asked whether it draws fixtures), what to expect, which AI reads
//               them, how long it may be busy, and one button. A session that
//               read nothing says why, not that the AI found nothing.
//   The job     runs on the server (ws_plan_ai.py); the sheet asks for its
//               status every 3 s and can cancel it between reads.
//   The list    one row per suggestion, with a crop of the plan drawn from
//               the Library's signed picture link and the box the AI gave:
//               say it looks right, mark it wrong (one reason chip), later, all
//               written at once, or take that back; "already in your house"
//               and "ignored before" listed apart; Manage ignored.
//   New,        go into the editor's draft: a new stair is a draft piece, a
//   Correction  correction the target piece moved, a railing its side and
//               style, a light its kind (never its place), each one undo step,
//               and what is pending is read off the
//               draft, so Undo, Discard and a lost page take it back and the
//               server never knew. Save sends them first to plan_ai_commit, the
//               one writer (plan_ai_write.py), and only then the person's other
//               edits. "Undo this session" takes a whole session back.
//
// Imports nothing; the editor hands in the sheet, the host's callWS, the floors,
// its draft and three.js. No placement, picture size or map record is read
// here: the server answers in metres and the crop is cut by fractions of the picture.

const CSS = `
.la3d-sheet.plans{max-height:calc(100% - 120px);overflow-y:auto;width:min(520px,calc(100% - 24px))}
@media (max-width:600px){.la3d-sheet.plans{left:10px;right:10px;width:auto;top:auto!important;bottom:58px;max-height:60%}}
.la3d-sheet.plans h4 .pl-chip{flex:none}
.la3d-sheet.plans .pl-ban{font-size:11px;line-height:1.45;color:#fde68a;border:1px solid rgba(251,191,36,.45);border-radius:8px;padding:6px 8px;margin:0 0 8px}
.la3d-sheet.plans .pl-chip{display:inline-block;font-size:10px;font-weight:700;letter-spacing:.06em;color:#fbbf24;border:1px solid rgba(251,191,36,.45);border-radius:999px;padding:0 7px;margin-left:6px;vertical-align:middle}
.la3d-sheet.plans .pl-sum{font-size:12px;color:#cbd5e1;line-height:1.5;margin:0 0 8px}
.la3d-sheet.plans h5{font-size:12px;color:#a7f3d0;margin:10px 0 4px}
.la3d-sheet.plans .pl-row{display:flex;gap:10px;align-items:flex-start;padding:8px 0;border-top:1px solid rgba(255,255,255,.08)}
.la3d-sheet.plans .pl-row canvas{flex:none;width:120px;height:84px;border-radius:6px;background:#0b1510;border:1px solid rgba(255,255,255,.1)}
.la3d-sheet.plans .pl-row.pl-lu{display:block}
.la3d-sheet.plans .pl-row.pl-lu canvas{display:block;width:auto;height:auto;max-width:100%;max-height:420px;margin:0 auto 6px;background:#fff}
.la3d-sheet.plans .pl-lu-key{font-size:10px;color:#94a3b8;margin:0 0 4px}
.la3d-sheet.plans .pl-txt{flex:1;min-width:0;font-size:12px;line-height:1.45;color:#e2e8f0}
.la3d-sheet.plans .pl-sub{font-size:11px;color:#94a3b8}
.la3d-sheet.plans .pl-rel{display:inline-block;font-size:10px;font-weight:700;border-radius:999px;padding:0 7px;margin-right:6px;border:1px solid}
.la3d-sheet.plans .pl-rel.new{color:#f59e0b;border-color:rgba(245,158,11,.5)}
.la3d-sheet.plans .pl-rel.correction{color:#60a5fa;border-color:rgba(96,165,250,.5)}
.la3d-sheet.plans .pl-rel.stacked{color:#c4b5fd;border-color:rgba(196,181,253,.5)}
.la3d-sheet.plans .pl-rel.stale{color:#94a3b8;border-color:rgba(148,163,184,.5)}
.la3d-sheet.plans .pl-rel.kept{color:#6ee7b7;border-color:rgba(110,231,183,.5)}
.la3d-sheet.plans .pl-choose{display:flex;flex-wrap:wrap;gap:4px;align-items:center;margin-top:6px;font-size:11px;color:#94a3b8}
.la3d-sheet.plans .pl-choose button{font:inherit;font-size:11px;padding:4px 8px;border-radius:8px;border:1px solid rgba(255,255,255,.18);background:rgba(255,255,255,.06);color:#e2e8f0;cursor:pointer;min-height:28px}
.la3d-sheet.plans .pl-choose button[aria-pressed="true"]{background:#1b4332;border-color:#52b788;color:#d8f3dc}
.la3d-sheet.plans .pl-foot button.go{background:#1b4332;border-color:#52b788;color:#d8f3dc;font-weight:700}
.la3d-sheet.plans .pl-acts button:focus-visible,.la3d-sheet.plans .pl-foot button:focus-visible{outline:2px solid #fbbf24;outline-offset:1px}
.la3d-sheet.plans .pl-acts{display:flex;flex-wrap:wrap;gap:6px;margin-top:6px}
.la3d-sheet.plans .pl-acts button{font:inherit;font-size:11px;padding:6px 10px;border-radius:8px;border:1px solid rgba(255,255,255,.18);background:rgba(255,255,255,.06);color:#e2e8f0;cursor:pointer;min-height:32px}
.la3d-sheet.plans .pl-acts button[disabled]{opacity:.45;cursor:default}
.la3d-sheet.plans .pl-acts button.go{background:#1b4332;border-color:#52b788;color:#d8f3dc;font-weight:700}
.la3d-sheet.plans .pl-acts button.why{border-color:rgba(245,158,11,.5);color:#fde68a}
.la3d-sheet.plans label.pl-tick{display:flex;gap:8px;align-items:flex-start;font-size:12px;color:#e2e8f0;padding:4px 0;cursor:pointer}
.la3d-sheet.plans label.pl-tick input{margin-top:2px}
.la3d-sheet.plans label.pl-tick img{flex:none;width:44px;height:32px;object-fit:cover;border-radius:4px;background:#0b1510;border:1px solid rgba(255,255,255,.1)}
.la3d-sheet.plans .pl-note{font-size:11px;color:#94a3b8;line-height:1.45;margin:6px 0}
.la3d-sheet.plans .pl-bad{color:#fca5a5}
.la3d-sheet.plans .pl-foot{display:flex;flex-wrap:wrap;gap:6px;margin-top:10px;padding-top:8px;border-top:1px solid rgba(255,255,255,.08)}
.la3d-sheet.plans .pl-foot button{font:inherit;font-size:11px;padding:6px 10px;border-radius:8px;border:1px solid rgba(255,255,255,.18);background:rgba(255,255,255,.06);color:#e2e8f0;cursor:pointer;min-height:32px}
.la3d-sheet.plans.pl-flat{position:static;display:block;width:auto;max-height:none;margin:0 0 12px;padding:10px 12px 12px;border-radius:12px;background:rgba(6,14,9,.95);border:1px solid rgba(120,190,155,.26);color:#e2e8f0;font-size:13px}
.la3d-sheet.plans.pl-flat h4{margin:0 0 2px;font-size:14px;font-weight:700;color:#f3f6f4;display:flex;gap:8px;align-items:center}
.la3d-sheet.plans.pl-flat h4 span:not(.pl-chip){flex:1}
.la3d-sheet.plans.pl-flat .la3d-sub{margin:0 0 8px;color:#94a3b8;font-size:12px}
/* The vetting map's card: one card, the item first, everything else folded away. */
.la3d-sheet.plans.map{width:min(330px,calc(100% - 20px));max-height:calc(100% - 96px);padding:10px 12px}
.la3d-sheet.plans.map h4{font-size:13px;margin:0}
.la3d-sheet.plans.map .pl-strip{font-size:11px;line-height:1.35;color:#fde68a;margin:3px 0 8px}
.la3d-sheet.plans.map .pl-q{display:flex;align-items:center;gap:5px;font-size:12px;color:#94a3b8;font-variant-numeric:tabular-nums}
.la3d-sheet.plans.map .pl-q button{all:unset;cursor:pointer;width:26px;height:26px;line-height:24px;text-align:center;border-radius:7px;border:1px solid rgba(255,255,255,.16);color:#e2e8f0;font-size:15px}
.la3d-sheet.plans.map .pl-q button:hover{background:rgba(255,255,255,.08)}
.la3d-sheet.plans.map .pl-q button:focus-visible{outline:2px solid #fbbf24;outline-offset:1px}
.la3d-sheet.plans.map .pl-q .pl-of{white-space:nowrap}
.la3d-sheet.plans.map .pl-title{font-size:14px;font-weight:700;color:#f3f6f4;line-height:1.3}
.la3d-sheet.plans.map .pl-q .pl-title{flex:1;min-width:0}
.la3d:has(.la3d-sheet.plans.map) .la3d-hint{flex:0 1 auto;width:fit-content;padding:2px 7px;border-radius:6px;background:rgba(6,14,9,.82);text-shadow:none}
.la3d-sheet.plans.map .pl-sub2{font-size:12px;color:#94a3b8;line-height:1.4;margin-top:1px}
.la3d-sheet.plans.map .pl-cue{font-size:12px;color:#fde68a;line-height:1.4;margin-top:6px}
.la3d-sheet.plans.map .pl-say{font-size:12px;color:#e2e8f0;line-height:1.4;margin-top:6px}
.la3d-sheet.plans.map .pl-say b{color:#fff}
.la3d-sheet.plans.map .pl-rec{font-size:11px;color:#a7f3d0;margin-top:6px}
.la3d-sheet.plans.map .pl-v{display:grid;grid-template-columns:repeat(3,1fr);gap:5px;margin-top:8px}
.la3d-sheet.plans.map .pl-v button{font:inherit;font-size:12px;font-weight:600;min-height:34px;padding:4px 4px;border-radius:8px;border:1px solid rgba(255,255,255,.18);background:rgba(255,255,255,.06);color:#e2e8f0;cursor:pointer;white-space:normal;line-height:1.15}
.la3d-sheet.plans.map .pl-v button:hover:not([disabled]){background:rgba(255,255,255,.12)}
.la3d-sheet.plans.map .pl-v button[disabled]{opacity:.35;cursor:default}
.la3d-sheet.plans.map .pl-v button:focus-visible{outline:2px solid #fbbf24;outline-offset:1px}
.la3d-sheet.plans.map .pl-v button.new{background:#1b4332;border-color:#52b788;color:#d8f3dc}
.la3d-sheet.plans.map .pl-v button.cor{background:#172c4d;border-color:#60a5fa;color:#dbeafe}
.la3d-sheet.plans.map .pl-v button.bad{border-color:rgba(148,163,184,.6);color:#cbd5e1}
.la3d-sheet.plans.map .pl-v.four{grid-template-columns:repeat(4,1fr);margin-top:5px}
.la3d-sheet.plans.map .pl-v button.wide{grid-column:span 3}
.la3d-sheet.plans.map .pl-v kbd{font:inherit;font-size:10px;opacity:.6;margin-left:4px;font-weight:400}
.la3d-sheet.plans.map .pl-ctl{display:flex;align-items:center;gap:8px;margin-top:8px;font-size:11px;color:#94a3b8}
.la3d-sheet.plans.map .pl-ctl input[type=range]{flex:1;min-width:0}
.la3d-sheet.plans.map .pl-mini{font:inherit;font-size:11px;padding:3px 9px;min-height:26px;border-radius:999px;border:1px solid rgba(255,255,255,.18);background:rgba(255,255,255,.05);color:#cbd5e1;cursor:pointer;white-space:nowrap}
.la3d-sheet.plans.map .pl-mini[aria-pressed="true"]{background:#1b4332;border-color:#52b788;color:#d8f3dc}
.la3d-sheet.plans.map .pl-mini:focus-visible{outline:2px solid #fbbf24;outline-offset:1px}
.la3d-sheet.plans.map .pl-plans{display:flex;flex-wrap:wrap;gap:4px;margin-top:5px}
.la3d-sheet.plans.map .pl-keep{width:100%;font:inherit;font-size:12px;font-weight:700;min-height:36px;margin-top:9px;padding:6px 8px;border-radius:8px;border:1px solid #52b788;background:#52b788;color:#06210f;cursor:pointer}
.la3d-sheet.plans.map .pl-keep[disabled]{opacity:.5;cursor:default}
.la3d-sheet.plans.map .pl-more{display:flex;flex-wrap:wrap;gap:4px;margin-top:6px}
.la3d-sheet.plans.map .pl-sep{border-top:1px solid rgba(255,255,255,.08);margin-top:9px;padding-top:7px}
.la3d-sheet.plans.map .pl-miss{margin:6px 0 0;padding:0;list-style:none;font-size:12px;line-height:1.4;color:#e2e8f0}
.la3d-sheet.plans.map .pl-miss li{padding:2px 0}
@media (max-width:600px){
  .la3d-sheet.plans.map{left:0;right:0;bottom:52px;width:auto;max-height:44%;border-radius:14px;padding:8px 10px}
  .la3d-sheet.plans.map .pl-strip{margin:1px 0 4px}
  .la3d-sheet.plans.map .pl-cue,.la3d-sheet.plans.map .pl-say{margin-top:3px}
  .la3d-sheet.plans.map .pl-v{margin-top:6px}
  .la3d-sheet.plans.map .pl-v button{min-height:44px}
  .la3d-sheet.plans.map .pl-v kbd{display:none}
  .la3d-sheet.plans.map .pl-q button{width:40px;height:36px;line-height:34px}
  .la3d-sheet.plans.map .pl-mini{min-height:36px}
  .la3d-sheet.plans.map .pl-keep{min-height:44px}
  /* The map needs the room: on a phone the other tools stand aside (Done is in the bar). */
  .la3d:has(.la3d-sheet.plans.map) .la3d-toolseg{display:none!important}
}
.pl-pins{position:absolute;inset:0;z-index:3;pointer-events:none;overflow:hidden}
.pl-pin{position:absolute;left:0;top:0;display:flex;align-items:center;justify-content:center;gap:3px;box-sizing:border-box;height:28px;min-width:40px;padding:0 7px;margin:0;
  pointer-events:auto;touch-action:none;cursor:pointer;border-radius:999px;border:2px solid #fff;font:700 12px/1 system-ui,sans-serif;font-variant-numeric:tabular-nums;color:#241703;background:#f59e0b;box-shadow:0 1px 5px rgba(0,0,0,.6)}
.pl-pin svg{width:13px;height:13px;flex:none}
.pl-pin[data-state="new"],.pl-pin[data-state="kept_new"]{background:#52b788;color:#06210f}
.pl-pin[data-state="correction"],.pl-pin[data-state="kept_correction"]{background:#60a5fa;color:#071a33}
.pl-pin[data-state="failure"],.pl-pin[data-state="unmatched"]{background:#64748b;color:#f1f5f9;border-color:#cbd5e1}
.pl-pin[data-state="later"]{background:rgba(6,14,9,.88);color:#fde68a;border-color:#f59e0b}
.pl-pin[data-state="right"]{background:rgba(6,14,9,.88);color:#a7f3d0;border-color:#52b788}
.pl-pin[data-state="stale"]{background:repeating-linear-gradient(45deg,#64748b 0 5px,#334155 5px 10px);color:#f8fafc;border-color:#cbd5e1}
.pl-pin.cur{box-shadow:0 0 0 3px #06210f,0 0 0 5px #fff,0 2px 8px rgba(0,0,0,.6);z-index:2}
.pl-pin.moving{cursor:grab}
.pl-pin:focus-visible{outline:3px solid #fbbf24;outline-offset:3px}
.pl-pins.touch .pl-pin{height:44px;min-width:44px;font-size:14px;padding:0 9px}
.pl-pins.touch .pl-pin svg{width:15px;height:15px}
.pl-tag{position:absolute;left:0;top:0;padding:2px 8px;border-radius:999px;background:rgba(6,14,9,.92);border:1px solid rgba(245,158,11,.6);color:#fde68a;font:600 11px/1.4 system-ui,sans-serif;white-space:nowrap;pointer-events:none}
`;
const BANNER = "Experimental. On a small local AI about 2 in 10 stair suggestions are wrong and 2-3 in 10 real stairs are missed; railings about half; "
  + "lights only where the plan draws them. Doors and windows aren't offered: the local model got them mostly wrong.";
const CUE = { stairs: "Check which way is up and the shape.", railing: "The AI can't tell the side for sure: look at the plan.", light: "A wrong kind only changes the drawing." };
const STRIP = { stairs: "About 2 in 10 stairs are wrong, 2-3 in 10 are missed.", railing: "Railings: about half are wrong.", light: "About 3 in 10 lights are wrong, 4 in 10 are missed; handwritten marks far more." };
const SYMBOL_WORD = { pot: "a pot light", pendant: "a pendant", sconce: "a wall light" };
// What a kind is called (live_aboard_house.js LIGHT_KINDS, as the Heights tool says it).
const KIND_WORD = { glow: "just its light", fixture: "a ceiling light", pot: "pot lights", pot_ring: "pot lights round the room", pendant: "a pendant", chandelier: "a chandelier",
  sconce: "a wall light", vanity: "a vanity light", strip: "an LED strip", valance: "a valance", spot: "a spot", track: "track lights", tube: "a tube", fan: "a fan" };
const kindWord = (k) => KIND_WORD[k] || (k ? String(k).replace(/_/g, " ") : KIND_WORD.glow);
const SVG = (d) => `<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${d}</svg>`;
// Each kind: its word and its pin's glyph.
const KIND_OF = { stairs: { word: "Stairs", glyph: SVG('<path d="M2 14h3v-4h3V6h3V2h3"/>') },
  railing: { word: "Railing hint", glyph: SVG('<path d="M2 4h12M4 4v9M8 4v9M12 4v9"/>') },
  light: { word: "Light", glyph: SVG('<circle cx="8" cy="8" r="5"/><path d="M4.5 4.5l7 7M11.5 4.5l-7 7"/>') } };
const GHOST = 0.45, DASH_COL = "#f59e0b", RECAP_EVERY = 25, TEX_MAX = 1024, PLAN_OPACITY = 0.7, SPOT_M = 14, MIN_PX_M = 34;
/** The signed picture links last 24 hours (map_image_view.py SIGN_TTL): asked for again well before that. */
const LINK_MS = 20 * 3600 * 1000;
const WHY = [["wrong_place", "Wrong place"], ["nothing_there", "Nothing there"], ["already_here", "Already here"], ["wrong_kind", "Wrong kind"], ["cant_tell", "Can't tell"]];
const WHY_WORD = Object.fromEntries(WHY);
const POLL_MS = 3000;
const PIECE_LABEL = "Stairs (from the plan)";
const RAIL_STYLES = [["balustrade", "Balustrade"], ["topless", "Topless"], ["single_bar", "Single bar"]];
const OPEN = new Set(["queued", "later", "right", "stale"]);
const CANCEL_WORDS = { user: "cancelled", switch_off: "stopped: the switch was turned off", house3d_off: "stopped: Live Aboard was turned off",
  licence: "stopped: the licence lapsed", plan_gone: "stopped: a plan was removed", plan_changed: "stopped: a plan was moved or replaced", restart: "" };
// Why reads failed (the session's `errors`), and so why a session read nothing at all (its `error`).
const NO_READ = { no_media: "Home Assistant's media folder couldn't take the plans for the AI", no_picture: "the plans' pictures wouldn't open",
  unreachable: "the AI couldn't be reached (is the computer it runs on switched on?)", timeout: "the AI didn't answer in time", bad_answer: "the AI gave no answer that could be used" };
/** A shared AI box: the session's budget (plan_ai.PLAN_BUDGET_S) is how long reads can hold it. */
const sharedNote = (withBackup) => `Reading can keep ${withBackup ? "this AI or the backup" : "this AI"} busy for up to 8 minutes: if ${withBackup ? "either" : "it"} also answers your voice assistant, voice may be slow until it ends.`;

const num = (v) => (typeof v === "number" && Number.isFinite(v) ? v : null);
const m1 = (v) => (num(v) === null ? "?" : (Math.round(v * 10) / 10).toFixed(1));
const mins = (s) => { s = Math.max(0, Math.round(num(s) || 0)); return s >= 60 ? `${Math.floor(s / 60)} m ${s % 60} s` : `${s} s`; };

// ── the vetting map's rules, pure (tests/js/plans_map.mjs runs them) ─────────
/** What a suggestion's pin says, from the store's state and what the draft holds
 *  for it (design 4.1). null: no pin (a duplicate, a stair's settled hint, one
 *  undone, one ignored before): the list and the what's-missing pass have those. */
export function pinState(sug, pend = null){
  if (pend) return pend.v === "correction" ? "correction" : "new";
  switch (sug && sug.state) {
    case "queued": case "later": case "right": case "stale": case "unmatched": return sug.state;
    case "failure": return sug.verdict && sug.verdict.remembered ? null : "failure";
    case "committed_new": return "kept_new";
    case "committed_correction": return "kept_correction";
    default: return null;
  }
}
/** Still waiting for a person? */
export const isOpen = (state) => state === "queued" || state === "stale";
/** A staircase's hints straight after it, floors bottom up, then room by room as
 *  the plan reads, top left first. The number on a pin is its place here, so it
 *  never changes under a person. roomRank: a number, smaller first. */
export function orderItems(items, floorRank, roomRank){
  const byId = new Map(items.map(s => [s.id, s]));
  const key = (s) => {
    const home = (s.of_stair && byId.get(s.of_stair)) || s, g = home.geom || {};
    return [floorRank(home), roomRank(home), num(g.y_m) ?? 0, num(g.x_m) ?? 0, home.id, s === home ? 0 : 1, s.id];
  };
  const keyed = items.map(s => [key(s), s]);
  keyed.sort((a, b) => { for (let i = 0; i < a[0].length; i++) { if (a[0][i] < b[0][i]) return -1; if (a[0][i] > b[0][i]) return 1; } return 0; });
  return keyed.map(k => k[1]);
}
/** The next item to look at after `fromId`: anything still open, from there on,
 *  round to the start; then what was put off, only those after it, so a pass
 *  through Later ends. null: nothing left. */
export function nextOpen(order, fromId, stateOf){
  const at = order.findIndex(s => s.id === fromId), n = order.length;
  for (let i = 1; i <= n; i++) { const s = order[(Math.max(at, 0) + i) % n]; if (s && s.id !== fromId && isOpen(stateOf(s))) return s; }
  for (let i = Math.max(at, -1) + 1; i < n; i++) { const s = order[i]; if (s.id !== fromId && stateOf(s) === "later") return s; }
  return null;
}
/** Dashes along a line through `pts` (closed: back to the first), as triangles on
 *  a level plane: real width, because a WebGL line is one pixel on any screen. */
export function dashTriangles(pts, closed, dash = 0.24, gap = 0.16, w = 0.055){
  const out = [], list = closed ? [...pts, pts[0]] : pts;
  for (let i = 0; i + 1 < list.length; i++) {
    const [ax, ay] = list[i], [bx, by] = list[i + 1], L = Math.hypot(bx - ax, by - ay);
    if (L < 1e-3) continue;
    const ux = (bx - ax) / L, uy = (by - ay) / L, nx = -uy * w / 2, ny = ux * w / 2;
    for (let t = 0; t < L; t += dash + gap) {
      const e = Math.min(L, t + dash), x0 = ax + ux * t, y0 = ay + uy * t, x1 = ax + ux * e, y1 = ay + uy * e;
      out.push(x0 + nx, 0, y0 + ny, x1 + nx, 0, y1 + ny, x1 - nx, 0, y1 - ny, x0 + nx, 0, y0 + ny, x1 - nx, 0, y1 - ny, x0 - nx, 0, y0 - ny);
    }
  }
  return new Float32Array(out);
}
/** Pins on screen ([x, y] px, in their order) moved just far enough apart to press
 *  each (a stair and its hint share a spot): a later one to the nearest free place
 *  round where it belongs, never further than it has to go. */
export function spreadPins(pts, gap){
  const out = [], clear = (x, y) => !out.some(q => q && Math.hypot(q[0] - x, q[1] - y) < gap);
  for (const p of pts) {
    if (!p) { out.push(null); continue; }
    let at = clear(p[0], p[1]) ? p : null;
    for (let r = 1; !at && r <= 3; r++) for (let a = 0; !at && a < 8; a++) {
      const x = p[0] + Math.cos(a * Math.PI / 4) * gap * r, y = p[1] + Math.sin(a * Math.PI / 4) * gap * r;
      if (clear(x, y)) at = [x, y];
    }
    out.push(at || p);
  }
  return out;
}
/** A picture's size, the longer side at most `max`, never enlarged. */
export function fitSize(w, h, max = TEX_MAX){
  const k = Math.min(1, max / Math.max(1, w, h));
  return [Math.max(1, Math.round(w * k)), Math.max(1, Math.round(h * k))];
}
/** "1.4 m east": a move in plan metres, in compass words. compass: {north, east}, unit plan vectors. */
export function moveWords(dx, dy, compass){
  const L = Math.hypot(dx, dy);
  if (!compass || L < 0.05) return `${m1(L)} m`;
  const n = dx * compass.north[0] + dy * compass.north[1], e = dx * compass.east[0] + dy * compass.east[1];
  const i = Math.round(((Math.atan2(e, n) * 180 / Math.PI) + 360) % 360 / 45) % 8;
  return `${m1(L)} m ${["north", "north-east", "east", "south-east", "south", "south-west", "west", "north-west"][i]}`;
}
/** The tally a recap says, from each item's pin state. */
export function tally(states){
  const t = { new: 0, correction: 0, failure: 0, later: 0, right: 0, open: 0 };
  for (const s of states) {
    if (s === "new" || s === "kept_new") t.new++;
    else if (s === "correction" || s === "kept_correction") t.correction++;
    else if (s === "failure" || s === "later" || s === "right") t[s]++;
    else if (isOpen(s)) t.open++;
  }
  return t;
}
// Rooms from plans' outline list, shared with the rooms helper (ai_wizard.js).
const { roomShapes } = await import(`./plan_room_shapes.js${new URL(import.meta.url).search}`);

export const inPolygon = (x, y, pts) => {
  let c = false;
  for (let i = 0, j = pts.length - 1; i < pts.length; j = i++) {
    const [xi, yi] = pts[i], [xj, yj] = pts[j];
    if ((yi > y) !== (yj > y) && x < (xj - xi) * (y - yi) / (yj - yi) + xi) c = !c;
  }
  return c;
};
/** The what's-missing pass for one floor: what the queue can't show, the gaps
 *  (plans: {map_id, name, floor_id, answered}; stairs: the draft's on this floor, {id, label, room, x, y}). */
export function missingLines(fid, sugList, plans, stairs, same = (a, b) => String(a) === String(b)){
  const out = [], mine = plans.filter(p => same(p.floor_id, fid) && p.answered);
  const onPlan = (mid) => sugList.filter(s => s.kind === "stairs" && (s.map_id === mid || (s.seen_on || []).some(o => o.map_id === mid)));
  for (const p of mine) if (!onPlan(p.map_id).length) out.push(`The AI found no stairs on the ${p.name || "this"} plan.`);
  for (const st of stairs) for (const p of mine) {
    const seen = onPlan(p.map_id).some((s) => {
      const m = s.match || {}, g = s.geom || {};
      return m.target === st.id || (m.near || []).includes(st.id) || (num(g.x_m) !== null && Math.hypot(g.x_m - st.x, g.y_m - st.y) <= 2.5);
    });
    if (onPlan(p.map_id).length && !seen) out.push(`Your 3D stair${st.room ? ` in ${st.room}` : st.label ? `, ${st.label},` : ""} wasn't seen on ${p.name || "this plan"}.`);
  }
  const here = sugList.filter(s => same(s.floor_id, fid));
  const unmatched = here.filter(s => s.state === "unmatched").length;
  if (unmatched) out.push(`${unmatched} fixture symbol${unmatched === 1 ? "" : "s"} had no placed light (Mapping → Atlas builder).`);
  const ignored = here.filter(s => s.state === "failure" && s.verdict && s.verdict.remembered).length;
  if (ignored) out.push(`${ignored} ignored before.`);
  return out;
}

/** Which AI reads the plans, in the photo step's own words (its aiNote) with "plan" for "photo". */
function planNote(ai, n){
  const name = (ai && ai.name) || "The AI Task";
  const [them, stay, leave, it_] = n === 1 ? ["the plan", "stays", "leaves", "it"] : ["the plans", "stay", "leave", "them"];
  const whereOf = (local, it = "it") => (local === true ? `${it[0].toUpperCase()}${it.slice(1)} runs in your home, so ${them} ${stay} in the house.`
    : local === false ? `${it[0].toUpperCase()}${it.slice(1)} runs in the cloud: ${them} ${leave} the house for that service.`
    : `If ${it} runs in the cloud, ${them} ${leave} the house for that service.`);
  const bk = ai && ai.backup ? (ai.backup_name || ai.backup) : null;
  if (!bk && ai && ai.main_away) return `${name} is away right now, so nothing can read ${them}. Start it, or set a backup in Settings → AI, then open this again.`;
  if (bk && ai.main_away) return `The main AI Task is away, so the backup, ${bk}, will read ${them}. ${whereOf(ai.backup_local)} PadSpan keeps no copy.`;
  const also = bk ? ` If it's away, the backup, ${bk}, reads ${it_} instead. ${whereOf(ai.backup_local, "that one")}` : "";
  return `${name} will read ${them}. ${whereOf(ai && ai.local)}${also} PadSpan keeps no copy.`;
}

/**
 * ctx = { root, sheet, guard, host() → {callWS, settings} | null, floors() → [{fl: {id, name, outdoor}}],
 *         hint(text, bad), redraw() (the editor's paint and sheet again),
 *         DRAFT (live_aboard_draft.js), draft() → the editor's draft, change(fn) → one undo step, save() (the editor's Save),
 *         saving(), stairPiece(geom, floor id, label) → a draft piece, fileWritten(data) (an undo wrote the file),
 *         reloadFile() (read the 3D file again: someone else wrote it) }
 */
export function createPlans(ctx){
  const { sheet, guard } = ctx;
  // The tool's walls the server never sees (telemetry.PLANS_TOOL_EVENTS), through the host's telemetry;
  // `once`: one count per opening of the tool, however often the sheet repaints.
  const wallsSeen = new Set();
  const count = (ev, once = false) => {
    if (once) { if (wallsSeen.has(ev)) return; wallsSeen.add(ev); }
    const h = ctx.host();
    if (h && typeof h.telemetry === "function") { try { h.telemetry(ev); } catch (_) { /* a count, never in the way */ } }
  };
  let shownNow = false, step = "idle", info = null, sess = null, poll = null, busy = false, err = "", view = "list";
  let urls = null, urlsAt = 0, urlsAsked = false, ignored = null, failing = null, cancelNote = "", runningId = null, undoInfo = null, askUndo = false, focusBtn = null;
  let record = null;                 // this house's own record, per kind (the server's: plan_ai.track_record)
  const stackFloor = new Map();      // a stacked item's floor, as picked
  const railPick = new Map();        // a railing hint's side and style, as picked
  const picked = new Set();
  const kinds = { stairs: true, railing: true, light: false };
  const fixtures = new Map();        // map id → does it draw light fixtures: yes, no, unsure (the person's answer; lights read only on yes)
  const style = document.createElement("style");
  style.textContent = CSS;
  ctx.root.appendChild(style);

  const redraw = () => { const y = sheet.scrollTop; ctx.redraw(); sheet.scrollTop = y; };   // a verdict never jumps the list to its top
  const d = (tag, cls, text) => { const n = document.createElement(tag); if (cls) n.className = cls; if (text !== undefined) n.textContent = text; return n; };
  const btn = (text, title, act, cls) => {
    const b = d("button", cls, text);
    b.type = "button"; b.title = title || "";
    b.addEventListener("click", guard((e) => { e.stopPropagation(); act(); }));
    return b;
  };
  const call = (type, extra) => {
    const h = ctx.host();
    if (!h || typeof h.callWS !== "function") return Promise.reject(new Error("The Plans tool has no connection."));
    return h.callWS({ type: `padspan_ha/${type}`, ...(extra || {}) });
  };
  const fail = (e) => { err = String((e && (e.message || e.code)) || e || "failed"); busy = false; redraw(); };
  const floorName = (fid) => { const G = (ctx.floors() || []).find(g => g && g.fl && String(g.fl.id) === String(fid)); return G ? (G.fl.name || String(fid)) : String(fid); };
  const outdoor = (fid) => { const s = String(fid).toLowerCase(); if (s === "__outside__" || s === "outside") return true;   // the server leaves these out too (plan_ai.plans)
    const G = (ctx.floors() || []).find(g => g && g.fl && String(g.fl.id) === String(fid)); return !!(G && G.fl.outdoor); };
  const planName = (mid) => { const p = ((info && info.plans) || []).find(x => x.map_id === mid) || ((sess && sess.plans) || []).find(x => x.map_id === mid); return p ? (p.name || "a plan") : "a plan"; };
  const sugs = () => Object.values((sess && sess.suggestions) || {});
  const movedPlan = (mid) => !!((sess && sess.plans) || []).find(x => x.map_id === mid && x.changed);
  const unread = () => ((sess && sess.plans) || []).filter(p => p.read && !p.answered).length;   // its whole read was tried, and no answer came of it
  // What is pending is the draft's: read off it each time, never kept here.
  const pendings = () => { const dr = ctx.draft && ctx.draft(); return dr && ctx.DRAFT ? ctx.DRAFT.planPending(dr.cur) : []; };
  const pendingOf = (id) => pendings().find(p => p.sug_id === id) || null;
  const dirty = () => { const dr = ctx.draft && ctx.draft(); return !!(dr && dr.dirty); };
  const take = (r) => { if (r && r.session) sess = r.session; if (r && "undo" in r) undoInfo = r.undo; if (r && r.record) record = r.record; };

  // ── opening: what is there to read, and what the last session left ───────
  async function open(){
    busy = true; err = ""; step = "loading"; redraw();
    try {
      info = await call("plan_ai_plans");
      if (!info || !Array.isArray(info.plans)) { info = null; step = "sample"; busy = false; redraw(); return; }
      picked.clear();
      for (const p of info.plans) if (!outdoor(p.floor_id)) picked.add(p.map_id);
      loadUrls();
      if (info.running) { sess = null; step = "progress"; startPoll(info.running); }
      else if (info.latest) {
        const r = await call("plan_ai_status", { session: info.latest });
        sess = r && r.session ? r.session : null;
        undoInfo = r ? r.undo || null : null;
        record = r && r.record ? r.record : null;
        settle();
        // What the last session left, or how it ended ("Home Assistant restarted during the read; run it again").
        step = sess && (Object.keys(sess.suggestions || {}).length || sess.status !== "done") ? "list" : "consent";
      } else step = "consent";
    } catch (e) { step = "consent"; err = String((e && e.message) || e); }
    busy = false;
    redraw();
  }
  function loadUrls(){
    if ((urls && Date.now() - urlsAt < LINK_MS) || urlsAsked) return;
    urlsAsked = true;
    call("maps_image_urls").then((r) => { urls = (r && r.image_urls) || {}; urlsAt = Date.now(); urlsAsked = false; redraw(); }).catch(() => { urls = {}; urlsAt = Date.now(); urlsAsked = false; });
  }

  /** Back to the plans and the button, with what the server says now (a start may be allowed again). */
  async function readAgain(){
    if (pendings().length) { ctx.hint("Save or take back the items you kept first: a new read starts a new list.", true); return; }
    step = "consent"; err = ""; redraw();
    try { const r = await call("plan_ai_plans"); if (r && Array.isArray(r.plans)) info = r; } catch (e) { err = String((e && e.message) || e); }
    redraw();
  }

  // ── the job: start, poll, cancel ──────────────────────────────────────────
  async function start(){
    if (busy) return;
    const ids = [...picked];
    if (!ids.length) { err = "Tick at least one plan."; redraw(); return; }
    busy = true; err = ""; redraw();
    try {
      const want = ["stairs"].concat(kinds.railing ? ["railing"] : [], kinds.light ? ["light"] : []);
      const r = await call("plan_ai_start", { map_ids: ids, kinds: want, ...(kinds.light ? { fixtures: Object.fromEntries(ids.map(id => [id, fixtures.get(id) || "unsure"])) } : null) });
      sess = null; cancelNote = ""; step = "progress"; busy = false;
      startPoll(r.session);
    } catch (e) { fail(e); }
    redraw();
  }
  function startPoll(sid){
    stopPoll();
    runningId = sid;
    const tick = guard(async () => {
      try {
        const r = await call("plan_ai_status", { session: sid });
        sess = r && r.session ? r.session : sess;
        if (r && "undo" in r) undoInfo = r.undo;
        if (r && r.record) record = r.record;
        if (sess && sess.status !== "running") { stopPoll(); step = "list"; loadUrls(); }
      } catch (e) { err = String((e && e.message) || e); stopPoll(); step = "consent"; }
      redraw();
    });
    poll = setInterval(tick, POLL_MS);
    tick();
  }
  function stopPoll(){ if (poll) { clearInterval(poll); poll = null; } }
  async function cancel(){
    if (!runningId) return;
    try { const r = await call("plan_ai_cancel", { session: runningId }); cancelNote = (r && r.message) || ""; }
    catch (e) { cancelNote = String((e && e.message) || e); }
    redraw();
  }

  // ── verdicts: failure, later, take that back; written at once ────────────
  async function verdict(sug, v, why){
    if (busy || !sess) return false;
    busy = true; err = ""; redraw();
    let ok = false;
    try {
      const r = await call("plan_ai_verdict", { session: sess.id, rev: sess.rev, sug_id: sug.id, v, ...(why ? { why } : {}) });
      sess.rev = r.rev; sess.suggestions[sug.id] = r.suggestion; failing = null;
      if (r.record) record = r.record;
      for (const h of r.changed || []) sess.suggestions[h.id] = h;     // a stair's railing hint goes and comes back with it
      ctx.hint(v === "failure" ? (why === "already_here" ? "Noted: yours stays where it is." : (r.changed || []).length ? "Noted. Its railing hint goes with it." : "Noted.") : v === "later" ? "Later, then."
        : v === "right" ? "Noted: it looks right. Nothing is written to your house." : "Taken back.");
      ok = true;
    } catch (e) {
      if (e && e.code === "rev_mismatch") { ctx.hint("That list had changed: here it is again."); await reload(); }
      else err = String((e && e.message) || e);
    }
    busy = false;
    settle();
    redraw();
    return ok;
  }
  async function reload(){
    if (!sess) return;
    try { take(await call("plan_ai_status", { session: sess.id })); } catch (_) { /* kept */ }
  }

  // ── New and Correction: the editor's draft, one undo step each ───────────
  const NOTE = () => ctx.DRAFT.PLAN_NOTE;
  /** A note added to the piece's entry for this suggestion (a piece can hold a stair's and its railing's). */
  const noted = (q, sugId, e) => { const n = q[NOTE()] || { session: sess.id, sugs: {} }; n.sugs[sugId] = e; q[NOTE()] = n; };
  function keepNew(sug){
    if (!ctx.change || !sess) return;
    if (sug.state === "stale" && movedPlan(sug.map_id)) { ctx.hint("The plan moved: read it again.", true); return; }
    const fid = stackFloor.get(sug.id) || sug.floor_id;
    const piece = ctx.stairPiece(sug.geom || {}, fid, PIECE_LABEL);
    if (!piece) { ctx.hint("The furniture builders aren't loaded yet: try again in a moment.", true); return; }
    noted(piece, sug.id, { v: "new", made: true });
    if (ctx.change((c) => { c.pieces[piece.id] = piece; })) ctx.hint("In your draft: nothing is kept until Save. Undo takes it back.");
    redraw();
  }
  function takeAi(sug, target = null){
    const m = sug.match || {}, tid = target || m.target, g = sug.geom || {};
    const ok = ctx.change((c) => {
      const q = c.pieces[tid];
      if (!q) return;
      noted(q, sug.id, { v: "correction", was: { x_m: q.x_m, y_m: q.y_m }, ...(target ? { target } : null) });
      q.x_m = g.x_m; q.y_m = g.y_m;
    });
    if (ok) ctx.hint(`Moved in your draft, ${m1(m.distance_m)} m: nothing is kept until Save. Undo takes it back.`);
    else ctx.hint("That stair isn't in your draft any more: it was removed.", true);
    redraw();
  }
  /** A light's kind, in the draft: never its place. One kind on a light: a second symbol's replaces the first's. */
  function keepLight(sug){
    const m = sug.match || {}, eid = m.target, kind = m.want_kind;
    if (!ctx.change || !sess || !eid || !kind) return;
    const others = new Set(pendings().filter(p => p.light && p.piece === eid && p.sug_id !== sug.id).map(p => p.sug_id));
    const ok = ctx.change((c) => {
      if (others.size) ctx.DRAFT.dropPlanPending(c, others);
      const lights = c.lights || (c.lights = {}), q = lights[eid] || (lights[eid] = {});
      noted(q, sug.id, { v: "correction", was: { kind: q.kind ?? null } });
      q.kind = kind;
    });
    if (ok) ctx.hint("Its kind is in your draft: nothing is kept until Save. Undo takes it back.");
    redraw();
  }
  /** Mapping → Atlas builder on the room a symbol with no placed light is in. */
  function openAtlas(sug){
    const h = ctx.host();
    if (h && typeof h.openAtlasRoom === "function") h.openAtlasRoom(sug.floor_id, roomOf(sug));
  }
  const canOpenAtlas = () => { const h = ctx.host(); return !!(h && typeof h.openAtlasRoom === "function"); };
  function takeBack(sug){
    if (ctx.change((c) => { ctx.DRAFT.dropPlanPending(c, new Set([sug.id])); })) ctx.hint("Taken back. Nothing was kept.");
    redraw();
  }
  /** The piece a railing hint goes on: the stair in the house, or its stair if it is kept or about to be. */
  function railHome(hint){
    const m = hint.match || {};
    if (m.target) return m.target;
    const stair = (sess.suggestions || {})[(hint.geom || {}).stair];
    if (!stair) return null;
    if (String(stair.state).startsWith("committed")) return stair.piece_id;
    const pend = pendingOf(stair.id);
    return pend ? pend.piece : null;
  }
  const flat = (params) => ((params && params.shape) || "straight") === "straight";
  function railSides(params){
    return flat(params) ? [["both", "Both"], ["inner", "Left"], ["outer", "Right"]] : [["both", "Both"], ["inner", "Inside"], ["outer", "Outside"]];
  }
  function keepRail(hint){
    const home = railHome(hint), pick = railPick.get(hint.id) || {};
    if (!home || !pick.side) return;
    const v = (hint.match || {}).relation === "correction" ? "correction" : "new", style = pick.style || "balustrade";
    const ok = ctx.change((c) => {
      const q = c.pieces[home];
      if (!q || !q.recipe) return;
      const params = q.recipe.params = { ...(q.recipe.params || {}) };
      noted(q, hint.id, { v, rail: { side: pick.side, style }, was_params: { rail: params.rail ?? null, rail_style: params.rail_style ?? null } });
      params.rail = pick.side; params.rail_style = style;
    });
    if (ok) ctx.hint("The railing is in your draft: nothing is kept until Save. Undo takes it back.");
    else ctx.hint("That stair isn't in your draft any more.", true);
    redraw();
  }
  /** Anything pending whose suggestion can't be kept any more (kept by someone
   *  else, marked wrong, gone) leaves the draft; in the file it is already. */
  function settle(extra = null){
    const dr = ctx.draft && ctx.draft();
    if (!dr || !ctx.DRAFT || !sess) return;
    const drop = new Set(extra || []);
    for (const p of pendings()) {
      if (p.session !== sess.id) continue;
      const s = (sess.suggestions || {})[p.sug_id];
      if (!s || !OPEN.has(s.state) || (s.state === "stale" && (p.v !== "new" || !p.made || movedPlan(s.map_id)))) drop.add(p.sug_id);
    }
    if (drop.size && !(ctx.saving && ctx.saving())) ctx.change((c) => { ctx.DRAFT.dropPlanPending(c, drop); });
  }

  // ── Save: what the draft holds goes to the one writer ─────────────────────
  /** Called by the editor's Save. {data, pieces, renamed, said}, or a refusal
   *  thrown (err.planRefusal): nothing was written and the draft stays. */
  async function commit(){
    const all = pendings();
    const sid = all.length ? all[0].session : null;
    if (!sid) return null;
    if (!sess || sess.id !== sid) { take(await call("plan_ai_status", { session: sid })); }
    if (!sess || sess.id !== sid) return null;
    const dr = ctx.draft(), mine = all.filter(p => p.session === sid), renamed = {}, keys = new Set();
    const items = mine.map((p) => {
      keys.add(p.piece);
      const sug = (sess.suggestions || {})[p.sug_id] || {};
      if (p.light) return { sug_id: p.sug_id, v: "correction" };                                  // its kind is the symbol the AI read
      if (sug.kind === "railing") return { sug_id: p.sug_id, v: p.v, rail: p.rail };
      const q = dr.cur.pieces[p.piece], final = p.made ? ctx.DRAFT.planFinal(q) : { x_m: q.x_m, y_m: q.y_m };   // a correction: where it stands, nothing else
      return { sug_id: p.sug_id, v: p.v, final, ...(p.target ? { target: p.target } : null) };
    });
    let r;
    try {
      r = await call("plan_ai_commit", { session: sid, rev: sess.rev, items });
    } catch (e) {
      throw Object.assign(new Error(String((e && e.message) || e)), { code: e && e.code, planRefusal: true });
    }
    if (r && r.ok === false) throw Object.assign(new Error(r.message || r.code), { code: r.code, planRefusal: true, changed: r.changed, items: r.items });
    sess.rev = r.rev;
    for (const [id, s] of Object.entries(r.suggestions || {})) sess.suggestions[id] = s;
    undoInfo = r.undo || undoInfo;
    const ids = r.piece_ids || {}, f = ctx.DRAFT.ownedOf(r.data), pieces = {}, lights = {};
    for (const p of mine) {
      const pid = ids[p.sug_id];
      if (!pid) continue;
      if (p.light) { if (f.lights[pid]) lights[pid] = f.lights[pid]; continue; }
      if (p.made) renamed[p.piece] = pid;
      if (f.pieces[pid]) pieces[pid] = f.pieces[pid];
    }
    const nNew = mine.filter(p => p.v === "new" && p.made).length, nCorr = mine.filter(p => p.v === "correction").length, nRail = mine.filter(p => p.rail).length;
    const said = `Kept ${[nNew ? `${nNew} new` : "", nCorr ? `${nCorr} correction${nCorr === 1 ? "" : "s"}` : "", nRail ? `${nRail} railing${nRail === 1 ? "" : "s"}` : ""].filter(Boolean).join(", ")} from the plans. Undo this session takes them back.`;
    return { data: r.data, pieces, lights, renamed, said };
  }
  /** Refused: nothing was written. The list as it is now; what changed leaves the draft. */
  async function refused(e){
    await reload();
    const gone = new Set((e.changed || []).map(c => c.sug_id));
    for (const id of e.items || []) gone.add(id);
    if (e.code === "not_found") for (const p of pendings()) gone.add(p.sug_id);
    settle(gone);
    if (e.code === "changed_since") e.message = "Some items changed since you looked. Nothing was saved: check them again.";
    if (ctx.reloadFile && e.code !== "changed_since") ctx.reloadFile();   // someone else's keep: the house as it is now
    redraw();
  }

  // ── Undo this session ─────────────────────────────────────────────────────
  async function undoSession(){
    if (!undoInfo || busy) return;
    if (dirty()) { ctx.hint("Save or discard your changes first: an undo starts from what is saved.", true); askUndo = false; redraw(); return; }
    busy = true; err = ""; askUndo = false; redraw();
    try {
      const was = undoInfo, r = await call("plan_ai_undo", { batch_id: was.id });
      if (r && r.data && r.undone) ctx.fileWritten(r.data);
      await reload();                                      // the list, and what undoing now would do
      const left = (r.skipped || []).length;
      ctx.hint(`${was.puts_back ? "Put back" : "Undone"}: ${r.undone} of ${r.of}.${left ? ` ${left} ${left === 1 ? "was" : "were"} changed since and left as ${left === 1 ? "it is" : "they are"}.` : ""}`, !r.undone);
    } catch (e) { err = String((e && e.message) || e); }
    busy = false;
    redraw();
  }
  async function forget(key){
    if (busy) return;
    busy = true; err = ""; redraw();
    try {
      await call("plan_ai_reject_forget", { key });
      ignored = null;
      if (sess) { const r = await call("plan_ai_status", { session: sess.id }); sess = r.session || sess; }
    } catch (e) { err = String((e && e.message) || e); }
    busy = false;
    redraw();
  }
  async function openIgnored(){
    view = "ignored"; ignored = null; redraw();
    try { const r = await call("plan_ai_rejects_get"); ignored = (r && r.rejects) || []; } catch (e) { err = String((e && e.message) || e); ignored = []; }
    redraw();
  }

  // ── the crop: the plan's picture round the AI's box ───────────────────────
  const pics = new Map();
  function drawCrop(c, sug){
    const url = urls && urls[sug.map_id];
    if (movedPlan(sug.map_id)) return;                    // the picture may not be the one that was read
    if (!url || !Array.isArray(sug.box_px) || !Array.isArray(sug.frame)) return;
    let img = pics.get(url);
    if (!img) { img = new Image(); img.src = url; pics.set(url, img); }
    const paint = () => {
      try {
        const [fw, fh] = sug.frame, [x1, y1, x2, y2] = sug.box_px;
        const W = img.naturalWidth, H = img.naturalHeight;
        if (!W || !H) return;
        const bx = x1 / fw * W, by = y1 / fh * H, bw = (x2 - x1) / fw * W, bh = (y2 - y1) / fh * H;
        const m = Math.max(bw, bh) * 0.6;
        let sx = bx - m, sy = by - m, sw = bw + 2 * m, sh = bh + 2 * m;
        const ar = c.width / c.height;
        if (sw / sh < ar) { const nw = sh * ar; sx -= (nw - sw) / 2; sw = nw; } else { const nh = sw / ar; sy -= (nh - sh) / 2; sh = nh; }
        const g = c.getContext("2d");
        g.fillStyle = "#0b1510"; g.fillRect(0, 0, c.width, c.height);
        g.drawImage(img, sx, sy, sw, sh, 0, 0, c.width, c.height);
        const k = c.width / sw;
        g.strokeStyle = "#f59e0b"; g.lineWidth = 2; g.setLineDash([5, 3]);
        g.strokeRect((bx - sx) * k, (by - sy) * k, bw * k, bh * k);
      } catch (_) { /* a picture that will not draw leaves the box blank */ }
    };
    if (img.complete && img.naturalWidth) paint(); else img.addEventListener("load", paint, { once: true });
  }

  // ── the sheet ─────────────────────────────────────────────────────────────
  function head(title, sub){
    const h = d("h4");
    h.appendChild(d("span", null, title));
    h.appendChild(d("span", "pl-chip", "EXPERIMENTAL"));
    sheet.appendChild(h);
    if (sub) sheet.appendChild(d("p", "la3d-sub", sub));
  }
  function errLine(){ if (err) sheet.appendChild(d("div", "pl-note pl-bad", err)); }

  function paintConsent(){
    head("Add data via plans", "Your AI reads the floor plans you placed; you check every item.");
    sheet.appendChild(d("div", "pl-ban", BANNER));
    errLine();
    const plans = (info && info.plans) || [];
    if (!plans.length) { sheet.appendChild(d("div", "pl-note", "No floor plan with a scale to read yet: add one in Mapping → Upload, then measure it in Mapping → Edit → 📏 Measure.")); return; }
    // 1. Which plans, by floor; two on one floor said so.
    const byFloor = new Map();
    for (const p of plans) { if (outdoor(p.floor_id)) continue; if (!byFloor.has(p.floor_id)) byFloor.set(p.floor_id, []); byFloor.get(p.floor_id).push(p); }
    sheet.appendChild(d("h5", null, "Which plans"));
    for (const [fid, list] of byFloor) {
      sheet.appendChild(d("div", "pl-sub", floorName(fid)));
      for (const p of list) {
        const l = d("label", "pl-tick");
        const cb = d("input"); cb.type = "checkbox"; cb.checked = picked.has(p.map_id);
        cb.addEventListener("change", () => { if (cb.checked) picked.add(p.map_id); else picked.delete(p.map_id); redraw(); });
        l.appendChild(cb);
        if (urls && urls[p.map_id]) { const im = d("img"); im.src = urls[p.map_id]; im.alt = ""; im.loading = "lazy"; l.appendChild(im); }
        l.appendChild(d("span", null, `${p.name || "a plan"}${p.refs === 0 ? " (placed by eye)" : ""}`));
        sheet.appendChild(l);
      }
      if (list.length > 1) sheet.appendChild(d("div", "pl-note", `${list.length} plans cover ${floorName(fid)}: ${list.length === 2 ? "both" : "all"} are read, and you pick which to trust per item.`));
    }
    // 2. Which kinds.
    sheet.appendChild(d("h5", null, "Which kinds"));
    const kindRow = (key, text, on, disabled, note) => {
      const l = d("label", "pl-tick");
      const cb = d("input"); cb.type = "checkbox"; cb.checked = on; cb.disabled = disabled;
      if (key) cb.addEventListener("change", () => { kinds[key] = cb.checked; redraw(); });
      l.append(cb, d("span", null, text + (note ? ` — ${note}` : "")));
      sheet.appendChild(l);
    };
    kindRow(null, "Stairs", true, true, "always read");
    kindRow("railing", "Railings beside stairs", kinds.railing, false, "a hint beside each staircase found");
    kindRow("light", "Lights", kinds.light, false, "only on a plan that draws light fixtures");
    if (kinds.light) {
      sheet.appendChild(d("div", "pl-note", "Does this plan draw light fixtures, like circles or pot marks? Most architect's plans don't; electrical sheets do."));
      for (const p of plans) {
        if (!picked.has(p.map_id) || outdoor(p.floor_id)) continue;
        const row_ = d("div", "pl-choose"), now = fixtures.get(p.map_id) || "unsure";
        row_.appendChild(d("span", null, `${p.name || "a plan"}:`));
        for (const [v, word] of [["yes", "Yes"], ["no", "No"], ["unsure", "Not sure"]]) {
          const b = btn(word, v === "yes" ? "Read this plan for lights too" : "Don't read this plan for lights", () => { fixtures.set(p.map_id, v); redraw(); });
          b.setAttribute("aria-pressed", String(now === v));
          row_.appendChild(b);
        }
        sheet.appendChild(row_);
      }
    }
    // 3. What to expect.
    const n = picked.size, yes = kinds.light ? [...picked].filter(id => fixtures.get(id) === "yes").length : 0;
    const lo = Math.max(1, Math.round(n * 1.5)) + yes * 6, hi = Math.max(lo, n * 4 + yes * 12);
    sheet.appendChild(d("div", "pl-note", `About 1-2 staircases and 0-2 railing hints per plan${yes ? "; on a plan with fixtures 6-12 lights" : ""}. For your ${n} plan${n === 1 ? "" : "s"}: roughly ${lo}-${hi} items, `
      + `${Math.max(1, n) + yes}-${Math.max(1, n) * 3 + yes * 3} minutes to vet.`));
    if (yes) sheet.appendChild(d("div", "pl-note", "Light tiles are read last, 2.5-3 minutes a plan. Lights are never placed or moved: a symbol can only change a placed light's kind."));
    if (kinds.light) sheet.appendChild(d("div", "pl-note", "Tick only the sheets that draw lights: with more plans ticked, the session's time can run out before the lights are read."));
    // 4. Where the plans go.
    sheet.appendChild(d("h5", null, "Where the plans go"));
    const ai = info && info.ai;
    if (!ai || ai.ready === false) sheet.appendChild(d("div", "pl-note pl-bad", (ai && ai.message) || "Pick an AI Task in Settings → AI first."));
    else {
      sheet.appendChild(d("div", "pl-note", planNote(ai, n)));
      if (ai.local !== false || ai.backup) sheet.appendChild(d("div", "pl-note", sharedNote(!!ai.backup)));
    }
    // 5. Go.
    const acts = d("div", "pl-acts");
    const go = btn("", "Start reading", () => start(), "go");
    go.textContent = `Read ${n} plan${n === 1 ? "" : "s"}`;
    const blocked = info && info.start_blocked;
    go.disabled = busy || !ai || ai.ready === false || !!blocked || !n || (ai.main_away === true && !ai.backup);
    acts.appendChild(go);
    if (sess && Object.keys(sess.suggestions || {}).length) acts.appendChild(btn("Back to the last list", "The last session's items", () => { step = "list"; redraw(); }));
    sheet.appendChild(acts);
    if (blocked) sheet.appendChild(d("div", "pl-note", { already_running: "A session is already reading your plans.", too_soon: "A session started less than a minute ago: wait a moment.",
      daily_cap: "That's the day's sessions: try again tomorrow." }[blocked] || String(blocked)));
  }

  function paintProgress(){
    head("Reading your plans", "The read runs on the server: this page can close and come back.");
    const pr = (sess && sess.progress) || {};
    const name = pr.name || "a plan", i = pr.plan || 0, n = pr.of || (info && info.running ? "?" : 0);
    const what = pr.step === "check" ? `Checking a find on ${name}` : pr.step === "railing" ? `Looking for a railing on ${name}`
      : pr.step === "tiles" ? `Reading ${name} for lights, tile ${pr.tile || 1} of 9` : pr.step === "light_check" ? `Checking a light on ${name}` : `Reading ${name} for stairs`;
    const later = pr.step === "stairs" || !pr.step ? ` then checking each find.${sess && sess.lights_asked ? " Light tiles come last." : ""}` : "";
    sheet.appendChild(d("div", "pl-sum", `${what} (${i} of ${n})…${later} A local AI can take a minute a read.`));
    if (sess) sheet.appendChild(d("div", "pl-note", `${sess.reads || 0} reads so far, ${mins(sess.spent_s)} spent of ${mins(sess.budget_s)}.`));
    if (cancelNote) sheet.appendChild(d("div", "pl-note", cancelNote));
    errLine();
    const acts = d("div", "pl-acts");
    acts.appendChild(btn("Cancel", "Stop between reads; what was read so far is kept", () => cancel()));
    sheet.appendChild(acts);
  }

  /** A mark near a placed light that nobody read a symbol from: nothing says it is that light. */
  const unsaid = (s) => s.kind === "light" && s.state === "duplicate" && (s.geom || {}).symbol === "unknown";
  function summary(){
    if (sess.status === "failed" && NO_READ[sess.error]) return `Nothing was read: ${NO_READ[sess.error]}. That isn't the AI finding nothing: read again once it's sorted.`;
    const ss = sugs();
    const stairs = ss.filter(s => s.kind === "stairs" && s.state !== "duplicate").length;
    const rails = ss.filter(s => s.kind === "railing").length;
    const lights = ss.filter(s => s.kind === "light" && s.state !== "duplicate").length, lightsHere = ss.filter(s => s.kind === "light" && s.state === "duplicate" && !unsaid(s)).length, lightsUnsaid = ss.filter(unsaid).length;
    const skipped = sess.skipped || 0, read = (sess.plans || []).filter(p => p.answered).length, notRead = unread();
    const errs = sess.errors || {}, failedReads = Object.keys(NO_READ).reduce((t, k) => t + (errs[k] || 0), 0);
    const worst = Object.keys(NO_READ).reduce((a, k) => ((errs[k] || 0) > (errs[a] || 0) ? k : a));
    const lightsWord = sess.lights_asked ? `, ${lights} light${lights === 1 ? "" : "s"}` : "";
    let line = `Found ${stairs} stair${stairs === 1 ? "" : "s"}, ${rails} railing hint${rails === 1 ? "" : "s"}${lightsWord} on ${read} plan${read === 1 ? "" : "s"} in ${mins(sess.spent_s)}.`;
    if (lightsHere) line += ` ${lightsHere} light${lightsHere === 1 ? " was" : "s were"} already there.`;
    if (lightsUnsaid) line += ` ${lightsUnsaid} mark${lightsUnsaid === 1 ? "" : "s"} near a placed light ${lightsUnsaid === 1 ? "wasn't" : "weren't"} read closely enough to say what ${lightsUnsaid === 1 ? "it is" : "they are"}.`;
    if (sess.tiles_skipped === "slow") line += " Lights weren't read: this AI's first read took over 45 seconds, and nine tiles a plan would use up the session.";
    else if (sess.lights_asked && !sess.tiles && (sess.plans || []).some(p => (p.kinds || []).includes("light"))) line += " Lights weren't read: the time ran out first.";
    if (sess.light_dropped) line += ` ${sess.light_dropped} light${sess.light_dropped === 1 ? "" : "s"} left out: a closer look found no fixture there.`;
    if (skipped) line += ` ${skipped} plan${skipped === 1 ? "" : "s"} skipped (out of time).`;
    if (notRead) line += ` ${notRead} plan${notRead === 1 ? "" : "s"} couldn't be read.`;
    if (failedReads) line += ` ${failedReads} read${failedReads === 1 ? "" : "s"} failed: ${NO_READ[worst]}.`;
    if (sess.crop_dropped) line += ` ${sess.crop_dropped} left out: a closer look found no staircase there.`;
    if (sess.no_floor) line += ` ${sess.no_floor} left out: no floor below for a staircase to climb from.`;
    if (sess.status === "out_of_time") line += skipped || sess.cut_short ? " The session ran out of time." : " It stopped after two reads in a row got no answer.";
    if (sess.status === "cancelled") line += ` The session was ${CANCEL_WORDS[sess.error] || "cancelled"}.`;
    if (sess.status === "failed") line += sess.error === "restart" ? " Home Assistant restarted during the read; run it again." : " The read failed; run it again.";
    if (sess.backup_used) line += " Read by the backup AI task.";
    if (sess.frame === "named") line += " This AI's picture size isn't known, so positions may be coarse.";
    return line + (ss.length ? " Vet them one by one." : "");
  }

  /** What a light's card says, list and map alike. */
  function lightLines(sug, stillOpen){
    const m = sug.match || {}, g = sug.geom || {}, out = [];
    if (m.relation === "correction" && stillOpen) {
      out.push(`The plan draws ${SYMBOL_WORD[g.symbol] || "a fixture"} here. ${m.label || "This light"} is drawn as ${kindWord(m.now_kind)}.`);
      if (m.group) out.push("This room's lights are placed as a group: kind only?");
      else out.push("Only what it is drawn as can change: where it stands stays.");
    }
    if (sug.state === "unmatched") out.push("A fixture symbol with no placed light here. PadSpan doesn't place lights from a plan: place it yourself if it's right.");
    return out;
  }
  function row(sug, acts){
    const r = d("div", "pl-row");
    const c = d("canvas"); c.width = 240; c.height = 168;
    r.appendChild(c);
    if (urls) drawCrop(c, sug);
    const t = d("div", "pl-txt");
    const g = sug.geom || {}, m = sug.match || {};
    const kind = (KIND_OF[sug.kind] || KIND_OF.stairs).word;
    const seen = Array.isArray(sug.seen_on) && sug.seen_on.length > 1 ? ` · seen on ${sug.seen_on.length} plans` : ` · ${planName(sug.map_id)}`;
    const size = sug.kind === "stairs" ? ` · ${m1(g.width_m)} × ${m1(g.depth_m)} m` : "";
    const side = sug.kind === "railing" ? (g.side ? ` · the AI says ${g.side}` : " · a rail on one side: which?") : "";
    t.appendChild(d("div", null, `${kind} · ${floorName(sug.floor_id)}${seen}${size}${side}`));
    const rel = d("div", "pl-sub");
    const label = m.target_snap && m.target_snap.label ? m.target_snap.label : "a stair";
    const pend = pendingOf(sug.id);
    if (sug.kind === "light" && !pend && sug.state !== "stale" && !String(sug.state).startsWith("committed") && sug.state !== "undone") {
      if (m.relation === "correction") rel.appendChild(d("span", "pl-rel correction", `correction · ${m.label || "a placed light"} is drawn as ${kindWord(m.now_kind)}`));
      else if (m.relation === "unmatched") rel.appendChild(d("span", "pl-rel stale", "a fixture symbol with no placed light here"));
    } else if (pend) rel.appendChild(d("span", "pl-rel kept", pend.v === "correction" ? "kept as a correction, until Save" : "kept, until Save"));
    else if (sug.state === "committed_new") rel.appendChild(d("span", "pl-rel kept", "kept as new"));
    else if (sug.state === "committed_correction") rel.appendChild(d("span", "pl-rel kept", "kept as a correction"));
    else if (sug.state === "undone") rel.appendChild(d("span", "pl-rel stale", "undone"));
    else if (sug.state === "stale") rel.appendChild(Object.assign(d("span", "pl-rel stale", movedPlan(sug.map_id) ? "the plan moved: read it again" : "changed since you looked"), { title: "The plan or the stair it points at changed since the read." }));
    else if (m.relation === "correction" && sug.kind === "railing") rel.appendChild(d("span", "pl-rel correction", `correction · a rail on another side of ${label}`));
    else if (m.relation === "correction") rel.appendChild(d("span", "pl-rel correction", `correction · ${m1(m.distance_m)} m from ${label}`));
    else if (m.relation === "stacked") rel.appendChild(d("span", "pl-rel stacked", "a second staircase here, stacked?"));
    else if (m.relation === "new") rel.appendChild(d("span", "pl-rel new", (m.near_names || []).length ? `new · near ${m.near_names.join(" and ")}` : "new"));
    rel.appendChild(document.createTextNode(CUE[sug.kind] || ""));
    t.appendChild(rel);
    const stillOpen = OPEN.has(sug.state) && sug.state !== "stale";
    if (stillOpen && sug.kind === "stairs" && m.relation === "correction" && m.hand === true) t.appendChild(d("div", "pl-sub", `You placed this one. The AI puts it ${m1(m.distance_m)} m away. Keep yours unless the plan says otherwise.`));
    else if (stillOpen && sug.kind === "stairs" && m.relation === "correction") t.appendChild(d("div", "pl-sub", `The AI placed this one too. This read puts it ${m1(m.distance_m)} m away.`));
    if (sug.kind === "light") for (const line of lightLines(sug, stillOpen)) t.appendChild(d("div", "pl-sub", line));
    for (const o of m.others || []) t.appendChild(d("div", "pl-sub", `${planName(o.map_id)} puts one ${m1(o.distance_m)} m from here: both are listed, nothing wins by itself.`));
    if (m.held === "frame") t.appendChild(d("div", "pl-sub", "Position may be coarse: this AI's picture size isn't known."));
    else if (m.held === "eye") t.appendChild(d("div", "pl-sub", sug.kind === "light" ? "The plan was placed by eye, so this may be another light." : "The plan was placed by eye, so the offset may be the plan's."));
    if (sug.verdict && sug.verdict.why) t.appendChild(d("div", "pl-sub", `Marked wrong: ${WHY_WORD[sug.verdict.why] || sug.verdict.why}${sug.verdict.remembered ? " (ignored before)" : ""}`));
    if (acts) t.appendChild(acts);
    r.appendChild(t);
    return r;
  }
  /** The floor a stacked staircase climbs from: asked before it is kept (the arrow read is unreliable). */
  function floorChoice(sug){
    const all = (ctx.floors() || []).filter(G => G && G.fl && !G.fl.outdoor && !G.fl.parent).sort((p, q) => (p.fl.elev || 0) - (q.fl.elev || 0));
    const from = all.slice(0, -1);
    const row_ = d("div", "pl-choose");
    row_.appendChild(d("span", null, "It climbs from:"));
    const cur = stackFloor.get(sug.id) || sug.floor_id;
    for (const G of from) {
      const b = btn(G.fl.name || String(G.fl.id), `It starts on ${G.fl.name || G.fl.id}`, () => { stackFloor.set(sug.id, String(G.fl.id)); if (mapAwake) goTo(sug.id); else redraw(); });   // its pin and ghost are on that floor now
      b.setAttribute("aria-pressed", String(String(G.fl.id) === String(cur)));
      row_.appendChild(b);
    }
    return row_;
  }
  /** A railing hint: which side (only when the AI could tell is one picked for you), which style. */
  function railActs(sug, a){
    const home = railHome(sug), dr = ctx.draft && ctx.draft();
    const q = home && dr ? dr.cur.pieces[home] : null;
    const params = q && q.recipe ? q.recipe.params : null;
    const pick = railPick.get(sug.id) || {};
    const said = { left: "inner", right: "outer", both: "both" }[(sug.geom || {}).side];
    if (!pick.side && said && (said === "both" || flat(params))) pick.side = said;
    if (!pick.style && params && RAIL_STYLES.some(([v]) => v === params.rail_style)) pick.style = params.rail_style;
    railPick.set(sug.id, pick);
    if (!home || !q) { a.appendChild(d("span", "pl-sub", "Keep its stair first: there is nothing to put a rail on yet.")); return; }
    const sides = d("div", "pl-choose");
    sides.appendChild(d("span", null, "Side:"));
    for (const [v, word] of railSides(params)) {
      const b = btn(word, `A rail: ${word.toLowerCase()}`, () => { pick.side = v; redraw(); });
      b.setAttribute("aria-pressed", String(pick.side === v));
      sides.appendChild(b);
    }
    a.appendChild(sides);
    const looks = d("div", "pl-choose");
    looks.appendChild(d("span", null, "Style:"));
    for (const [v, word] of RAIL_STYLES) {
      const b = btn(word, `The rail's style: ${word.toLowerCase()}`, () => { pick.style = v; redraw(); });
      b.setAttribute("aria-pressed", String((pick.style || "balustrade") === v));
      looks.appendChild(b);
    }
    a.appendChild(looks);
    const keep = btn("Keep this rail", "Into your draft: nothing is kept until Save", () => keepRail(sug), "go");
    keep.disabled = busy || !pick.side;
    a.appendChild(keep);
  }
  function queuedActs(sug){
    const a = d("div", "pl-acts");
    const m = sug.match || {};
    const stale = sug.state === "stale";
    // Already in the draft: only taking it back. The toolbar's Undo does the same.
    if (pendingOf(sug.id)) {
      const b = btn("Take that back", "Out of your draft: nothing was kept", () => takeBack(sug));
      b.disabled = busy;
      a.appendChild(b);
      return a;
    }
    const moved = movedPlan(sug.map_id);
    if (sug.kind === "light") {
      if (!stale && !moved && m.relation === "correction") {
        const mine = btn("Keep mine", "It stays as it is (noted at once)", () => verdict(sug, "failure", "already_here"));
        a.append(btn("Take the kind", "Into your draft: nothing is kept until Save", () => keepLight(sug), "go"), mine);
      }
    } else if (sug.kind === "railing") { if (!stale) railActs(sug, a); }
    else if (!moved) {
      if (m.relation === "stacked") a.appendChild(floorChoice(sug));
      const bNew = btn("New", m.relation === "correction" ? "A staircase of its own, beside the one you have (into your draft)" : "Add it to your draft: nothing is kept until Save", () => keepNew(sug), m.relation === "correction" ? null : "go");
      if (m.relation === "correction" && !stale) {
        // Keep mine is where a hand-placed stair starts; the AI's position only where the AI placed it too.
        const mine = btn("Keep mine", "Yours stays where it is (noted at once)", () => verdict(sug, "failure", "already_here"));
        const takeIt = btn("Take the AI's position", "Move it there in your draft: nothing is kept until Save", () => takeAi(sug), m.hand === true ? null : "go");
        if (m.hand === true) { a.append(mine, takeIt); if (!focusBtn) focusBtn = mine; }
        else { a.append(takeIt, mine); if (!focusBtn) focusBtn = takeIt; }
      }
      a.appendChild(bNew);
      if (m.relation === "new" && !m.held) for (const [i, id] of (m.near || []).entries()) {
        if (m.near_snaps && m.near_snaps[id]) a.appendChild(btn(`A correction of ${(m.near_names || [])[i] || "that stair"}`, "Move that stair here in your draft: nothing is kept until Save", () => takeAi(sug, id)));
      }
    }
    if (failing === sug.id) {
      for (const [k, word] of WHY) a.appendChild(btn(word, `Mark it wrong: ${word.toLowerCase()}`, () => verdict(sug, "failure", k), "why"));
      a.appendChild(btn("Never mind", "Keep it in the queue", () => { failing = null; redraw(); }));
    } else {
      if (sug.state !== "stale" && sug.state !== "right") a.appendChild(btn("Looks right", "The AI got this one right (noted at once; nothing is written to your house)", () => verdict(sug, "right")));
      a.appendChild(btn("Failure", "Mark it wrong, with a reason (noted at once)", () => { failing = sug.id; redraw(); }));
      if (sug.state !== "stale" && sug.state !== "later") a.appendChild(btn("Later", "Come back to it (noted at once)", () => verdict(sug, "later")));
      if (sug.state === "right" || sug.state === "later") a.appendChild(btn("Take that back", "Back to the queue", () => verdict(sug, "back")));
    }
    for (const b of a.querySelectorAll("button")) if (!b.disabled) b.disabled = busy;
    return a;
  }
  function backActs(sug){
    const a = d("div", "pl-acts");
    const b = btn("Take that back", "Back to the queue", () => verdict(sug, "back")); b.disabled = busy;
    a.appendChild(b);
    return a;
  }

  function paintList(){
    head("Add data via plans", "The AI's finds, one by one. Nothing goes into your house until you press Save.");
    sheet.appendChild(d("div", "pl-ban", BANNER));
    sheet.appendChild(d("div", "pl-sum", summary()));
    errLine();
    const ss = sugs();
    const order = (s) => (s.kind === "stairs" ? 0 : s.kind === "railing" ? 1 : 2);
    const group = (title, list, actsOf) => {
      if (!list.length) return;
      sheet.appendChild(d("h5", null, `${title} (${list.length})`));
      for (const s of list.sort((a, b) => order(a) - order(b) || String(a.floor_id).localeCompare(String(b.floor_id)))) sheet.appendChild(row(s, actsOf ? actsOf(s) : null));
    };
    const pendIds = new Set(pendings().map(p => p.sug_id));
    group("To keep, when you Save", ss.filter(s => pendIds.has(s.id)), queuedActs);
    group("To check", ss.filter(s => s.state === "queued" && !pendIds.has(s.id)), queuedActs);
    group("Changed since you looked", ss.filter(s => s.state === "stale" && !pendIds.has(s.id)), queuedActs);
    group("Looks right", ss.filter(s => s.state === "right" && !pendIds.has(s.id)), queuedActs);
    group("Later", ss.filter(s => s.state === "later" && !pendIds.has(s.id)), queuedActs);
    group("Marked wrong", ss.filter(s => s.state === "failure" && !(s.verdict && s.verdict.remembered)), backActs);
    group("No placed light here", ss.filter(s => s.state === "unmatched"), (s) => {
      if (!canOpenAtlas()) return null;
      const a = d("div", "pl-acts");
      a.appendChild(btn("Open Mapping → Atlas builder", "Place a light there yourself: the plans never place one", () => openAtlas(s)));
      return a;
    });
    group("Kept", ss.filter(s => String(s.state).startsWith("committed")), null);
    group("Undone", ss.filter(s => s.state === "undone"), null);
    group("Gone with its stair", ss.filter(s => s.state === "settled"), null);
    group("Already in your house", ss.filter(s => s.state === "duplicate" && !unsaid(s)), null);
    group("Near a placed light, not read closely", ss.filter(unsaid), null);
    group("Ignored before", ss.filter(s => s.state === "failure" && s.verdict && s.verdict.remembered),
      (s) => { const a = d("div", "pl-acts"); const b = btn("Un-ignore", "Forget that reject and queue it again", () => forget(s.verdict.reject)); b.disabled = busy; a.appendChild(b); return a; });
    if (!ss.length && sess.status === "done") sheet.appendChild(d("div", "pl-note", unread() ? "The AI found nothing on the plans it could read." : "The AI found nothing on these plans."));
    const foot = d("div", "pl-foot");
    const pend = pendings();
    if (pend.length) {
      const n = pend.filter(p => p.v === "new" && p.made).length, c = pend.filter(p => p.v === "correction").length, l = pend.filter(p => p.rail).length;
      const words = [n ? `${n} new` : "", c ? `${c} correction${c === 1 ? "" : "s"}` : "", l ? `${l} railing${l === 1 ? "" : "s"}` : ""].filter(Boolean).join(", ");
      const keep = btn(`Keep ${words} (one undo for the whole session)`, "Save: into your 3D house, with a safety backup and one undo", () => ctx.save(), "go");
      keep.disabled = busy || !!(ctx.saving && ctx.saving());
      foot.appendChild(keep);
    }
    if (undoInfo && !askUndo) {
      const word = undoInfo.puts_back ? `Put back ${undoInfo.items}` : `Undo this session (${undoInfo.items})`;
      const b = btn(word, "Takes back what this session kept; anything changed since is left", () => { askUndo = true; redraw(); });
      b.disabled = busy;
      foot.appendChild(b);
    }
    foot.appendChild(btn("Manage ignored", "The finds you marked wrong, remembered per plan", () => openIgnored()));
    foot.appendChild(btn("Read again", "Back to the plans and the button", () => readAgain()));
    if (mapCan() && mapItems().length) foot.appendChild(btn("Back to the map", "The plan under the house, a pin per item", () => { listAsked = false; redraw(); }));
    sheet.appendChild(foot);
    if (undoInfo && askUndo) {
      const a = d("div", "pl-acts");
      a.appendChild(d("span", "pl-sub", undoInfo.puts_back ? "Put those items back in your 3D house?" : "Take what this session kept out of your 3D house? Anything you changed since is left as it is."));
      a.appendChild(btn(undoInfo.puts_back ? "Put back" : "Undo", "Goes at once", () => undoSession(), "go"));
      a.appendChild(btn("Cancel", "Leave it", () => { askUndo = false; redraw(); }));
      sheet.appendChild(a);
    }
  }

  function paintIgnored(){
    head("Ignored before", "Finds you marked wrong, remembered for that plan until it is moved or replaced.");
    errLine();
    if (ignored === null) sheet.appendChild(d("div", "pl-note", "Loading…"));
    else if (!ignored.length) sheet.appendChild(d("div", "pl-note", "Nothing is ignored."));
    for (const r of ignored || []) {
      const rowEl = d("div", "pl-row");
      const t = d("div", "pl-txt");
      t.appendChild(d("div", null, `${(KIND_OF[r.kind] || KIND_OF.stairs).word} · ${r.plan || "a plan"} · ${floorName(r.floor_id)} · at ${m1(r.x_m)}, ${m1(r.y_m)} m`));
      t.appendChild(d("div", "pl-sub", `Marked wrong: ${WHY_WORD[r.why] || r.why || "no reason given"}`));
      const a = d("div", "pl-acts");
      const b = btn("Forget", "Queue it again next time", () => forget(r.key)); b.disabled = busy;
      a.appendChild(b);
      t.appendChild(a);
      rowEl.appendChild(t);
      sheet.appendChild(rowEl);
    }
    const foot = d("div", "pl-foot");
    foot.appendChild(btn("Back", "Back to the list", () => { view = "list"; redraw(); }));
    sheet.appendChild(foot);
  }

  // ── the vetting map ───────────────────────────────────────────────────────
  // One card, one plan, a few pins. The list is one press away (and the only
  // view with no 3D behind it). All of it hangs off one group in the view's
  // scene and one layer of pins, taken away whole when the tool closes.
  const { THREE } = ctx;
  const pinsEl = d("div", "pl-pins");
  ctx.root.appendChild(pinsEl);
  const pins = new Map(), ghosts = new Map(), stairGhosts = new Map(), tags = new Map();
  let listAsked = false, mapAwake = false, cur = null, card = "item", floorSeen = null, expectFloor = null, shell = null, flyDue = false;
  let vCount = 0, vSinceRecap = 0, lastRecapAt = 0, moving = null, gesture = null, more = false, askDismiss = false, nextFloorItem = null, nearOpen = false;
  let planOn = true, opacity = PLAN_OPACITY, fade = GHOST, planNow = null, planMesh = null, planTok = 0, planKey = null, texLive = 0, planGone = false;
  let group = null, onion = null, onionKey = "", suppressClick = false, ghostsLate = false;
  const planPick = new Map(), acts = [];

  const mapCan = () => !!THREE && typeof ctx.scene === "function";
  const stateOf = (s) => pinState(s, pendingOf(s.id));
  const mapItems = () => sugs().filter(s => stateOf(s) !== null);
  const mapWanted = () => mapCan() && !listAsked && step === "list" && view === "list" && !!sess && mapItems().length > 0;
  const floorUi = (fid) => {
    const all = ctx.floors() || [], want = ctx.canon ? String(ctx.canon(fid)) : String(fid);
    return all.find(G => G && G.fl && String(G.fl.id) === want) || all.find(G => G && G.fl && String(G.fl.id) === String(fid)) || null;
  };
  const same = (a, b) => { const fa = floorUi(a), fb = floorUi(b); return fa && fb ? fa === fb : String(a) === String(b); };
  const itemFloorId = (s) => { const p = pendingOf(s.id), dr = ctx.draft && ctx.draft(); const q = p && dr ? dr.cur.pieces[p.piece] : null; return q ? q.floor_id : stackFloor.get(s.id) || s.floor_id; };
  const roomAt = (s, at = null, fid = itemFloorId(s)) => {
    const F = floorUi(fid), g = at || s.geom || {};
    return (F && (F.rooms || []).find(r2 => !r2.outdoor && Array.isArray(r2.pts) && r2.pts.length >= 3 && inPolygon(num(g.x_m) ?? 0, num(g.y_m) ?? 0, r2.pts))) || null;
  };
  const roomOf = (s, at = null) => { const r = roomAt(s, at); return r ? r.name || "" : ""; };
  // The order goes by the floor the AI read it on: a floor picked for a stacked stair renumbers nothing.
  const roomRank = (s) => { const r = roomAt(s, null, s.floor_id); return r ? Math.min(...r.pts.map(p => p[1])) * 1000 + Math.min(...r.pts.map(p => p[0])) : Infinity; };
  const floorRank = (s) => { const F = floorUi(s.floor_id); return F ? num(F.fl.elev) ?? 0 : 0; };
  const orderNow = () => orderItems(mapItems(), floorRank, roomRank);
  const sugOf = (id) => (id && sess && sess.suggestions ? sess.suggestions[id] || null : null);
  const shownFloor = () => (expectFloor && floorUi(expectFloor)) || (ctx.currentFloor ? ctx.currentFloor() : null);
  /** Where an item stands now: a stair kept moves with its piece in the draft. */
  function posOf(s){
    const dr = ctx.draft && ctx.draft(), p = pendingOf(s.id), g = s.geom || {};
    const pc = (id) => (id && dr ? dr.cur.pieces[id] : null);
    const q = (p && pc(p.piece)) || (s.kind === "railing" ? pc(railHome(s)) : null) || (String(s.state).startsWith("committed") ? pc(s.piece_id) : null);
    return q ? { x_m: q.x_m, y_m: q.y_m } : { x_m: g.x_m, y_m: g.y_m };
  }
  const targetOf = (s) => { const m = s.match || {}, dr = ctx.draft && ctx.draft(); return m.target && dr ? dr.cur.pieces[m.target] || null : null; };
  /** The plans another read of this staircase came from, and that suggestion. */
  const twins = (s) => {
    const m = s.match || {};
    return (m.others || []).map(o => ({ ...o, sug: sugs().find(t => t.id !== s.id && t.kind === s.kind && t.map_id === o.map_id && same(t.floor_id, s.floor_id)) || null }));
  };

  // ── the plan under the house: one texture, one plane ──────────────────────
  function planChoices(F){
    const all = (info && info.plans) || [];
    return F ? all.filter(p => same(p.floor_id, F.fl.id) && !movedPlan(p.map_id)) : [];
  }
  function planWanted(F){
    const list = planChoices(F), c = sugOf(cur);
    const want = F ? planPick.get(String(F.fl.id)) || (c && same(itemFloorId(c), F.fl.id) ? c.map_id : null) : null;
    return all_(info).find(p => p.map_id === want && !movedPlan(p.map_id)) || list[0] || null;
  }
  const all_ = (i) => (i && i.plans) || [];
  function releasePlan(){
    planTok++;
    planKey = null; planNow = null; planGone = false;
    if (!planMesh) return;
    if (planMesh.parent) planMesh.parent.remove(planMesh);
    if (planMesh.material.map) { planMesh.material.map.dispose(); texLive--; }
    planMesh.material.dispose(); planMesh.geometry.dispose();
    planMesh = null;
  }
  /** The plan as a plane on floor F, its corners in metres from the server. A
   *  picture that won't load or draw leaves the house without it, nothing more. */
  function syncPlan(F){
    const p = planWanted(F), url = p && urls ? urls[p.map_id] : null;
    const key = p && url && F ? `${p.map_id}|${F.fl.id}|${F.fl.elev}` : null;
    if (key !== planKey) {
      releasePlan();
      planKey = key; planNow = key ? p : null;
      if (key) loadPlan(p, url, F, planTok);
    }
    if (planMesh) { planMesh.visible = planOn; planMesh.material.opacity = opacity; }
  }
  function loadPlan(p, url, F, tok){
    const img = new Image();
    img.onload = () => {
      if (tok !== planTok) return;                      // the floor or the plan changed while it loaded: never a second texture
      try {
        const [w, h] = fitSize(img.naturalWidth, img.naturalHeight), c = document.createElement("canvas");
        c.width = w; c.height = h;
        c.getContext("2d").drawImage(img, 0, 0, w, h);
        const tex = new THREE.CanvasTexture(c);
        if (THREE.SRGBColorSpace) tex.colorSpace = THREE.SRGBColorSpace;
        texLive++;
        const geo = new THREE.BufferGeometry(), y = F.fl.elev + 0.025, cs = p.corners_m;
        geo.setAttribute("position", new THREE.BufferAttribute(new Float32Array([cs[0][0], y, cs[0][1], cs[1][0], y, cs[1][1], cs[2][0], y, cs[2][1], cs[3][0], y, cs[3][1]]), 3));
        geo.setAttribute("uv", new THREE.BufferAttribute(new Float32Array([0, 1, 1, 1, 1, 0, 0, 0]), 2));
        geo.setIndex([0, 2, 1, 0, 3, 2]);
        const mat = new THREE.MeshBasicMaterial({ map: tex, transparent: true, opacity, depthWrite: false, side: THREE.DoubleSide, polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -4 });
        planMesh = new THREE.Mesh(geo, mat);
        planMesh.renderOrder = 1; planMesh.visible = planOn; planMesh.frustumCulled = false;
        if (group) group.add(planMesh);
        if (ctx.render) ctx.render();
      } catch (_) { planGone = true; }
    };
    img.onerror = () => { if (tok === planTok) { planGone = true; redraw(); } };
    img.src = url;
  }

  // ── ghosts: the real builders, outside the draft ──────────────────────────
  const dashMat = (colour = DASH_COL) => new THREE.MeshBasicMaterial({ color: colour, transparent: true, opacity: 0.95, depthTest: false, depthWrite: false, side: THREE.DoubleSide });
  function dashMesh(tris, y, colour){
    const geo = new THREE.BufferGeometry();
    geo.setAttribute("position", new THREE.BufferAttribute(tris, 3));
    const m = new THREE.Mesh(geo, dashMat(colour));
    m.position.y = y; m.renderOrder = 8; m.frustumCulled = false;
    return m;
  }
  const dropMesh = (m) => { if (m.parent) m.parent.remove(m); m.geometry.dispose(); m.material.dispose(); };
  /** The piece a suggestion would be, for drawing only. A correction is the stair
   *  it would move, where the AI puts it: shape and turn are never corrected. */
  function ghostPiece(s){
    const m = s.match || {}, g = s.geom || {};
    if (s.kind === "stairs") {
      if (m.relation === "correction") { const t = targetOf(s); if (t) return { ...t, x_m: g.x_m, y_m: g.y_m }; }
      const fid = stackFloor.get(s.id) || s.floor_id, k = `${s.id}|${fid}`;
      if (!stairGhosts.has(k)) { const pc = ctx.stairPiece(g, fid, PIECE_LABEL); if (!pc) return null; stairGhosts.set(k, pc); }
      return stairGhosts.get(k);
    }
    if (s.kind === "railing" && s.id === cur) {
      // A rail on its stair, as it would be: the side picked, or both while none is.
      const dr = ctx.draft && ctx.draft(), home = railHome(s), st = sugOf((s.geom || {}).stair) || sugOf(s.of_stair);
      const base = (home && dr ? dr.cur.pieces[home] : null) || (st ? ghostPiece(st) : null), pick = railPick.get(s.id) || {};
      if (!base || !base.recipe) return null;
      const said = { left: "inner", right: "outer", both: "both" }[g.side];
      return { ...base, recipe: { ...base.recipe, params: { ...(base.recipe.params || {}), rail: pick.side || said || "both", rail_style: pick.style || "balustrade" } } };
    }
    return null;
  }
  function ghostWanted(s){
    if (pendingOf(s.id) || movedPlan(s.map_id)) return false;
    return s.state === "queued" || s.state === "later" || s.state === "stale" || (s.kind === "light" && s.state === "unmatched");
  }
  function dropGhost(id){
    const G = ghosts.get(id);
    if (!G) return;
    if (G.root.parent) G.root.parent.remove(G.root);
    dropMesh(G.dash);
    for (const m of G.mats) m.dispose();
    if (G.geo) G.geo.dispose();
    try { const B = ctx.FURN && ctx.FURN(); if (B && B.disposePiece && G.body) B.disposePiece(G.body); } catch (_) { /* best effort */ }
    ghosts.delete(id);
  }
  function buildGhost(id, piece, F, key){
    const B = ctx.FURN && ctx.FURN();
    if (!B || typeof B.buildPiece !== "function") { ghostsLate = true; return; }    // the builders still on their way: drawn when they are in
    const recipe = ctx.recipeOf ? ctx.recipeOf(piece) || piece.recipe : piece.recipe;
    const body = B.buildPiece(THREE, recipe, { quality: "low" }), mats = [];
    const see = (m) => { const c = m.clone(); c.transparent = true; c.opacity = id === cur ? fade : GHOST; c.depthWrite = false; mats.push(c); return c; };
    body.traverse((o) => { if (o.isMesh) { o.material = Array.isArray(o.material) ? o.material.map(see) : see(o.material); o.castShadow = false; o.receiveShadow = false; o.renderOrder = 5; } });
    const root = new THREE.Group();
    root.name = `plan-ghost:${id}`;
    root.position.set(num(piece.x_m) ?? 0, F.fl.elev + (num(piece.z_m) ?? 0), num(piece.y_m) ?? 0);
    root.rotation.set(0, ctx.PIECES.yawOfRot(piece.rotation), 0);
    root.add(body);
    group.add(root);
    const corners = ctx.STOREY && ctx.STOREY.footprint ? ctx.STOREY.footprint(piece) : null;
    const dash = dashMesh(dashTriangles(corners || [[piece.x_m, piece.y_m]], true), F.fl.elev + 0.05);
    group.add(dash);
    ghosts.set(id, { root, dash, body, mats, key, corners, id, floor: F });
  }
  /** A light's ghost: a disc and a dashed ring where the plan draws the symbol. It stands for nothing in the house. */
  function buildLightGhost(id, g, F, key){
    const x = num(g.x_m) ?? 0, y = num(g.y_m) ?? 0, R = 0.28, ring = [], corners = [[x - R, y - R], [x + R, y - R], [x + R, y + R], [x - R, y + R]];
    for (let i = 0; i < 16; i++) ring.push([x + Math.cos(i * Math.PI / 8) * R, y + Math.sin(i * Math.PI / 8) * R]);
    const geo = new THREE.CircleGeometry(0.17, 24);
    geo.rotateX(-Math.PI / 2);
    const mat = new THREE.MeshBasicMaterial({ color: DASH_COL, transparent: true, opacity: id === cur ? fade : GHOST, depthTest: false, depthWrite: false, side: THREE.DoubleSide });
    const disc = new THREE.Mesh(geo, mat), root = new THREE.Group();
    disc.renderOrder = 6;
    root.name = `plan-ghost:${id}`;
    root.position.set(x, F.fl.elev + 0.05, y);
    root.add(disc);
    group.add(root);
    const dash = dashMesh(dashTriangles(ring, true, 0.09, 0.06, 0.04), F.fl.elev + 0.05);
    group.add(dash);
    ghosts.set(id, { root, dash, body: null, geo, mats: [mat], key, corners, id, floor: F });
  }
  function syncGhosts(F){
    const want = new Map();
    if (F) for (const s of sugs()) {
      if (!same(itemFloorId(s), F.fl.id) || !ghostWanted(s)) continue;
      if (s.kind === "light") { want.set(s.id, { light: s.geom || {}, key: JSON.stringify([(s.geom || {}).x_m, (s.geom || {}).y_m, F.fl.elev]) }); continue; }
      const pc = ghostPiece(s);
      if (!pc) continue;
      const recipe = ctx.recipeOf ? ctx.recipeOf(pc) || pc.recipe : pc.recipe;
      want.set(s.id, { pc, key: JSON.stringify([pc.x_m, pc.y_m, pc.z_m, pc.rotation, recipe, F.fl.elev]) });
    }
    for (const [id, G] of [...ghosts]) { const w = want.get(id); if (!w || w.key !== G.key) dropGhost(id); }
    for (const [id, w] of want) if (!ghosts.has(id)) { try { if (w.light) buildLightGhost(id, w.light, F, w.key); else buildGhost(id, w.pc, F, w.key); } catch (_) { /* a ghost that won't draw: its pin still stands */ } }
    for (const [id, G] of ghosts) for (const m of G.mats) m.opacity = id === cur ? fade : GHOST;
  }
  /** Before and after on a correction: the path of the move, dashed, between the stair and the ghost. */
  function syncOnion(F){
    const c = sugOf(cur), p = c ? pendingOf(c.id) : null;
    let from = null, to = null;
    if (c && c.kind === "light" && F && same(itemFloorId(c), F.fl.id)) {
      // Which light it is about: the line from the light to the symbol. Nothing moves.
      const snap = (c.match || {}).target_snap, g = c.geom || {};
      if (snap && (c.match || {}).relation === "correction" && ghostWanted(c) && Math.hypot(snap.x_m - g.x_m, snap.y_m - g.y_m) >= 0.05) { from = [snap.x_m, snap.y_m]; to = [g.x_m, g.y_m]; }
    } else if (c && c.kind === "stairs" && F && same(itemFloorId(c), F.fl.id)) {
      if (p && p.v === "correction") {
        const dr = ctx.draft(), q = dr.cur.pieces[p.piece], e = q && q[NOTE()] && q[NOTE()].sugs[c.id];
        if (q && e && e.was) { from = [e.was.x_m, e.was.y_m]; to = [q.x_m, q.y_m]; }
      } else if (!p && (c.match || {}).relation === "correction" && ghostWanted(c)) {
        const t = targetOf(c), g = c.geom || {};
        if (t) { from = [t.x_m, t.y_m]; to = [g.x_m, g.y_m]; }
      }
    }
    const key = from ? JSON.stringify([from, to, F.fl.elev]) : "";
    if (key === onionKey) return;
    onionKey = key;
    if (onion) { dropMesh(onion); onion = null; }
    if (from) { onion = dashMesh(dashTriangles([from, to], false, 0.18, 0.12, 0.07), F.fl.elev + 0.06); group.add(onion); }
  }

  // ── pins ──────────────────────────────────────────────────────────────────
  function pressPin(id, e){
    if (e) e.stopPropagation();
    if (suppressClick) { suppressClick = false; return; }
    goTo(id);
  }
  function syncPins(F, order){
    pinsEl.classList.toggle("touch", touchy());
    const here = new Set();
    order.forEach((s, i) => {
      if (!F || !same(itemFloorId(s), F.fl.id)) return;
      const st = stateOf(s);
      here.add(s.id);
      let P = pins.get(s.id);
      if (!P) {
        const el = d("button", "pl-pin");
        el.type = "button";
        el.addEventListener("click", guard((e) => pressPin(s.id, e)));
        el.addEventListener("pointerdown", guard((e) => {
          if (moving && s.id === cur) { e.preventDefault(); e.stopPropagation(); gesture = dragFrom(e, true); try { el.setPointerCapture(e.pointerId); } catch (_) { /* moved on the canvas instead */ } }
        }));
        el.addEventListener("pointermove", guard((e) => { if (gesture && gesture.pin) move(e); }));
        el.addEventListener("pointerup", guard((e) => { if (gesture && gesture.pin) { suppressClick = gesture.moved; up(e); } }));
        pinsEl.appendChild(el);
        P = { id: s.id, el, xf: "" };
        pins.set(s.id, P);
      }
      const word = (KIND_OF[s.kind] || KIND_OF.stairs).word, n = String(i + 1), el = P.el;
      if (el.dataset.n !== n || el.dataset.kind !== s.kind) { el.innerHTML = `${(KIND_OF[s.kind] || KIND_OF.stairs).glyph}<span>${n}</span>`; el.dataset.n = n; el.dataset.kind = s.kind; }
      el.dataset.state = st;
      el.classList.toggle("cur", s.id === cur);
      el.classList.toggle("moving", moving !== null && s.id === cur);
      el.title = `${n}: ${word} · ${PIN_SAYS[st] || st}`;
      el.setAttribute("aria-label", el.title);
    });
    for (const [id, P] of [...pins]) if (!here.has(id)) { P.el.remove(); pins.delete(id); }
    // The plans' names on both ghosts, when two plans disagree; the move in numbers beside a correction.
    const c = sugOf(cur), wantTags = new Map();
    if (c && card === "item" && F && same(itemFloorId(c), F.fl.id)) {
      const tw = twins(c).filter(t => t.sug);
      if (tw.length) { wantTags.set(c.id, planName(c.map_id)); for (const t of tw) wantTags.set(t.sug.id, planName(t.map_id)); }
    }
    for (const [id, el] of [...tags]) if (!wantTags.has(id)) { el.remove(); tags.delete(id); }
    for (const [id, text] of wantTags) {
      let el = tags.get(id);
      if (!el) { el = d("div", "pl-tag"); pinsEl.appendChild(el); tags.set(id, el); }
      el.textContent = text;
    }
  }
  const touchy = () => (ctx.root && ctx.root.clientWidth > 0 && ctx.root.clientWidth <= 600) || !!(typeof matchMedia === "function" && matchMedia("(pointer: coarse)").matches);
  const PIN_SAYS = { queued: "to check", new: "new, until Save", correction: "a correction, until Save", failure: "marked wrong", later: "later", right: "looks right",
    stale: "changed since you looked", unmatched: "no placed light here", kept_new: "kept as new", kept_correction: "kept as a correction" };
  /** Only when the view draws (it draws nothing at rest): pins where they are on
   *  screen, and a floor or a house redrawn under them. */
  function layout(){
    if (!mapAwake) return;
    const F0 = ctx.currentFloor ? ctx.currentFloor() : null, id = F0 ? String(F0.fl.id) : null, gen = ctx.shellGen ? ctx.shellGen() : 0;
    if (ghostsLate && ctx.FURN && ctx.FURN()) { ghostsLate = false; syncMap(); }
    const arrived = !!expectFloor && floorUi(expectFloor) === F0;
    if (arrived) expectFloor = null;
    if (id !== floorSeen || gen !== shell) {
      const moved = id !== floorSeen && floorSeen !== null;
      floorSeen = id; shell = gen;
      if (moved && !arrived && !expectFloor) floorByHand(F0);
      else syncMap();
    }
    const F = shownFloor();
    if (!F || !ctx.screenAt) return;
    const r0 = ctx.root.getBoundingClientRect();
    const list = [...pins.values()], gap = touchy() ? 54 : 46;
    const pts = list.map((P) => { const s = sugOf(P.id), at = s ? posOf(s) : null, q = at ? ctx.screenAt(F, at.x_m, at.y_m, 0.1) : null; return q ? [q[0] - r0.left, q[1] - r0.top] : null; });
    const placed = spreadPins(pts, gap);
    list.forEach((P, i) => {
      const q = placed[i], xf = q ? `translate(${q[0].toFixed(1)}px,${q[1].toFixed(1)}px) translate(-50%,-50%)` : "";
      if (xf !== P.xf) { P.xf = xf; P.el.style.transform = xf; P.el.style.display = q ? "" : "none"; }
      const t = tags.get(P.id);
      if (t) { if (q) { t.style.display = ""; t.style.transform = `translate(${(q[0] - P.el.offsetWidth / 2 - 6).toFixed(1)}px,${q[1].toFixed(1)}px) translate(-100%,-50%)`; } else t.style.display = "none"; }
    });
  }

  // ── going to an item ──────────────────────────────────────────────────────
  /** What covers the view: the toolbar on top, the card to the right (or, on a phone, below), the bar. */
  function padNow(){
    const r = ctx.root.getBoundingClientRect(), c = sheet.getBoundingClientRect(), of = (q) => { const e = ctx.root.querySelector(q); return e ? e.getBoundingClientRect() : null; };
    const tools = of(".la3d-tools"), bar = of(".la3d-bar"), under = c.width >= r.width * 0.8;
    return { top: tools ? Math.max(0, tools.bottom - r.top) : 0, right: c.width && !under ? Math.max(0, r.right - c.left) : 0,
             bottom: Math.max(c.width && under ? r.bottom - c.top : 0, bar ? r.bottom - bar.top : 0) };
  }
  /** A floor that shows well whole stays whole, so the house never leaves the view.
   *  Too small that way (a phone, a big house): the item with what is round it. */
  function flyToItem(s){
    if (!ctx.flySpot || !s) return;
    const F = floorUi(itemFloorId(s)), at = posOf(s);
    if (!F || num(at.x_m) === null) return;
    const xs = [], ys = [], pad = padNow(), r0 = ctx.root.getBoundingClientRect();
    for (const r of F.rooms || []) for (const p of r.pts || []) { xs.push(p[0]); ys.push(p[1]); }
    const room = Math.min(r0.width - pad.right, r0.height - pad.top - pad.bottom), most = room > 0 ? Math.max(5, room / MIN_PX_M) : SPOT_M;
    const x0 = Math.min(...xs), x1 = Math.max(...xs), y0 = Math.min(...ys), y1 = Math.max(...ys), big = Math.max(x1 - x0, y1 - y0) + 2;
    if (!xs.length || big > most) ctx.flySpot(F, at.x_m, at.y_m, most, pad);
    else ctx.flySpot(F, (x0 + x1) / 2, (y0 + y1) / 2, big, pad);
  }
  function goTo(id, fly = true){
    const s = sugOf(id);
    if (!s) return;
    cur = id; card = "item"; failing = null; moving = null; nearOpen = false; fade = GHOST; askDismiss = false; askUndo = false;
    const fid = itemFloorId(s), F = shownFloor();
    planPick.delete(String(fid));
    if (!F || !same(fid, F.fl.id)) { const G = floorUi(fid); if (G) { expectFloor = String(G.fl.id); ctx.setTopFloor(String(G.fl.id)); } }
    redraw();
    if (fly) flyToItem(s);
  }
  /** The floor changed by hand: this floor's first item, after a recap if verdicts wait for one. */
  function floorByHand(F){
    const order = orderNow(), mine = order.filter(s => F && same(itemFloorId(s), F.fl.id));
    const c = sugOf(cur);
    if (!c || !F || !same(itemFloorId(c), F.fl.id)) {
      const first = mine.find(s => isOpen(stateOf(s))) || mine[0] || null;
      cur = first ? first.id : cur;
      moving = null; failing = null;
      card = vSinceRecap ? "recap" : first ? "item" : "floor";
      if (card === "recap") { vSinceRecap = 0; lastRecapAt = vCount; }
      nextFloorItem = null;
      redraw();
      if (first) flyToItem(first);
      return;
    }
    redraw();
  }
  /** Where a verdict leads: a recap every 25, the floor's what's-missing pass when it is done, else the next item. */
  function advance(fromId){
    moving = null; failing = null; nearOpen = false;
    if (vCount - lastRecapAt >= RECAP_EVERY) { lastRecapAt = vCount; vSinceRecap = 0; card = "recap"; redraw(); return; }
    continueFrom(fromId);
  }
  function continueFrom(fromId){
    const order = orderNow(), from = sugOf(fromId), next = nextOpen(order, fromId, stateOf);
    if (from && (!next || !same(itemFloorId(next), itemFloorId(from)))) { card = "floor"; nextFloorItem = next ? next.id : null; lastRecapAt = vCount; vSinceRecap = 0; redraw(); return; }
    if (next) goTo(next.id); else { card = "floor"; nextFloorItem = null; redraw(); }
  }
  const counted = (id, how) => { vCount++; vSinceRecap++; acts.push({ id, how }); if (acts.length > 100) acts.shift(); };
  function step_(dir){
    const order = orderNow();
    if (!order.length) return;
    const at = order.findIndex(s => s.id === cur);
    const next = order[(Math.max(at, 0) + dir + order.length) % order.length];
    if (next) goTo(next.id);
  }

  // ── the verdicts on the map: the list's own, then on to the next ──────────
  async function vServer(s, v, why){
    if (!await verdict(s, v, why)) return;
    counted(s.id, v);
    advance(s.id);
  }
  function vNew(s){
    if (s.kind === "railing") { vRail(s); return; }
    const had = pendings().length;
    keepNew(s);
    if (pendings().length > had) { counted(s.id, "draft"); advance(s.id); }
  }
  function vTake(s, target = null){
    const had = pendings().length;
    takeAi(s, target);
    if (pendings().length > had) { counted(s.id, "draft"); advance(s.id); }
  }
  function vKind(s){
    const had = pendingOf(s.id);
    keepLight(s);
    if (!had && pendingOf(s.id)) { counted(s.id, "draft"); advance(s.id); }
  }
  function vRail(s){
    const pick = railPick.get(s.id) || {};
    if (!railHome(s)) { ctx.hint("Keep its stair first: there is nothing to put a rail on yet.", true); return; }
    if (!pick.side) { ctx.hint("Pick a side first: the AI can't tell it for sure.", true); return; }
    const had = pendings().length;
    keepRail(s);
    if (pendings().length > had) { counted(s.id, "draft"); advance(s.id); }
  }
  /** Move by hand: accept it, then it is yours to drag; Done goes on. */
  function vMove(s){
    const had = pendings().length, m = s.match || {};
    if (!pendingOf(s.id)) {
      if (m.relation === "correction") takeAi(s); else keepNew(s);
      if (pendings().length > had) counted(s.id, "draft");
    }
    const p = pendingOf(s.id);
    if (!p) return;
    moving = p.piece;
    ctx.hint("Drag the stair or its pin into place. Nothing is kept until Save.");
    redraw();
  }
  /** Move by hand lasts as long as its item is in the draft: Undo or Discard ends it, so no drag goes outside the item's note. */
  const pendingPiece = (id) => pendings().some(p => p.piece === id);
  function holdMove(){ if (moving && !pendingPiece(moving)) moving = null; return !!moving; }
  function moveDone(){
    if (!moving) return;
    const id = cur;
    moving = null;
    advance(id);
  }
  function vTakeBack(s){
    const p = pendingOf(s.id);
    if (p) takeBack(s); else verdict(s, "back");
    moving = null;
  }
  /** Z: the last verdict, as it was given: a draft step by Undo, one written at click by the server's take-back. */
  function undoLast(){
    const a = acts.pop();
    if (!a) { ctx.undo(); return; }
    const s = sugOf(a.id);
    if (a.how === "draft") ctx.undo();
    else if (s) verdict(s, "back");
    vCount = Math.max(0, vCount - 1); vSinceRecap = Math.max(0, vSinceRecap - 1);
    if (s) goTo(s.id, false);
  }
  /** The one bulk action: everything unvetted goes to Later, never to wrong. */
  async function dismissRest(){
    askDismiss = false;
    const rest = orderNow().filter(s => stateOf(s) === "queued");
    for (const s of rest) if (!await verdict(s, "later")) break;
    ctx.hint(`${rest.length} put off to Later. Nothing was marked wrong.`);
    redraw();
  }

  // ── a finger, a pen or the mouse on the view, while it shows ──────────────
  const rayer = THREE ? new THREE.Raycaster() : null, ndc = THREE ? new THREE.Vector2() : null, levelPl = THREE ? new THREE.Plane() : null;
  const hitV = THREE ? new THREE.Vector3() : null, UP = THREE ? new THREE.Vector3(0, 1, 0) : null;
  function onFloor(x, y, F){
    const r = ctx.rect(), cam = ctx.camera();
    if (!r || !r.width || !r.height || !cam || !F) return null;
    ndc.set((x - r.left) / r.width * 2 - 1, -((y - r.top) / r.height) * 2 + 1);
    cam.updateMatrixWorld();
    rayer.setFromCamera(ndc, cam);
    levelPl.set(UP, -F.fl.elev);
    return rayer.ray.intersectPlane(levelPl, hitV) ? [hitV.x, hitV.z] : null;
  }
  function dragFrom(e, pin){
    const dr = ctx.draft(), q = dr && moving ? dr.cur.pieces[moving] : null, F = q ? floorUi(q.floor_id) : null, at = F ? onFloor(e.clientX, e.clientY, F) : null;
    if (!q || !at) return null;
    return { id: moving, F, off: pin ? [0, 0] : [q.x_m - at[0], q.y_m - at[1]], x0: e.clientX, y0: e.clientY, moved: false, pin: !!pin, group: `plan-drag:${moving}:${Math.random()}` };
  }
  function down(e){
    const F = shownFloor();
    if (holdMove()) {
      const dr = ctx.draft(), q = dr ? dr.cur.pieces[moving] : null, at = F ? onFloor(e.clientX, e.clientY, F) : null;
      const corners = q && ctx.STOREY && ctx.STOREY.footprint ? ctx.STOREY.footprint(q) : null;
      if (at && corners && inPolygon(at[0], at[1], corners)) { gesture = dragFrom(e, false); if (gesture) return "drag"; }
    } else if (F) {
      const at = onFloor(e.clientX, e.clientY, F);
      const g = at ? [...ghosts.values()].find(G => G.corners && inPolygon(at[0], at[1], G.corners)) : null;
      if (g && g.id !== cur) { gesture = { tap: g.id, x0: e.clientX, y0: e.clientY }; return "swallow"; }
    }
    return e.pointerType === "touch" || e.pointerType === "pen" ? "swallow" : "pan";
  }
  function move(e){
    const g = gesture;
    if (!g || !g.id) return;
    if (!pendingPiece(g.id)) { gesture = null; return; }
    if (!g.moved && Math.hypot(e.clientX - g.x0, e.clientY - g.y0) <= 6) return;
    g.moved = true;
    const at = onFloor(e.clientX, e.clientY, g.F);
    if (!at) return;
    const x = Math.round((at[0] + g.off[0]) * 1000) / 1000, y = Math.round((at[1] + g.off[1]) * 1000) / 1000;
    ctx.change((c) => { const q = c.pieces[g.id]; if (q) { q.x_m = x; q.y_m = y; } }, g.group, { piece: g.id });
  }
  function up(e){
    const g = gesture;
    gesture = null;
    if (!g) return;
    if (g.tap) { if (Math.hypot(e.clientX - g.x0, e.clientY - g.y0) <= 6) goTo(g.tap); return; }
    if (g.moved) { if (ctx.redrawHouse) ctx.redrawHouse(); redraw(); }
  }
  function hover(e){
    if (!holdMove()) return "";
    const F = shownFloor(), dr = ctx.draft(), q = dr ? dr.cur.pieces[moving] : null, at = F ? onFloor(e.clientX, e.clientY, F) : null;
    const corners = q && ctx.STOREY && ctx.STOREY.footprint ? ctx.STOREY.footprint(q) : null;
    return at && corners && inPolygon(at[0], at[1], corners) ? "grab" : "";
  }
  /** While the map shows and focus is in no field: N, C, F, L, Enter, Backspace, Z, P. True: it was ours.
   *  N, C, F and L are always ours here, doing something or not, held or not, so none reaches Home Assistant's
   *  own one-letter shortcuts ("c" is its command palette); E, D, M and A go on to it. The map off the page
   *  (another view, another Home Assistant page: the slot isn't told): no key is ours.
   *  (Inside the panel's shadow root a window listener sees its host as the target: composedPath has the real one.) */
  function key(e){
    if (!mapAwake || !ctx.root.isConnected || e.ctrlKey || e.metaKey || e.altKey) return false;
    const t = (typeof e.composedPath === "function" && e.composedPath()[0]) || e.target;
    if (t && (/^(input|textarea|select)$/i.test(String(t.tagName || t.localName || "")) || t.isContentEditable)) return false;
    const mine = /^[ncfl]$/i.test(String(e.key));
    if (e.repeat || (ctx.saving && ctx.saving()) || ctx.root.querySelector(".la3d-ask.on")) return mine;
    // Enter on a button in the card is that button (Keep mine, where it starts); on a pin, the next item.
    const k = e.key, onBtn = !!(t && String(t.tagName).toUpperCase() === "BUTTON" && !(t.classList && t.classList.contains("pl-pin")));
    if (k === "Escape") {
      if (moving) { moveDone(); return true; }
      if (failing) { failing = null; redraw(); return true; }
      return false;
    }
    if (k === "p" || k === "P") { planOn = !planOn; if (planMesh) planMesh.visible = planOn; redraw(); if (ctx.render) ctx.render(); return true; }
    if (k === "z" || k === "Z") { undoLast(); return true; }
    if (card !== "item") {
      if (k === "Enter" && !onBtn) { onward(); return true; }
      return mine;
    }
    if (k === "Enter") { if (onBtn) return false; if (moving) moveDone(); else step_(1); return true; }
    if (k === "Backspace") { step_(-1); return true; }
    const s = sugOf(cur);
    if (!s || busy) return mine;
    const low = k.length === 1 ? k.toLowerCase() : "";
    const st = stateOf(s), open = st === "queued" || st === "stale" || st === "later" || st === "right", m = s.match || {};
    if (low === "n" && open && !movedPlan(s.map_id) && s.kind !== "light" && !(s.kind === "railing" && m.relation === "correction")) { vNew(s); return true; }
    if (low === "c" && open && st !== "stale") {
      if (s.kind === "light") { if (m.relation === "correction" && !movedPlan(s.map_id)) vKind(s); }
      else if (m.relation === "correction" && s.kind === "stairs") vTake(s);
      else if (m.relation === "correction") vRail(s);
      else if (m.relation === "new" && !m.held && (m.near || []).length) { nearOpen = true; redraw(); }
      return true;
    }
    if (low === "f" && open) { if (failing === s.id) vServer(s, "failure", "nothing_there"); else { failing = s.id; redraw(); } return true; }
    if (low === "l" && open && st !== "stale") { vServer(s, "later"); return true; }
    return mine;
  }
  /** On from a recap, or from the floor's what's-missing pass. */
  function onward(){
    const c = cur, wasFloor = card === "floor", go = nextFloorItem;
    card = "item";
    if (wasFloor) {
      nextFloorItem = null;
      if (go && sugOf(go)) goTo(go); else redraw();
      return;
    }
    continueFrom(c);
  }

  // ── the card ──────────────────────────────────────────────────────────────
  function vbtn(text, title, act, cls, keyHint, off){
    const b = btn("", title, act, cls);
    b.textContent = text;
    if (keyHint) { const kb = d("kbd", null, keyHint); b.appendChild(kb); }
    b.disabled = !!off || busy;
    return b;
  }
  /** The plan: on or off, how strong, which of two. */
  function paintPlanRow(F){
    const list = planChoices(F), ctl = d("div", "pl-ctl pl-sep");
    if (!list.length && !planNow) {
      const c = sugOf(cur);
      ctl.appendChild(d("span", null, c && movedPlan(c.map_id) ? "The plan moved: read it again." : "No plan to show on this floor."));
      sheet.appendChild(ctl);
      return;
    }
    const tog = d("button", "pl-mini", "Plan");
    tog.type = "button"; tog.title = "The plan under the house, on or off (P)";
    tog.setAttribute("aria-pressed", String(planOn));
    tog.addEventListener("click", guard(() => { planOn = !planOn; if (planMesh) planMesh.visible = planOn; redraw(); if (ctx.render) ctx.render(); }));
    ctl.appendChild(tog);
    const r = d("input");
    r.type = "range"; r.min = "0.15"; r.max = "1"; r.step = "0.05"; r.value = String(opacity);
    r.setAttribute("aria-label", "How strongly the plan shows");
    r.title = "How strongly the plan shows";
    r.addEventListener("input", guard(() => { opacity = Number(r.value); if (planMesh) planMesh.material.opacity = opacity; if (ctx.render) ctx.render(); }));
    r.addEventListener("change", () => { r.blur(); });
    ctl.appendChild(r);
    sheet.appendChild(ctl);
    const names = new Map(list.map(p => [p.map_id, p]));
    if (planNow) names.set(planNow.map_id, planNow);
    if (names.size > 1) {
      const row = d("div", "pl-plans");
      for (const p of names.values()) {
        const b = d("button", "pl-mini", p.name || "a plan");
        b.type = "button"; b.title = `Show ${p.name || "this plan"} under the house`;
        b.setAttribute("aria-pressed", String(!!planNow && planNow.map_id === p.map_id));
        b.addEventListener("click", guard(() => { planPick.set(String(F.fl.id), p.map_id); redraw(); }));
        row.appendChild(b);
      }
      sheet.appendChild(row);
    }
    if (planGone) sheet.appendChild(d("div", "pl-sub2", "The plan's picture wouldn't open here."));
  }
  function paintFoot(){
    const pend = pendings();
    if (pend.length) {
      const n = pend.filter(p => p.v === "new" && p.made).length, c = pend.filter(p => p.v === "correction").length, l = pend.filter(p => p.rail).length;
      const words = [n ? `${n} new` : "", c ? `${c} correction${c === 1 ? "" : "s"}` : "", l ? `${l} railing${l === 1 ? "" : "s"}` : ""].filter(Boolean).join(", ");
      const keep = btn(`Keep ${words} (one undo for the whole session)`, "Save: into your 3D house, with a safety backup and one undo", () => ctx.save(), "pl-keep");
      keep.disabled = busy || !!(ctx.saving && ctx.saving());
      sheet.appendChild(keep);
    }
    const row = d("div", "pl-more");
    const tog = d("button", "pl-mini", more ? "Less" : "More");
    tog.type = "button"; tog.setAttribute("aria-expanded", String(more));
    tog.addEventListener("click", guard(() => { more = !more; askDismiss = false; redraw(); }));
    row.appendChild(tog);
    const mini = (text, title, act) => { const b = d("button", "pl-mini", text); b.type = "button"; b.title = title; b.disabled = busy; b.addEventListener("click", guard((e) => { e.stopPropagation(); act(); })); row.appendChild(b); return b; };
    if (more) {
      const rest = orderNow().filter(s => stateOf(s) === "queued").length;
      if (rest) mini("Dismiss the rest", "Puts everything you haven't looked at off to Later. It never marks anything wrong.", () => { askDismiss = true; redraw(); });
      mini("What's missing?", "What the AI didn't find on this floor", () => { card = "floor"; nextFloorItem = null; redraw(); });
      mini("As a list", "The same items, one row each", () => { listAsked = true; redraw(); });
      mini("Manage ignored", "The finds you marked wrong, remembered per plan", () => openIgnored());
      mini("Read again", "Back to the plans and the button", () => readAgain());
      if (undoInfo) mini(undoInfo.puts_back ? `Put back ${undoInfo.items}` : `Undo this session (${undoInfo.items})`, "Takes back what this session kept; anything changed since is left", () => { askUndo = true; redraw(); });
    }
    sheet.appendChild(row);
    if (askDismiss) {
      const rest = orderNow().filter(s => stateOf(s) === "queued").length;
      sheet.appendChild(d("div", "pl-say", `${rest} item${rest === 1 ? "" : "s"} you haven't looked at go to Later. None is marked wrong or kept.`));
      const a = d("div", "pl-more");
      const go = d("button", "pl-mini", "Dismiss them"); go.type = "button"; go.addEventListener("click", guard(() => dismissRest()));
      const no = d("button", "pl-mini", "Cancel"); no.type = "button"; no.addEventListener("click", guard(() => { askDismiss = false; redraw(); }));
      a.append(go, no);
      sheet.appendChild(a);
    }
    if (askUndo && undoInfo) {
      sheet.appendChild(d("div", "pl-say", undoInfo.puts_back ? "Put those items back in your 3D house?" : "Take what this session kept out of your 3D house? Anything you changed since is left as it is."));
      const a = d("div", "pl-more");
      const go = d("button", "pl-mini", undoInfo.puts_back ? "Put back" : "Undo"); go.type = "button"; go.addEventListener("click", guard(() => undoSession()));
      const no = d("button", "pl-mini", "Cancel"); no.type = "button"; no.addEventListener("click", guard(() => { askUndo = false; redraw(); }));
      a.append(go, no);
      sheet.appendChild(a);
    }
  }
  function tallyWords(states){
    const t = tally(states), bits = [];
    if (t.new) bits.push(`${t.new} new`);
    if (t.correction) bits.push(`${t.correction} correction${t.correction === 1 ? "" : "s"}`);
    if (t.right) bits.push(`${t.right} looked right`);
    if (t.failure) bits.push(`${t.failure} marked wrong`);
    if (t.later) bits.push(`${t.later} later`);
    if (t.open) bits.push(`${t.open} still to check`);
    return bits.join(", ") || "nothing yet";
  }
  /** Every 25 verdicts, and at a floor change: where this stands, in a person's own numbers. */
  function paintRecap(){
    const order = orderNow();
    sheet.appendChild(d("div", "pl-title", "So far"));
    sheet.appendChild(d("div", "pl-say", `${tallyWords(order.map(stateOf))}.`));
    sheet.appendChild(d("div", "pl-cue", "Look at the plan again: the AI misses things too, and the queue can't show what it missed."));
    const recs = recordLines();
    for (const line of recs) sheet.appendChild(d("div", "pl-rec", line));
    const a = d("div", "pl-v");
    const go = vbtn("Carry on", "On to the next item (Enter)", () => onward(), "new wide", "Enter");
    a.appendChild(go);
    sheet.appendChild(a);
    if (!focusBtn) focusBtn = go;
  }
  /** One floor's what's-missing pass: what the queue can't show. */
  function paintFloorDone(F){
    const fid = F ? F.fl.id : null, name = F ? F.fl.name || String(fid) : "This floor";
    const order = orderNow(), mine = order.filter(s => F && same(itemFloorId(s), fid));
    sheet.appendChild(d("div", "pl-title", `${name}: what's missing?`));
    sheet.appendChild(d("div", "pl-say", `On this floor: ${tallyWords(mine.map(stateOf))}.`));
    const dr = ctx.draft && ctx.draft();
    const stairs = dr && ctx.STOREY && fid !== null ? Object.values(dr.cur.pieces || {}).filter(p => ctx.STOREY.isStairs(p) && same(p.floor_id, fid) && !(p[NOTE()] && Object.values(p[NOTE()].sugs || {}).some(e => e.made)))
      .map(p => ({ id: p.id, label: p.label, x: p.x_m, y: p.y_m, room: roomOf({ floor_id: fid, id: "", geom: {} }, { x_m: p.x_m, y_m: p.y_m }) })) : [];
    const lines = fid === null ? [] : missingLines(fid, sugs(), (sess.plans || []).map(p => ({ ...p, floor_id: p.floor_id ?? ((info && info.plans) || []).find(q => q.map_id === p.map_id)?.floor_id })), stairs, same);
    const ul = d("ul", "pl-miss");
    if (!lines.length) ul.appendChild(d("li", null, "Nothing else to say on this floor."));
    for (const line of lines) ul.appendChild(d("li", null, line));
    sheet.appendChild(ul);
    const a = d("div", "pl-v");
    const go = nextFloorItem && sugOf(nextFloorItem);
    const on = vbtn(go ? `On to ${floorName(itemFloorId(sugOf(nextFloorItem)))}` : "Done", go ? "The next floor's items (Enter)" : "Back to the map (Enter)", () => onward(), "new");
    if (!go) on.style.gridColumn = "span 2";
    a.appendChild(on);
    if (go) a.appendChild(vbtn("Stay here", "Back to this floor's items", () => { nextFloorItem = null; card = "item"; redraw(); }));
    if (ctx.addByHand) a.appendChild(vbtn("Add by hand", "Opens Build ▾ so you can place what the AI missed", () => {
      const h = ctx.host(), kind = "stairs";
      if (h && typeof h.telemetry === "function") { try { h.telemetry(`plan_ai_missing_added:${kind}`); } catch (_) { /* a count, never in the way */ } }
      ctx.addByHand();
    }));
    sheet.appendChild(a);
    if (!focusBtn) focusBtn = on;
  }
  function recordLines(only = null){
    const out = [];
    for (const [kind, r] of Object.entries(record || {})) {
      if ((only && kind !== only) || !r || !(r.of >= 5)) continue;
      out.push(`${kind === "railing" ? "Railings" : kind === "light" ? "Lights" : "Stairs"}: ${r.right} of ${r.of} right in this house so far.`);
    }
    return out;
  }
  function paintItem(s, F){
    const order = orderNow(), at = order.findIndex(q => q.id === s.id), st = stateOf(s), m = s.match || {}, g = s.geom || {};
    const q = d("div", "pl-q"), room = roomOf(s, posOf(s));
    const prev = btn("‹", "The one before (Backspace)", () => step_(-1)), next = btn("›", "The next one (Enter)", () => step_(1));
    q.append(d("div", "pl-title", [(KIND_OF[s.kind] || KIND_OF.stairs).word, floorName(itemFloorId(s)), room].filter(Boolean).join(" · ")), d("span", "pl-of", `${at + 1} of ${order.length}`), prev, next);
    sheet.appendChild(q);
    const seen = Array.isArray(s.seen_on) && s.seen_on.length > 1 ? `seen on ${s.seen_on.length} plans` : planName(s.map_id);
    const size = s.kind === "stairs" ? `${m1(g.width_m)} × ${m1(g.depth_m)} m` : "";
    sheet.appendChild(d("div", "pl-sub2", [seen, size].filter(Boolean).join(" · ")));
    const decided = !(st === "queued" || st === "stale" || st === "later" || st === "right");
    if (!decided && CUE[s.kind]) sheet.appendChild(d("div", "pl-cue", CUE[s.kind]));
    // What it is, in words at the point of deciding.
    const label = m.target_snap && m.target_snap.label ? m.target_snap.label : "this stair";
    const t = s.kind === "stairs" ? targetOf(s) : null, mv = t && num(g.x_m) !== null ? moveWords(g.x_m - t.x_m, g.y_m - t.y_m, ctx.compass ? ctx.compass() : null) : `${m1(m.distance_m)} m`;
    const say = (text) => sheet.appendChild(d("div", "pl-say", text));
    if (st === "stale") say(movedPlan(s.map_id) ? "The plan moved: read it again." : "Changed since you looked.");
    if (st === "queued" || st === "later" || st === "right") {
      if (s.kind === "stairs" && m.relation === "correction") {
        say(m.hand === true ? `You placed this one. The AI puts it ${mv}. Keep yours unless the plan says otherwise.` : `The AI placed this one too. This read puts it ${mv}.`);
        if (t && g.shape && ((t.recipe && t.recipe.params && t.recipe.params.shape) || "straight") !== g.shape) say(`The AI read it as ${g.shape === "u" ? "a U" : g.shape === "l" ? "an L" : `a ${g.shape} flight`}: only where it stands can change here.`);
      } else if (s.kind === "stairs" && m.relation === "stacked") say("A second staircase here, stacked? Say which floor it climbs from.");
      else if (s.kind === "stairs" && (m.near_names || []).length) say(`Near ${m.near_names.join(" and ")}.`);
      if (s.kind === "railing" && m.relation === "correction") say(`A rail on another side of ${label}.`);
      if (s.kind === "railing" && g.side) say(`The AI says ${g.side}.`);
    }
    if (s.kind === "light") for (const line of lightLines(s, st === "queued" || st === "later" || st === "right")) say(line);
    for (const tw of twins(s)) say(`${planName(s.map_id)} puts it here, ${planName(tw.map_id)} there, ${m1(tw.distance_m)} m apart. Nothing wins by itself.`);
    if (m.held === "frame") say("Position may be coarse: this AI's picture size isn't known.");
    else if (m.held === "eye") say(s.kind === "light" ? "The plan was placed by eye, so this may be another light." : "The plan was placed by eye, so the offset may be the plan's.");
    const pend = pendingOf(s.id);
    if (moving) {
      const pc = ctx.draft().cur.pieces[moving], dist = pc && num(g.x_m) !== null ? Math.hypot(pc.x_m - g.x_m, pc.y_m - g.y_m) : 0;
      say(dist >= 0.05 ? `Drag it into place: ${moveWords(pc.x_m - g.x_m, pc.y_m - g.y_m, ctx.compass ? ctx.compass() : null)} from where the AI put it.` : "Drag the stair or its pin into place.");
      const a = d("div", "pl-v");
      const done = vbtn("Done", "That's where it goes (Enter)", () => moveDone(), "new", "Enter");
      a.append(done, vbtn("Take that back", "Out of your draft: nothing was kept", () => { vTakeBack(s); redraw(); }));
      a.children[1].style.gridColumn = "span 2";
      sheet.appendChild(a);
      if (!focusBtn) focusBtn = done;
    } else if (pend) {
      say(s.kind === "light" ? `Drawn as ${kindWord(m.want_kind)} in your draft: nothing is kept until Save.` : pend.v === "correction" ? `A correction in your draft: nothing is kept until Save.` : "New, in your draft: nothing is kept until Save.");
      const a = d("div", "pl-v");
      const back = vbtn("Take that back", "Out of your draft: nothing was kept", () => { vTakeBack(s); redraw(); });
      back.style.gridColumn = "span 2";
      a.appendChild(back);
      if (s.kind === "stairs") a.appendChild(vbtn("Move by hand", "Drag it into place", () => vMove(s)));
      sheet.appendChild(a);
    } else if (st === "unmatched") {
      if (canOpenAtlas()) {
        const a = d("div", "pl-v");
        a.appendChild(vbtn("Open Mapping → Atlas builder", "Place a light there yourself: the plans never place one", () => openAtlas(s), "wide"));
        sheet.appendChild(a);
      } else say("Place one in Mapping → Atlas builder.");
    } else if (st === "kept_new" || st === "kept_correction") {
      say(st === "kept_new" ? "Kept as new. Undo this session is under More." : "Kept as a correction. Undo this session is under More.");
    } else if (st === "failure") {
      const why = s.verdict && s.verdict.why;
      say(`Marked wrong: ${WHY_WORD[why] || why || "no reason given"}.`);
      const a = d("div", "pl-v");
      a.appendChild(vbtn("Take that back", "Back to the queue", () => verdict(s, "back"), "wide"));
      sheet.appendChild(a);
    } else if (failing === s.id) {
      say("What's wrong with it?");
      const a = d("div", "pl-v");
      for (const [k, word] of WHY) {
        const b = vbtn(word, `Mark it wrong: ${word.toLowerCase()} (noted at once)`, () => vServer(s, "failure", k), "bad");
        if (k === "nothing_there" && !focusBtn) focusBtn = b;
        a.appendChild(b);
      }
      a.appendChild(vbtn("Never mind", "Keep it in the queue (Esc)", () => { failing = null; redraw(); }));
      sheet.appendChild(a);
    } else paintVerdicts(s, st);
    const rec = recordLines(s.kind);
    for (const line of rec) sheet.appendChild(d("div", "pl-rec", line));
    if (s.kind === "stairs" && m.relation === "correction" && ghostWanted(s) && !pend) {
      const ctl = d("label", "pl-ctl");
      ctl.appendChild(d("span", null, "Fade"));
      const r = d("input");
      r.type = "range"; r.min = "0"; r.max = "1"; r.step = "0.05"; r.value = String(fade);
      r.setAttribute("aria-label", "Fade between your stair and the AI's ghost");
      r.title = "Your stair is solid; the AI's ghost is dashed. Fade it in and out.";
      r.addEventListener("input", guard(() => { fade = Number(r.value); const G = ghosts.get(s.id); if (G) { for (const mat of G.mats) mat.opacity = fade; } if (ctx.render) ctx.render(); }));
      r.addEventListener("change", () => { r.blur(); });
      ctl.appendChild(r);
      sheet.appendChild(ctl);
    }
  }
  /** A light's verdicts: its kind or not. No New, no Move by hand: a light's place is never touched from here. */
  function paintLightVerdicts(s, st){
    const m = s.match || {}, moved = movedPlan(s.map_id), stale = st === "stale", a = d("div", "pl-v"), b2 = d("div", "pl-v");
    if (m.relation === "correction" && !stale) {
      const take = vbtn("Take the kind", `Draw it as ${kindWord(m.want_kind)}, in your draft`, () => vKind(s), "cor", "C", moved);
      a.append(take, vbtn("Keep mine", "It stays as it is (noted at once)", () => vServer(s, "failure", "already_here")));
      a.children[1].style.gridColumn = "span 2";
      if (!focusBtn && !moved) focusBtn = take;
    }
    b2.appendChild(vbtn("Failure", "Mark it wrong, with a reason (noted at once)", () => { failing = s.id; redraw(); }, "bad", "F"));
    b2.appendChild(vbtn("Looks right", "The AI got this one right (noted at once; nothing is written to your house)", () => vServer(s, "right"), null, null, stale || st === "right"));
    b2.appendChild(vbtn("Later", "Come back to it (noted at once)", () => vServer(s, "later"), null, "L", stale || st === "later"));
    if (a.children.length) sheet.appendChild(a);
    sheet.appendChild(b2);
    if (st === "right" || st === "later") { const c = d("div", "pl-v"); c.appendChild(vbtn("Take that back", "Back to the queue", () => verdict(s, "back"), "wide")); sheet.appendChild(c); }
  }
  function paintVerdicts(s, st){
    if (s.kind === "light") { paintLightVerdicts(s, st); return; }
    const m = s.match || {}, moved = movedPlan(s.map_id), stale = st === "stale", rail = s.kind === "railing";
    if (rail && !stale) {
      const box = d("div");
      railActs(s, box);
      for (const kid of [...box.children]) if (kid.tagName === "BUTTON") kid.remove();   // its Keep this rail is the verdict row's New or Correction here
      sheet.appendChild(box);
    }
    if (s.kind === "stairs" && m.relation === "stacked" && !moved && !stale) sheet.appendChild(floorChoice(s));
    const a = d("div", "pl-v"), b2 = d("div", "pl-v four");
    const noRail = rail ? !railHome(s) || !(railPick.get(s.id) || {}).side : moved;
    const fixing = s.kind === "stairs" && m.relation === "correction" && !stale, rest = fixing ? b2 : a;
    if (fixing) {
      // Keep mine is where a hand-placed stair starts; the AI's position only where the AI placed it too.
      const mine = vbtn("Keep mine", "Yours stays where it is (noted at once)", () => vServer(s, "failure", "already_here"), m.hand === true ? "new" : null);
      const take = vbtn("Take the AI's position", "A correction: move it there in your draft", () => vTake(s), "cor", "C", moved);
      const hand = vbtn("Move by hand", "A correction: accept it, then drag it into place", () => vMove(s), null, null, moved);
      if (m.hand === true) { a.append(mine, take, hand); if (!focusBtn) focusBtn = mine; } else { a.append(take, mine, hand); if (!focusBtn) focusBtn = take; }
      b2.appendChild(vbtn("New", "A staircase of its own, beside the one you have", () => vNew(s), null, "N", moved));
    } else {
      const canCorrect = !stale && !moved && (rail ? m.relation === "correction" : m.relation === "new" && !m.held && (m.near || []).length > 0);
      a.appendChild(vbtn("New", rail ? "This rail, on its stair, in your draft" : "Add it to your draft: nothing is kept until Save", () => vNew(s), "new", "N", rail ? noRail || m.relation === "correction" : moved));
      a.appendChild(vbtn("Correction", canCorrect ? (rail ? "This side instead, in your draft" : "It is one of the stairs near it") : "Nothing near it to correct", () => { if (rail) vRail(s); else { nearOpen = !nearOpen; redraw(); } }, "cor", "C", !canCorrect || (rail && noRail)));
    }
    rest.appendChild(vbtn("Failure", "Mark it wrong, with a reason (noted at once)", () => { failing = s.id; redraw(); }, "bad", "F"));
    rest.appendChild(vbtn("Looks right", "The AI got this one right (noted at once; nothing is written to your house)", () => vServer(s, "right"), null, null, stale || st === "right"));
    rest.appendChild(vbtn("Later", "Come back to it (noted at once)", () => vServer(s, "later"), null, "L", stale || st === "later"));
    if (s.kind === "stairs" && m.relation !== "correction") rest.appendChild(vbtn("Move by hand", "Accept it, then drag it into place", () => vMove(s), null, null, moved));
    sheet.appendChild(a);
    if (fixing) sheet.appendChild(b2);
    if (st === "right" || st === "later") { const c = d("div", "pl-v"); c.appendChild(vbtn("Take that back", "Back to the queue", () => verdict(s, "back"), "wide")); sheet.appendChild(c); }
    if (nearOpen && !rail) {
      const c = d("div", "pl-v");
      for (const [i, id] of (m.near || []).entries()) if (m.near_snaps && m.near_snaps[id]) c.appendChild(vbtn(`A correction of ${(m.near_names || [])[i] || "that stair"}`, "Move that stair here in your draft", () => vTake(s, id), "cor wide"));
      sheet.appendChild(c);
    }
  }
  function paintMap(){
    const h = d("h4");
    h.appendChild(d("span", null, "Add data via plans"));
    h.appendChild(d("span", "pl-chip", "EXPERIMENTAL"));
    sheet.appendChild(h);
    const strip = d("div", "pl-strip", STRIP.stairs);
    sheet.appendChild(strip);
    errLine();
    const order = orderNow();
    if (!sugOf(cur) || stateOf(sugOf(cur)) === null) {
      // Start where the person is, when they picked a floor with items left; else at the first. Always one floor, never All.
      const F = ctx.currentFloor ? ctx.currentFloor() : null, picked = ctx.picked ? ctx.picked() : null;
      const first = (picked ? order.find(s => F && same(itemFloorId(s), F.fl.id) && isOpen(stateOf(s))) : null) || order.find(s => isOpen(stateOf(s))) || order[0];
      cur = first ? first.id : null;
      if (first) { const G = floorUi(itemFloorId(first)); if (G && (!picked || !F || G !== F)) { if (G !== F) expectFloor = String(G.fl.id); ctx.setTopFloor(String(G.fl.id)); } flyDue = true; }
    }
    const s = sugOf(cur), F = shownFloor();
    strip.textContent = STRIP[(s && s.kind) || "stairs"] || STRIP.stairs;
    syncPlan(F);                                         // so the plan row below says the plan that shows
    if (card === "recap") paintRecap();
    else if (card === "floor") paintFloorDone(F);
    else if (s) paintItem(s, F);
    paintPlanRow(F);
    paintFoot();
    if (flyDue && s) { flyDue = false; requestAnimationFrame(guard(() => { if (mapAwake) flyToItem(s); })); }
  }
  function syncMap(){
    if (!mapCan()) return;
    const sc = ctx.scene();
    if (!sc) return;
    if (!group) { group = new THREE.Group(); group.name = "plan-ai"; }
    if (group.parent !== sc) sc.add(group);
    if (!mapAwake) {
      mapAwake = true;
      keysTo(true);
      if (ctx.quiet) ctx.quiet(true);
      // A phone: the map and the card fill the screen, whatever the page had above them.
      if (touchy() && ctx.root.scrollIntoView) { try { ctx.root.scrollIntoView({ block: "start" }); } catch (_) { /* it stays where it is */ } } const F0 = ctx.currentFloor ? ctx.currentFloor() : null; floorSeen = F0 ? String(F0.fl.id) : null; shell = ctx.shellGen ? ctx.shellGen() : 0;
    }
    pinsEl.style.display = "";
    const F = shownFloor(), order = orderNow();
    syncPlan(F);
    syncGhosts(F);
    syncOnion(F);
    syncPins(F, order);
    if (ctx.render) ctx.render();
  }
  /** Heard first, on the window, only while the map shows: Home Assistant's own one-letter shortcuts ("c" is its
   *  command palette) listen further along, and a key that is ours goes no further. */
  const keyFirst = guard((e) => { if (key(e)) { e.preventDefault(); e.stopPropagation(); } });
  let keysOn = false;
  const keysTo = (on) => { if (on === keysOn) return; keysOn = on; window[on ? "addEventListener" : "removeEventListener"]("keydown", keyFirst, true); };
  function mapSleep(){
    if (!mapAwake) return;
    keysTo(false);
    mapAwake = false; expectFloor = null; gesture = null; moving = null;
    releasePlan();
    for (const id of [...ghosts.keys()]) dropGhost(id);
    stairGhosts.clear();
    if (onion) { dropMesh(onion); onion = null; onionKey = ""; }
    for (const P of pins.values()) P.el.remove();
    pins.clear();
    for (const t of tags.values()) t.remove();
    tags.clear();
    pinsEl.style.display = "none";
    if (ctx.quiet) ctx.quiet(false);
    if (group && group.parent) group.parent.remove(group);
    if (ctx.render) ctx.render();
  }


  // ── Line up plans (Build from plans, experimental; plan_ai.py's line-up) ─
  // The Plans tool's second tab, drawn only when the server says it is on
  // (plan_build_info: the master switch, Build from plans, and Claude Opus 5.5
  // or newer as the AI Task). One floor at a time: Claude reads the text, the
  // server measures. Each proposal is shown on the vetting map, the 3D view
  // the Plans tool already uses (no new screen): the plan as a ghost where the
  // proposal puts it (red) over the plan it is fitted to (blue), purple where
  // the drawings agree, its outline now (grey) and proposed (amber), every flag
  // an arrow from where a thing is stored to where its click would land. With no
  // 3D view, or "As a list", the same items are cards with a 2D overlay drawn
  // from the signed picture links and the server's corners. Verdicts are
  // written at the click; Accept saves that one item (plan_build_commit, the one
  // writer, a backup first); the floor's Save saves only the items that shift
  // nothing drawn on a plan; Undo this line-up session takes every save back.
  // Every control here says experimental (tests/js/plan_build_tab.mjs scans it).
  let mode = "add", lu = null, luSess = null, luFloor = null, luPoll = null, luBusy = false, luErr = "", luWrongFor = null, luTyped = null;
  let luNow = false;                                   // the overlays show where each plan is now, not the proposal
  let luCur = null, luList = false, luDimFor = null, luRefileFor = null, luAskUndo = false, luFade = 0.8;
  let luAwake = false, luKey = null, luTok = 0, luFly = false;
let luOff = null;                                    // no Line up or Rooms tab: "locked" (Claude) or "off" (the switch), for the hint
  const luMeshes = [];
  const luPicked = new Set(), luTaps = new Map(), tints = new Map();
  const LU_PREFIX = "Line up plans (experimental): ";
  const LU_BANNER = "Experimental. Claude reads the text; PadSpan measures. Matches and scales can still be wrong; look at each overlay before you accept.";
  const LU_WRONG = [["wrong_match", "Wrong match"], ["wrong_scale", "Wrong scale"], ["wrong_floor", "Wrong floor"], ["cant_tell", "Can't tell"]];
  const LU_ORDER = { place: 0, refile: 1, anchor_scale: 2 };
  const LU_TAKES = new Set(["open", "undone"]);        // what Accept saves (an undone item can be saved again)
  const pct = (v) => (num(v) === null ? "?" : `${(Math.round(v * 1000) / 10).toFixed(1)} %`);
  const f1 = (v) => (num(v) === null ? "?" : v.toFixed(1));
  // A score from 0 to 1 said in words (the line-up's match bands, plan_build_fit); the number stays in the hover.
  const fitWord = (v) => (v >= 0.85 ? "well" : v >= 0.7 ? "roughly" : "poorly");
  const subLine = (s) => { const n = d("div", "pl-sub", typeof s === "string" ? s : s.text); if (s && s.title) n.title = s.title; return n; };
  const luSaid = (e) => LU_PREFIX + String((e && e.message) || e).replace(LU_PREFIX, "");   // every message of the tab says experimental (design 7)
  const luCall = (type, extra) => call(type, extra).catch((e) => { throw Object.assign(new Error(String((e && e.message) || e)), { code: e && e.code }); });
  const luPlan = (mid) => ((luSess && luSess.plans) || []).find(p => p.map_id === mid) || null;
  const luFloorName = (fid) => { const f = ((lu && lu.floors) || []).find(x => x.id === fid); return f ? f.name || fid : floorName(fid); };
  const luItems = () => Object.entries((luSess && luSess.items) || {}).sort((a, b) => ((LU_ORDER[a[1].kind] ?? 9) - (LU_ORDER[b[1].kind] ?? 9)) || String(a[1].name).localeCompare(String(b[1].name)));
  const luAcceptable = (it) => LU_TAKES.has(it.state) || (it.state === "not_now" && it.kind === "anchor_scale" && !it.verdict);
  const luShifts = (it) => (it.flags || []).length > 0;
  const luMapWanted = () => mapCan() && !luList && !!luSess && luSess.status !== "running" && luItems().length > 0;
  async function luInfo(){
    try { lu = await luCall("plan_build_info"); } catch (_) { lu = null; }
    if (lu && !lu.on) count(lu.unlock && lu.unlock.ok ? "plan_build_stop_ui:no_tabs_off" : "plan_build_stop_ui:no_tabs_locked", true);
    luOff = lu && !lu.on ? (lu.unlock && lu.unlock.ok ? "off" : "locked") : null;
    if (!lu || !lu.on) { lu = null; if (mode === "lineup" || mode === "rooms") mode = "add"; }
    return lu;
  }
  // Where the tool stops, its next actions (the host's go: Measure a plan in Mapping, the rooms helper,
  // Settings → AI); none on a wall screen, where the words say where to do it instead.
  const luGo = () => { const h = ctx.host(); return (h && h.go) || null; };
  const luUnscaled = (fid) => ((lu && lu.unscaled) || {})[fid] || [];   // plan_build_info: a floor's plans with no scale yet
  const plural = (n, w) => `${n} ${w}${n === 1 ? "" : "s"}`;
  /** A plan with no scale yet: Measure it in Mapping; with `helper`, the rooms helper where its rule offers it. */
  function paintMeasure(plan, helper = true){
    const g = luGo(), box = d("div", "pl-acts");
    box.setAttribute("data-plans-next", "measure");
    if (g && g.measure) {
      const b = btn(`Measure ${plan.name || "this plan"} in Mapping`, "Mapping → Edit on this plan, with the Measure tool: two lengths you know, like a doorway or a wall",
        () => { count("plans_tool_go:measure"); g.measure(plan.map_id); }, "go");
      b.setAttribute("data-plans-go", "measure");
      box.appendChild(b);
    } else box.appendChild(d("div", "pl-sub", `From another screen: Mapping → Edit, open ${plan.name || "the plan"}, then 📏 Measure two lengths you know, like a doorway or a wall.`));
    sheet.appendChild(box);
    if (helper && g && g.helper && g.helperOffered && g.helperOffered()) {
      const l = d("div", "pl-note");
      l.setAttribute("data-plans-next", "helper");
      // Setup's words where the helper was left (ai_wizard_offer.lineWords, one copy): Carry on, else this tool's own Try it.
      const w = (g.helperWords && g.helperWords()) || {};
      l.appendChild(d("span", null, w.back ? `${w.text} ` : "Or let Claude draw the rooms for you: it starts with one measurement. "));
      const h = btn(w.go || "Try it →", "Let Claude draw your rooms (experimental)", () => { count("plans_tool_go:helper"); g.helper(); });
      h.setAttribute("data-plans-go", "helper");
      l.appendChild(h);
      sheet.appendChild(l);
    }
  }
  /** No Line up or Rooms tab here: one muted line on what turns them on (the tool is an administrator's only). */
  function luHint(){
    if (!luOff) return;
    const box = d("div", "pl-note");
    box.setAttribute("data-plans-next", "tabs");
    box.appendChild(d("span", null, luOff === "off"
      ? "Two more tabs, Line up plans and Rooms from plans, come with Settings → AI → Build from plans (experimental). "
      : "Two more tabs, Line up plans and Rooms from plans, need Claude Opus 5.5 or newer through Home Assistant's Anthropic integration, then Settings → AI → Build from plans (experimental). "));
    const g = luGo();
    if (g && g.settings) {
      const b = btn("Open Settings → AI", "Where Build from plans is turned on", () => { count("plans_tool_go:settings"); g.settings(); });
      b.setAttribute("data-plans-go", "settings");
      box.appendChild(b);
    }
    sheet.appendChild(box);
  }
  function luTabs(){
    if (!lu || !lu.on) { luHint(); return; }
    const row = d("div", "pl-choose");
    row.setAttribute("data-plan-build", "tabs");
    const tabs = [["add", "Add data via plans"], ["lineup", "Line up plans (experimental)"], ...(lu.rooms ? [["rooms", "Rooms from plans (experimental)"]] : [])];
    for (const [m, word] of tabs) {
      const b = btn(word, m === "lineup" ? "Claude reads one floor's plans and PadSpan lines them up (experimental)"
        : m === "rooms" ? "Claude reads a lined-up floor's rooms, doors, windows and stairs (experimental)" : "Stairs, railings and lights from your plans", () => {
        mode = m; luErr = ""; rbErr = "";
        count(`plans_tab:${m}`);
        if (m === "lineup" && !luSess) luOpen(); else if (m === "rooms" && !rbSess) rbOpen(); else redraw();
      });
      b.setAttribute("aria-pressed", String(mode === m));
      row.appendChild(b);
    }
    sheet.appendChild(row);
  }
  async function luOpen(){
    luBusy = true; redraw();
    await luInfo();
    loadUrls();
    if (lu && lu.running) { luPollStart(lu.running); luBusy = false; return; }
    const last = ((lu && lu.floors) || []).map(f => f.last).filter(Boolean).sort((a, b) => (b.at || 0) - (a.at || 0))[0];
    if (last && last.session) { try { luSess = (await luCall("plan_build_status", { session: last.session })).session; luFloor = luSess && luSess.floor_id; } catch (e) { luErr = luSaid(e); } }
    luBusy = false; luKey = null; luFly = true; redraw();
  }
  function luPick(fid){
    luFloor = fid; luSess = null; luPicked.clear();
    count("plans_floor:s1");
    const f = ((lu && lu.floors) || []).find(x => x.id === fid);
    for (const p of (f && f.plans) || []) luPicked.add(p.map_id);
    redraw();
  }
  async function luStart(){
    if (luBusy || !luFloor) return;
    luBusy = true; luErr = ""; redraw();
    try { const r = await luCall("plan_build_start", { floor_id: luFloor, map_ids: [...luPicked] }); luPollStart(r.session); }
    catch (e) { luErr = LU_PREFIX + String(e.message || e).replace(LU_PREFIX, ""); }
    luBusy = false; redraw();
  }
  function luPollStart(sid){
    luPollStop();
    const tick = guard(async () => {
      try {
        const r = await luCall("plan_build_status", { session: sid });
        luSess = r.session; luFloor = luSess && luSess.floor_id;
        if (luSess && luSess.status !== "running") { luPollStop(); luKey = null; luFly = true; }
      } catch (e) { luErr = luSaid(e); luPollStop(); }
      redraw();
    });
    luPoll = setInterval(tick, POLL_MS);
    tick();
  }
  function luPollStop(){ if (luPoll) { clearInterval(luPoll); luPoll = null; } }
  async function luReload(){
    try { const r = await luCall("plan_build_status", { session: luSess.id }); if (r && r.session) luSess = r.session; } catch (_) { /* what is shown stays */ }
  }
  async function luDo(type, extra, after){
    if (luBusy || !luSess) return;
    luBusy = true; luErr = ""; redraw();
    try { const r = await luCall(type, { session: luSess.id, ...(extra || {}) }); if (after) after(r); }
    catch (e) {
      if (e.code === "rev_mismatch") await luReload();
      luErr = LU_PREFIX + String(e.message || e).replace(LU_PREFIX, "");
    }
    luBusy = false; redraw();
  }
  /** A save, an undo or a refile: an ok: false answer is a refusal (nothing written), said in its words. */
  async function luWrite(type, extra, done){
    if (luBusy || !luSess) return;
    luBusy = true; luErr = ""; luAskUndo = false; redraw();
    try {
      const r = (await luCall(type, { session: luSess.id, ...(extra || {}) })) || {};
      if (r.session) luSess = r.session;
      if (r.ok === false) { luErr = LU_PREFIX + String(r.message || r.code || "").replace(LU_PREFIX, ""); if (!r.session) await luReload(); }
      else if (done) done(r);
    } catch (e) {
      if (e.code === "rev_mismatch") await luReload();
      luErr = LU_PREFIX + String(e.message || e).replace(LU_PREFIX, "");
    }
    luKey = null; luBusy = false; redraw();
  }
  const luVerdict = (id, v, why) => luDo("plan_build_verdict", { rev: luSess.rev, item_id: id, v, ...(why ? { why } : null) }, (r) => {
    luSess.rev = r.rev; luSess.items[id] = r.item; luWrongFor = null; luKey = null;
    ctx.hint(LU_PREFIX + (v === "back" ? "taken back." : v === "wrong" ? "noted: wrong. Nothing in your house changes." : "not now, then."));
  });
  const luSave = (ids, group) => luWrite("plan_build_commit", { rev: luSess.rev, items: ids, ...(group ? { group: true } : null) }, () =>
    ctx.hint(`${LU_PREFIX}saved ${ids.length === 1 ? "it" : `${ids.length} items`}. A backup was taken first; Undo this line-up session takes it back.`));
  const luUndo = () => luWrite("plan_build_undo", {}, (r) => {
    const n = r.undone || 0, k = (r.skipped || []).length;
    ctx.hint(`${LU_PREFIX}${n} plan${n === 1 ? "" : "s"} put back where ${n === 1 ? "it was" : "they were"}${k ? `; ${k} moved by hand since ${k === 1 ? "was" : "were"} left as ${k === 1 ? "it is" : "they are"}` : ""}.`);
  });
  const luRefile = (mid, fid) => { luRefileFor = null; return luWrite("plan_build_refile", { rev: luSess.rev, map_id: mid, to_floor_id: fid }, (r) => { if (r.item_id) luCur = r.item_id; }); };
  const luAnswer = (q, answer) => luDo("plan_build_answer", { question_id: q.id, answer }, (r) => {
    luSess = r.session; luTaps.delete(q.id); luTyped = null; luKey = null;
    if (luSess && luSess.status === "running") luPollStart(luSess.id);   // re-measuring on the server, with Stop, until it ends
  });

  // -- pictures: the plan's ink in one colour, kept per link and colour ------
  function tinted(url, rgb, done){
    const key = `${url}|${rgb}`;
    if (tints.has(key)) { const t = tints.get(key); if (t.ready) return t.c; t.waiting.push(done); return null; }
    const t = { ready: false, c: null, waiting: [done] };
    tints.set(key, t);
    const img = new Image();
    img.onload = () => {
      try {
        const [w, h] = fitSize(img.naturalWidth, img.naturalHeight), c = document.createElement("canvas");
        c.width = w; c.height = h;
        const g = c.getContext("2d");
        g.drawImage(img, 0, 0, w, h);
        const px = g.getImageData(0, 0, w, h), a = px.data;
        for (let i = 0; i < a.length; i += 4) {
          const ink = 255 - (a[i] * 0.299 + a[i + 1] * 0.587 + a[i + 2] * 0.114);
          a[i] = rgb[0]; a[i + 1] = rgb[1]; a[i + 2] = rgb[2]; a[i + 3] = Math.min(255, ink * 1.6);
        }
        g.putImageData(px, 0, 0);
        t.c = c; t.ready = true;
      } catch (_) { t.ready = true; }
      for (const f of t.waiting.splice(0)) try { f(); } catch (_) { /* a card gone */ }
    };
    img.onerror = () => { t.ready = true; };
    img.src = url;
    return null;
  }
  /** One picture drawn with its four corners in metres (corners[0] its top left, [1] top right, [3] bottom left). */
  function drawAt(g, pic, corners, toPx){
    if (!pic || !Array.isArray(corners) || corners.length < 4) return;
    const [p0, p1, , p3] = corners.map(toPx);
    g.save();
    g.setTransform((p1[0] - p0[0]) / pic.width, (p1[1] - p0[1]) / pic.width, (p3[0] - p0[0]) / pic.height, (p3[1] - p0[1]) / pic.height, p0[0], p0[1]);
    g.drawImage(pic, 0, 0);
    g.restore();
  }
  function outline(g, corners, toPx, colour, dash){
    if (!Array.isArray(corners) || corners.length < 4) return;
    g.save(); g.strokeStyle = colour; g.lineWidth = 2; g.setLineDash(dash);
    g.beginPath(); corners.map(toPx).forEach(([x, y], i) => (i ? g.lineTo(x, y) : g.moveTo(x, y))); g.closePath(); g.stroke(); g.restore();
  }
  /** What an item shows, on the 3D map or on a card: the plan it is fitted to (blue), this plan
   *  where the proposal puts it (red; where it is now with "now"), the outlines, the flags. */
  function luParts(it){
    const anchorId = it.kind === "place" ? (it.evidence || {}).anchor : null, anchor = anchorId ? luPlan(anchorId) : null, pl = luPlan(it.map_id);
    const now = it.corners_now_m || (pl && pl.corners_m) || null, next = it.kind === "refile" ? null : it.corners_new_m || null;
    return { anchor, now, next, blueMid: anchor ? anchor.map_id : it.kind === "anchor_scale" ? it.map_id : null,
             blueAt: anchor ? anchor.corners_m : it.kind === "anchor_scale" ? now : null, redAt: luNow || !next ? now : next };
  }
  /** The overlay of one item on a card (no 3D view, or the list): the same drawing, flat. */
  function overlay(c, it){
    const p = luParts(it);
    const all = [...(p.now || []), ...(p.next || []), ...(p.blueAt || [])];
    if (!all.length) return;
    const xs = all.map(q => q[0]), ys = all.map(q => q[1]);
    const x0 = Math.min(...xs), x1 = Math.max(...xs), y0 = Math.min(...ys), y1 = Math.max(...ys);
    c.height = Math.round(Math.min(720, Math.max(200, c.width * (y1 - y0) / Math.max(0.1, x1 - x0))));   // the plans' own shape
    const paintIt = () => {
      const g = c.getContext("2d");
      g.setTransform(1, 0, 0, 1, 0, 0);
      g.fillStyle = "#ffffff"; g.fillRect(0, 0, c.width, c.height);
      const k = Math.min((c.width - 16) / Math.max(0.1, x1 - x0), (c.height - 16) / Math.max(0.1, y1 - y0));
      const toPx = ([x, y]) => [8 + (x - x0) * k, 8 + (y - y0) * k];
      const blue = p.blueMid && urls && urls[p.blueMid] ? tinted(urls[p.blueMid], [37, 99, 235], paintIt) : null;
      const red = urls && urls[it.map_id] ? tinted(urls[it.map_id], [220, 38, 38], paintIt) : null;
      if (blue) drawAt(g, blue, p.blueAt, toPx);
      g.globalCompositeOperation = "multiply";
      if (red) drawAt(g, red, p.redAt, toPx);
      g.globalCompositeOperation = "source-over";
      outline(g, p.now, toPx, "#64748b", [6, 4]);
      outline(g, p.next, toPx, "#f59e0b", [10, 4]);
      for (const f of it.flags || []) {
        if (!f.stored_m || !f.click_m) continue;
        const [ax, ay] = toPx(f.stored_m), [bx, by] = toPx(f.click_m);
        g.strokeStyle = f.what === "calibration" ? "#7c3aed" : "#0f766e"; g.lineWidth = 2; g.setLineDash([]);
        g.beginPath(); g.moveTo(ax, ay); g.lineTo(bx, by); g.stroke();
        g.beginPath(); g.arc(ax, ay, 3.5, 0, Math.PI * 2); g.fill();
      }
    };
    paintIt();
  }
  /** A picture's crop: a question's dimension with its ticks, a dimension measured on a proposal, or a whole plan to tap on. */
  function questionPic(c, q, mid, onTap){
    const url = urls && urls[mid];
    if (!url) return;
    const img = new Image();
    const paintIt = () => {
      const g = c.getContext("2d"), W = img.naturalWidth, H = img.naturalHeight;
      if (!W || !H) return;
      let sx = 0, sy = 0, sw = W, sh = H;
      const pl = luPlan(mid), fw = pl ? pl.size_px[0] : W, fh = pl ? pl.size_px[1] : H, kx = W / fw, ky = H / fh;
      if (q.kind === "confirm_dimension" && Array.isArray(q.box)) {
        const [x1, y1, x2, y2] = q.box, m = 40;
        sx = Math.max(0, (x1 - m) * kx); sy = Math.max(0, (y1 - m) * ky); sw = Math.min(W - sx, (x2 - x1 + 2 * m) * kx); sh = Math.min(H - sy, (y2 - y1 + 2 * m) * ky);
      }
      const k = Math.min(c.width / sw, c.height / sh);
      g.fillStyle = "#fff"; g.fillRect(0, 0, c.width, c.height);
      g.drawImage(img, sx, sy, sw, sh, 0, 0, sw * k, sh * k);
      const at = (x, y) => [(x * kx - sx) * k, (y * ky - sy) * k];
      if (q.kind === "confirm_dimension" && Array.isArray(q.box) && q.mark) {   // the dimension line as read, highlighted
        const [a, b] = [at(q.box[0], q.box[1]), at(q.box[2], q.box[3])];
        g.fillStyle = "rgba(251,191,36,.28)"; g.fillRect(a[0], a[1], b[0] - a[0], b[1] - a[1]);
        g.strokeStyle = "#f59e0b"; g.lineWidth = 1.5; g.setLineDash([5, 3]); g.strokeRect(a[0], a[1], b[0] - a[0], b[1] - a[1]); g.setLineDash([]);
      }
      g.strokeStyle = "#16a34a"; g.lineWidth = 2;
      if (q.kind === "confirm_dimension" && Array.isArray(q.ticks_px) && q.ticks_px.length === 2) {
        const [a, b] = q.ticks_px.map(p => at(p[0], p[1]));
        g.beginPath(); g.moveTo(a[0], a[1]); g.lineTo(b[0], b[1]); g.stroke();
        for (const p of [a, b]) { g.beginPath(); g.moveTo(p[0], p[1] - 12); g.lineTo(p[0], p[1] + 12); g.stroke(); }
      }
      for (const [i, t] of (luTaps.get(q.id) || []).entries()) {
        if ((i % 2 === 0) !== (mid === q.map_id)) continue;
        const [x, y] = [t[0] * fw * kx * k - sx * k, t[1] * fh * ky * k - sy * k];
        g.fillStyle = "#f59e0b"; g.beginPath(); g.arc(x, y, 6, 0, Math.PI * 2); g.fill();
        g.fillStyle = "#111"; g.font = "bold 11px system-ui"; g.fillText(String(Math.floor(i / 2) + 1), x + 8, y - 6);
      }
      if (onTap) c.onclick = (e) => { const r = c.getBoundingClientRect(), x = (e.clientX - r.left) * c.width / r.width, y = (e.clientY - r.top) * c.height / r.height;
        onTap([Math.min(1, Math.max(0, (x / k + sx) / W)), Math.min(1, Math.max(0, (y / k + sy) / H))]); };
    };
    img.onload = paintIt;
    img.src = url;
  }

  // -- on the vetting map (the Live Aboard view the Plans tool already uses) --
  function luDrop(){
    luTok++;
    for (const m of luMeshes.splice(0)) { if (m.material && m.material.map) { m.material.map.dispose(); texLive--; } dropMesh(m); }
  }
  function luSleep(){
    if (!luAwake) return;
    luAwake = false; luKey = null;
    luDrop();
    if (ctx.quiet) ctx.quiet(false);
    if (ctx.render) ctx.render();
  }
  function luPlane(canvas, cs, y, opacity){
    const tex = new THREE.CanvasTexture(canvas);
    if (THREE.SRGBColorSpace) tex.colorSpace = THREE.SRGBColorSpace;
    texLive++;
    const geo = new THREE.BufferGeometry();
    geo.setAttribute("position", new THREE.BufferAttribute(new Float32Array([cs[0][0], y, cs[0][1], cs[1][0], y, cs[1][1], cs[2][0], y, cs[2][1], cs[3][0], y, cs[3][1]]), 3));
    geo.setAttribute("uv", new THREE.BufferAttribute(new Float32Array([0, 1, 1, 1, 1, 0, 0, 0]), 2));
    geo.setIndex([0, 2, 1, 0, 3, 2]);
    const m = new THREE.Mesh(geo, new THREE.MeshBasicMaterial({ map: tex, transparent: true, opacity, depthWrite: false, side: THREE.DoubleSide,
      polygonOffset: true, polygonOffsetFactor: -2, polygonOffsetUnits: -4 }));
    m.renderOrder = 2; m.frustumCulled = false;
    return m;
  }
  /** The item on the map: two pictures at most (one on a phone: Now / Proposed is its blink), the outlines, the flags' arrows. */
  function luBuild(it, F){
    const tok = luTok, y = F.fl.elev, p = luParts(it), add = (m) => { luMeshes.push(m); group.add(m); };
    const later = () => { if (tok === luTok && luAwake) { luKey = null; luSync(); } };
    if (p.blueMid && p.blueAt && urls && urls[p.blueMid] && !touchy()) {
      const c = tinted(urls[p.blueMid], [37, 99, 235], later);
      if (c) add(luPlane(c, p.blueAt, y + 0.03, 0.7));
    }
    if (p.redAt && urls && urls[it.map_id]) {
      const c = tinted(urls[it.map_id], [220, 38, 38], later);
      if (c) { const m = luPlane(c, p.redAt, y + 0.036, luFade); m.renderOrder = 3; m.userData.proposed = true; add(m); }
    }
    if (p.now) add(dashMesh(dashTriangles(p.now, true, 0.4, 0.25, 0.1), y + 0.05, "#cbd5e1"));
    if (p.next) add(dashMesh(dashTriangles(p.next, true, 0.6, 0.25, 0.12), y + 0.055, DASH_COL));
    for (const f of it.state === "committed" ? [] : it.flags || []) {          // saved: what it shifted is drawn from metres again
      if (!f.stored_m || !f.click_m) continue;
      const col = f.what === "calibration" ? "#a855f7" : "#14b8a6", ring = [];
      for (let i = 0; i < 12; i++) ring.push([f.stored_m[0] + Math.cos(i * Math.PI / 6) * 0.2, f.stored_m[1] + Math.sin(i * Math.PI / 6) * 0.2]);
      add(dashMesh(dashTriangles([f.stored_m, f.click_m], false, 0.15, 0.08, 0.08), y + 0.06, col));
      add(dashMesh(dashTriangles(ring, true, 0.08, 0.03, 0.07), y + 0.06, col));
    }
  }
  function luFlyTo(it, F){
    if (!ctx.flySpot) return;
    const p = luParts(it), pts = [...(p.blueAt || []), ...(p.redAt || []), ...(p.now || [])];
    if (!pts.length) return;
    const xs = pts.map(q => q[0]), ys = pts.map(q => q[1]);
    const x0 = Math.min(...xs), x1 = Math.max(...xs), y0 = Math.min(...ys), y1 = Math.max(...ys);
    ctx.flySpot(F, (x0 + x1) / 2, (y0 + y1) / 2, Math.max(x1 - x0, y1 - y0) + 2, padNow());
  }
  function luSync(){
    if (!mapCan() || !luSess) return;
    const sc = ctx.scene();
    if (!sc) return;
    if (!group) { group = new THREE.Group(); group.name = "plan-ai"; }
    if (group.parent !== sc) sc.add(group);
    const list = luItems(), F = floorUi(luSess.floor_id);
    if (!list.some(([id]) => id === luCur)) luCur = (list.find(([, it]) => luAcceptable(it)) || list[0] || [null])[0];
    if (!luAwake) {
      luAwake = true; luFly = true; luKey = null;
      if (ctx.quiet) ctx.quiet(true);
      if (touchy() && ctx.root.scrollIntoView) { try { ctx.root.scrollIntoView({ block: "start" }); } catch (_) { /* it stays where it is */ } }
    }
    const it = luCur ? luSess.items[luCur] : null;
    if (luFly && F && ctx.setTopFloor && (ctx.currentFloor ? ctx.currentFloor() : null) !== F) ctx.setTopFloor(String(F.fl.id));
    const key = it && F ? JSON.stringify([luCur, it.state, luNow, F.fl.elev, !!urls, touchy(), it.corners_new_m]) : "";
    if (key !== luKey) { luDrop(); luKey = key; if (it && F) { try { luBuild(it, F); } catch (_) { /* a plan that won't draw: its card still says it all */ } } }
    for (const m of luMeshes) if (m.userData && m.userData.proposed) m.material.opacity = luFade;
    if (luFly && it && F) { luFly = false; requestAnimationFrame(guard(() => { if (luAwake) luFlyTo(it, F); })); }
    if (ctx.render) ctx.render();
  }

  // -- the tab ---------------------------------------------------------------
  function luSection(cls){ const s = d("div", cls || "pl-row"); s.setAttribute("data-plan-build", ""); return s; }
  function paintLineup(onMap){
    luTabs();
    head("Line up plans", "Claude reads one floor's plans; PadSpan measures and lines them up. Experimental.");
    sheet.appendChild(d("div", "pl-ban", LU_BANNER));
    if (luErr) { const e = d("div", "pl-note pl-bad", luErr); e.setAttribute("role", "alert"); sheet.appendChild(e); }
    if (luBusy && !luSess) { sheet.appendChild(d("div", "pl-note", "Looking…")); return; }
    if (luSess && luSess.status === "running") return paintLuProgress();
    if (luSess) return paintLuSession(onMap);
    paintLuPicker();
  }
  function paintLuPicker(){
    const floors = (lu && lu.floors) || [];
    if (floors.length && !floors.some(f => (f.plans || []).length)) count("plan_build_stop_ui:s1_no_plans", true);   // every chip "0 plans"
    // No plan in the house measured: nothing to line the others up to. One message, not a list of floors it can't use.
    if (lu && lu.gauge === false) {
      sheet.appendChild(d("div", "pl-note", "Line up needs one plan measured first: the other plans are lined up to it. Experimental."));
      const first = floors.map(x => luUnscaled(x.id)[0] || (x.plans || [])[0]).find(Boolean);
      if (first) paintMeasure(first); else sheet.appendChild(d("div", "pl-note", "There's no plan to line up yet: add one in Mapping → Upload."));
      return;
    }
    sheet.appendChild(d("h5", null, "Which floor (experimental)"));
    const chips = d("div", "pl-choose");
    chips.setAttribute("data-plan-build", "floors");
    const noScale = floors.filter(x => !(x.plans || []).length && luUnscaled(x.id).length);   // plans there, none with a scale yet
    for (const f of floors) {
      const n = (f.plans || []).length, un = n ? 0 : luUnscaled(f.id).length;
      const b = btn(`${f.name || f.id} · ${un ? `${plural(un, "plan")}, none with a scale yet` : plural(n, "plan")}`,
        un ? "Its plans need a scale before they can be lined up" : f.last ? `Last lined up: ${new Date((f.last.at || 0) * 1000).toLocaleDateString()}` : "Not lined up yet", () => luPick(f.id));
      b.setAttribute("aria-pressed", String(luFloor === f.id)); b.disabled = !n;
      chips.appendChild(b);
    }
    sheet.appendChild(chips);
    noScale.forEach((x, i) => {
      sheet.appendChild(d("div", "pl-note", `${x.name || x.id}: its plans have no scale yet, so they can't be lined up.`));
      paintMeasure(luUnscaled(x.id)[0], i === 0);
    });
    const f = floors.find(x => x.id === luFloor);
    if (!f) { sheet.appendChild(d("div", "pl-note", "Pick a floor. One floor is read at a time; the plans of other floors are used as they are.")); return; }
    for (const p of f.plans || []) {
      const l = d("label", "pl-tick");
      l.setAttribute("data-plan-build", "plan");
      const cb = d("input"); cb.type = "checkbox"; cb.checked = luPicked.has(p.map_id);
      cb.addEventListener("change", () => { if (cb.checked) luPicked.add(p.map_id); else luPicked.delete(p.map_id); redraw(); });
      l.appendChild(cb);
      if (urls && urls[p.map_id]) { const im = d("img"); im.src = urls[p.map_id]; im.alt = ""; l.appendChild(im); }
      const dr = p.drawn || {}, bits = [dr.rooms ? `rooms traced: ${dr.rooms}` : "", dr.calibration ? `calibration points: ${dr.calibration}` : "",
        (dr.receivers || 0) + (dr.beacons || 0) + (dr.lights || 0) ? `devices drawn: ${(dr.receivers || 0) + (dr.beacons || 0) + (dr.lights || 0)}` : ""].filter(Boolean);
      l.appendChild(d("span", null, `${p.name || "a plan"}${p.gauge ? " · the plan that set your house's scale (never moved)" : ""} — ${bits.length ? bits.join(", ") : "nothing drawn on it"}`));
      sheet.appendChild(l);
    }
    // The AI credit tracker's own estimate for the ticked plans (plan_ai.plan_estimate): every read once, to every read twice.
    const ticked = (f.plans || []).filter(p => luPicked.has(p.map_id)), priced = ticked.filter(p => Array.isArray(p.est_usd));
    const est = !ticked.length ? "tick the plans to read" : priced.length === ticked.length
      ? `about $${priced.reduce((s, p) => s + p.est_usd[0], 0).toFixed(2)}–$${priced.reduce((s, p) => s + p.est_usd[1], 0).toFixed(2)} for ${ticked.length === 1 ? "this plan" : `these ${ticked.length} plans`} (estimate, experimental)`
      : "no price is known for this model";
    sheet.appendChild(d("div", "pl-note", `${(lu && lu.unlock && lu.unlock.display) || "Claude"} reads them: the plans leave the house for Anthropic. Claude looks at each plan about 5 times; ${est}. `
      + "Nothing is saved until you accept a proposal: a backup is taken before each save, and one undo takes the whole session back."));
    const acts = d("div", "pl-acts");
    acts.setAttribute("data-plan-build", "start");
    const go = btn(`Line up ${f.name || f.id} (experimental)`, "Claude reads; PadSpan measures; you check every proposal", () => luStart(), "go");
    go.disabled = luBusy || !luPicked.size || !!(lu && lu.start_blocked);
    acts.appendChild(go);
    sheet.appendChild(acts);
    if (lu && lu.start_blocked) sheet.appendChild(d("div", "pl-note", { already_running: "A reading of your plans is running.", too_soon: "A session started less than a minute ago.", daily_cap: "That's the day's sessions." }[lu.start_blocked] || ""));
  }
  function paintLuProgress(){
    const pr = luSess.progress || {};
    sheet.appendChild(d("div", "pl-sum", `${pr.step === "measure" ? "Measuring" : pr.step === "dimension" ? `Reading a dimension on ${pr.name || "a plan"}` : `Reading ${pr.name || "a plan"}`} (${pr.plan || 0} of ${pr.of || 0})… experimental.`));
    sheet.appendChild(d("div", "pl-note", `${luSess.reads || 0} reads so far, ${mins(luSess.spent_s)} of ${mins(luSess.budget_s)}.`));
    const acts = d("div", "pl-acts");
    acts.setAttribute("data-plan-build", "cancel");
    acts.appendChild(btn("Stop (experimental)", "Stops after the read in flight; what was read is kept", () => luCall("plan_build_cancel", { session: luSess.id }).then(r => ctx.hint(r.message)).catch(() => {})));
    sheet.appendChild(acts);
  }
  function luSummary(){
    const s = luSess, items = Object.values(s.items || {});
    const n = (k) => items.filter(i => i.kind === k).length, saved = items.filter(i => i.state === "committed").length;
    const word = { done: "done", needs_help: "needs your help", cancelled: "stopped", failed: "failed", out_of_time: "ran out of time", no_credit: "out of credit" }[s.status] || s.status;
    const cost = num(s.est_usd) !== null ? `, about $${s.est_usd.toFixed(2)} (estimate)` : "";
    return `${luFloorName(s.floor_id)}: ${word}. ${s.reads || 0} reads${s.reused ? `, ${s.reused} plan${s.reused === 1 ? "" : "s"} reused` : ""}${cost}, in ${mins(s.spent_s)}. `
      + `${plural(n("place"), "plan")} to line up, ${n("refile")} to move to another floor${n("anchor_scale") ? ", a scale check of the plan the others are lined up to" : ""}.`
      + (saved ? ` ${saved} saved.` : "")
      + (s.cross_floor ? ` Its stairs sit ${m1(s.cross_floor.stairs_m)} m from ${luFloorName(s.cross_floor.floor_id)}'s.` : "");
  }
  function paintLuSession(onMap){
    sheet.appendChild(d("div", "pl-sum", luSummary()));
    const stops = (luSess.stops || []).filter(x => x.reason !== "help_unanswered" || (luSess.questions || []).some(q => q.state === "open"));
    if (stops.length || luSess.resumable) {            // the server says whether Resume can carry it on (a plan moved under it: line up again)
      const box = luSection("pl-note");
      box.appendChild(d("div", "pl-sub", "Where it stopped (experimental):"));
      for (const st of stops.slice(-6)) box.appendChild(d("div", null, `${st.say}${st.next ? ` ${st.next}` : ""}`));
      if (luSess.resumable) {
        const b = btn("Resume (experimental)", "Reads what is left; what was read is kept", () => luDo("plan_build_resume", {}, (r) => luPollStart(r.session)));
        b.disabled = luBusy;
        box.appendChild(b);
      }
      sheet.appendChild(box);
    }
    for (const q of (luSess.questions || []).filter(q => q.state === "open")) paintLuQuestion(q);
    const items = luItems();
    if (items.length) sheet.appendChild(d("h5", null, "Proposals (experimental)"));
    if (onMap && items.length) {
      const at = Math.max(0, items.findIndex(([id]) => id === luCur));
      const nav = d("div", "pl-q");
      nav.setAttribute("data-plan-build", "nav");
      const go = (k) => { luCur = items[(at + k + items.length) % items.length][0]; luDimFor = null; luWrongFor = null; luFly = true; luKey = null; redraw(); };
      nav.append(d("span", "pl-title", `${at + 1} of ${items.length} on the map (experimental)`), btn("‹", "The one before", () => go(-1)), btn("›", "The next one", () => go(1)));
      sheet.appendChild(nav);
      paintLuItem(items[at][0], items[at][1], true);
    } else for (const [id, it] of items) paintLuItem(id, it, false);
    if (!items.length && luSess.status === "done") sheet.appendChild(d("div", "pl-note", "Nothing to propose on this floor."));
    paintLuRefile();
    paintLuFoot(onMap, items);
  }
  /** "This plan isn't Basement?": a refile by hand (design 2), only for a plan with nothing drawn on it; the server says so when not. */
  function paintLuRefile(){
    const others = ((lu && lu.floors) || []).filter(f => f.id !== luSess.floor_id);
    const has = new Set(Object.values(luSess.items || {}).filter(it => it.kind === "refile").map(it => it.map_id));
    const plans = (luSess.plans || []).filter(p => p.role !== "gauge" && !has.has(p.map_id));
    if (!plans.length || !others.length) return;
    const box = luSection("pl-row pl-lu");
    box.setAttribute("data-plan-build", "refile");
    box.appendChild(d("div", "pl-sub", "A plan filed on the wrong floor? Say which floor it shows and it moves there, checked and saved like any other change. Only a plan with nothing drawn on it can move here (experimental)."));
    const here = luFloorName(luSess.floor_id);
    for (const p of plans) {
      const a = d("div", "pl-acts");
      if (luRefileFor === p.map_id) {
        a.appendChild(d("span", "pl-sub", `${p.name || "This plan"} shows:`));
        for (const f of others) a.appendChild(btn(f.name || f.id, `Move ${p.name || "this plan"} to ${f.name || f.id}`, () => luRefile(p.map_id, f.id)));
        a.appendChild(btn("Cancel", "Leave it on " + here, () => { luRefileFor = null; redraw(); }));
      } else a.appendChild(btn(`${p.name || "This plan"} isn't ${here}? (experimental)`, "Say which floor it shows", () => { luRefileFor = p.map_id; redraw(); }));
      for (const b of a.querySelectorAll("button")) b.disabled = luBusy;
      box.appendChild(a);
    }
    sheet.appendChild(box);
  }
  function paintLuFoot(onMap, items){
    const foot = d("div", "pl-foot");
    foot.setAttribute("data-plan-build", "foot");
    const open = items.filter(([, it]) => LU_TAKES.has(it.state) && (it.kind === "place" || it.kind === "refile"));
    const calm = open.filter(([, it]) => !luShifts(it)), loud = open.length - calm.length;
    if (calm.length) {
      const np = calm.filter(([, it]) => it.kind === "place").length, nr = calm.length - np;
      const save = btn(`Save line-up for ${luFloorName(luSess.floor_id)} (experimental): ${[np ? `${np} plan${np === 1 ? "" : "s"}` : "", nr ? `${nr} to another floor` : ""].filter(Boolean).join(", ")}`,
        "Saves the proposals that shift nothing drawn on their plans, together; a backup is taken first", () => luSave(calm.map(([id]) => id), true), "go");
      save.disabled = luBusy;
      foot.appendChild(save);
    }
    if (loud) foot.appendChild(d("div", "pl-note", `${loud} change${loud === 1 ? "" : "s"} would move things drawn on ${loud === 1 ? "its plan" : "their plans"}, so ${loud === 1 ? "it is" : "they are"} accepted one by one.`));
    if (items.some(([, it]) => it.state === "committed")) {
      if (luAskUndo) {
        foot.appendChild(d("div", "pl-note", "Put every plan this session saved back where it was? A backup is taken first; a plan you moved by hand since is left as it is."));
        const yes = btn("Undo it (experimental)", "Takes the whole line-up session back", () => luUndo(), "go");
        yes.disabled = luBusy;
        foot.append(yes, btn("Cancel", "Keep what was saved", () => { luAskUndo = false; redraw(); }));
      } else foot.appendChild(btn("Undo this line-up session (experimental)", "Puts every plan this session saved back where it was", () => { luAskUndo = true; redraw(); }));
    }
    foot.appendChild(btn(luNow ? "Show the proposals (experimental)" : "Show where they are now (experimental)", "The overlays: now or proposed", () => { luNow = !luNow; luKey = null; redraw(); }));
    if (onMap) {
      const r = d("input");
      r.type = "range"; r.min = "0.15"; r.max = "1"; r.step = "0.05"; r.value = String(luFade);
      r.title = "How strongly the proposed plan shows (experimental)"; r.setAttribute("aria-label", r.title);
      r.addEventListener("input", guard(() => { luFade = Number(r.value); for (const m of luMeshes) if (m.userData && m.userData.proposed) m.material.opacity = luFade; if (ctx.render) ctx.render(); }));
      foot.appendChild(r);
    }
    if (mapCan()) foot.appendChild(btn(luList ? "On the map (experimental)" : "As a list (experimental)", luList ? "Each proposal on the 3D view" : "The same proposals as cards", () => { luList = !luList; luKey = null; luFly = true; redraw(); }));
    foot.appendChild(btn("Line up again (experimental)", "Pick a floor and read it again", () => { luSess = null; luKey = null; luInfo().then(() => redraw()); }));
    sheet.appendChild(foot);
  }
  function paintLuQuestion(q){
    const box = luSection();
    box.setAttribute("data-plan-build", "question");
    const t = d("div", "pl-txt");
    const h = d("div");
    h.append(d("span", null, q.kind === "confirm_dimension" ? `A dimension on ${q.name || "a plan"}` : `Tap the same corner on ${q.name || "a plan"} and ${q.other_name || "the other plan"}`),
      d("span", "pl-chip", "EXPERIMENTAL"));
    t.appendChild(h);
    if (q.kind === "confirm_dimension") {
      const c = d("canvas"); c.width = 460; c.height = 120; c.style.width = "100%"; c.style.height = "auto";
      t.appendChild(c); questionPic(c, q, q.map_id);
      const ai = q.ai || {};
      t.appendChild(d("div", "pl-sub", `Claude reads ${ai.text ? `“${ai.text}”` : "a length"} (${m1(ai.metres)} m) here. Is that what the plan says? Experimental: if unsure, Skip.`));
      const a = d("div", "pl-acts");
      a.appendChild(btn("Yes", "That's what it says", () => luAnswer(q, "yes"), "go"));
      if (luTyped === q.id) {
        const inp = d("input"); inp.type = "number"; inp.step = "0.001"; inp.min = "0.1"; inp.placeholder = "metres"; inp.style.width = "90px";
        a.appendChild(inp);
        a.appendChild(btn("Use it", "The length printed, in metres", () => { const v = parseFloat(inp.value); if (v > 0) luAnswer(q, { metres: v }); }));
      } else a.appendChild(btn("It says…", "Type what the plan says, in metres", () => { luTyped = q.id; redraw(); }));
      a.appendChild(btn("Skip this one", "Leave this dimension out", () => luAnswer(q, "skip")));
      t.appendChild(a);
    } else {
      const taps = luTaps.get(q.id) || [];
      t.appendChild(d("div", "pl-sub", `Tap a corner on the first plan, then the same corner on the second; then a second corner far from it, on both. ${taps.length} of 4. Experimental: if unsure, Skip.`));
      const two = d("div", "pl-choose");
      for (const mid of [q.map_id, q.other_map_id]) {
        const c = d("canvas"); c.width = 220; c.height = 220; c.style.border = "1px solid rgba(255,255,255,.2)";
        two.appendChild(c);
        questionPic(c, q, mid, (frac) => {
          const list = luTaps.get(q.id) || [];
          if (list.length >= 4 || ((list.length % 2 === 0) !== (mid === q.map_id))) return;
          list.push(frac); luTaps.set(q.id, list); redraw();
        });
      }
      t.appendChild(two);
      const a = d("div", "pl-acts");
      const use = btn("Use these taps", "Line it up from them", () => luAnswer(q, { taps: luTaps.get(q.id) }), "go");
      use.disabled = taps.length !== 4 || luBusy;
      a.append(use, btn("Clear", "Tap again", () => { luTaps.delete(q.id); redraw(); }), btn("Skip", "Leave this plan out: Mapping → 3D Stack → Alignment Overlay lines it up by hand", () => luAnswer(q, "skip")));
      t.appendChild(a);
    }
    box.appendChild(t);
    sheet.appendChild(box);
  }
  function flagLine(f){
    const m = m1(f.moved_m);
    if (f.what === "calibration") return `A calibration click lands ${m} m from where it is stored${f.room_click && f.room_click !== f.room_now ? `, in ${f.room_click}` : ""}. This tool never moves calibration points.`;
    if (f.what === "room_trace") return `${f.label || "A room"} was traced on this plan; its outline in the house stays where it is. The trace would sit up to ${m} m off.`;
    return `${f.label || "A device"} drawn on this plan would land ${m} m from where it is stored. This tool never moves it: Mapping moves it.`;
  }
  /** The printed dimensions a proposal stands on: this plan's (and the plan it is fitted to), measured between their ticks. */
  function luDims(it){
    const out = [], add = (mid, role) => {
      const pl = luPlan(mid);
      for (const x of ((pl && pl.dims) || []).filter(x => x.ok && Array.isArray(x.box)).slice(0, 2)) out.push({ mid, name: (pl && pl.name) || "a plan", role, d: x });
    };
    if (it.kind !== "refile") add(it.map_id, "this plan");
    const a = it.kind === "place" ? (it.evidence || {}).anchor : null;
    if (a) add(a, "the plan it is fitted to");
    return out;
  }
  function paintLuDims(t, it){
    const list = luDims(it), ev = it.evidence || {}, box = d("div");
    box.setAttribute("data-plan-build", "dimension");
    box.appendChild(d("div", "pl-sub", "The printed sizes this change is based on (experimental). Amber: the size line Claude read; green: the length PadSpan measured between its end marks."));
    for (const x of list) {
      const tall = x.d.axis === "y", c = d("canvas");             // a dimension down the page gets a tall crop, not a sliver
      c.width = tall ? 200 : 460; c.height = tall ? 340 : 110; c.style.width = tall ? "auto" : "100%"; c.style.maxWidth = "100%"; c.style.height = "auto";
      c.style.display = "block"; c.style.background = "#fff"; c.style.borderRadius = "6px"; c.style.marginTop = "4px";
      box.appendChild(c);
      questionPic(c, { id: `dim_${x.mid}`, kind: "confirm_dimension", box: x.d.box, ticks_px: x.d.ticks_px, map_id: x.mid, mark: true }, x.mid);
      const m = num(x.d.parse_m) ?? num(x.d.metres);
      box.appendChild(d("div", "pl-sub", `${x.name} (${x.role}): “${x.d.text || "?"}” = ${m === null ? "?" : m.toFixed(3)} m ${x.d.axis === "y" ? "down" : "across"}; `
        + `${num(x.d.span_px) === null ? "?" : Math.round(x.d.span_px)} px between its end marks, so ${f1(x.d.ppm)} pixels per metre${x.d.source === "person" ? " (as you typed it)" : ""}.`));
    }
    const pp = ev.ppm_printed || [], pn = ev.ppm_now || [], pw = ev.ppm_new || [];
    if (pp.some(v => num(v) !== null)) box.appendChild(d("div", "pl-sub", `Scale in pixels per metre, across / down: from the printed sizes ${f1(pp[0])} / ${f1(pp[1])}; now ${f1(pn[0])} / ${f1(pn[1])}; proposed ${f1(pw[0])} / ${f1(pw[1])}.`));
    if (!list.length) box.appendChild(d("div", "pl-sub", "No printed size could be measured on this plan: where it goes comes from matching the pictures alone."));
    t.appendChild(box);
  }
  function paintLuItem(id, it, onMap){
    const box = luSection("pl-row pl-lu");
    box.setAttribute("data-plan-build", `item:${it.kind}`);
    if (it.kind !== "refile" && !onMap) {
      const c = d("canvas"); c.width = 480; c.height = 320;
      box.appendChild(c);
      overlay(c, it);
    }
    const anchorName = (it.evidence || {}).anchor_name || "the plan it is lined up to";
    if (it.kind !== "refile") box.appendChild(d("div", "pl-lu-key", onMap
      ? (it.kind === "place" ? `On the map: blue is ${anchorName}; red is this plan ${luNow ? "where it is now" : "where it would go"}; purple where the two drawings agree. Grey dashed outline: now; amber: where it would go; arrows: where things drawn on it would land.`
        : "On the map: blue is this plan now; red is it at its printed sizes. Grey dashed outline: now; amber: where it would go.")
      : (it.kind === "place" ? `Blue: ${anchorName}. Red: this plan ${luNow ? "where it is now" : "where it would go"}; purple where the two drawings agree. Grey dashed outline: now; amber: where it would go.`
        : "Blue: this plan now. Red: it at its printed sizes. Grey dashed outline: now; amber: where it would go.")));
    const t = d("div", "pl-txt");
    const head_ = d("div");
    head_.append(d("span", null, `${{ place: "Line up", refile: "Move to another floor", anchor_scale: "Scale of the plan the others are lined up to" }[it.kind] || it.kind} · ${it.name || "a plan"}`),
      d("span", "pl-chip", "EXPERIMENTAL"));
    t.appendChild(head_);
    const ev = it.evidence || {};
    const lines = [];
    if (it.state === "committed") lines.push("Saved (experimental). A backup was taken first; Undo this line-up session takes it back.");
    if (it.state === "undone") lines.push("Undone: it is back where it was. Accept saves it again.");
    if (it.refused && it.refused.why === "points_out_of_range" && it.state !== "committed") lines.push(`Not saved: ${it.refused.off} of ${it.refused.owned} calibration points on this plan would fall off its picture.`);
    if (it.kind === "place") {
      if (it.state === "same") lines.push(`Already lined up: no corner would move more than ${Math.max(1, Math.round((num(it.max_move_m) || 0) * 100))} cm. Nothing to change.`);
      else lines.push(`Moves up to ${m1(it.max_move_m)} m; scale changes ${pct(it.scale_change)}.`);
      if (ev.anchor_name) lines.push({ text: `Matches ${ev.anchor_name}${num(ev.corr) === null ? "" : ` ${fitWord(ev.corr)}`} (found by ${ev.seed === "stairs" ? "the stairs" : ev.seed === "taps" ? "your taps" : "a search"}); turned ${num(ev.tilt_deg) === null ? "0" : Math.abs(ev.tilt_deg).toFixed(2)}°.`,
        title: num(ev.corr) === null ? "" : `Match score ${ev.corr.toFixed(2)} (1.00: a perfect match)` });
      if (it.held === "no_anchor") lines.push("No plan on this floor matches its own printed sizes, so there's nothing sure to line it up to: look closely.");
    } else if (it.kind === "anchor_scale") {
      const e = ev.scale_err || [];
      lines.push(`The plan the others are lined up to is ${pct(Math.abs(e[0] || 0))} off its own printed sizes across, ${pct(Math.abs(e[1] || 0))} down. ${it.state === "info" ? "Under 3 %: for information only." : "3 % or more: left alone unless you accept it."}`);
    } else {
      const why = (it.proposal || {}).why || {};
      lines.push(`${it.by_hand ? "You say it" : "It"} shows ${it.to_name || "another floor"}${why.title ? ` (“${why.title}”)` : ""}${(why.rooms || []).length ? `: ${why.rooms.join(", ")}` : ""}. Then line it up on ${it.to_name || "that floor"}.`);
      if (it.state === "refused") { const dr = it.drawn || {}; lines.push(`${[dr.rooms ? `${dr.rooms} rooms traced` : "", dr.calibration ? `${dr.calibration} calibration points` : "", (dr.receivers || 0) + (dr.beacons || 0) + (dr.lights || 0) ? "devices" : ""].filter(Boolean).join(" and ")} are drawn on this plan; move it by hand in Mapping → 3D Stack if you're sure.`); }
    }
    if (it.state !== "committed") for (const f of it.flags || []) lines.push(flagLine(f));
    if ((it.others || {}).n && it.state !== "committed") lines.push(`${it.others.n} other device${it.others.n === 1 ? "" : "s"} on this floor lie under this plan; check them against the corrected picture.`);
    if (it.state === "stale") lines.push("The plan moved or changed since this was read: line the floor up again.");
    for (const ln of lines) t.appendChild(subLine(ln));
    const a = d("div", "pl-acts");
    if (luAcceptable(it)) {
      const nf = (it.flags || []).length;
      a.appendChild(btn(nf ? `Accept: ${nf} thing${nf === 1 ? "" : "s"} drawn on this plan would move` : "Accept", "Saves this one (experimental): a backup first; Undo this line-up session takes it back", () => luSave([id], false), "go"));
    }
    if (["open", "same", "info"].includes(it.state)) a.appendChild(btn("Not now", "Leave it (noted at once)", () => luVerdict(id, "not_now")));
    if (["open", "same", "info", "not_now", "undone"].includes(it.state)) {
      if (luWrongFor === id) { for (const [k, w] of LU_WRONG) a.appendChild(btn(w, `Mark it wrong: ${w.toLowerCase()}`, () => luVerdict(id, "wrong", k), "why")); }
      else a.appendChild(btn("Wrong", "Mark it wrong, with one reason (noted at once)", () => { luWrongFor = id; redraw(); }));
    }
    if (it.verdict && ["not_now", "wrong"].includes(it.state)) a.appendChild(btn("Take that back", "Back as it was", () => luVerdict(id, "back")));
    if (it.kind !== "refile" && luDims(it).length) a.appendChild(btn(luDimFor === id ? "Hide the dimension" : "Show me the dimension", "The printed sizes it is based on, on the plan (experimental)", () => { luDimFor = luDimFor === id ? null : id; redraw(); }));
    for (const b of a.querySelectorAll("button")) if (!b.disabled) b.disabled = luBusy;
    t.appendChild(a);
    if (luDimFor === id) paintLuDims(t, it);
    box.appendChild(t);
    sheet.appendChild(box);
  }

  // ── Rooms from plans (Build from plans, Stage 2, experimental) ───────────
  // The Plans tool's third tab (design 5): on a floor whose line-up has ended,
  // Claude reads each lined-up plan twice for its rooms, doors, windows and
  // stairs together; the server proposes the person's own rooms by overlap
  // (never by name), the extra spaces, the doors and windows both reads found
  // (one read only: "maybe", unticked) and the stairs. A flat floor map (and,
  // with a 3D view, the same outlines on it) shows them; a tap selects rooms
  // and spaces to merge. Everything ticked is saved by one "Accept all for this
  // floor" (plan_build_rooms_commit: one backup, one undo), after the rooms gate.
  // Every control here says experimental (tests/js/plan_build_rooms.mjs scans it).
  let rbSess = null, rbFloor = null, rbPoll = null, rbBusy = false, rbErr = "", rbAreas = [], rbUndo = null, rbAskUndo = false;
  let rbGate = null, rbGateKey = "", rbBoth = null, rbNameFor = null, rbAwake = false, rbKey = null, rbFly = false, rbTok = 0;
  const rbPicked = new Set(), rbTicks = new Set(), rbSel = new Set(), rbMeshes = [];
  const RB_PREFIX = "Rooms from plans (experimental): ";
  const RB_BANNER = "Experimental. Claude reads each plan twice; where the two reads agree, their outline is offered, even if it differs from yours. Where they differ, look closely. "
    + "Nothing is saved until Accept all: a backup is taken first, and one undo takes it all back.";
  const RB_COL = { his: "#94a3b8", ready: "#22c55e", look: "#f59e0b", space: "#fb923c", sel: "#3b82f6", r1: "#06b6d4", r2: "#d946ef", door: "#ef4444", window: "#60a5fa", stairs: "#f97316" };
  const rbSaid = (e) => RB_PREFIX + String((e && e.message) || e).replace(RB_PREFIX, "");
  const rbProp = () => (rbSess && rbSess.proposal) || null;
  const rbSaved = (id) => !!(rbSess && rbSess.saved && rbSess.saved[id]);
  const rbInfo = (fid) => ((lu && lu.rooms) || {})[fid] || null;
  const rbArea = (pts) => { let a = 0; for (let i = 0; i < (pts || []).length; i++) { const p = pts[i], q = pts[(i + 1) % pts.length]; a += p[0] * q[1] - q[0] * p[1]; } return Math.abs(a) / 2; };
  const rbInside = (x, y, p) => inPolygon(x, y, p);
  const rbSpaceShown = (s) => !s.merged_into;
  const rbMapWanted = () => mapCan() && !!rbProp() && rbSess.status !== "running";
  /** What a session proposes, ticked by default (the server's `default`): a room the reads agree on, a new room once named, doors, windows and stairs both reads found. */
  function rbDefaults(){
    rbTicks.clear();
    const p = rbProp();
    if (!p) return;
    for (const r of Object.values(p.rooms || {})) if (r.default !== false && !rbSaved(r.id)) rbTicks.add(r.id);
    for (const s of Object.values(p.spaces || {})) if (s.new && rbSpaceShown(s) && !rbSaved(s.id)) rbTicks.add(s.id);
    for (const o of Object.values(p.openings || {})) if (o.default && !rbSaved(o.id)) rbTicks.add(o.id);
    for (const s of Object.values(p.stairs || {})) if (s.default && !rbSaved(s.id)) rbTicks.add(s.id);
  }
  function rbTake(r, fresh){
    if (!r) return;
    const was = rbSess && rbSess.id;
    if ("session" in r) rbSess = r.session;
    if (r.areas) rbAreas = r.areas;
    if ("undo" in r) rbUndo = r.undo;
    if (rbSess) rbFloor = rbSess.floor_id;
    if (fresh || !rbSess || rbSess.id !== was) { rbDefaults(); rbSel.clear(); }
    else {                                                      // after an edit: what is new is ticked as offered, what went is dropped
      const p = rbProp() || {};
      const have = new Set([...Object.keys(p.openings || {}), ...Object.keys(p.stairs || {}), ...Object.values(p.rooms || {}).map(x => x.id),
        ...Object.values(p.spaces || {}).filter(rbSpaceShown).map(x => x.id)]);
      for (const id of [...rbTicks]) if (!have.has(id) || rbSaved(id)) rbTicks.delete(id);
      for (const r2 of Object.values(p.rooms || {})) if (!rbSaved(r2.id) && !rbSel.has(r2.id) && r2.default !== false && !rbTicks.has(r2.id) && r2.flags && r2.flags.includes("merge_only")) rbTicks.add(r2.id);
      for (const s of Object.values(p.spaces || {})) if (s.new && rbSpaceShown(s) && !rbSaved(s.id)) rbTicks.add(s.id);
      for (const id of [...rbSel]) if (!have.has(id)) rbSel.delete(id);
    }
    rbGateKey = "";
  }
  async function rbOpen(){
    rbBusy = true; redraw();
    await luInfo();
    loadUrls();
    if (lu && lu.rooms_running) { rbPollStart(lu.rooms_running); rbBusy = false; return; }
    const last = Object.values((lu && lu.rooms) || {}).map(f => f.last).filter(Boolean).sort((a, b) => (b.at || 0) - (a.at || 0))[0];
    if (last && last.session && !rbSess) { try { rbTake(await luCall("plan_build_rooms_status", { session: last.session }), true); } catch (e) { rbErr = rbSaid(e); } }
    rbBusy = false; rbKey = null; rbFly = true; redraw();
  }
  function rbPick(fid){
    rbFloor = fid; rbSess = null; rbPicked.clear(); rbErr = "";
    count("plans_floor:s2");
    if (!(rbInfo(fid) || {}).ready) count("plan_build_stop_ui:s2_not_placed");
    for (const p of ((rbInfo(fid) || {}).plans || [])) if (p.tick !== false) rbPicked.add(p.map_id);
    redraw();
  }
  /** The line-up's note (Garry, 2026-11-10: a note, not a block), with the way to finish it. */
  const RB_NOTE = { no_lineup: "This floor hasn't been lined up", lineup_open: "Line-up not finished on this floor", moved: "A plan moved since this floor's line-up",
                    not_lined_up: "Not every plan on this floor is lined up" };
  function rbLineupNote(fid, note){
    if (!note) return;
    const box = luSection("pl-note");
    box.setAttribute("data-plan-build", "rooms-lineup-note");
    box.appendChild(d("div", null, `${RB_NOTE[note] || RB_NOTE.lineup_open}: outlines follow your plans as placed now. Finish the line-up for a closer fit. Experimental.`));
    const a = d("div", "pl-acts");
    a.appendChild(btn("Finish the line-up (experimental)", "Open Line up plans on this floor", () => { mode = "lineup"; luFloor = fid; luOpen().then(() => { if (!luSess) luPick(fid); }); }));
    box.appendChild(a);
    sheet.appendChild(box);
  }
  /** Read again: a third read of the plans a flagged room was read on; two of three decide it. */
  const rbReadAgain = (room) => rbWrite("plan_build_rooms_read_again", { rev: rbSess.rev, room }, () => { if (rbSess && rbSess.status === "running") rbPollStart(rbSess.id); });
  async function rbStart(){
    if (rbBusy || !rbFloor) return;
    rbBusy = true; rbErr = ""; redraw();
    try { const r = await luCall("plan_build_rooms_start", { floor_id: rbFloor, map_ids: [...rbPicked] }); rbPollStart(r.session); }
    catch (e) { rbErr = rbSaid(e); }
    rbBusy = false; redraw();
  }
  function rbPollStart(sid){
    rbPollStop();
    const tick = guard(async () => {
      try {
        const r = await luCall("plan_build_rooms_status", { session: sid });
        rbTake(r, true);
        if (rbSess && rbSess.status !== "running") { rbPollStop(); rbKey = null; rbFly = true; }
      } catch (e) { rbErr = rbSaid(e); rbPollStop(); }
      redraw();
    });
    rbPoll = setInterval(tick, POLL_MS);
    tick();
  }
  function rbPollStop(){ if (rbPoll) { clearInterval(rbPoll); rbPoll = null; } }
  async function rbReload(){ try { rbTake(await luCall("plan_build_rooms_status", { session: rbSess.id }), false); } catch (_) { /* what is shown stays */ } }
  async function rbEdit(op, extra, after){
    if (rbBusy || !rbSess) return;
    rbBusy = true; rbErr = ""; redraw();
    try { rbTake(await luCall("plan_build_rooms_edit", { session: rbSess.id, rev: rbSess.rev, op, ...extra }), false); if (after) after(); }
    catch (e) { if (e.code === "rev_mismatch") await rbReload(); rbErr = rbSaid(e); }
    rbBusy = false; rbKey = null; redraw();
  }
  /** The rooms gate for the ticks as they are (plan_build_rooms_check), asked once a change of ticks or edits. */
  function rbCheck(){
    const p = rbProp();
    if (!p || !rbSess || rbSess.status === "running") return;
    const ids = [...rbTicks].filter(i => i.startsWith("room:") || i.startsWith("space:")).sort();
    const key = `${rbSess.id}|${rbSess.rev}|${ids.join(",")}`;
    if (key === rbGateKey) return;
    rbGateKey = key;
    luCall("plan_build_rooms_check", { session: rbSess.id, items: ids }).then((r) => { if (rbGateKey === key) { rbGate = r.gate; redraw(); } }).catch(() => { /* Save checks it again */ });
  }
  /** A new stair's piece, as Add data via plans builds one (the 3D view's builders); null with no 3D view. */
  function rbFinals(ids){
    const out = {}, p = rbProp();
    for (const id of ids) {
      const s = id.startsWith("stairs:") ? p.stairs[id] : null;
      if (!s || s.relation === "correction") continue;
      const piece = ctx.stairPiece ? ctx.stairPiece(s.geom, s.floor_id, PIECE_LABEL) : null;
      if (piece) out[id] = ctx.DRAFT && ctx.DRAFT.planFinal ? ctx.DRAFT.planFinal(piece) : piece;
    }
    return out;
  }
  async function rbWrite(type, extra, done){
    if (rbBusy || !rbSess) return;
    rbBusy = true; rbErr = ""; rbAskUndo = false; redraw();
    try {
      const r = (await luCall(type, { session: rbSess.id, ...(extra || {}) })) || {};
      rbTake(r, r.ok !== false);
      if (r.gate) rbGate = r.gate;
      if (r.ok === false) rbErr = RB_PREFIX + String(r.message || r.code || "").replace(RB_PREFIX, "");
      else if (done) done(r);
    } catch (e) {
      if (e.code === "rev_mismatch") await rbReload();
      rbErr = rbSaid(e);
    }
    rbKey = null; rbBusy = false; redraw();
  }
  const rbSave = () => { const ids = [...rbTicks]; return rbWrite("plan_build_rooms_commit", { rev: rbSess.rev, items: ids, finals: rbFinals(ids) }, () =>
    ctx.hint(`${RB_PREFIX}saved ${ids.length} item${ids.length === 1 ? "" : "s"} in one save. A backup was taken first; Undo takes it all back.`)); };
  const rbUndoIt = () => rbWrite("plan_build_rooms_undo", {}, (r) => {
    const k = (r.skipped || []).length;
    ctx.hint(`${RB_PREFIX}${r.undone || 0} put back${k ? `; ${k} changed since ${k === 1 ? "was" : "were"} left as ${k === 1 ? "it is" : "they are"}` : ""}.`);
  });

  // -- the flat floor map: his outlines, the proposal, the selection ---------
  function rbShapes(){ return roomShapes(rbProp(), { both: rbBoth }); }
  function rbHit(x, y){
    const hits = rbShapes().filter(s => (s.kind === "ready" || s.kind === "look" || s.kind === "space" || s.kind === "dim") && rbInside(x, y, s.pts));
    hits.sort((a, b) => rbArea(a.pts) - rbArea(b.pts));
    return hits.length ? hits[0].id : null;
  }
  function rbToggleSel(id){ if (!id) return; if (rbSel.has(id)) rbSel.delete(id); else rbSel.add(id); rbKey = null; redraw(); }
  function rbCanvas(){
    const c = d("canvas"), shapes = rbShapes(), p = rbProp() || {};
    c.setAttribute("data-plan-build", "rooms-map");
    c.width = 480; c.height = 320; c.style.width = "100%"; c.style.height = "auto"; c.style.background = "#0b1510"; c.style.borderRadius = "8px"; c.style.cursor = "pointer";
    const all = shapes.flatMap(s => s.pts || []);
    if (!all.length) return c;
    const xs = all.map(q => q[0]), ys = all.map(q => q[1]);
    const x0 = Math.min(...xs), x1 = Math.max(...xs), y0 = Math.min(...ys), y1 = Math.max(...ys);
    c.height = Math.round(Math.min(560, Math.max(220, c.width * (y1 - y0) / Math.max(0.1, x1 - x0))));
    const k = Math.min((c.width - 20) / Math.max(0.1, x1 - x0), (c.height - 20) / Math.max(0.1, y1 - y0));
    const toPx = ([x, y]) => [10 + (x - x0) * k, 10 + (y - y0) * k];
    const g = c.getContext && c.getContext("2d");
    if (g) {
      const poly = (pts, stroke, dash, fill, w = 2) => {
        if (!pts || pts.length < 3) return;
        g.beginPath(); pts.map(toPx).forEach(([x, y], i) => (i ? g.lineTo(x, y) : g.moveTo(x, y))); g.closePath();
        if (fill) { g.fillStyle = fill; g.fill(); }
        g.strokeStyle = stroke; g.lineWidth = w; g.setLineDash(dash); g.stroke(); g.setLineDash([]);
      };
      for (const s of shapes) {
        const sel = rbSel.has(s.id);
        if (s.kind === "his") poly(s.pts, RB_COL.his, [5, 4], null, 1.5);
        else if (s.kind === "r1" || s.kind === "r2") poly(s.pts, RB_COL[s.kind], [8, 4], null, 2);
        else poly(s.pts, sel ? RB_COL.sel : RB_COL[s.kind === "dim" ? "look" : s.kind] || RB_COL.look, s.kind === "dim" ? [2, 4] : [],
          sel ? "rgba(59,130,246,.25)" : s.kind === "space" ? "rgba(251,146,60,.12)" : "rgba(34,197,94,.07)", sel ? 3 : 2);
      }
      for (const o of Object.values(p.openings || {})) {
        if (!o.a_m || !o.b_m) continue;
        const [a, b] = [toPx(o.a_m), toPx(o.b_m)];
        g.strokeStyle = o.cls === "window" ? RB_COL.window : RB_COL.door; g.lineWidth = rbTicks.has(o.id) ? 4 : 2; g.setLineDash(rbTicks.has(o.id) ? [] : [3, 3]);
        g.beginPath(); g.moveTo(a[0], a[1]); g.lineTo(b[0], b[1]); g.stroke(); g.setLineDash([]);
      }
      for (const s of Object.values(p.stairs || {})) {
        const q = s.geom || {}, [cx, cy] = toPx([q.x_m, q.y_m]), r = Math.max(4, Math.min(q.width_m || 1, q.depth_m || 1) * k / 2);
        g.strokeStyle = RB_COL.stairs; g.lineWidth = rbTicks.has(s.id) ? 3 : 1.5; g.strokeRect(cx - r, cy - r, 2 * r, 2 * r);
      }
      g.font = "11px system-ui"; g.fillStyle = "#e2e8f0";
      for (const s of shapes) if (s.name && (s.kind === "ready" || s.kind === "look" || s.kind === "space")) {
        const xs2 = s.pts.map(q => q[0]), ys2 = s.pts.map(q => q[1]), [tx, ty] = toPx([(Math.min(...xs2) + Math.max(...xs2)) / 2, (Math.min(...ys2) + Math.max(...ys2)) / 2]);
        g.fillText(s.name.slice(0, 18), tx - 24, ty + 4);
      }
    }
    c.onclick = guard((e) => { const r = c.getBoundingClientRect(), px = (e.clientX - r.left) * c.width / (r.width || c.width), py = (e.clientY - r.top) * c.height / (r.height || c.height);
      rbToggleSel(rbHit(x0 + (px - 10) / k, y0 + (py - 10) / k)); });
    return c;
  }

  // -- on the 3D view: the same outlines, at the floor ------------------------
  function rbDrop(){ rbTok++; for (const m of rbMeshes.splice(0)) dropMesh(m); }
  function rbSleep(){ if (!rbAwake) return; rbAwake = false; rbKey = null; rbDrop(); if (ctx.quiet) ctx.quiet(false); if (ctx.render) ctx.render(); }
  function rbSync(){
    if (!mapCan() || !rbProp()) return;
    const sc = ctx.scene();
    if (!sc) return;
    if (!group) { group = new THREE.Group(); group.name = "plan-ai"; }
    if (group.parent !== sc) sc.add(group);
    const F = floorUi(rbSess.floor_id);
    if (!rbAwake) { rbAwake = true; rbFly = true; rbKey = null; if (ctx.quiet) ctx.quiet(true); }
    if (rbFly && F && ctx.setTopFloor && (ctx.currentFloor ? ctx.currentFloor() : null) !== F) ctx.setTopFloor(String(F.fl.id));
    const key = F ? JSON.stringify([rbSess.id, rbSess.rev, [...rbSel], [...rbTicks], rbBoth, F.fl.elev]) : "";
    if (key !== rbKey) {
      rbDrop(); rbKey = key;
      if (F) {
        const y = F.fl.elev, add = (pts, col, h, closed = true) => { if (pts && pts.length >= 2) { const m = dashMesh(dashTriangles(pts, closed, closed ? 0.5 : 2, closed ? 0.2 : 0.01, 0.1), y + h, col); rbMeshes.push(m); group.add(m); } };
        for (const s of rbShapes()) add(s.pts, rbSel.has(s.id) ? RB_COL.sel : RB_COL[s.kind === "dim" ? "look" : s.kind] || RB_COL.look, s.kind === "his" ? 0.04 : 0.06);
        for (const o of Object.values(rbProp().openings || {})) if (o.a_m && rbTicks.has(o.id)) add([o.a_m, o.b_m], o.cls === "window" ? RB_COL.window : RB_COL.door, 0.08, false);
      }
    }
    if (rbFly && F && ctx.flySpot) {
      rbFly = false;
      const pts = rbShapes().flatMap(s => s.pts || []);
      if (pts.length) { const xs = pts.map(q => q[0]), ys = pts.map(q => q[1]);
        requestAnimationFrame(guard(() => { if (rbAwake) ctx.flySpot(F, (Math.min(...xs) + Math.max(...xs)) / 2, (Math.min(...ys) + Math.max(...ys)) / 2, Math.max(Math.max(...xs) - Math.min(...xs), Math.max(...ys) - Math.min(...ys)) + 2, padNow()); })); }
    }
    if (ctx.render) ctx.render();
  }

  // -- the tab ---------------------------------------------------------------
  function paintRooms(){
    luTabs();
    head("Rooms from plans", "Claude reads a floor's plans: rooms, doors, windows and stairs together. Experimental.");
    sheet.appendChild(d("div", "pl-ban", RB_BANNER));
    if (rbErr) { const e = d("div", "pl-note pl-bad", rbErr); e.setAttribute("role", "alert"); sheet.appendChild(e); }
    if (rbBusy && !rbSess) { sheet.appendChild(d("div", "pl-note", "Looking…")); return; }
    if (rbSess && rbSess.status === "running") return paintRbProgress();
    if (rbSess) return paintRbSession();
    paintRbPicker();
  }
  function paintRbPicker(){
    const floors = (lu && lu.floors) || [];
    sheet.appendChild(d("h5", null, "Which floor (experimental)"));
    const chips = d("div", "pl-choose");
    chips.setAttribute("data-plan-build", "rooms-floors");
    for (const f of floors) {
      const ri = rbInfo(f.id) || {}, n = (ri.plans || []).length, un = luUnscaled(f.id).length;
      const b = btn(`${f.name || f.id} · ${ri.ready ? `${n} plan${n === 1 ? "" : "s"}${ri.lined_up ? " lined up" : ""}` : un ? `${plural(un, "plan")}, no scale yet` : "no plan"}`,
        ri.ready ? "Read its rooms" : un ? "Its plans need a scale before their rooms can be read" : "No plan is filed on this floor", () => rbPick(f.id));
      b.setAttribute("aria-pressed", String(rbFloor === f.id));
      chips.appendChild(b);
    }
    sheet.appendChild(chips);
    const f = floors.find(x => x.id === rbFloor), ri = f ? rbInfo(f.id) : null;
    if (!f) { sheet.appendChild(d("div", "pl-note", "Pick a floor. Its plans are read where they sit now; lining the floor up first gives closer outlines.")); return; }
    if (!ri || !ri.ready) {                              // the one stop here: no plan with a scale to read; says why, offers the way on
      const un = luUnscaled(f.id);
      if (un.length) {
        sheet.appendChild(d("div", "pl-note", `${luFloorName(f.id)}: the plans on this floor have no scale yet, so their rooms can't be read. Experimental.`));
        paintMeasure(un[0]);
      } else sheet.appendChild(d("div", "pl-note", `${luFloorName(f.id)}: there's no plan on this floor yet, so there is nothing to read. Add one in Mapping → Upload. Experimental.`));
      return;
    }
    rbLineupNote(f.id, ri.note);
    const LINE = { lined_up: "lined up", not_lined_up: "not lined up: read where it sits now", moved: "moved since its line-up: read where it sits now",
                   other_floor: "the line-up says it shows another floor: not ticked" };
    for (const p of ri.plans || []) {
      const l = d("label", "pl-tick");
      l.setAttribute("data-plan-build", "rooms-plan");
      const cb = d("input"); cb.type = "checkbox"; cb.checked = rbPicked.has(p.map_id);
      cb.addEventListener("change", () => { if (cb.checked) rbPicked.add(p.map_id); else rbPicked.delete(p.map_id); redraw(); });
      l.appendChild(cb);
      if (urls && urls[p.map_id]) { const im = d("img"); im.src = urls[p.map_id]; im.alt = ""; l.appendChild(im); }
      l.appendChild(d("span", null, `${p.name || "a plan"} — ${LINE[p.lineup] || LINE.not_lined_up}`));
      sheet.appendChild(l);
    }
    const ticked = (ri.plans || []).filter(p => rbPicked.has(p.map_id)), priced = ticked.filter(p => num(p.est_usd) !== null);
    const est = !ticked.length ? "tick the plans to read" : priced.length === ticked.length ? `about $${priced.reduce((s, p) => s + p.est_usd, 0).toFixed(2)} for ${ticked.length === 1 ? "this plan" : `these ${ticked.length} plans`} (estimate, experimental)` : "no price is known for this model";
    sheet.appendChild(d("div", "pl-note", `${(lu && lu.unlock && lu.unlock.display) || "Claude"} reads each plan twice: the plans leave the house for Anthropic; ${est}. `
      + "Nothing is saved until you accept: one save for the floor, a backup first, one undo."));
    const acts = d("div", "pl-acts");
    acts.setAttribute("data-plan-build", "rooms-start");
    const go = btn(`Read rooms on ${f.name || f.id} (experimental)`, "Claude reads each ticked plan twice; you check everything before it is saved", () => rbStart(), "go");
    go.disabled = rbBusy || !rbPicked.size || !!(lu && lu.start_blocked);
    acts.appendChild(go);
    sheet.appendChild(acts);
  }
  function paintRbProgress(){
    const pr = rbSess.progress || {};
    sheet.appendChild(d("div", "pl-sum", `${pr.step === "measure" ? "Working out the rooms" : pr.step === "read 3" && rbSess.third_for ? `Reading ${rbSess.third_for.room} again, a third read` : `Reading ${pr.name || "a plan"}, ${pr.step || "read 1"}`} (${pr.plan || 0} of ${pr.of || 0})… experimental.`));
    sheet.appendChild(d("div", "pl-note", `${rbSess.reads || 0} reads so far, ${mins(rbSess.spent_s)} of ${mins(rbSess.budget_s)}.`));
    const acts = d("div", "pl-acts");
    acts.setAttribute("data-plan-build", "rooms-cancel");
    acts.appendChild(btn("Stop (experimental)", "Stops after the read in flight; what was read is kept", () => luCall("plan_build_cancel", { session: rbSess.id }).then(r => ctx.hint(r.message)).catch(() => {})));
    sheet.appendChild(acts);
  }
  function rbTick(id, label, sub, opts = {}){
    const l = d("label", "pl-tick");
    l.setAttribute("data-plan-build-item", id.split(":")[0]);            // a row under its section's heading, which says experimental
    const cb = d("input"); cb.type = "checkbox"; cb.checked = rbTicks.has(id); cb.disabled = !!opts.off || rbSaved(id) || rbBusy;
    cb.addEventListener("change", () => { if (cb.checked) rbTicks.add(id); else rbTicks.delete(id); rbKey = null; redraw(); });
    l.appendChild(cb);
    const t = d("span", "pl-txt");
    t.appendChild(d("div", null, rbSaved(id) ? `${label} · saved` : label));
    for (const s of sub || []) if (s) t.appendChild(subLine(s));
    l.appendChild(t);
    return l;
  }
  function paintRbSession(){
    const s = rbSess, p = rbProp() || {}, rooms = Object.values(p.rooms || {}), spaces = Object.values(p.spaces || {}).filter(rbSpaceShown);
    const ops = Object.values(p.openings || {}), stairs = Object.values(p.stairs || {});
    const word = { done: "done", cancelled: "stopped", failed: "failed", out_of_time: "ran out of time", no_credit: "out of credit" }[s.status] || s.status;
    const cost = num(s.est_usd) !== null ? `, about $${s.est_usd.toFixed(2)} (estimate)` : "";
    sheet.appendChild(d("div", "pl-sum", `${luFloorName(s.floor_id)}: ${word}. ${s.reads || 0} reads${cost}. ${rooms.length} room${rooms.length === 1 ? "" : "s"} `
      + `(${rooms.filter(r => r.ready).length} ready, ${rooms.filter(r => !r.ready).length} to look at), `
      + `${spaces.length} extra space${spaces.length === 1 ? "" : "s"}, ${ops.filter(o => o.cls === "door").length} doors, ${ops.filter(o => o.cls === "window").length} windows, ${stairs.length} stair${stairs.length === 1 ? "" : "s"}.`));
    rbLineupNote(s.floor_id, s.lineup_note);
    const stops = (s.stops || []).slice(-4);
    if (stops.length || s.resumable) {
      const box = luSection("pl-note");
      box.setAttribute("data-plan-build", "rooms-stops");
      box.appendChild(d("div", "pl-sub", "Where it stopped (experimental):"));
      for (const st of stops) box.appendChild(d("div", null, `${st.say}${st.next ? ` ${st.next}` : ""}`));
      if (s.resumable) {
        const b = btn("Resume (experimental)", "Reads what is left; what was read is kept", async () => {
          try { const r = await luCall("plan_build_rooms_resume", { session: s.id }); rbPollStart(r.session); } catch (e) { rbErr = rbSaid(e); redraw(); }
        });
        b.disabled = rbBusy; box.appendChild(b);
      }
      sheet.appendChild(box);
    }
    if (!p.rooms) { paintRbFoot(); return; }
    // The map, and what is selected on it.
    const mapBox = luSection("pl-row pl-lu");
    mapBox.appendChild(rbCanvas());
    mapBox.appendChild(d("div", "pl-lu-key", "Grey dashes: your rooms now. Green: proposed, the reads agree; amber: look closely; orange: extra spaces; blue: selected. "
      + "Red: doors, light blue: windows, orange squares: stairs (dotted: not ticked). Tap a room or a space to select it. Experimental."));
    const sel = [...rbSel];
    const bar = d("div", "pl-acts");
    bar.setAttribute("data-plan-build", "rooms-merge");
    if (sel.length) {
      const names = sel.map(id => id.startsWith("room:") ? id.slice(5) : ((p.spaces || {})[id] || {}).name || id);
      bar.appendChild(d("span", "pl-sub", `Selected: ${names.join(", ")}.`));
      const m = btn(`Merge selected into one (experimental)`, "One clean outline; at most one of your rooms in it, never two", () => rbEdit("merge", { parts: sel }, () => rbSel.clear()), "go");
      m.disabled = rbBusy || sel.length < 2 || sel.filter(i => i.startsWith("room:")).length > 1;
      bar.append(m, btn("Clear", "Select nothing", () => { rbSel.clear(); rbKey = null; redraw(); }));
      if (sel.filter(i => i.startsWith("room:")).length > 1) bar.appendChild(d("div", "pl-sub", "Two of your rooms can't be merged here: that would remove one. Merge spaces into one room."));
    } else bar.appendChild(d("span", "pl-sub", "Extra spaces that belong to a room: select them with the room on the map, then Merge selected (experimental)."));
    mapBox.appendChild(bar);
    sheet.appendChild(mapBox);
    paintRbGate();
    paintRbRooms(rooms, p);
    paintRbSpaces(spaces, p);
    paintRbOpenings(ops);
    paintRbStairs(stairs);
    paintRbFoot();
  }
  function paintRbGate(){
    rbCheck();
    const g = rbGate, line = d("div", "pl-note");
    line.setAttribute("data-plan-build", "rooms-gate");
    if (!g || g.now === null || g.now === undefined) line.textContent = "Rooms right on your calibration spots: working it out… (experimental)";
    else {
      const f = (v) => `${Math.round(v * 10) / 10} %`;
      line.textContent = g.scored ? `For information: your calibration spots inside their own room, ${f(g.now)} now, ${f(g.with)} with what is ticked (${g.spots} spots). Each room below says its own. Experimental.`
        : `Only ${g.spots} calibration spot${g.spots === 1 ? "" : "s"} on this floor: too few to judge (${g.inside_now} inside their room now, ${g.inside_with} with these). Experimental.`;
      if (g.held_out && g.held_out.now !== null) line.textContent += ` A second check against your calibration spots: ${g.held_out.now} % now, ${g.held_out.with} % with these.`;
    }
    sheet.appendChild(line);
  }
  function paintRbRooms(rooms, p){
    sheet.appendChild(d("h5", null, "Rooms (experimental)"));
    for (const r of rooms.sort((a, b) => Number(a.ready) - Number(b.ready) || a.room.localeCompare(b.room))) {
      const fl = r.flags || [], sub = [];
      if (fl.includes("merge_only")) sub.push("Not on these plans: its outline now, with what you merged into it.");
      else if (r.third && r.third.decided && r.ready) sub.push({ text: "Read again: two of three reads agree.", title: `Agreement ${Math.max(...(r.third.agree || [0])).toFixed(2)} (1.00: the same outline)` });
      else if (r.ready) sub.push({ text: "Both reads agree.", title: `Agreement ${(r.agree || 0).toFixed(2)} (1.00: the same outline)` });
      else if (fl.includes("one_read")) sub.push("Only one read found it: not ticked; tick it to use it.");
      else if (fl.includes("three_differ")) sub.push("Look closely: read again, and all three reads differ. Not ticked: pick the one that fits and tick it, or keep yours.");
      else if (fl.includes("reads_differ")) sub.push({ text: "Look closely: the two reads differ. Not ticked: show both reads to compare, read it again, or tick it to use it.", title: `Agreement ${(r.agree || 0).toFixed(2)} (1.00: the same outline)` });
      else sub.push({ text: "Look closely: both reads agree, but its printed rooms didn't join into one shape. Not ticked: merge, or tick it to use it.", title: `Agreement ${(r.agree || 0).toFixed(2)} (1.00: the same outline)` });
      if (!fl.includes("merge_only")) sub.push({ text: `Matches your outline ${fitWord(r.iou_now || 0)}; ${m1(r.area_now)} → ${m1(r.area_new)} m².`, title: `Overlap ${(r.iou_now || 0).toFixed(2)} (1.00: the same outline)` });
      if (fl.includes("apart")) sub.push("Some of its printed rooms didn't join the rest: only the largest part is used.");
      if (!fl.includes("merge_only") && (r.spots || [])[2]) sub.push(`Using read ${r.pick}${r.picked_by === "person" ? " (your pick)" : ""}: ${Math.max(0, r.spots[r.pick - 1])} of the ${r.spots[2]} calibration spots in this room stay inside it.`);
      if ((r.cal || {}).leaving) sub.push(`${r.cal.leaving} of your ${r.cal.labelled} spots would fall outside it${r.cal.most ? " (half or more: not ticked)" : ""}; ${r.cal.leaving === 1 ? "it keeps its" : "they keep their"} room label. Your choice: keep yours, or use Claude's.`);
      if ((r.merged || []).length) sub.push(`Merged in: ${r.merged.map(id => ((p.spaces || {})[id] || {}).name || id).join(", ")}.`);
      const row = rbTick(r.id, r.room, sub);
      const a = d("div", "pl-acts");
      if (!fl.includes("merge_only") && (r.reads_m || []).every(Boolean)) {
        a.appendChild(btn(rbBoth === r.room ? "Hide both reads" : "Show both reads", "Read 1 cyan, read 2 magenta, on the map (experimental)", () => { rbBoth = rbBoth === r.room ? null : r.room; rbKey = null; redraw(); }));
        for (const k of [1, 2, 3].filter(k => k !== r.pick && (r.reads_m || [])[k - 1])) a.appendChild(btn(`Use read ${k}`, "Use that read's outline for this room (experimental)", () => rbEdit("pick", { room: r.room, read: k })));
        if (fl.includes("reads_differ") || fl.includes("three_differ")) a.appendChild(btn("Read again (experimental)",
          `A third read of ${(r.plans || []).length === 1 ? "its plan" : `its ${(r.plans || []).length} plans`}, the whole plan again (crops cut rooms off in the test); two of three decide`, () => rbReadAgain(r.room)));
      }
      if ((r.cal || {}).leaving) {
        a.appendChild(btn("Keep mine", "Leave your outline as it is (untick)", () => { rbTicks.delete(r.id); rbKey = null; redraw(); }, rbTicks.has(r.id) ? "" : "go"));
        a.appendChild(btn("Use Claude's", "Save Claude's outline anyway (tick)", () => { rbTicks.add(r.id); rbKey = null; redraw(); }, rbTicks.has(r.id) ? "go" : ""));
      }
      for (const m of ((rbSess.edits || {}).merges || []).filter(m => m.into === r.id)) a.appendChild(btn("Separate (experimental)", "Take this merge back", () => rbEdit("separate", { merge: m.id })));
      a.appendChild(btn(rbSel.has(r.id) ? "Selected" : "Select", "Select it on the map, to merge", () => rbToggleSel(r.id)));
      for (const b of a.querySelectorAll("button")) b.disabled = rbBusy || rbSaved(r.id);
      row.lastChild.appendChild(a);
      sheet.appendChild(row);
    }
    if ((p.unseen || []).length) sheet.appendChild(d("div", "pl-note", `Not on these plans, left as they are: ${p.unseen.join(", ")}. Experimental.`));
  }
  function paintRbSpaces(spaces, p){
    if (!spaces.length) return;
    sheet.appendChild(d("h5", null, "Extra spaces (experimental)"));
    sheet.appendChild(d("div", "pl-note", "Spaces on the plan that aren't one of your rooms yet. Merge one into a room, add it as a new room with a name you pick, or leave it out (the default)."));
    const his = Object.keys(p.rooms || {}).concat(p.unseen || []).sort();
    for (const sp of spaces) {
      const sub = [`${m1(rbArea(sp.outline_m))} m² · ${sp.reads.length > 1 ? "both reads" : "one read only"}`];
      if (sp.new) sub.push(`New room: ${sp.new}. Ticked to save.`);
      const row = sp.new ? rbTick(sp.id, `${sp.name} → ${sp.new}`, sub) : (() => { const b = luSection("pl-row"); b.setAttribute("data-plan-build-item", "space"); const t = d("div", "pl-txt"); t.appendChild(d("div", null, sp.name)); t.appendChild(d("div", "pl-sub", sub[0] + " · left out")); b.appendChild(t); return b; })();
      const holder = sp.new ? row.lastChild : row.firstChild;
      const a = d("div", "pl-acts");
      const pick = d("select");
      pick.appendChild(d("option", null, "Merge into…"));
      for (const n of his) { const o = d("option", null, n); o.value = n; pick.appendChild(o); }
      pick.addEventListener("change", guard(() => { if (pick.value && pick.value !== "Merge into…") rbEdit("merge", { parts: [`room:${pick.value}`, sp.id] }); }));
      pick.title = "Merge it into one of your rooms (experimental)"; pick.disabled = rbBusy;
      a.appendChild(pick);
      if (rbNameFor === sp.id) {
        const inp = d("input"); inp.type = "text"; inp.placeholder = "room name"; inp.maxLength = 40; inp.style.width = "120px";
        const list = d("select");
        list.appendChild(d("option", null, "Home Assistant areas…"));
        for (const n of rbAreas) { const o = d("option", null, n); o.value = n; list.appendChild(o); }
        list.addEventListener("change", () => { if (list.value && list.value !== "Home Assistant areas…") inp.value = list.value; });
        a.append(list, inp, btn("Use it", "Add it as a new room with this name (experimental)", () => { const v = inp.value.trim(); if (v) rbEdit("space", { space: sp.id, name: v }, () => { rbNameFor = null; rbTicks.add(sp.id); }); }, "go"),
          btn("Cancel", "Leave it as it is", () => { rbNameFor = null; redraw(); }));
      } else if (!sp.new) a.appendChild(btn("Add as a new room (experimental)", "You pick its name: a Home Assistant area or your own", () => { rbNameFor = sp.id; redraw(); }));
      if (sp.new) a.appendChild(btn("Leave out", "Not a room after all", () => rbEdit("space", { space: sp.id, name: "" }, () => rbTicks.delete(sp.id))));
      if (sp.merge) a.appendChild(btn("Separate (experimental)", "Take this merge back", () => rbEdit("separate", { merge: sp.merge })));
      a.appendChild(btn(rbSel.has(sp.id) ? "Selected" : "Select", "Select it on the map, to merge", () => rbToggleSel(sp.id)));
      for (const b of a.querySelectorAll("button")) b.disabled = b.disabled || rbBusy || rbSaved(sp.id);
      holder.appendChild(a);
      sheet.appendChild(row);
    }
  }
  function paintRbOpenings(ops){
    if (!ops.length) return;
    sheet.appendChild(d("h5", null, "Doors and windows (experimental)"));
    const n = (f) => ops.filter(f).length;
    sheet.appendChild(d("div", "pl-note", `Proposed when both reads found it: ${n(o => o.cls === "door" && o.reads > 1)} doors, ${n(o => o.cls === "window" && o.reads > 1)} windows. `
      + `Found by one read only ("maybe", not ticked): ${n(o => o.reads === 1)}. Already in your house, offered as a correction (not ticked): ${n(o => o.existing && o.existing.what === "opening")}. `
      + `Already drawn on your map, left as is: ${n(o => o.existing && o.existing.what !== "opening")}. Not on a wall of your rooms: ${n(o => !o.placed)}.`));
    const what = (o) => o.cls === "window" ? `Window${o.rooms.length ? ` in ${o.rooms[0]}` : ""}` : `${o.kind === "doorway" ? "Doorway" : "Door"}${o.rooms.length > 1 ? ` between ${o.rooms[0]} and ${o.rooms[1]}` : o.rooms.length ? ` of ${o.rooms[0]}` : ""}${o.type ? ` (${o.type})` : ""}`;
    for (const o of ops.sort((a, b) => (b.reads - a.reads) || a.id.localeCompare(b.id))) {
      const fix = !!(o.existing && o.existing.what === "opening"), off = !o.placed || (!!o.existing && !fix);
      sheet.appendChild(rbTick(o.id, what(o), [fix ? "Already in your house: a correction moves or resizes yours to the one read. Not ticked." : o.existing ? "Already drawn on your map: left as is."
        : !o.placed ? "Not on a wall of your rooms: not offered." : o.reads > 1 ? "Both reads." : "Maybe: one read only."], { off }));
    }
  }
  function paintRbStairs(stairs){
    if (!stairs.length) return;
    sheet.appendChild(d("h5", null, "Stairs (experimental)"));
    for (const s of stairs) {
      const rel = ({ new: "new", correction: `moves the stair you have by ${m1(s.distance_m)} m${s.hand ? "; you placed that one, so it isn't ticked" : ""}`, duplicate: "already in your house: left as is",
        stacked: "a second staircase here? Not ticked" }[s.relation] || s.relation) + (s.other_floor ? `; it climbs from ${floorName(s.floor_id)}, best read with that floor, so it isn't ticked` : "");
      const off = s.relation === "duplicate", need = (s.relation === "new" || s.relation === "stacked") && !ctx.stairPiece;
      sheet.appendChild(rbTick(s.id, `Stairs${s.room ? ` in ${s.room}` : ""}${s.geom && s.geom.says ? `, ${s.geom.says}` : ""} · ${floorName(s.floor_id)}`,
        [`${rel}.${s.reads > 1 ? "" : " Maybe: one read only."}`, need ? "A new stair is built in the 3D view: open Live Aboard to save it." : ""], { off: off || need }));
    }
  }
  function paintRbFoot(){
    const foot = d("div", "pl-foot");
    foot.setAttribute("data-plan-build", "rooms-foot");
    const ids = [...rbTicks].filter(id => !rbSaved(id)), c = (pre) => ids.filter(i => i.startsWith(pre)).length;
    if (rbProp() && ids.length) {
      const save = btn(`Accept all for ${luFloorName(rbSess.floor_id)} (experimental): ${[c("room:") ? `${c("room:")} rooms` : "", c("space:") ? `${c("space:")} new` : "", c("door:") ? `${c("door:")} doors` : "",
        c("window:") ? `${c("window:")} windows` : "", c("stairs:") ? `${c("stairs:")} stairs` : ""].filter(Boolean).join(", ")}`,
      "Everything ticked, in one save: a backup is taken first, and one undo takes it all back", () => rbSave(), "go");
      save.disabled = rbBusy;
      foot.appendChild(save);
    }
    if (rbSess.saved && Object.keys(rbSess.saved).length) {
      if (rbAskUndo) {
        foot.appendChild(d("div", "pl-note", "Put every room, door, window and stair this session saved back as it was? A backup is taken first; anything you changed since is left as it is."));
        const yes = btn("Undo it (experimental)", "Takes the whole rooms session back", () => rbUndoIt(), "go");
        yes.disabled = rbBusy;
        foot.append(yes, btn("Cancel", "Keep what was saved", () => { rbAskUndo = false; redraw(); }));
      } else foot.appendChild(btn("Undo this rooms session (experimental)", "Puts back everything this session saved", () => { rbAskUndo = true; redraw(); }));
    }
    foot.appendChild(btn("Read the floor again (experimental)", "Pick a floor and read it again", () => { rbSess = null; rbKey = null; rbSel.clear(); rbGate = null; rbSleep(); luInfo().then(() => redraw()); }));
    sheet.appendChild(foot);
  }

  /** Keep mine, or the AI's position where the AI placed it too: where the keyboard starts on the first correction. */
  function paintFocus(){
    if (focusBtn && !focusBtn.disabled) { try { focusBtn.focus({ preventScroll: true }); } catch (_) { /* no matter */ } }
  }
  function paint(){
    if (urls) loadUrls();                                // a tool left open overnight: fresh links before the old ones run out
    holdMove();
    sheet.classList.add("plans");
    const onMap = mapWanted();
    sheet.classList.toggle("map", onMap);
    focusBtn = null;
    if (view === "ignored") { mapSleep(); paintIgnored(); return true; }
    if (step === "loading") { mapSleep(); head("Add data via plans"); sheet.appendChild(d("div", "pl-note", "Looking for your plans…")); return true; }
    if (step === "sample") { mapSleep(); head("Add data via plans"); sheet.appendChild(d("div", "pl-note", "Sample mode shows a sample house: switch to Live mode to read your own plans.")); return true; }
    if (mode === "rooms" && lu) {
      // Rooms from plans: its outlines on the 3D view when there is one, the flat map and the lists on the sheet.
      mapSleep(); luSleep();
      const rbMap = rbMapWanted();
      if (!rbMap) rbSleep();
      paintRooms();
      if (rbMap) rbSync();
      return true;
    }
    rbSleep();
    if (mode === "lineup" && lu) {
      // The proposals on the vetting map when there is one (the 3D view), else as cards.
      mapSleep();
      const luMap = luMapWanted();
      sheet.classList.toggle("map", luMap);
      if (!luMap) luSleep();
      paintLineup(luMap);
      if (luMap) luSync();
      return true;
    }
    luSleep();
    if (step === "progress") { mapSleep(); luTabs(); paintProgress(); return true; }
    if (onMap) { paintMap(); paintFocus(); syncMap(); return true; }
    mapSleep();
    if (step === "list" && sess) { luTabs(); paintList(); paintFocus(); return true; }
    luTabs();
    paintConsent();
    return true;
  }

  return {
    /** The Plans tool on (the editor's tool) or off. */
    show(on){
      on = !!on;
      if (on === shownNow) return;
      shownNow = on;
      if (on) { wallsSeen.clear(); count("plans_tool:opened"); view = "list"; failing = null; listAsked = false; cur = null; card = "item"; urls = null; mode = "add"; open(); luInfo().then(() => redraw()); }
      else { stopPoll(); luPollStop(); rbPollStop(); sheet.classList.remove("plans"); sheet.classList.remove("map"); mapSleep(); luSleep(); rbSleep(); pics.clear(); tints.clear(); }
    },
    /** The sheet's content for the step we are at; true: there is one. */
    sheet: () => paint(),
    commit, refused,
    /** A Save went in: each correction's target and each plan checked again. */
    afterSave(){ if (sess && shownNow) reload().then(() => { settle(); redraw(); }); },
    mapShown: () => mapAwake,
    down, move, up, cancel: () => { gesture = null; }, hover, layout, key,
    /** What the harness and the tests read. */
    state(){
      return { cur, card, moving, onMap: mapAwake, floor: floorSeen, pins: [...pins.values()].map(p => ({ id: p.id, n: Number(p.el.dataset.n), state: p.el.dataset.state })),
               ghosts: [...ghosts.keys()], plan: planNow ? planNow.map_id : null, planShown: !!(planMesh && planMesh.visible), opacity, textures: texLive, verdicts: vCount, fade,
               lineup: { on: !!(lu && lu.on), mode, floor: luFloor, session: luSess ? luSess.id : null, status: luSess ? luSess.status : null,
                         items: luSess ? Object.keys(luSess.items || {}) : [], cur: luCur, onMap: luAwake, meshes: luMeshes.length },
               rooms: { floor: rbFloor, session: rbSess ? rbSess.id : null, status: rbSess ? rbSess.status : null, ticks: [...rbTicks].sort(), selected: [...rbSel],
                        gate: rbGate, onMap: rbAwake, meshes: rbMeshes.length } };
    },
    /** Line up plans on the map: show this item (the harness and its screenshots). */
    lineupItem(id){ luCur = id; luDimFor = null; luFly = true; luKey = null; redraw(); },
    /** Line up plans (experimental): straight to its tab, on a floor (the harness and Settings' link). */
    lineup(fid){ mode = "lineup"; if (fid) luFloor = fid; luOpen().then(() => { if (fid && !luSess) luPick(fid); }); },
    /** Rooms from plans (experimental): straight to its tab, on a floor (the harness and its screenshots). */
    rooms(fid){ mode = "rooms"; rbOpen().then(() => { if (fid && !rbSess) rbPick(fid); }); },
    /** Rooms from plans: select a room or space as a tap on the map does, show both reads of a room (the harness). */
    roomsSelect(id){ rbToggleSel(id); },
    roomsBoth(room){ rbBoth = room; rbKey = null; redraw(); },
    dispose(){ stopPoll(); luPollStop(); rbPollStop(); shownNow = false; mapSleep(); luSleep(); rbSleep(); keysTo(false); try { style.remove(); pinsEl.remove(); } catch (_) { /* gone with its root */ } },
  };
}

/**
 * The list, with no 3D view behind it (no WebGL: Mapping → Furnish offers it).
 * Mounts in `box`; host = {callWS, floors: [{id, name, level, outdoor}], toast, and the view's rules: DRAFT, PIECES, FURN}.
 * The same draft rules and the same one writer as in Edit; a new stair stands as
 * the AI read it (nothing here knows the rooms' walls to square it to).
 */
export async function openPlansList(box, host){
  const { DRAFT, PIECES, FURN } = host;
  const r = await host.callWS({ type: "padspan_ha/house3d_get" });
  const file = DRAFT.ownedOf((r && r.data) || r || {});
  const draft = DRAFT.createDraft(file);
  const sheet = document.createElement("div");
  sheet.className = "la3d-sheet plans pl-flat on";
  box.appendChild(sheet);
  const floors = (host.floors || []).map(f => ({ fl: { id: f.id, name: f.name, outdoor: !!f.outdoor, elev: num(f.level) ?? 0 }, rooms: [] }));
  let saving = false, tool = null;
  const redraw = () => { const y = sheet.scrollTop; sheet.replaceChildren(); tool.sheet(); sheet.scrollTop = y; };
  const toast = (t, bad) => { if (typeof host.toast === "function") host.toast(t, bad); };
  tool = createPlans({ root: box, sheet, guard: (f) => f, host: () => host, floors: () => floors, hint: toast, redraw, DRAFT, draft: () => draft,
    change: (fn) => { const ok = draft.change(fn); if (ok) redraw(); return ok; }, saving: () => saving,
    stairPiece: (g, fid, label) => {
      const base = FURN ? FURN.defaultRecipe("stairs") : null;
      if (!base || base.kind !== "stairs") return null;
      const p = PIECES.makePiece({ ...base, params: { ...(base.params || {}), shape: g.shape || "straight", style: "closed", rail: "none" }, width_m: g.width_m, depth_m: g.depth_m }, fid, { x: g.x_m, y: g.y_m, rotation: g.rotation }, "build");
      p.label = label;
      return p;
    },
    fileWritten: (data) => { draft.rebase(DRAFT.ownedOf(data)); },
    save: async () => {
      if (saving) return;
      saving = true; redraw();
      try {
        const kept = await tool.commit();
        if (kept) { draft.adopt("pieces", kept.pieces, kept.renamed); if (kept.lights) draft.adopt("lights", kept.lights); draft.rebase(DRAFT.ownedOf(kept.data)); toast(kept.said); }
      } catch (e) {
        if (e && e.planRefusal) await tool.refused(e);
        toast(String((e && (e.message || e.code)) || e), true);
      }
      saving = false; redraw();
    } });
  tool.show(true);
  return { tool, dispose(){ tool.dispose(); sheet.remove(); } };
}
