# PadSpan HA — BLE Room-Presence Tracking for Home Assistant
# Copyright (C) 2026 Garry Broeckling
# Licensed under the GNU General Public License v3.0
# See LICENSE file or https://www.gnu.org/licenses/gpl-3.0.html
"""
PadSpan HA — Presence Sensors
================================
Creates sensor entities for every BLE device the user has labelled:

  sensor.{label}_area          — current room name ("unknown" / "not_home")
  sensor.{label}_distance      — distance to the nearest scanner (metres)
  sensor.{label}_distance_{scanner} — distance to each individual scanner (metres)

The per-scanner distance sensors are created dynamically: a new entity is
registered the first time a scanner reports an advertisement from the device.
State returns None (unavailable) while the device is away.

Entity ID examples:
  sensor.padspan_car_keys_area
  sensor.padspan_car_keys_distance
  sensor.padspan_car_keys_distance_kitchen_proxy
Automation example:
  trigger when sensor.padspan_wallet_distance_bedroom_proxy < 1.5
"""
from __future__ import annotations

import logging
import time
from datetime import timedelta
from typing import Any

from homeassistant.components.sensor import SensorEntity, SensorStateClass
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant, callback
from homeassistant.helpers.entity_platform import AddEntitiesCallback
from homeassistant.helpers.update_coordinator import CoordinatorEntity
from homeassistant.helpers import device_registry as dr

from .const import (
    DOMAIN,
    DATA_SETTINGS,
    DATA_DEVICE_REGISTRY,
)
from .presence_coordinator import PresenceCoordinator
from .presence_rules import away_timeout_s, calc_distance as _calc_distance
from .entity_identity import alternates_of, pick_uid_key, registry_ready, uid_safe

_LOGGER = logging.getLogger(__name__)

# The away rule lives in presence_rules; this alias keeps existing call sites
# reading naturally while there is exactly one implementation.
_away_timeout_s = away_timeout_s


async def async_setup_entry(
    hass: HomeAssistant,
    entry: ConfigEntry,
    async_add_entities: AddEntitiesCallback,
) -> None:
    coordinator: PresenceCoordinator | None = hass.data.get(DOMAIN, {}).get("presence_coordinator")
    if not coordinator:
        return

    created: set[str] = set()
    # label → list of sensor entities (for key migration on MAC rotation)
    label_sensors: dict[str, list[SensorEntity]] = {}
    created_scanner: set[tuple[str, str]] = set()
    # label → list of scanner sensor entities
    label_scanner_sensors: dict[tuple[str, str], PadSpanScannerDistanceSensor] = {}

    # Creates entities for newly-seen labelled devices, and MIGRATES existing
    # entities to a fresher coordinator key when one shows up for the same
    # label — never creates a second entity for the same label. This is the
    # fix for two related historical bugs: rotating-MAC devices (unlabelled
    # IRK, random-static MACs) used to mint a brand-new sensor.*_2 entity
    # every time the MAC rotated, and remove/re-add of a labelled device
    # without a full factory reset could duplicate entities too. Migration
    # always prefers the coordinator entry with the lowest age_s (freshest
    # data), on the theory that whichever key is currently reporting live
    # data is the one still attached to the real device.
    _since = time.monotonic()

    @callback
    def _check_new() -> None:
        if not coordinator.data:
            return
        if not registry_ready(hass, _since):
            return   # its saved ids decide the unique_ids (entity_identity)
        st = hass.data.get(DOMAIN, {}).get(DATA_SETTINGS)
        _sd = (st.data or {}) if st else {}
        _area_on = _sd.get("ha_entity_area_enabled", True)
        _dist_on = _sd.get("ha_entity_distance_enabled", True)
        _scan_on = _sd.get("ha_entity_scanner_distance_enabled", True)
        new: list[SensorEntity] = []
        # Sort by freshness — lowest age_s first so the active key wins dedup.
        # Only labelled objects can have entities: sorting the whole street
        # every poll was wasted work (issue #91).
        items = sorted(
            ((k, o) for k, o in coordinator.data.items() if _should_track(o)),
            key=lambda kv: kv[1].get("age_s") if isinstance(kv[1].get("age_s"), (int, float)) else 999999,
        )
        by_label: dict[str, list[tuple[str, str]]] = {}
        alt_label: dict[str, list[str]] = {}
        for key, obj in items:
            by_label.setdefault(obj["user_label"], []).append((key, _stable_uid_key(hass, key, obj)))
            alt_label.setdefault(obj["user_label"], []).extend(alternates_of(key, obj))

        def _fresher(key: str, obj: dict[str, Any], cur_key: str) -> bool:
            if key == cur_key:
                return False
            age = obj.get("age_s")
            old_age = (coordinator.data or {}).get(cur_key, {}).get("age_s")
            return isinstance(age, (int, float)) and (not isinstance(old_age, (int, float)) or age < old_age)

        for key, obj in items:
            if not _should_track(obj):
                continue
            label = obj["user_label"]
            if label in label_sensors:
                # Every poll, not only when a new key appears: once both keys
                # of a label were known, a sensor stayed on the one that went
                # quiet (not_home) while the tracker followed the live one.
                existing = label_sensors[label]
                if existing and _fresher(key, obj, existing[0]._key):
                    for ent in existing:
                        _LOGGER.debug(
                            "Migrating sensor '%s' from key %s to fresher key %s",
                            label, ent._key, key,
                        )
                        ent._key = key
            elif key not in created:
                uid = pick_uid_key(hass, "sensor", lambda u: [f"padspan_ha__{uid_safe(u)}__area",
                                                              f"padspan_ha__{uid_safe(u)}__distance"],
                                   by_label[label], alt_label.get(label))
                sensors: list[SensorEntity] = []
                if _area_on:
                    s = PadSpanAreaSensor(coordinator, key, uid)
                    new.append(s)
                    sensors.append(s)
                if _dist_on:
                    s = PadSpanDistanceSensor(coordinator, key, uid)
                    new.append(s)
                    sensors.append(s)
                label_sensors[label] = sensors
            created.add(key)
            # Per-scanner distance sensors — one per device × scanner pair
            if _scan_on:
                for source in (obj.get("_source_rssi") or {}).keys():
                    pair = (key, source)
                    label_pair = (label, source)
                    if label_pair in label_scanner_sensors:
                        existing_s = label_scanner_sensors[label_pair]
                        if _fresher(key, obj, existing_s._key):
                            existing_s._key = key
                    elif pair not in created_scanner:
                        # One already registered keeps its name (an older
                        # version named a scanner sensor after the key it
                        # was first heard on); a new one takes the label's
                        # area/distance identity, so all sit on one device.
                        _lbl = label_sensors.get(label)
                        uid = pick_uid_key(
                            hass, "sensor", lambda u: [f"padspan_ha__{uid_safe(u)}__dist__{uid_safe(source)}"],
                            by_label[label], alt_label.get(label),
                            fallback=_lbl[0]._uid_key if _lbl else None)
                        s = PadSpanScannerDistanceSensor(coordinator, key, source, uid)
                        new.append(s)
                        label_scanner_sensors[label_pair] = s
                    created_scanner.add(pair)
        if new:
            _LOGGER.debug("Adding %d new PadSpan sensor(s)", len(new))
            async_add_entities(new)

    _check_new()
    entry.async_on_unload(coordinator.async_add_listener(_check_new))

    # ── Occupancy sensors (off by default, enabled in Settings) ──────────
    st = hass.data.get(DOMAIN, {}).get(DATA_SETTINGS)
    _occ_on = ((st.data or {}) if st else {}).get("ha_entity_occupancy_enabled", False)
    if _occ_on:
        from .websocket import compute_occupancy_estimate
        occ_coord = PadSpanOccupancyCoordinator(hass, compute_occupancy_estimate)
        await occ_coord.async_config_entry_first_refresh()
        async_add_entities([PadSpanOccupancySensor(occ_coord)])


def _should_track(obj: dict[str, Any]) -> bool:
    """Only create entities for BLE objects the user has explicitly labelled."""
    return obj.get("kind") in ("ble", "private_ble", "ibeacon") and bool(obj.get("user_label"))


def _device_uid(obj: dict[str, Any]) -> str:
    # Prefer padspan_id (immutable stable identity from DeviceRegistry),
    # then canonical_id (survives MAC rotation for private_ble),
    # then volatile identifiers as last resort.
    if obj.get("padspan_id"):
        return obj["padspan_id"]
    if obj.get("canonical_id"):
        return obj["canonical_id"]
    return obj.get("address") or obj.get("entity_id") or obj.get("key", "")


def _stable_uid_key(hass: HomeAssistant, key: str, obj: dict[str, Any]) -> str:
    """Return the identity string used to build entity unique_ids.

    irk:/ibeacon:/entity: keys are already stable — keep the key-based scheme
    so entities registered under it are not orphaned.  Plain ble:/MAC keys
    rotate across restarts (labelled phones without a registered IRK,
    random-static MACs, degraded-mode IRK devices), minting _2/_3 orphan
    entities — for those, prefer the persistent padspan_id from the
    DeviceRegistry, then canonical_id, falling back to the key itself.
    """
    if key.startswith(("irk:", "ibeacon:", "entity:")):
        return key
    dev_reg = hass.data.get(DOMAIN, {}).get(DATA_DEVICE_REGISTRY)
    if dev_reg:
        # Only trust persistent registry entries — ephemeral padspan_ids are
        # regenerated every restart and would fragment unique_ids further.
        pid = obj.get("padspan_id")
        if pid and dev_reg.get(pid):
            return str(pid)
        rpid = dev_reg.resolve(key)
        if rpid and dev_reg.get(rpid):
            return str(rpid)
    if obj.get("canonical_id"):
        return str(obj["canonical_id"])
    return key


class PadSpanAreaSensor(CoordinatorEntity[PresenceCoordinator], SensorEntity):
    """Reports the current room for a labelled BLE device."""

    _attr_icon = "mdi:map-marker"
    _attr_has_entity_name = True

    def __init__(self, coordinator: PresenceCoordinator, key: str, uid_key: str | None = None) -> None:
        super().__init__(coordinator)
        self._key = key
        obj = (coordinator.data or {}).get(key, {})
        self._init_label = str(obj.get("user_label") or obj.get("name") or key)
        self._init_uid = _device_uid(obj) or key
        # Snapshot at creation: unique_id must never follow _key migrations
        self._uid_key = uid_key or _stable_uid_key(coordinator.hass, key, obj)

    # ── internal helpers ─────────────────────────────────────────────────────

    @property
    def _obj(self) -> dict[str, Any]:
        return (self.coordinator.data or {}).get(self._key, {})

    def _label(self) -> str:
        obj = self._obj
        return str(obj.get("user_label") or obj.get("name") or self._init_label)

    # ── HA entity identity ────────────────────────────────────────────────────

    @property
    def unique_id(self) -> str:
        safe = self._uid_key.replace(":", "_").replace(" ", "_").replace("/", "_")
        return f"padspan_ha__{safe}__area"

    @property
    def name(self) -> str:
        # With has_entity_name=True this renders as "{device name} Area"
        return "Area"

    @property
    def device_info(self) -> dict[str, Any]:
        uid = _device_uid(self._obj) or self._init_uid
        address = self._obj.get("address")
        model_id = self._obj.get("kind")
        serial_number = self._obj.get("padspan_id")
        return {
            "identifiers": {(DOMAIN, uid)},
            "name": self._label(),
            "manufacturer": "PadSpan HA",
            "model": "BLE Presence Tracker",
            "model_id": model_id,
            "serial_number": serial_number,
            "connections": {(dr.CONNECTION_BLUETOOTH, address)}
        }

    # ── state ─────────────────────────────────────────────────────────────────

    @property
    def native_value(self) -> str:
        obj = self._obj
        age = obj.get("age_s")
        if isinstance(age, (int, float)) and age > _away_timeout_s(self.coordinator.hass):
            return "not_home"
        return obj.get("room") or "unknown"

    @property
    def available(self) -> bool:
        # Entity stays available as long as the coordinator is healthy.
        # "not_home" is a valid state — going unavailable would break automations.
        return bool(self.coordinator.last_update_success and self.coordinator.data is not None)

    @property
    def extra_state_attributes(self) -> dict[str, Any]:
        obj = self._obj
        age = obj.get("age_s")
        timeout = _away_timeout_s(self.coordinator.hass)
        home = not (isinstance(age, (int, float)) and age > timeout)
        attrs: dict[str, Any] = {
            "kind": obj.get("kind"),
            "address": obj.get("address"),
            "padspan_id": obj.get("padspan_id"),
            "rssi": obj.get("rssi") if home else None,
            "age_s": round(age, 1) if isinstance(age, (int, float)) else None,
            "sources": obj.get("sources") if home else None,
            "home": home,
            "room_confidence": obj.get("room_confidence"),
            "rssi_margin_confidence": obj.get("rssi_margin_confidence"),
        }
        if obj.get("ibeacon_uuid"):
            attrs["ibeacon_uuid"] = obj["ibeacon_uuid"]
            attrs["ibeacon_major"] = obj.get("ibeacon_major")
            attrs["ibeacon_minor"] = obj.get("ibeacon_minor")
        all_addrs = obj.get("all_addresses") or []
        if all_addrs:
            attrs["num_addresses"] = len(all_addrs)
            # Cap the list persisted to the recorder — high-rotation devices (iPhone IRK)
            # can accumulate hundreds of MACs and exceed the 16384-byte attribute limit.
            attrs["all_addresses"] = all_addrs[:5]
        return attrs


class PadSpanDistanceSensor(CoordinatorEntity[PresenceCoordinator], SensorEntity):
    """Reports the estimated distance (metres) to the nearest scanner for a labelled BLE device."""

    _attr_icon = "mdi:ruler"
    _attr_has_entity_name = True
    _attr_native_unit_of_measurement = "m"
    _attr_state_class = SensorStateClass.MEASUREMENT
    _attr_suggested_display_precision = 1

    def __init__(self, coordinator: PresenceCoordinator, key: str, uid_key: str | None = None) -> None:
        super().__init__(coordinator)
        self._key = key
        obj = (coordinator.data or {}).get(key, {})
        self._init_label = str(obj.get("user_label") or obj.get("name") or key)
        self._init_uid = _device_uid(obj) or key
        # Snapshot at creation: unique_id must never follow _key migrations
        self._uid_key = uid_key or _stable_uid_key(coordinator.hass, key, obj)

    @property
    def _obj(self) -> dict[str, Any]:
        return (self.coordinator.data or {}).get(self._key, {})

    def _label(self) -> str:
        obj = self._obj
        return str(obj.get("user_label") or obj.get("name") or self._init_label)

    @property
    def unique_id(self) -> str:
        safe = self._uid_key.replace(":", "_").replace(" ", "_").replace("/", "_")
        return f"padspan_ha__{safe}__distance"

    @property
    def name(self) -> str:
        return "Distance"

    @property
    def device_info(self) -> dict[str, Any]:
        uid = _device_uid(self._obj) or self._init_uid
        address = self._obj.get("address")
        model_id = self._obj.get("kind")
        serial_number = self._obj.get("padspan_id")
        return {
            "identifiers": {(DOMAIN, uid)},
            "name": self._label(),
            "manufacturer": "PadSpan HA",
            "model": "BLE Presence Tracker",
            "model_id": model_id,
            "serial_number": serial_number,
            "connections": {(dr.CONNECTION_BLUETOOTH, address)}
        }

    @property
    def native_value(self) -> float | None:
        obj = self._obj
        rssi = obj.get("rssi")
        age = obj.get("age_s")
        if rssi is None:
            return None
        if isinstance(age, (int, float)) and age > _away_timeout_s(self.coordinator.hass):
            return None
        return _calc_distance(float(rssi), obj, self.coordinator.hass)

    @property
    def available(self) -> bool:
        return bool(self.coordinator.last_update_success and self.coordinator.data is not None)

    @property
    def extra_state_attributes(self) -> dict[str, Any]:
        obj = self._obj
        age = obj.get("age_s")
        return {
            "rssi": obj.get("rssi"),
            "tx_power": obj.get("tx_power"),
            "age_s": round(age, 1) if isinstance(age, (int, float)) else None,
            "room": obj.get("room"),
        }


class PadSpanScannerDistanceSensor(CoordinatorEntity[PresenceCoordinator], SensorEntity):
    """Reports the estimated distance (metres) from one specific scanner to a labelled BLE device.

    One entity is created per device × scanner pair the first time a scanner reports
    an advertisement from the device.  State returns None while the device is away or
    the scanner has not heard from it recently.

    Automation example:
        trigger when sensor.my_tag_distance_bedroom_proxy < 1.5
    """

    _attr_icon = "mdi:bluetooth-audio"
    _attr_has_entity_name = True
    _attr_native_unit_of_measurement = "m"
    _attr_state_class = SensorStateClass.MEASUREMENT
    _attr_suggested_display_precision = 1

    def __init__(self, coordinator: PresenceCoordinator, key: str, source: str, uid_key: str | None = None) -> None:
        super().__init__(coordinator)
        self._key = key
        self._source = source
        obj = (coordinator.data or {}).get(key, {})
        self._init_label = str(obj.get("user_label") or obj.get("name") or key)
        self._init_uid = _device_uid(obj) or key
        # Snapshot at creation: unique_id must never follow _key migrations
        self._uid_key = uid_key or _stable_uid_key(coordinator.hass, key, obj)

    @property
    def _obj(self) -> dict[str, Any]:
        return (self.coordinator.data or {}).get(self._key, {})

    def _label(self) -> str:
        obj = self._obj
        return str(obj.get("user_label") or obj.get("name") or self._init_label)

    @property
    def unique_id(self) -> str:
        safe_key = self._uid_key.replace(":", "_").replace(" ", "_").replace("/", "_")
        safe_src = self._source.replace(":", "_").replace(" ", "_").replace("/", "_")
        return f"padspan_ha__{safe_key}__dist__{safe_src}"

    @property
    def name(self) -> str:
        return f"Distance {self._source}"

    @property
    def device_info(self) -> dict[str, Any]:
        uid = _device_uid(self._obj) or self._init_uid
        address = self._obj.get("address")
        model_id = self._obj.get("kind")
        serial_number = self._obj.get("padspan_id")
        return {
            "identifiers": {(DOMAIN, uid)},
            "name": self._label(),
            "manufacturer": "PadSpan HA",
            "model": "BLE Presence Tracker",
            "model_id": model_id,
            "serial_number": serial_number,
            "connections": {(dr.CONNECTION_BLUETOOTH, address)}
        }

    @property
    def native_value(self) -> float | None:
        obj = self._obj
        age = obj.get("age_s")
        if isinstance(age, (int, float)) and age > _away_timeout_s(self.coordinator.hass):
            return None
        rssi = (obj.get("_source_rssi") or {}).get(self._source)
        if rssi is None:
            return None
        return _calc_distance(float(rssi), obj, self.coordinator.hass)

    @property
    def available(self) -> bool:
        return bool(self.coordinator.last_update_success and self.coordinator.data is not None)

    @property
    def extra_state_attributes(self) -> dict[str, Any]:
        obj = self._obj
        rssi = (obj.get("_source_rssi") or {}).get(self._source)
        age = obj.get("age_s")
        return {
            "scanner": self._source,
            "rssi": round(rssi, 1) if rssi is not None else None,
            "age_s": round(age, 1) if isinstance(age, (int, float)) else None,
            "room": obj.get("room"),
        }


# ══════════════════════════════════════════════════════════════════════════════
# Occupancy Estimation Sensors
# ══════════════════════════════════════════════════════════════════════════════

from homeassistant.helpers.update_coordinator import DataUpdateCoordinator


class PadSpanOccupancyCoordinator(DataUpdateCoordinator):
    """Polls the occupancy estimator on a 30s interval."""

    def __init__(self, hass: HomeAssistant, compute_fn) -> None:
        super().__init__(
            hass, _LOGGER,
            name="PadSpan Occupancy",
            update_interval=timedelta(seconds=30),
        )
        self._compute = compute_fn

    async def _async_update_data(self) -> dict[str, Any]:
        try:
            return await self._compute(self.hass)
        except Exception as err:
            _LOGGER.warning("Occupancy estimate failed: %s", err)
            return self.data or {}


class PadSpanOccupancySensor(CoordinatorEntity["PadSpanOccupancyCoordinator"], SensorEntity):
    """Building-level occupancy estimate sensor."""

    _attr_has_entity_name = True
    _attr_state_class = SensorStateClass.MEASUREMENT

    def __init__(self, coordinator: PadSpanOccupancyCoordinator) -> None:
        super().__init__(coordinator)

    @property
    def unique_id(self) -> str:
        return "padspan_ha__occupancy_estimate"

    @property
    def name(self) -> str:
        return "Occupancy"

    @property
    def icon(self) -> str:
        return "mdi:account-group"

    @property
    def device_info(self) -> dict[str, Any]:
        return {
            "identifiers": {(DOMAIN, "padspan_occupancy")},
            "name": "PadSpan Occupancy",
            "manufacturer": "PadSpan HA",
            "model": "Occupancy Estimator",
        }

    @property
    def native_value(self) -> int | None:
        d = self.coordinator.data
        if not d:
            return None
        return d.get("total_estimate")

    @property
    def native_unit_of_measurement(self) -> str:
        return "people"

    @property
    def extra_state_attributes(self) -> dict[str, Any]:
        d = self.coordinator.data or {}
        # Rooms carry evidence, not a second headcount: who is placed there,
        # how many unclaimed phones, whether a sensor says someone.
        room_summary = {
            r["room"]: {"people": r.get("people"), "phones": r.get("phones"),
                        "occupancy": r.get("occupancy"), "motion": r.get("motion")}
            for r in (d.get("rooms") or [])
        }
        return {
            "minimum": d.get("total_low"),
            "maximum": d.get("total_high"),
            "confidence": d.get("confidence"),
            "known": d.get("known"),
            "unknown": d.get("unknown"),
            "people": [{"name": p.get("name"), "room": p.get("room"), "kind": p.get("kind")}
                       for p in (d.get("people") or [])],
            "rooms": room_summary,
        }
