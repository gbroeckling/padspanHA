# PadSpan HA — BLE Room-Presence Tracking for Home Assistant
# Copyright (C) 2026 Garry Broeckling
# Licensed under the GNU General Public License v3.0
# See LICENSE file or https://www.gnu.org/licenses/gpl-3.0.html
"""Websocket commands for Live Aboard's file (house3d_store.py).

Plan: docs/IDEA_ATLAS_3D_HOUSE.md on the live-aboard branch. This is the
first build step, the switch and the empty store: house3d_get and
house3d_clear. Later phases add the piece, light, opening, photo, terms and
library commands, each refused while the feature is off.

- house3d_get: any user, and it works while the feature is off (backups
  label the file from it). It reads; it never writes. It says whether this
  version writes the file (writable): the browser can't tell a schema of 1.0
  from 1 once JSON has read it. Neither it nor house3d_edit ever sends the
  library's owner tokens (house3d_library.without_tokens).
- house3d_clear: admin only, refused while the feature is off and below Pro
  (as if off), and takes an automatic backup of the file first. No backup, no
  clear. A file that was never written has nothing to clear: no backup, no
  write. With only="pieces" it is "Remove all furniture" (P2): every piece
  goes and every other section stays; no furniture, nothing to remove.
- house3d_edit: the 3D editor's Save (P1 part C, P2 Furnish): its whole
  draft — doors and windows drawn on walls, a barrier's hinge, swing, sill
  and head, 3D-only heights of lights and other devices, and furniture —
  checked, then written in one
  store write, or not at all. The light-placement gate (ws_fabric: any user,
  no admin, at the paid tier), inside the Pro-only feature: refused while off
  and below Pro, as if off. The first Save creates the file; from then on
  backups carry it. heights_set names the devices whose height the Save
  writes here because they have no placement record (live_aboard_draft.js
  splitSave): the newest height each has, so one a removed record had made
  out of date in this file (fabric_store "light_heights_gone") counts again
  once the file holds it, and the answer says which are still out of date.

A file that is there but cannot be read is never shown as empty or written
over: the commands answer read_failed until a read succeeds. The two that
write leave a newer PadSpan's file alone (house3d_newer). A write counts only
once the file reads back as written (save_failed otherwise, with nothing
changed), and the writes take turns (House3dStore.lock).
"""

from __future__ import annotations

import voluptuous as vol
from homeassistant.components import websocket_api
from homeassistant.core import HomeAssistant

from .const import DATA_FABRIC, DATA_MODEL, DOMAIN, HOUSE3D_STORE_KEY
from .house3d_library import carried_over, without_tokens
from .house3d_store import (EDIT_SECTIONS, NEWER_MESSAGE, EditError, House3dStore, NewerFile, ReadFailed,
                            apply_edit, async_get_store, empty, enabled, without_pieces, writable)
from .ws_common import admin_if_enhanced_security, _tier_at_least

OFF_CODE = "house3d_off"
OFF_MESSAGE = "Live Aboard is off. Turn it on in Settings → Atlas → Live Aboard."
# Below Pro the 3D house is as if off, whatever the switch says; the message
# says what would bring it back (editions.js: a gate is never a dead end).
PRO_MESSAGE = ("Live Aboard (experimental) needs PadSpan Pro. Enter a key in Settings → Features "
               "→ PadSpan licence, or get one at https://padspan.traks.ca/#pro")
READ_CODE = "read_failed"
READ_MESSAGE = "Could not read Live Aboard's file. Nothing was changed; try again."
NEWER_CODE = "house3d_newer"


async def _loaded(hass: HomeAssistant, connection, msg) -> House3dStore | None:
    """The store, or None once read_failed is sent."""
    try:
        return await async_get_store(hass)
    except ReadFailed:
        connection.send_error(msg["id"], READ_CODE, READ_MESSAGE)
        return None


@websocket_api.websocket_command({"type": "padspan_ha/house3d_get"})
@websocket_api.async_response
async def ws_house3d_get(hass: HomeAssistant, connection, msg) -> None:
    store = await _loaded(hass, connection, msg)
    if store is None:
        return
    connection.send_result(msg["id"], {"enabled": enabled(hass), "data": without_tokens(store.data),
                                       "writable": writable(store.data), "counts": store.counts()})


@websocket_api.websocket_command({"type": "padspan_ha/house3d_clear", vol.Optional("only"): vol.In(("pieces",))})
@websocket_api.require_admin
@websocket_api.async_response
async def ws_house3d_clear(hass: HomeAssistant, connection, msg) -> None:
    furniture = msg.get("only") == "pieces"      # "Remove all furniture": the other sections stay
    if not enabled(hass):
        connection.send_error(msg["id"], OFF_CODE, OFF_MESSAGE)
        return
    if not _tier_at_least(hass, "pro"):
        connection.send_error(msg["id"], OFF_CODE, PRO_MESSAGE)
        return
    store = await _loaded(hass, connection, msg)
    if store is None:
        return
    async with store.lock:
        if not writable(store.data):
            connection.send_error(msg["id"], NEWER_CODE, NEWER_MESSAGE)
            return
        from .house3d_store import async_file_exists  # noqa: PLC0415
        if (furniture and not store.data["pieces"]) or not await async_file_exists(hass):
            # Never written, or no furniture to remove: nothing to remove. No
            # backup (an empty one would push a real safety backup out of the
            # three kept) and no new file.
            store.data = {**store.data, "pieces": {}} if furniture else {}
            connection.send_result(msg["id"], {"cleared": True, "backup_id": None})
            return
        from .ws_backup import _auto_backup  # noqa: PLC0415
        backup_id = await _auto_backup(hass, "Before removing all furniture in Live Aboard" if furniture
                                       else "Before removing everything in Live Aboard", [HOUSE3D_STORE_KEY])
        if not backup_id:
            connection.send_error(msg["id"], "backup_failed",
                                  "Could not take the safety backup — nothing was removed.")
            return
        # What this house shared to the library stays: the owner tokens are
        # the only way to withdraw it (house3d_library.carried_over).
        # A strip run on a piece stays where it was (without_pieces).
        if not await store.async_write(without_pieces(store.data) if furniture
                                       else carried_over(store.data, empty())):
            connection.send_error(msg["id"], "save_failed",
                                  "Could not empty Live Aboard's file. Nothing was removed; the safety backup is kept.")
            return
        connection.send_result(msg["id"], {"cleared": True, "backup_id": backup_id})


@websocket_api.websocket_command({
    "type": "padspan_ha/house3d_edit",
    vol.Optional("openings"): dict,
    vol.Optional("lights"): dict,
    vol.Optional("devices"): dict,
    vol.Optional("pieces"): dict,
    vol.Optional("figures"): dict,
    # The devices with no placement record whose height this Save writes here.
    vol.Optional("heights_set"): [str],
})
@websocket_api.async_response
@admin_if_enhanced_security
async def ws_house3d_edit(hass: HomeAssistant, connection, msg) -> None:
    """Save the 3D editor's draft: {openings, lights, devices, pieces, figures}, each
    {key: entry to set | None to remove}, and heights_set (see above). Returns
    the whole file."""
    if not enabled(hass):
        connection.send_error(msg["id"], OFF_CODE, OFF_MESSAGE)
        return
    if not _tier_at_least(hass, "pro"):
        connection.send_error(msg["id"], OFF_CODE, PRO_MESSAGE)
        return
    store = await _loaded(hass, connection, msg)
    if store is None:
        return
    if "figures" in msg:                 # FIGURE's lists (house3d_builders), read off the loop
        from .house3d_builders import async_data  # noqa: PLC0415
        await async_data(hass)
    async with store.lock:
        try:
            new = apply_edit(store.data, {k: msg[k] for k in EDIT_SECTIONS if k in msg})
        except NewerFile as err:
            connection.send_error(msg["id"], NEWER_CODE, str(err))
            return
        except EditError as err:
            connection.send_error(msg["id"], "invalid", str(err))
            return
        if not await store.async_write(new):
            connection.send_error(msg["id"], "save_failed", "Could not save Live Aboard. Nothing was changed.")
            return
        answer = {"data": without_tokens(store.data), "counts": store.counts()}
        if "heights_set" in msg:
            # The file holds them now: only then are they taken off the list.
            answer["light_heights_gone"] = await _heights_back(hass, msg["heights_set"])
        connection.send_result(msg["id"], answer)


async def _heights_back(hass: HomeAssistant, eids: list[str]) -> list[str]:
    """Take the devices Live Aboard just wrote a height for in its file off
    fabric_store's light_heights_gone (one fabric write, only when one was
    on it); returns the list as it is now."""
    dom = hass.data.get(DOMAIN, {})
    fab = getattr(dom.get(DATA_MODEL), "fabric", None) or dom.get(DATA_FABRIC)
    if fab is None:
        return []
    back = sorted(set(eids) & set(fab.light_heights_gone()))
    if back:
        await fab.async_spatial_update(file_heights_set=back, op="house3d_heights")
    return fab.light_heights_gone()


WS_COMMANDS = (ws_house3d_get, ws_house3d_clear, ws_house3d_edit)
