# PadSpan HA — BLE Room-Presence Tracking for Home Assistant
# Copyright (C) 2026 Garry Broeckling
# Licensed under the GNU General Public License v3.0
# See LICENSE file or https://www.gnu.org/licenses/gpl-3.0.html
"""Opt-in usage statistics — "help the developer improve PadSpan".

OFF by default. Nothing here runs until a person turns it on in Settings →
Presence → Help improve PadSpan, where a Preview button shows the exact JSON
that will go. What goes out is COUNTS and VERSIONS, never things:

    which version, which edition and tier, which Home Assistant
    how many scanners / floors / rooms / placed lights / walls / maps / IRKs
    which feature switches are on
    how many times each tab was opened and each feature used since the
        last report (an allow-listed vocabulary — see EVENTS)
    a few health flags: crypto present, BLE callback alive, coverage floor
        active, how many rotating addresses actually resolved
    whether the building is described at all: floors carrying a real
        storey height, scanners carrying a mounting height, calibration
        points that never got a floor, whether any map is measured
    uncaught panel errors by the PadSpan module that threw, and the tab
        that was open — the half of PadSpan the Python log cannot see
        (see UI_ERRORS)
    Apple Find My: how many Find My addresses are on the air now by type
        (and how many of those are away from their owner), how many tags
        PadSpan follows, and how its hand-overs went — followed, missed by
        reason, wrong links undone by themselves or by a person, tags back
        on their day key (env.findmy, and the findmy_* EVENTS)
    up to 10 saved Showcase presets' VALUES (theme, Automorph settings, a
        few display toggles) — never the preset's own name — so popular
        combinations across installs can surface in every install's own
        "Popular presets" pulldown (see popular_presets.py)
    how hard the machine works and what class of machine it is: load per
        CPU, Home Assistant's own CPU and memory, memory available, swap,
        event-loop lag, how long PadSpan's own snapshot builds and polls
        take, and how often any of them hit a limit (health.perf); CPU
        count, RAM size, architecture, installation type and board family
        from fixed lists (env.hw) — see perf_sampler.py and PERF_METRICS

The reason, in one sentence: the developer has one house to test on, and
this is how features that only exist elsewhere (an iPhone with an IRK, a
Bermuda install, twelve floors, a lighting-only house) get seen at all.

Never: MAC addresses, IRKs or licence keys, device or room or floor NAMES,
coordinates, entity ids, email addresses, timestamps finer than the day.
`assert_shareable` walks every value before a send and refuses the whole
report if anything identifier-shaped is in it — belt on top of the design's
braces — and tests/test_telemetry.py builds a payload from a house full of
names and MACs and proves none of them are in it.

"Become a tester" (tester.py) is a separate channel — its own consent,
button, address, id and storage — and never part of this report.

The install id is a random UUID minted the first time the switch goes on. It
exists so installs can be counted rather than pings; "New anonymous ID" in
the same card replaces it. It is the only thing that persists across
reports, and it means nothing outside this file.

Endpoint: TELEMETRY_URL. At most one POST per UTC day (the last sent day is
persisted, so restarts do not repeat it), about 2-5 KB, hard cap 8 KB.
Failure is silent and non-fatal; nothing is retried, nothing is queued; the
counters survive a failed send and go with the next one.
"""

from __future__ import annotations

import json
import logging
import math
import re
import time
import uuid
from datetime import timedelta
from typing import Any

from homeassistant.core import HomeAssistant

from .build_info import BUILD_VERSION
from .const import (
    DATA_FABRIC,
    DATA_MAPS,
    DATA_MODEL,
    DATA_SETTINGS,
    DOMAIN,
)

_LOGGER = logging.getLogger(__name__)

TELEMETRY_URL = "https://padspan.traks.ca/api/telemetry.php"
# The developer's view of what the reports add up to (server/stats.php).
# Read-only, other people's installs in aggregate; the server admits only a
# key on its developer list, so the Pro + Dev-mode gate in the panel is a
# courtesy and the server is the lock.
STATS_URL = "https://padspan.traks.ca/api/stats.php"
SCHEMA = 1
_INTERVAL = timedelta(hours=24)
_FIRST_DELAY_S = 600           # after the update check, never during startup
_DATA_UNSUBS = "_telemetry_unsubs"
_DATA_COUNTERS = "telemetry_counters"
_DATA_STARTED = "_telemetry_started_mono"
_MAX_BYTES = 8192

# The vocabulary. An event that is not here is dropped, so the frontend and
# every backend call site can only ever count what this file allows — a
# closed list, because the report's KEYS are also data that leaves the box,
# and an open pattern would let any authenticated user put a word into it.
EVENTS: frozenset[str] = frozenset({
    "light_placed", "light_removed", "wall_placed", "wall_removed",
    "room_committed", "irk_added", "irk_add_refused", "irk_validate",
    "calibration_point_added", "capture_started", "forensics_query",
    "showcase_on", "backup_created", "backup_restored", "factory_reset",
    "bright_import",
    # A map's placement committed from the align editor, and one the writer
    # refused because it would have stranded the calibration pins. Both halves
    # matter: a refusal nobody ever hits is a guard nobody needs, and a
    # refusal everybody hits is a guard in the wrong place.
    "map_placement_committed", "map_placement_refused", "point_align_applied",
    # IRK resolution, cumulative over the window: a NEW address resolved to a
    # registered key; a NEW rotating address that matched no key.
    "irk_resolved", "irk_unresolved_rpa",
    # A radio's live scan mode CHANGED. Counted separately by what that radio
    # was asked to do, because the two carry opposite meanings and together
    # they say whether the reported mode means the same thing on every install.
    #
    #   ..._auto    expected and frequent. An AUTO scanner is promoted to
    #               active in short windows, so flips prove the field is
    #               tracking the radio rather than echoing a stored setting.
    #   ..._pinned  expected to be ~0. HA leaves an explicitly ACTIVE or
    #               PASSIVE scanner alone, so a pinned radio that keeps
    #               changing means the mode is NOT under the user's control
    #               there — the one result that would make the map indicator
    #               dishonest, and it cannot be seen from a single install.
    "scan_mode_flip_auto", "scan_mode_flip_pinned",
    # The three guided wizards (v0.38.21): which step was REACHED, once per
    # distinct visit to that step (the wizard dedupes against its own last-
    # counted step, the same way a tab-open event never double-counts a
    # re-render). This is a funnel: comparing step counts against each other
    # shows where people stop advancing, on a feature that only exists in
    # the browser and that the developer's one house cannot exercise every
    # path of. "..._exited_early" is the explicit "Exit setup"/"Exit guide"
    # click before the Finish step — the funnel alone cannot tell a
    # deliberate exit from someone who just has not come back yet.
    "wizard_maps_step_upload", "wizard_maps_step_scale", "wizard_maps_step_rooms",
    "wizard_maps_step_scanners", "wizard_maps_step_finish", "wizard_maps_exited_early",
    "wizard_calib_step_tune", "wizard_calib_step_setup", "wizard_calib_step_roam",
    "wizard_calib_step_model", "wizard_calib_step_finish", "wizard_calib_exited_early",
    # The Lights builder's guided tour: opened (button or auto-open on first
    # visit), reached its last card and closed via Done, or closed via the
    # ✕ before that. A tour with a high opened-to-dismissed ratio and a low
    # completed count is a tour worth shortening, not a tour working as meant.
    "lights_tour_opened", "lights_tour_completed", "lights_tour_dismissed_early",
    # The Free/Bright/Bright Pro/Pro onboarding wizard (Settings -> Features
    # -> PadSpan licence -> "What does each tier unlock?"): which step was
    # reached, once per distinct visit, and whether it was finished via Done
    # or abandoned before the last step — same funnel shape as the other
    # guided wizards above.
    "wizard_tiers_step_free", "wizard_tiers_step_ladder", "wizard_tiers_step_upgrade",
    "wizard_tiers_completed", "wizard_tiers_exited_early",
    # Apple Find My tags (AirTags and "works with Find My" tags) followed
    # across their address changes (findmy.py; runs with mac_rotation_bridging
    # on). Garry, 2026-09-27: "make sure the opt-in records how well tools for
    # this feature actually work" — the switch alone says it is on, not that
    # it follows anything, and one house cannot show how it fares in others.
    #
    #   findmy_linked         a hand-over followed: a tag carried onto its
    #                         next address. `_slow`: of those, the ones that
    #                         landed over 2 minutes after the old address's
    #                         last report (by design, about one minute).
    #   findmy_missed_...     a tag's hand-over window (HANDOVER_WINDOW_S)
    #                         closed with no link — once per tag per window,
    #                         by the strongest reason it came to
    #                         (findmy.MISS_REASONS):
    #     _ambiguous          a candidate fitted, but another pairing was too
    #                         close to call (MARGIN_DB): refused, not guessed;
    #     _late               a new address where the tag was, after the timing
    #                         rule allows (APPEAR_AFTER_S) but no later than a
    #                         real hand-over can be first heard on that
    #                         install (its reseed + poll gap) — a real one the
    #                         timing rule turned down. None at the defaults;
    #     _elsewhere          a new address at the hand-over moment, but not
    #                         where the tag was: another device's own change,
    #                         or the tag carried off as it changed;
    #     _no_candidate       neither: the tag most likely LEFT RANGE.
    #                         The last two are not matcher failures, and never
    #                         to be read as ones — the follow rate is (linked
    #                         − undone) / (linked − undone + ambiguous +
    #                         late), they beside it: a wrong link undone was
    #                         no hand-over due, and undone / linked is its own
    #                         number. A window the bridge did not watch whole
    #                         (a restart, bridging off) is never counted.
    #   findmy_moved_back     a wrong link undone by itself (the tag heard on
    #                         an earlier address again); `_addrs`: how many
    #                         links those undid.
    #   findmy_back_on_day_key  a separated tag back on its day key after
    #                         time near its owner: the Find My schedule, its
    #                         links right — kept apart from the above.
    #   findmy_not_this_tag   a wrong link undone by a person (the Bluetooth
    #                         tab's "Not <name>? Unlink").
    "findmy_linked", "findmy_linked_slow",
    "findmy_missed_ambiguous", "findmy_missed_late", "findmy_missed_elsewhere", "findmy_missed_no_candidate",
    "findmy_moved_back", "findmy_moved_back_addrs", "findmy_back_on_day_key", "findmy_not_this_tag",
    # The Atlas emergency lighting test (emergency_test.py): a test started,
    # ended (the lights already on left on), or ended with Force off.
    "emergency_test_on", "emergency_test_off", "emergency_force_off",
})
# The panel's views (panel.js _VIEW_PATHS — tests/test_telemetry.py asserts
# equality) and the sub-tabs of the two views that have them.
VIEWS: frozenset[str] = frozenset({
    "follow", "overview", "purelive", "objects", "devices", "bluetooth", "presence",
    "history", "monitor", "maps", "events", "health", "settings", "manage", "debug",
    "diagnostics", "qa", "training", "calibration", "traceback", "forensics",
    "sandbox", "occupancy", "installbase",
})
SUBTABS: dict[str, frozenset[str]] = {
    "bluetooth": frozenset({"visualization", "monitor", "scanners", "irk_panel", "esphome_configs"}),
    "maps": frozenset({"library", "upload", "edit", "stack", "rooms", "lights", "export", "help"}),
}
TAB_EVENTS: frozenset[str] = frozenset(
    {f"tab:{v}" for v in VIEWS} | {f"tab:{v}/{s}" for v, subs in SUBTABS.items() for s in subs}
)
# Uncaught panel errors, counted by the PadSpan MODULE that threw
# (www/padspan-ha/views/ui_error.js). The panel is the half of PadSpan the
# Python log cannot see: v0.35.0 shipped a Mapping tab that threw before it
# re-rendered, so the previous tab stayed on screen and it read as a hang.
# A COUNT per module — never the message, never a stack, never anything the
# page happened to be holding.
#
# Before this, the name was the view that was OPEN, and every error on the
# page counted — Home Assistant's own, other cards', browser extensions' — so
# ui_error:overview meant "something threw while Overview was showing". Now
# only a throw with PadSpan code on its stack counts, as
#   ui_error:<view id>        a view module (views/<id>.js, id in VIEWS)
#   ui_error:<helper>         a shared helper in views/ (UI_ERROR_HELPERS)
#   ui_error:panel            panel.js, the shell around the views
#   ui_error:atlas_panel      lights_panel.js, the Atlas sidebar panel
#   ui_error:lib              the vendored Preact/htm, nothing of ours below it
#   ui_error:other            any other PadSpan file (help_content, sample_data)
# and, counted beside it, the tab that was on screen:
#   ui_error_while:<view id> | ui_error_while:atlas
# A report carrying ui_error:* WITHOUT any ui_error_while:* is from a build
# before the change (server/telemetry_summary.py splits them on that).
# tests/test_telemetry.py holds UI_ERROR_HELPERS to the files in views/.
UI_ERROR_HELPERS: frozenset[str] = frozenset({
    "atlas_weather", "fabric_compass", "live_aboard", "live_aboard_draft", "live_aboard_edit", "live_aboard_furniture",
    "live_aboard_house", "live_aboard_library", "live_aboard_use",
    "live_aboard_weather", "live_aboard_showcase",
    "live_aboard_pieces", "live_aboard_furnish",   # Live Aboard P2 Furnish
    "live_aboard_import",
    "live_aboard_devices",                          # Live Aboard P5: furniture that is a device
    "live_aboard_tracked",                          # Live Aboard P6: beacons, scanners and people, live
    "live_aboard_people", "live_aboard_photo",
    "live_aboard_runs", "live_aboard_strip",        # Live Aboard's Strip tool: strips and string lights
    "atlas_screen", "atlas_aboard",                 # the flat Atlas: the map alone, full screen; Live Aboard's on the map
    "live_aboard_marks",                            # Live Aboard: the Atlas's leak sensors, locks, codes and class chips
    "live_aboard_motion",                           # Live Aboard: motion (the ring, the room's glow, markers, coverage, the chip)
    "busy_times", "calibration_matrix", "editions", "evidence_diagram", "house_activity",
    "insights", "iso_lights", "iso_motion", "light_codes", "lights_map", "locate",
    "pan_zoom", "path_loss", "plan_viewer", "push_subscription", "radio_map",
    "room_color", "setup_status", "stack_transform", "tune_save_plan", "ui_error",
    "wall_geom", "whatif_placement", "wled_advanced", "wled_model", "wled_tab_backup",
    "wled_tab_leds", "wled_tab_look", "wled_tab_presets", "wled_tab_settings",
    "wled_tab_sync", "wled_ui", "trial_offer", "release_notes",
})
UI_ERROR_SHELLS: frozenset[str] = frozenset({"panel", "atlas_panel", "lib", "other"})
UI_ERRORS: frozenset[str] = frozenset(
    {f"ui_error:{m}" for m in VIEWS | UI_ERROR_HELPERS | UI_ERROR_SHELLS}
    | {f"ui_error_while:{v}" for v in VIEWS | {"atlas"}}
)
# The 90-day trial offer (views/trial_offer.js) and the Overview's Getting
# started card — a funnel, like the wizards above: where the offer was SEEN
# (once per surface per page), where it was STARTED, and where the licence
# server said no. The email never comes near this: an event is a surface's
# name, from this closed list, and nothing else. TRIAL_SURFACES is
# trial_offer.js's own list; GETTING_STARTED_STEPS is the card's step ids
# (panel.js), plus "trial" for its last line (tests/test_conversion.py
# holds both to the frontend's).
# update_banner / milestone / sidebar: the "updated to vX" banner's trial
# line, the one-time milestone card on Overview (trial_nudge_dismissed is its
# "No thanks" / ✕), and the quiet entry under the PadSpan sidebar menu.
TRIAL_SURFACES: tuple[str, ...] = ("overview", "atlas", "placement", "maps", "locate", "busy_times", "settings",
                                   "update_banner", "milestone", "sidebar")
GETTING_STARTED_STEPS: tuple[str, ...] = ("upload", "scale", "rooms", "scanners", "calibrate", "positioned", "trial")
OFFER_EVENTS: frozenset[str] = frozenset(
    {f"{what}:{s}" for what in ("trial_offer_shown", "trial_started", "trial_failed") for s in TRIAL_SURFACES}
    | {f"getting_started_step:{s}" for s in GETTING_STARTED_STEPS}
    | {"getting_started_shown", "getting_started_dismissed", "trial_nudge_dismissed"}
)
# Atlas outdoor weather (views/atlas_weather.js — the same three lists there,
# held equal by tests/test_atlas_weather.py). Each counted once per page load
# per name, so a count is "pages that saw it", not "renders":
#   weather_error:<kind>     the overlay caught its own failure and drew no
#                            weather (the map itself is never affected)
#                            — except `source`: a chosen entity that no
#                            longer exists (deleted or renamed); a fallback,
#                            where there is one, still draws
#   weather_shown:<state>    what was drawn; `still` = drawn without motion
#                            (the free map, or reduced motion)
#   weather_source:<source>  what made it wet (rain_sensor | condition), none
#                            (no sensor and no weather entity), and which
#                            warning integration made it heavy — whether the
#                            fallbacks work outside Canada.
# Words only: never an entity id, never alert text.
WEATHER_WARNING_PLATFORMS: tuple[str, ...] = ("env_canada", "meteoalarm", "dwd_weather_warnings", "nina",
                                              "meteo_france", "weatheralerts", "nws_alerts")
WEATHER_ERROR_KINDS: tuple[str, ...] = ("mask_build", "mask_unsupported", "tiles", "decision", "mount", "source")
WEATHER_SHOWN_STATES: tuple[str, ...] = ("light_rain", "heavy_rain", "light_snow", "heavy_snow", "still")
WEATHER_SOURCES: tuple[str, ...] = ("rain_sensor", "condition", "none",
                                    *(f"warning:{p}" for p in WEATHER_WARNING_PLATFORMS), "warning:other")
WEATHER_EVENTS: frozenset[str] = frozenset(
    {f"weather_error:{k}" for k in WEATHER_ERROR_KINDS}
    | {f"weather_shown:{k}" for k in WEATHER_SHOWN_STATES}
    | {f"weather_source:{k}" for k in WEATHER_SOURCES}
)
# Live Aboard, the 3D house (views/live_aboard_house.js — the same lists
# there, held equal by tests/test_live_aboard_house.py). Each counted once per
# page load per name:
#   house3d_opened            the 3D view showed on a screen
#   house3d_fallback:<kind>   it could not, and the flat Atlas showed instead:
#                             no_webgl, slow_gpu (the frame-time check),
#                             context_lost, error
# Nothing is sent while the feature is off (settings.atlas_3d_enabled) or the
# tier is below Pro: the shared card draws no 3D at all then.
HOUSE3D_FALLBACK_KINDS: tuple[str, ...] = ("no_webgl", "slow_gpu", "context_lost", "error")
HOUSE3D_EVENTS: frozenset[str] = frozenset(
    {"house3d_opened"} | {f"house3d_fallback:{k}" for k in HOUSE3D_FALLBACK_KINDS}
)
# Its photo step (ws_house3d_photo.py), counted by the server once per photo
# sent: photo_read:ok, :no_ai_task (none chosen, gone, can't read pictures, or
# Home Assistant older than 2025.8), :bad_answer (nothing usable in the
# answer) or :error (the AI Task failed). Never the photo, the AI Task or the
# answer; and nothing while the 3D house is off (the command refuses first).
PHOTO_READ_OUTCOMES: tuple[str, ...] = ("ok", "no_ai_task", "bad_answer", "error")
PHOTO_EVENTS: frozenset[str] = frozenset(f"photo_read:{k}" for k in PHOTO_READ_OUTCOMES)

# The switches whose ON/OFF is reported (booleans only, by name). Every name
# here must be READ by something outside the settings plumbing — a switch
# that drives nothing is not a feature, and reporting it would put a fiction
# in the data (tests/test_telemetry.py holds the list to that).
_FEATURE_FLAGS: tuple[str, ...] = (
    "quiet_mode", "lights_showcase", "lights_fit_rooms", "lights_hide_untouched",
    "lights_hide_device_codes", "lights_isolux", "lights_automorph_enabled",
    "lights_show_beacons",
    "lights_panel_enabled", "radio_map_enabled", "distortion_map_enabled",
    "occupancy_hybrid_enabled", "rssi_capture_enabled", "forensics_enabled",
    "mac_rotation_bridging", "beacon_auto_calibrate", "beacon_profiling_enabled",
    "espresense_mqtt_enabled", "mqtt_publish_enabled", "bermuda_ignore",
    "phone_wizard_enabled", "overview_show_walls", "overview_show_outdoor",
    "overview_2d_mode", "overview_persistent_pins",
    "walk_to_identify_enabled",
    "adaptive_floor_detection", "apple_auto_classify", "aggressive_ble_reseed",
    "ha_entity_tracker_enabled", "ha_entity_area_enabled", "ha_entity_distance_enabled",
    "ha_entity_scanner_distance_enabled", "ha_entity_occupancy_enabled",
    "tags_room_events_enabled", "tags_nfc_identify_enabled", "tags_phone_autolink_enabled",
    "update_check_enabled", "onboarding_completed",
)
# Small enumerations reported by value (each from a fixed vocabulary in
# ws_settings; anything unexpected is dropped by assert_shareable's length rule).
_FEATURE_ENUMS: tuple[str, ...] = ("data_mode", "cpu_mode", "lights_automorph_style")

# Saved Showcase "look" presets (Mapping -> Lights) — Garry: "add presets and
# their components into the opt-in records" so popular combinations across
# installs can surface as a shared "Top 10" pulldown (see popular_presets.py
# and server/popular_presets.php). Every one of these fields is already the
# same trust tier as the live lights_automorph_style/lights_showcase_theme
# ENUMS reported in `features` above — a theme key, a style key, a few
# booleans, three small numbers — just captured as a considered, SAVED
# combination rather than momentary state. A preset's user-typed NAME is
# never included: it is the one field on a preset a person could put
# something personal into, and popularity only needs the values.
_PRESET_VALUE_KEYS: tuple[str, ...] = (
    "lights_showcase", "lights_showcase_theme", "lights_fit_rooms",
    "lights_isolux", "lights_show_beacons", "lights_hide_device_codes",
    "lights_hide_untouched", "lights_automorph_enabled",
    "lights_automorph_room_pct", "lights_automorph_hardness",
    "lights_automorph_style", "lights_automorph_subtlety",
)
# Even though up to 50 presets can be saved, only a courtesy sample is
# shared — plenty for popularity counting, nowhere near the whole list.
_PRESET_SHARE_CAP = 10

# Load and hardware — Garry, 2026-09-29: "Add load numbers and CPU info to
# opt-in for this type of decision in future", "need to watch the pi installs
# for max outs". perf_sampler.py measures; this is what of it may leave, and
# assert_shareable holds env.hw and health.perf to exactly these keys and
# words (_check_load_sections) — a closed list, like EVENTS, and nested under
# keys the receiver already allows (server/telemetry.php refuses any new
# top-level key, and a receiver not redeployed would drop every report).
HW_VALUES: dict[str, tuple[str, ...]] = {
    "ram": ("1g", "2g", "4g", "8g", "16g", "16g+", "unknown"),      # up to N GB
    "arch": ("x86_64", "x86", "aarch64", "armv7", "armv6", "other", "unknown"),
    "install": ("os", "supervised", "container", "core", "other", "unknown"),
    "board": ("rpi2", "rpi3", "rpi4", "rpi5", "rpi_other", "green", "yellow", "odroid", "tinker",
              "khadas", "vm", "generic_x86_64", "generic_aarch64", "other", "unknown"),
}
HW_MAX_CPUS = 64                     # "64" reads "64 or more"
# Report name → (perf_sampler metric, statistics). `_pc` values are whole
# percents, everything else two significant figures; `per_h` is how many per
# hour over the window. Memory available reports its LOW end — that is where
# a machine runs out. A metric with nothing measured is left out (a machine
# without /proc has no memory figures); `samples` says how much of the window
# the once-a-minute sampler covered, and `over` how many of those samples hit
# each limit (perf_sampler.OVER_*: load above 1 per CPU, HA above 90% of one
# core, under 10% memory available, loop lag over 1 s).
PERF_METRICS: dict[str, tuple[str, tuple[str, ...]]] = {
    "load_pc": ("load", ("p50", "p95", "max")),        # 1-min load per CPU
    "cpu_pc": ("cpu", ("p50", "p95", "max")),          # HA's process, of one core
    "cpu_all_pc": ("cpu", ("p50", "p95", "max")),      # ... of all cores
    "rss_mb": ("rss", ("p50", "max")),                 # HA's process
    "mem_avail_pc": ("mem", ("p50", "p05", "min")),    # host
    "swap_mb": ("swap", ("p50", "max")),               # host, used
    "lag_ms": ("lag", ("p50", "p95", "max")),          # event loop
    "snap_ms": ("snap", ("p50", "p95", "max", "per_h")),    # live snapshot build
    "cycle_ms": ("cycle", ("p50", "p95", "max", "per_h")),  # presence poll (incl. its snapshot fetch)
}
PERF_OVER: tuple[str, ...] = ("load", "cpu", "mem", "lag")

# What a report may contain at the top level — anything else is a bug.
_TOP_KEYS: frozenset[str] = frozenset({
    "schema", "install_id", "day", "version", "edition", "tier", "ha_version",
    "python", "env", "features", "usage", "health", "errors", "presets",
})

# Identifier shapes that must never appear in any value.
_MAC_RE = re.compile(r"\b[0-9A-Fa-f]{2}(?:[:\-.][0-9A-Fa-f]{2}){5}\b|\b[0-9A-Fa-f]{12}\b")   # 48:87:…, 48-87-…, 48.87.…, 48872D9DBC88
_UUID_RE = re.compile(r"\b[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}\b")
_HEX32_RE = re.compile(r"\b[0-9A-Fa-f]{32}\b")
_KEY_RE = re.compile(r"\bPSPAN-[A-Z0-9-]{8,}\b", re.I)
_IPV4_RE = re.compile(r"\b\d{1,3}(?:\.\d{1,3}){3}\b")
_IPV6_RE = re.compile(r"\b(?:[0-9A-Fa-f]{1,4}:){2,7}[0-9A-Fa-f]{1,4}\b")
_ENTITY_RE = re.compile(r"\b[a-z_]{2,}\.[a-z0-9_]{2,}\b")          # light.kitchen_valance, sensor.x
# Contact details belong to "Become a tester" (tester.py), never to this report.
_EMAIL_RE = re.compile(r"[A-Za-z0-9._%+'-]+@[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)*\.[A-Za-z]{2,}")


# ── counting ─────────────────────────────────────────────────────────────────

def enabled(hass: HomeAssistant) -> bool:
    st = hass.data.get(DOMAIN, {}).get(DATA_SETTINGS)
    return bool((st.data if st else {}).get("telemetry_enabled", False))


def event_allowed(name: str) -> bool:
    return (name in EVENTS or name in TAB_EVENTS or name in UI_ERRORS or name in OFFER_EVENTS
            or name in WEATHER_EVENTS or name in HOUSE3D_EVENTS or name in PHOTO_EVENTS)


def bump(hass: HomeAssistant, event: str, n: int = 1) -> bool:
    """Count one occurrence. Silently ignored when off or unknown.

    Cheap enough to call from any write path: a dict increment when on, one
    lookup when off. Returns whether it counted.
    """
    if not event_allowed(event) or not enabled(hass):
        return False
    dom = hass.data.setdefault(DOMAIN, {})
    counters: dict[str, int] = dom.setdefault(_DATA_COUNTERS, {})
    counters[event] = int(counters.get(event, 0)) + max(1, int(n))
    return True


def _take_counters(hass: HomeAssistant) -> dict[str, int]:
    """The counters since the last report — and reset them."""
    dom = hass.data.setdefault(DOMAIN, {})
    out = dict(dom.get(_DATA_COUNTERS) or {})
    dom[_DATA_COUNTERS] = {}
    return out


def _take_windows(hass: HomeAssistant) -> tuple[dict[str, int], dict[str, int], set[str], Any]:
    """The usage counters, WARNING+ log counts, keys that resolved and the
    load window since the last report — and reset them."""
    usage = _take_counters(hass)
    errors: dict[str, int] = {}
    ids: set[str] = set()
    perf = None
    try:
        from .ws_common import _log_handler  # noqa: PLC0415
        if _log_handler is not None:
            errors = _log_handler.take_counts()
    except Exception:
        pass
    try:
        from .private_ble_resolver import _resolvers  # noqa: PLC0415
        _r = _resolvers.get(id(hass))
        if _r is not None:
            ids = _r.take_resolved_ids()
    except Exception:
        pass
    try:
        from . import perf_sampler  # noqa: PLC0415
        perf = perf_sampler.take_window(hass)
    except Exception:
        pass
    return usage, errors, ids, perf


def _give_back_windows(hass: HomeAssistant, taken: tuple[dict[str, int], dict[str, int], set[str], Any]) -> None:
    """A send that failed: what it took goes with the next report, on top of
    whatever was counted meanwhile."""
    usage, errors, ids, perf = taken
    try:
        from . import perf_sampler  # noqa: PLC0415
        perf_sampler.give_back_window(hass, perf)
    except Exception:
        pass
    counters = hass.data.setdefault(DOMAIN, {}).setdefault(_DATA_COUNTERS, {})
    for k, v in usage.items():
        counters[k] = int(counters.get(k, 0)) + int(v)
    try:
        from .ws_common import _log_handler  # noqa: PLC0415
        if _log_handler is not None:
            for k, v in errors.items():
                _log_handler.counts[k] = _log_handler.counts.get(k, 0) + v
    except Exception:
        pass
    try:
        from .private_ble_resolver import _resolvers  # noqa: PLC0415
        _r = _resolvers.get(id(hass))
        if _r is not None:
            _r._resolved_ids_window |= ids
    except Exception:
        pass


# ── the report ───────────────────────────────────────────────────────────────

def _uptime_bucket(seconds: float) -> str:
    if seconds < 3600:
        return "<1h"
    if seconds < 86400:
        return "<1d"
    if seconds < 7 * 86400:
        return "1-7d"
    return ">7d"


def _len(x: Any) -> int:
    try:
        return len(x)
    except Exception:
        return 0


def _sig2(v: Any) -> int | float | None:
    """Two significant figures: 4123 → 4100, 3.456 → 3.5, 0.0123 → 0.012."""
    try:
        v = float(v)
    except (TypeError, ValueError):
        return None
    if not math.isfinite(v):
        return None
    if v <= 0:
        return 0
    r = round(v, 1 - math.floor(math.log10(v)))
    return int(r) if r >= 10 else r


def _hw_payload(hass: HomeAssistant) -> dict[str, Any]:
    """env.hw: the hardware class, each word from HW_VALUES."""
    from . import perf_sampler  # noqa: PLC0415
    raw = perf_sampler.hw_class(hass)
    cpus = raw.get("cpus")
    hw: dict[str, Any] = {"cpus": min(cpus, HW_MAX_CPUS) if isinstance(cpus, int) and cpus > 0 else 0}
    for k, allowed in HW_VALUES.items():
        v = raw.get(k)
        hw[k] = v if v in allowed else "unknown"
    return hw


def _to_hour(n: int) -> int:
    """To the nearest 60 once-a-minute samples (an hour), halves up."""
    return (int(n) + 30) // 60 * 60


def _perf_payload(w: Any, cpus: int, now: float | None = None) -> dict[str, Any]:
    """health.perf from a perf_sampler.PerfWindow, shaped by PERF_METRICS.

    `samples` is to the nearest hour (60 samples): to the minute, a window
    shorter than a day would say when Home Assistant last restarted. So is
    each `over` count of 30 or more — a machine over a limit the whole time
    counts every sample — while a smaller one says nothing of the uptime
    and stays exact; with no sample count to stand beside (under half an
    hour) there are none."""
    out: dict[str, Any] = {"samples": _to_hour(w.samples)}
    hours = w.hours(now)
    for name, (metric, stats) in PERF_METRICS.items():
        h = w.hists.get(metric)
        if h is None or not h.n:
            continue
        scale = 1.0
        if name == "cpu_all_pc":
            if not cpus:
                continue
            scale = 1.0 / cpus
        d: dict[str, Any] = {}
        for s in stats:
            if s == "per_h":
                if hours > 0:
                    d[s] = _sig2(h.n / hours)
                continue
            v = h.hi if s == "max" else h.lo if s == "min" else h.quantile(int(s[1:]) / 100)
            if v is None:
                continue
            v *= scale
            d[s] = int(round(v)) if name.endswith("_pc") else _sig2(v)
        out[name] = d
    if out["samples"]:
        over = {k: int(w.over.get(k, 0)) for k in PERF_OVER}
        out["over"] = {k: c if c < 30 else _to_hour(c) for k, c in over.items()}
    return out


def _positioning_now(coord) -> dict[str, int]:
    """What the engine did with the house's own objects this poll.

    Read from the coordinator's poll result — the same dict the live
    snapshot overlays onto objects — because the cached snapshot never
    carries `outside` or the solver's counts: both are attached per request
    inside ws_live_snapshot, so reading them off the cache reported 0 on
    every install, forever. Gated on is_identified_object, the engine's own
    test, so the count is of the house and not of the neighbourhood.
    """
    out = {"positioned": 0, "outside": 0}
    data = getattr(coord, "data", None)
    ident = getattr(coord, "is_identified_object", None)
    if not isinstance(data, dict) or not callable(ident):
        return out
    for key, v in data.items():
        if not isinstance(v, dict):
            continue
        try:
            if not ident(key):
                continue
        except Exception:
            continue
        if v.get("x_m") is not None and v.get("y_m") is not None:
            out["positioned"] += 1
        if v.get("outside"):
            out["outside"] += 1
    return out


def build_payload(hass: HomeAssistant, *, consume: bool = False) -> dict[str, Any]:
    """The report. `consume` resets the usage counters (a real send does;
    the Preview does not, so previewing never loses a day's counts)."""
    from .licence import edition as _edition, hass_tier as _tier  # noqa: PLC0415
    dom = hass.data.get(DOMAIN, {})
    st = dom.get(DATA_SETTINGS)
    settings: dict[str, Any] = (st.data if st else {}) or {}

    try:
        from homeassistant.const import __version__ as _HA_VERSION  # noqa: PLC0415
        ha_version = str(_HA_VERSION)
    except Exception:
        ha_version = ""

    # Environment — sizes of things, from the stores that own them.
    fab = getattr(dom.get(DATA_FABRIC), "data", None) or {}
    floors = fab.get("floors") if isinstance(fab.get("floors"), dict) else {}
    rooms = sum(_len(f.get("rooms") or {}) for f in floors.values() if isinstance(f, dict))
    mdl = getattr(dom.get(DATA_MODEL), "data", None) or {}
    maps = getattr(dom.get(DATA_MAPS), "data", None) or {}
    snap_entry = dom.get("snapshot_cache")
    snap = snap_entry[1] if isinstance(snap_entry, tuple) and len(snap_entry) == 2 and isinstance(snap_entry[1], dict) else {}
    ble = snap.get("ble") if isinstance(snap.get("ble"), dict) else {}
    objects = snap.get("objects") if isinstance(snap.get("objects"), dict) else {}
    summary = objects.get("summary") if isinstance(objects.get("summary"), dict) else {}
    resolver = summary.get("resolver") if isinstance(summary.get("resolver"), dict) else {}
    diag = ble.get("diag") if isinstance(ble.get("diag"), dict) else {}
    obj_list = objects.get("list") if isinstance(objects.get("list"), list) else []

    integrations = {}
    for name in ("private_ble_device", "bermuda", "esphome", "mqtt", "bluetooth", "mobile_app", "ibeacon", "espresense"):
        try:
            integrations[name] = _len(hass.config_entries.async_entries(name))
        except Exception:
            integrations[name] = 0

    radios = [r for r in (ble.get("radios") or []) if isinstance(r, dict)]
    scanner_kinds = {
        # "ip_known" = the scanner exposes diagnostic sensors PadSpan reads
        # (an ESPHome proxy set up with the config library); "espresense" by
        # source; the rest are proxies without diagnostics or local adapters.
        "ip_known": sum(1 for r in radios if r.get("ip")),
        "espresense": sum(1 for r in radios if str(r.get("source") or "").lower().startswith("espresense")),
    }
    scanner_kinds["other"] = max(0, len(radios) - scanner_kinds["ip_known"] - scanner_kinds["espresense"])
    scanner_state = {
        "lost": sum(1 for r in radios if r.get("lost")),
        "disabled": sum(1 for r in radios if r.get("disabled")),
        "excluded": _len(settings.get("excluded_scanners") or []),
    }
    # BLE scan mode. HA 2026.6 changed the default for every proxy from active
    # to auto, overriding what each device's own firmware config asked for, and
    # most people will not have noticed. Counting what installs actually run is
    # the only way to see whether the fleet at large is now scanning passively.
    #
    # BOTH are reported because they answer different questions. `requested` is
    # the CHOICE — the ESPHome config-entry option, or a deliberate pin. `mode`
    # is the momentary state, and an AUTO scanner reads "passive" almost all of
    # the time because it is only promoted to active in short windows. Reading
    # one for the other is the mistake this whole feature came out of.
    #
    # Counts only. A scan mode is one of four fixed words and says nothing about
    # the device, the house, or the person.
    _MODES = ("active", "passive", "auto")

    def _mode_counts(field: str) -> dict[str, int]:
        out = {m: 0 for m in _MODES}
        out["unknown"] = 0
        for r in radios:
            v = r.get(field)
            v = str(v).lower() if v is not None else ""
            out[v if v in out and v != "unknown" else "unknown"] += 1
        return out

    scan_modes = _mode_counts("scan_mode")
    scan_modes_requested = _mode_counts("requested_scan_mode")
    by_kind: dict[str, int] = {}
    for o in obj_list:
        if isinstance(o, dict):
            k = str(o.get("kind") or "?")[:16]
            by_kind[k] = by_kind.get(k, 0) + 1
    cal = getattr(dom.get("calibration"), "data", None) or {}
    cal_points = cal.get("points") if isinstance(cal.get("points"), list) else []
    # Beacon auto-calibration marks its points in the LABEL (`[auto] …`,
    # presence_coordinator / calibration_store.prune_auto_points); there has
    # never been a `source` key, and reading one counted zero on every install.
    cal_auto = sum(1 for p in cal_points if isinstance(p, dict) and str(p.get("label") or "").startswith("[auto]"))
    # Points that never got a floor. Since #54 such a point is no longer
    # assumed to be on the ground — it stays 2D — which fixed the phantom
    # elevation but left the point contributing nothing to the storey it was
    # actually captured on. That is invisible from the panel: the point is
    # there, it looks captured, and the floor quietly has fewer than it shows.
    # `async_backfill_floors` repairs them; this is how an install that needs
    # repairing says so without anyone having to notice first.
    cal_no_floor = sum(1 for p in cal_points if isinstance(p, dict)
                       and not str(p.get("floor_id") or "").strip())

    # Is the building described, or is it defaults wearing a building's shape?
    # A floor with no explicit floor_to_floor_m or base_elevation_m falls back
    # to DEFAULT_FLOOR_TO_FLOOR_M, and a scanner with no z_m has no mounting
    # height — either one leaves cross-floor positioning with nothing to
    # separate storeys by. PadSpan is developed against one house, where both
    # are always set, so this is the case the developer cannot see at all.
    mdl_floors = [f for f in (mdl.get("floors") or []) if isinstance(f, dict)]

    def _explicit(f: dict[str, Any]) -> bool:
        for k in ("floor_to_floor_m", "base_elevation_m"):
            v = f.get(k)
            if isinstance(v, (int, float)) and not isinstance(v, bool):
                return True
        return False

    floors_with_height = sum(1 for f in mdl_floors if _explicit(f))
    _z_vals = [float(v["z_m"]) for v in (fab.get("scanner_positions_m") or {}).values()
               if isinstance(v, dict) and isinstance(v.get("z_m"), (int, float))
               and not isinstance(v.get("z_m"), bool)]
    scanner_z_distinct = len({round(z, 2) for z in _z_vals})
    coord = dom.get("presence_coordinator")
    _pos = _positioning_now(coord)
    # Registered keys that resolved at least one address in the window — the
    # answer to "does the IRK path work anywhere". Read without resetting on
    # a preview; a send resets it with the other windows.
    resolving = 0
    _identity = {"total": 0, "resolving": 0, "silent": 0, "by_source": {}, "has_any": False}
    try:
        from .private_ble_resolver import _resolvers  # noqa: PLC0415
        _res = _resolvers.get(id(hass))
        if _res is not None:
            _ids = _res.take_resolved_ids() if consume else set(_res._resolved_ids_window)
            resolving = len(_ids)
            _identity = _res.identity_breakdown(_ids)
    except Exception:
        resolving = 0

    # Read-only self-check: maps this install cannot draw.
    #
    # It used to count DISAGREEMENT — the gap between a map's metric record
    # and its stack — under four headings. There is one placement now, so all
    # four read zero on every install and are gone rather than reported as a
    # clean bill of health nobody earned. What is left is a record that is not
    # a placement, a map with no placement at all, and a house with no metre
    # scale (which draws nothing, silently, and had no counter at all).
    _geometry_faults = 0
    _fault_unreadable = 0
    _fault_unplaced = 0
    _no_world_frame = False
    _has_anchor = False
    try:
        from . import fabric_truth as _ft  # noqa: PLC0415
        _mdl_store = dom.get(DATA_MODEL)
        _maps_list = maps.get("maps") or []
        if _mdl_store is not None:
            _faults = _ft.map_geometry_faults(_maps_list, _mdl_store)
            _geometry_faults = len(_faults)
            for _f in _faults:
                # The terms the gate fired on, as the gate named them.
                _terms = _f.get("terms") or []
                if "unreadable" in _terms:
                    _fault_unreadable += 1
                if "unplaced" in _terms:
                    _fault_unplaced += 1
                if "no_world_frame" in _terms:
                    _no_world_frame = True
            # "Does this house have a metre scale" is whether the GAUGE is
            # readable, not whether it remembers which picture it came from.
            _has_anchor = _ft.metre_gauge(_mdl_store) is not None
    except Exception:
        pass

    # A floor whose rooms are a different size than the map they were built
    # from — possible even when the map itself is now perfectly measured,
    # because rooms are traced once and never re-derive. Counts only; no
    # floor names, no coordinates. No total field: every fault is exactly one
    # of the two terms, so the total is just their sum and a third number
    # would only spend budget saying so.
    _room_undersized = 0
    _room_oversized = 0
    _maps_divergent = 0
    try:
        from . import fabric_truth as _ft  # noqa: PLC0415
        _mdl_store = dom.get(DATA_MODEL)
        _maps_list = maps.get("maps") or []
        if _mdl_store is not None:
            _rfaults = _ft.room_footprint_faults(_mdl_store.room_geometry_m(), _maps_list, _mdl_store)
            for _rf in _rfaults:
                _terms = _rf.get("terms") or []
                if "undersized" in _terms:
                    _room_undersized += 1
                if "oversized" in _terms:
                    _room_oversized += 1
            # Maps whose trace and committed fabric drifted apart as a group
            # — the state that hid rjbutler's trimmed floors for weeks. A
            # count of maps, nothing about the building.
            _maps_divergent = len(_ft.room_divergence_faults(
                _mdl_store.room_geometry_m(), _maps_list, _mdl_store))
    except Exception:
        pass

    # Placement adoption by CLASS, not just a single "placed_lights" total —
    # which of the newer classes (motion, flood, humidity, air quality,
    # lock...) people have actually started using since they shipped, a
    # question "placed_lights" alone could never answer. Counts only:
    # entity_id strings themselves never leave this function
    # (assert_shareable refuses anything entity-id-shaped).
    #
    # CORRECTED 2026-09-19 (Phase 2a registry audit): this used to bucket by
    # bare domain prefix alone — binary_sensor.* was ALL counted as
    # "motion_sensor" even though that domain also covers door/window and
    # flood/moisture sensors, and sensor.* was ALL counted as "temp_sensor"
    # even though it also covers humidity and air-quality; lock.* wasn't
    # counted in any bucket. Now looks up each placed entity's real
    # device_class from hass.states — the same test light_codes.js's own
    # classifiers use, kept intentionally approximate here (no enum-sensor-
    # by-name heuristic for the bathroom-outlet air-quality case) since this
    # is a telemetry bucket, not the source of truth for what the map draws.
    _AQ_DEVICE_CLASSES = {
        "aqi", "pm25", "pm10", "pm1",
        "volatile_organic_compounds", "volatile_organic_compounds_parts",
        "carbon_dioxide", "carbon_monoxide",
        "nitrogen_dioxide", "nitrogen_monoxide", "ozone", "sulphur_dioxide",
    }
    _light_ids = list((fab.get("light_positions_m") or {}).keys())
    placed_by_domain = {
        "light": 0, "fan": 0, "lock": 0, "motion_sensor": 0, "door_sensor": 0,
        "flood_sensor": 0, "temp_sensor": 0, "humidity_sensor": 0,
        "air_quality_sensor": 0, "other": 0,
    }
    for _eid in _light_ids:
        _eid = str(_eid)
        if _eid.startswith("light."):
            placed_by_domain["light"] += 1
        elif _eid.startswith("fan."):
            placed_by_domain["fan"] += 1
        elif _eid.startswith("lock."):
            placed_by_domain["lock"] += 1
        elif _eid.startswith("binary_sensor.") or _eid.startswith("sensor."):
            _st = hass.states.get(_eid)
            _dc = _st.attributes.get("device_class") if _st else None
            if _dc in ("motion", "occupancy"):
                placed_by_domain["motion_sensor"] += 1
            elif _dc in ("door", "window"):
                placed_by_domain["door_sensor"] += 1
            elif _dc == "moisture":
                placed_by_domain["flood_sensor"] += 1
            elif _dc == "humidity":
                placed_by_domain["humidity_sensor"] += 1
            elif _dc in _AQ_DEVICE_CLASSES:
                placed_by_domain["air_quality_sensor"] += 1
            elif _dc == "temperature" or (_eid.startswith("sensor.") and _dc is None):
                placed_by_domain["temp_sensor"] += 1
            else:
                placed_by_domain["other"] += 1
        else:
            placed_by_domain["other"] += 1

    # Pro-only per-light type override (WLED/partition/plain) — one of the
    # few settings that only does anything at pro tier (see light_codes.js
    # isWledLight/isPartitionLight honouring it first), so counting it by
    # chosen kind is a direct read on advanced-tier feature adoption rather
    # than just "is this install on pro".
    _overrides = settings.get("light_type_overrides") or {}
    type_overrides_by_kind: dict[str, int] = {}
    if isinstance(_overrides, dict):
        for v in _overrides.values():
            k = str(v)[:16] if v else "?"
            type_overrides_by_kind[k] = type_overrides_by_kind.get(k, 0) + 1

    # Apple Find My tags (findmy.py). `on_air` / `separated`: Find My
    # addresses heard in the last LIVE_S by type, and how many of them are
    # away from their owner — read off the snapshot's own adverts, so it says
    # whether following tags would matter here with bridging OFF too.
    # `tracked`: the tags the bridge follows, by type; `tracked_live` on the
    # air now; `tracked_carried` on an address other than the one they were
    # first known by — only while bridging is ON: the bridge stays in memory
    # after the switch goes off ("Not this tag" loads it too), holding tags
    # nothing follows any more. Zeros are left out, as the cap refuses the
    # whole report; an empty `findmy` is "counted, none here", no key at all
    # a report from before it. Fixed type keys and counts; no address leaves
    # findmy.py.
    from . import findmy as _fm  # noqa: PLC0415
    _fm_parts: dict[str, Any] = dict(_fm.on_air(ble.get("advertisements")))
    _fm_bridge = dom.get("findmy_bridge")        # snapshot_builder._FINDMY: there once bridging has run
    if settings.get("mac_rotation_bridging") and isinstance(_fm_bridge, _fm.FindMyBridge):
        _fm_parts.update(_fm_bridge.stats(time.time()))
    findmy: dict[str, Any] = {}
    for _part, _v in _fm_parts.items():
        if isinstance(_v, dict):
            _v = {k: n for k, n in _v.items() if n}
        if _v:
            findmy[_part] = _v

    env = {
        "scanners": len(radios),
        "scanner_kinds": scanner_kinds,
        "scanner_state": scanner_state,
        "scan_modes": scan_modes,
        "scan_modes_requested": scan_modes_requested,
        "floors": _len(floors) or _len(mdl.get("floors") or []),
        "rooms": rooms,
        "placed_lights": _len(fab.get("light_positions_m") or {}),
        "placed_by_domain": placed_by_domain,
        "light_type_overrides_by_kind": type_overrides_by_kind,
        "walls": _len(fab.get("rf_barriers_m") or []),
        "maps": _len(maps.get("maps") or []),
        "scanner_positions": _len(fab.get("scanner_positions_m") or {}),
        "beacon_positions": _len(fab.get("beacon_positions_m") or {}),
        "calibration_points": _len(cal_points),
        "calibration_auto_points": cal_auto,
        "calibration_no_floor": cal_no_floor,
        "floors_with_height": floors_with_height,
        "scanners_with_z": len(_z_vals),
        "irks": _len(settings.get("irk_devices") or []),
        "followed": _len(settings.get("followed_addrs") or []),
        "findmy": findmy,
        "objects_total": _len(obj_list),
        "objects_identified": sum(1 for o in obj_list if isinstance(o, dict) and o.get("identified")),
        "objects_by_kind": by_kind,
        "integrations": integrations,
    }
    # The hardware class and the load it runs at (perf_sampler.py) — so a
    # question like "does this feature max out a Pi" is answered per class
    # of machine rather than from the developer's one VM.
    try:
        env["hw"] = _hw_payload(hass)
    except Exception:
        pass
    features = {k: bool(settings.get(k)) for k in _FEATURE_FLAGS}
    for k in _FEATURE_ENUMS:
        v = settings.get(k)
        if isinstance(v, str) and 0 < len(v) <= 16:
            features[k] = v
    presets: list[dict[str, Any]] = []
    for p in (settings.get("lights_showcase_presets") or [])[:_PRESET_SHARE_CAP]:
        if not isinstance(p, dict):
            continue
        vals = p.get("values")
        if not isinstance(vals, dict):
            continue
        presets.append({k: vals[k] for k in _PRESET_VALUE_KEYS if k in vals})
    started = dom.get(_DATA_STARTED)
    health = {
        "crypto_ok": bool(resolver.get("crypto_ok", True)),
        "ble_callback_active": diag.get("callback_active") is not False,
        "ble_diag_ok": diag.get("ok") is not False,
        # NOT a resolution health metric, whatever the ratio looks like.
        # count_rpas() counts every structurally-resolvable address on the
        # air, which is every rotating device in radio range and therefore
        # mostly other people's phones. This describes the radio ENVIRONMENT
        # — how crowded it is, which bears on history size and CPU. Read
        # identity health from irks_* below, never from these two.
        "rpas_seen": int(resolver.get("rpa_count") or 0),
        "rpas_resolved": int(resolver.get("resolved") or 0),
        "resolver_errors": _len(resolver.get("errors") or []),
        "irk_devices_resolving": resolving,
        # Registered identities, and how many of them produced nothing at all.
        # `irks_silent` is the failure this report previously could not see: a
        # key that never matches looked exactly like a key nobody added.
        "irks_total": int(_identity.get("total") or 0),
        "irks_silent": int(_identity.get("silent") or 0),
        # Zeros above are only readable next to this. "None configured" and
        # "none working" are the same number and completely different bugs.
        "has_any_identity": bool(_identity.get("has_any")),
        # Which door the identities came in by, and which door actually works.
        # Fixed labels from PrivateBLEResolver.IDENTITY_SOURCES — no names.
        "irks_by_source": {k: v.get("total", 0)
                           for k, v in (_identity.get("by_source") or {}).items()},
        "irks_resolving_by_source": {k: v.get("resolving", 0)
                                     for k, v in (_identity.get("by_source") or {}).items()},
        "outside_now": _pos["outside"],
        "coverage_floor_active": getattr(coord, "_coverage_floor", None) is not None,
        # Identified objects the engine placed this poll, and judged outside.
        "positioned_now": _pos["positioned"],
        # How long since HA (re)started, coarsely — restart churn is a health
        # signal; a start time finer than that would be one thing too many.
        "uptime": _uptime_bucket(time.monotonic() - started) if isinstance(started, (int, float)) else "unknown",
        # Maps whose stored scale and stored placement no longer describe the
        # same picture, and whether one of them is the map anchoring the house
        # (which makes rooms wrong on every OTHER floor too). A COUNT and a
        # flag — no map names, no coordinates, nothing about the building.
        # This class of bug cost a user weeks of screenshots to surface once.
        "maps_geometry_faulted": _geometry_faults,
        "geometry_fault_unreadable": _fault_unreadable,
        "geometry_fault_unplaced": _fault_unplaced,
        # The one condition that blanks a working house: placements on disk
        # and no scale to draw them at.
        "geometry_no_world_frame": _no_world_frame,
        # Floors whose rooms are a different size than the map they were
        # built from — the failure mode `maps_geometry_faulted` above cannot
        # see, because it only checks a map against itself. Rooms are traced
        # once and never re-derive, so a map can be fixed today and its rooms
        # can still be wrong from before. Counts only.
        "room_footprint_undersized": _room_undersized,
        "room_footprint_oversized": _room_oversized,
        # Maps whose two room records disagree by one shared factor.
        "maps_divergent": _maps_divergent,
        # NULL, not zero, and deliberately still here. It counted maps whose
        # solved matrix and whose decomposed fields described different
        # footprints — a state that needed two stored copies of one placement
        # to exist in. There is one copy, so the question has no answer, and a
        # ZERO in a series that used to carry real counts reads as "fixed"
        # rather than "unaskable". `maps_affine` and `anchor_is_affine` went
        # the other way: they described which KIND of stack a map had, and a
        # map does not have a stack.
        "stack_desync": None,
        # The three "is it set up at all" flags. Each is only meaningful on a
        # multi-storey house, so each carries the floor test in it rather than
        # leaving a bare False to be misread as a fault on a bungalow.
        "has_metre_anchor": _has_anchor,
        "floors_all_default": bool(len(mdl_floors) > 1 and floors_with_height == 0),
        "scanner_z_uniform": bool(len(mdl_floors) > 1 and len(radios) > 1
                                  and scanner_z_distinct <= 1),
        # How each scanner was matched to its HA device. `ambiguous` is the
        # one that matters: it means two scanners are named so that one
        # contains the other, which is the condition that used to assign an
        # area to the wrong radio (issue #65) and now refuses instead. A count
        # of installs carrying that naming is the only way to know whether the
        # refusal is rare or whether people hit it constantly and need the
        # names checked at setup. `unresolved` says the scanner has no HA
        # device at all, which is a different problem wearing the same face.
        # Counts by outcome only — never which radios, never their names.
        "radios_ambiguous": sum(1 for r in radios if r.get("device_match") == "ambiguous"),
        "radios_unresolved": sum(1 for r in radios if r.get("device_match") == "none"),
        "radios_matched_partial": sum(1 for r in radios if r.get("device_match") == "partial"),
    }
    try:
        from . import perf_sampler as _ps  # noqa: PLC0415
        _pw = _ps.take_window(hass) if consume else _ps.window(hass)
        health["perf"] = _perf_payload(_pw, _ps.cached_cpus(hass) or 0)
    except Exception:
        pass
    usage = _take_counters(hass) if consume else dict(dom.get(_DATA_COUNTERS) or {})
    # WARNING+ log lines by module since the last report — the "what broke"
    # signal for the parts of the code the developer cannot exercise.
    errors: dict[str, int] = {}
    try:
        from .ws_common import _log_handler  # noqa: PLC0415
        if _log_handler is not None:
            errors = _log_handler.take_counts() if consume else dict(_log_handler.counts)
    except Exception:
        errors = {}

    import sys as _sys  # noqa: PLC0415
    payload = {
        "schema": SCHEMA,
        "install_id": str(settings.get("telemetry_install_id") or ""),
        "day": time.strftime("%Y-%m-%d", time.gmtime()),
        "version": BUILD_VERSION,
        "edition": _edition(),
        "tier": _tier(hass),
        "ha_version": ha_version,
        "python": f"{_sys.version_info.major}.{_sys.version_info.minor}",
        "env": env,
        "features": features,
        "usage": usage,
        "health": health,
        "errors": errors,
        "presets": presets,
    }
    # The cap refuses the WHOLE report, and a refused one keeps its counters,
    # so the next is no smaller: one busy day silenced an install until HA
    # restarted. The presets are a courtesy sample (popular_presets.py) — on
    # a day too full for all ten, fewer go, and the counts still do.
    while presets and len(json.dumps(payload)) > _MAX_BYTES:
        presets.pop()
    return payload


def assert_shareable(payload: dict[str, Any]) -> None:
    """Refuse a report that carries anything identifier-shaped.

    Walks every key and value. Raises ValueError naming the offence. The
    install id is exempt from the UUID rule by position (it IS a UUID, by
    design, and nothing else); every other UUID/MAC/32-hex/key/IP anywhere
    is a bug — the report is built from counts, so there is no honest way
    for one to be there.
    """
    if not isinstance(payload, dict):
        raise ValueError("payload is not a dict")
    extra = set(payload.keys()) - _TOP_KEYS
    if extra:
        raise ValueError(f"unexpected top-level keys: {sorted(extra)}")

    def walk(node: Any, path: str) -> None:
        if isinstance(node, dict):
            for k, v in node.items():
                walk(str(k), path + "." + str(k) + "<key>")
                walk(v, path + "." + str(k))
        elif isinstance(node, (list, tuple)):
            for i, v in enumerate(node):
                walk(v, f"{path}[{i}]")
        elif isinstance(node, str):
            if path == ".install_id":
                if node and not _UUID_RE.fullmatch(node):
                    raise ValueError("install_id is not a UUID")
                return
            # Most specific first, so the message names the real shape (a
            # UUID's tail is also twelve hex digits).
            for name, rx in (("UUID", _UUID_RE), ("32-hex", _HEX32_RE), ("licence key", _KEY_RE),
                             ("MAC address", _MAC_RE), ("IP address", _IPV4_RE),
                             ("IPv6 address", _IPV6_RE), ("email address", _EMAIL_RE),
                             ("entity id", _ENTITY_RE)):
                if rx.search(node):
                    raise ValueError(f"{name} in {path}")
            if len(node) > 64:
                raise ValueError(f"string too long in {path}")
        elif node is None or isinstance(node, (bool, int, float)):
            return
        else:
            raise ValueError(f"unexpected value type {type(node).__name__} in {path}")

    walk(payload, "")
    _check_load_sections(payload)
    if len(json.dumps(payload)) > _MAX_BYTES:
        raise ValueError("payload too large")


def _check_load_sections(payload: dict[str, Any]) -> None:
    """env.hw and health.perf carry only the keys and words listed in
    HW_VALUES / PERF_METRICS / PERF_OVER, and only finite, non-negative
    numbers — the generic walk refuses identifier SHAPES; this refuses
    anything that is not on the list at all (a board's model string, a
    hostname, a NaN the receiver could not parse)."""
    def _num(v: Any, path: str, *, allow_none: bool = False) -> None:
        if v is None and allow_none:
            return
        if isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v) or v < 0:
            raise ValueError(f"not a count in {path}")

    env = payload.get("env")
    hw = env.get("hw") if isinstance(env, dict) else None
    if hw is not None:
        if not isinstance(hw, dict):
            raise ValueError("env.hw is not a dict")
        for k, v in hw.items():
            if k == "cpus":
                if isinstance(v, bool) or not isinstance(v, int) or not 0 <= v <= HW_MAX_CPUS:
                    raise ValueError("env.hw.cpus out of range")
            elif k in HW_VALUES:
                if v not in HW_VALUES[k]:
                    raise ValueError(f"env.hw.{k} not in the vocabulary")
            else:
                raise ValueError(f"unexpected key in env.hw: {str(k)[:32]}")
    health = payload.get("health")
    perf = health.get("perf") if isinstance(health, dict) else None
    if perf is not None:
        if not isinstance(perf, dict):
            raise ValueError("health.perf is not a dict")
        for k, v in perf.items():
            if k == "samples":
                _num(v, "health.perf.samples")
            elif k == "over":
                if not isinstance(v, dict):
                    raise ValueError("health.perf.over is not a dict")
                for ok, ov in v.items():
                    if ok not in PERF_OVER:
                        raise ValueError(f"unexpected key in health.perf.over: {str(ok)[:32]}")
                    _num(ov, f"health.perf.over.{ok}")
            elif k in PERF_METRICS:
                if not isinstance(v, dict):
                    raise ValueError(f"health.perf.{k} is not a dict")
                for sk, sv in v.items():
                    if sk not in PERF_METRICS[k][1]:
                        raise ValueError(f"unexpected key in health.perf.{k}: {str(sk)[:32]}")
                    _num(sv, f"health.perf.{k}.{sk}", allow_none=True)
            else:
                raise ValueError(f"unexpected key in health.perf: {str(k)[:32]}")


# ── the schedule ─────────────────────────────────────────────────────────────

async def ensure_install_id(hass: HomeAssistant) -> str:
    """Mint the anonymous id on first use; return it."""
    st = hass.data.get(DOMAIN, {}).get(DATA_SETTINGS)
    if not st:
        return ""
    cur = str(st.data.get("telemetry_install_id") or "")
    if cur and _UUID_RE.fullmatch(cur):
        return cur
    new = str(uuid.uuid4())
    await st.async_set(telemetry_install_id=new)
    return new


def _today() -> str:
    return time.strftime("%Y-%m-%d", time.gmtime())


async def ensure_snapshot(hass: HomeAssistant) -> None:
    """Make sure there IS a snapshot to read the environment from.

    Half the report — scanners, objects, resolver health — comes from the
    live snapshot, which is built on demand and cached. A report sent ten
    minutes after a restart, with nobody looking at the panel, would
    otherwise say "0 scanners, 0 objects" about a full house. Measured on
    the first real send: exactly that. The builder serves its own cache when
    one is fresh, so this costs nothing when the panel is open.
    """
    try:
        from .snapshot_builder import _live_snapshot  # noqa: PLC0415
        await _live_snapshot(hass)
    except Exception as err:
        _LOGGER.debug("Telemetry could not build a snapshot: %s", err)


async def ensure_hw(hass: HomeAssistant) -> None:
    """Make sure env.hw names the installation type and board, not
    "unknown" because the sampler's first tick has not come yet. Detected
    once; a no-op after that."""
    try:
        from . import perf_sampler  # noqa: PLC0415
        await perf_sampler.async_ensure_hw(hass)
    except Exception as err:
        _LOGGER.debug("Telemetry could not read the hardware class: %s", err)


async def send_now(hass: HomeAssistant, *, force: bool = False) -> dict[str, Any]:
    """Build, check, POST. Returns {"sent": bool, "reason": str, "bytes": n}.

    At most one report per UTC day: the day of the last successful send is
    persisted (`telemetry_last_day`), so a restart or reload does not send
    again — the scheduler fires 10 minutes after every start. `force` is the
    "Send a report now" button. The windows (counters, log counts, resolved
    keys) are taken once the report has passed the gate, before the POST is
    awaited — what is counted while it is in flight belongs to the next
    report (review, 2026-09-27: taken after the await, it went with neither)
    — and a failed send gives them back, so a refused or failed send keeps
    the day's counts for the next attempt.
    """
    if not enabled(hass):
        return {"sent": False, "reason": "disabled", "bytes": 0}
    st = hass.data.get(DOMAIN, {}).get(DATA_SETTINGS)
    if not force and st and str(st.data.get("telemetry_last_day") or "") == _today():
        return {"sent": False, "reason": "already sent today", "bytes": 0}
    await ensure_install_id(hass)
    await ensure_snapshot(hass)
    await ensure_hw(hass)
    payload = build_payload(hass, consume=False)
    try:
        assert_shareable(payload)
    except ValueError as err:
        _LOGGER.error("Telemetry report refused before sending: %s", err)
        return {"sent": False, "reason": f"refused: {err}", "bytes": 0}
    body = json.dumps(payload).encode()
    # Nothing awaited since build_payload: these are what the report holds.
    taken = _take_windows(hass)
    try:
        from homeassistant.helpers.aiohttp_client import async_get_clientsession  # noqa: PLC0415
        session = async_get_clientsession(hass)
        async with session.post(TELEMETRY_URL, data=body,
                                headers={"Content-Type": "application/json"}, timeout=15) as resp:
            ok = 200 <= resp.status < 300
            if not ok:
                _LOGGER.debug("Telemetry HTTP %s", resp.status)
                _give_back_windows(hass, taken)
                return {"sent": False, "reason": f"http {resp.status}", "bytes": len(body)}
    except Exception as err:  # network errors are expected and non-fatal
        _LOGGER.debug("Telemetry send failed: %s", err)
        _give_back_windows(hass, taken)
        return {"sent": False, "reason": "network", "bytes": len(body)}
    if st:
        try:
            await st.async_set(telemetry_last_day=_today())
        except Exception:
            pass
    return {"sent": True, "reason": "", "bytes": len(body)}


def reset_windows(hass: HomeAssistant) -> None:
    """Start the usage and error windows now — called at opt-in, so the first
    report carries nothing from before the person said yes."""
    hass.data.setdefault(DOMAIN, {})[_DATA_COUNTERS] = {}
    try:
        from .ws_common import _log_handler  # noqa: PLC0415
        if _log_handler is not None:
            _log_handler.take_counts()
    except Exception:
        pass
    try:
        from .private_ble_resolver import _resolvers  # noqa: PLC0415
        _r = _resolvers.get(id(hass))
        if _r is not None:
            _r.take_resolved_ids()
    except Exception:
        pass
    try:
        from . import perf_sampler  # noqa: PLC0415
        perf_sampler.reset_window(hass)
    except Exception:
        pass


def async_setup_telemetry(hass: HomeAssistant) -> None:
    """Schedule the daily report (idempotent across reloads). Runs only when on.

    Also starts the load sampler (perf_sampler.py): one 60 s timer, itself
    idempotent, that measures only while the report is on."""
    from homeassistant.helpers.event import async_call_later, async_track_time_interval  # noqa: PLC0415

    dom = hass.data.setdefault(DOMAIN, {})
    dom.setdefault(_DATA_STARTED, time.monotonic())
    try:
        from . import perf_sampler  # noqa: PLC0415
        perf_sampler.async_start(hass)
    except Exception as err:
        _LOGGER.debug("Load sampler not started: %s", err)
    if dom.get(_DATA_UNSUBS):
        return

    async def _run(_now: Any = None) -> None:
        if enabled(hass):
            await send_now(hass)

    dom[_DATA_UNSUBS] = [
        async_call_later(hass, _FIRST_DELAY_S, _run),
        async_track_time_interval(hass, _run, _INTERVAL),
    ]


def async_stop_telemetry(hass: HomeAssistant) -> None:
    for unsub in hass.data.get(DOMAIN, {}).pop(_DATA_UNSUBS, []) or []:
        try:
            unsub()
        except Exception:
            pass
    try:
        from . import perf_sampler  # noqa: PLC0415
        perf_sampler.async_stop(hass)
    except Exception:
        pass
