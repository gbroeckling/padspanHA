# PadSpan HA — BLE Room-Presence Tracking for Home Assistant
# Copyright (C) 2026 Garry Broeckling
# Licensed under the GNU General Public License v3.0
# See LICENSE file or https://www.gnu.org/licenses/gpl-3.0.html
"""Opt-in usage statistics — "help the developer improve PadSpan".

OFF by default. Nothing here runs until a person turns it on in Settings →
Presence → Help improve PadSpan, where a Preview button shows the exact JSON
that will go. What goes out is COUNTS and VERSIONS, never things:

    which version, which edition and tier, which Home Assistant
    the country and language set in Home Assistant (Settings → System →
        General): a two-letter code and a language tag such as "en-GB",
        left out when blank — never looked up from the address
    where the person heard about PadSpan, only if they chose to say: one
        word from HEARD_WORDS, their own answer to an optional question
        asked once after the opt-in (env.heard_from)
    with a licence key on more than two homes, the licence's group code:
        16 hex characters made from the key (never the key), the same in
        every home of that licence, so its homes are seen together
        (licence_homes.py: a key on more than two homes needs every home's
        report on)
    how many scanners / floors / rooms / placed lights / walls / maps / IRKs
    which feature switches are on, and which theme the panel wears
        (Day, Light, or a named palette; Night is the absence of all three),
        and how the Overview is set up (its kind, layout and display
        switches, as words); with quiet mode on, the share it hides, bucketed
    how many times each tab was opened and each feature used since the
        last report (an allow-listed vocabulary — see EVENTS)
    a few health flags: crypto present, BLE callback alive, coverage floor
        active, how many rotating addresses actually resolved
    whether the building is described at all: floors carrying a real
        storey height, scanners carrying a mounting height, calibration
        points that never got a floor, whether any map is measured
    uncaught panel errors by the PadSpan module that threw, and the tab
        that was open — the half of PadSpan the Python log cannot see
        (see UI_ERRORS)
    Apple Find My: how many Find My addresses are on the air now by type
        (and how many of those are away from their owner), how many tags
        PadSpan follows, and how its hand-overs went — followed, missed by
        reason, wrong links undone by themselves or by a person, tags back
        on their day key (env.findmy, and the findmy_* EVENTS)
    up to 10 saved Showcase presets' VALUES (theme, Automorph settings, a
        few display toggles) — never the preset's own name — so popular
        combinations across installs can surface in every install's own
        "Popular presets" pulldown (see popular_presets.py)
    how hard the machine works and what class of machine it is: load per
        CPU, Home Assistant's own CPU and memory, memory available, swap,
        event-loop lag, how long PadSpan's own snapshot builds and polls
        take, and how often any of them hit a limit (health.perf); CPU
        count, RAM size, architecture, installation type and board family
        from fixed lists (env.hw) — see perf_sampler.py and PERF_METRICS
    what PadSpan itself holds and costs: objects, object history and the
        Bluetooth cache (counts, estimated MB), new addresses per hour, the
        live snapshot's size, Home Assistant's load while the Atlas or the 3D
        house is on a screen (health.perf); Home Assistant starts, unclean
        ends and the worst minutes since the last report, kept on disk so a
        run that ran out of memory still reports (health.runs); and the
        panels' frame rate and heap by view, and their device class, in
        buckets (CLIENT_EVENTS)
    wall screens: whether a screen is opened with ?kiosk=1, fills the
        screen untouched or in use, or is an ordinary window; whether a
        wall screen's reload after an update landed on the new build; and
        whether a ?view= link stayed on its view (SCREEN_EVENTS)

The reason, in one sentence: the developer has one house to test on, and
this is how features that only exist elsewhere (an iPhone with an IRK, a
Bermuda install, twelve floors, a lighting-only house) get seen at all.

Never: MAC addresses, IRKs or licence keys, device or room or floor NAMES,
coordinates, entity ids, email addresses, timestamps finer than the day.
`assert_shareable` walks every value before a send and refuses the whole
report if anything identifier-shaped is in it — belt on top of the design's
braces — and tests/test_telemetry.py builds a payload from a house full of
names and MACs and proves none of them are in it.

"Become a tester" (tester.py) is a separate channel — its own consent,
button, address, id and storage — and never part of this report.

The install id is a random UUID minted the first time the switch goes on. It
exists so installs can be counted rather than pings; "New anonymous ID" in
the same card replaces it. It is the only thing that persists across
reports, and it means nothing outside this file.

Endpoint: TELEMETRY_URL. At most one POST per UTC day (the last sent day is
persisted, so restarts do not repeat it), about 2-5 KB, hard cap 8 KB.
Failure is silent and non-fatal; nothing is retried, nothing is queued; the
counters survive a failed send and go with the next one.
"""

from __future__ import annotations

import threading
import json
import logging
import math
import re
import time
import uuid
from datetime import date, datetime, timedelta, timezone
from typing import Any

from homeassistant.core import HomeAssistant, callback

from .build_info import BUILD_VERSION
from .const import (
    DATA_CALIBRATION,
    DATA_FABRIC,
    DATA_MAPS,
    DATA_MODEL,
    DATA_SETTINGS,
    DOMAIN,
)
from .onboarding import BUCKET_WORDS as _ONB_BUCKETS, STEPS as _ONB_STEPS

_LOGGER = logging.getLogger(__name__)

TELEMETRY_URL = "https://padspan.traks.ca/api/telemetry.php"
# The developer's view of what the reports add up to (server/stats.php).
# Read-only, other people's installs in aggregate; the server admits only a
# key on its developer list, so the Pro + Dev-mode gate in the panel is a
# courtesy and the server is the lock.
STATS_URL = "https://padspan.traks.ca/api/stats.php"
SCHEMA = 1
_INTERVAL = timedelta(hours=24)
_FIRST_DELAY_S = 600           # after the update check, never during startup
# The first minutes after a start describe the start, not the day. Sent at
# _FIRST_DELAY_S, half of all reports were a few minutes of Home Assistant
# starting, and since an update is a restart, every first report on a new
# version was one. After a start the report waits for _STEADY_S of samples,
# unless the install has gone _STALE_DAYS without one: one that restarts
# more often than that still reports, with the short window its uptime
# bucket ("<1h") marks.
_STEADY_S = 6 * 3600
_STALE_DAYS = 2
_DATA_UNSUBS = "_telemetry_unsubs"
_DATA_COUNTERS = "telemetry_counters"
_DATA_STARTED = "_telemetry_started_mono"
_MAX_BYTES = 8192

# The vocabulary. An event that is not here is dropped, so the frontend and
# every backend call site can only ever count what this file allows — a
# closed list, because the report's KEYS are also data that leaves the box,
# and an open pattern would let any authenticated user put a word into it.
EVENTS: frozenset[str] = frozenset({
    # Mapping → 3D Stack's stale-receiver list opened (0.38.170 made it read-only
    # and honest): whether anyone looks, once per opening.
    "stale_receivers_listed",
    # The top bar's status dot (views/status_dot.js) clicked through to
    # Health: whether a dot that says something is wrong gets looked at.
    "status_dot_open",
    # The Receivers page (views/receivers.js): a height or signal adjustment
    # saved from its table, once per save. Never which receiver or the value.
    "receivers_page_edit",
    # "Preview a finished house" (Sample mode, panel.js _setDataMode): opened
    # from Live, and back to Live from it. Sample mode itself counts nothing.
    "preview_open", "preview_back",
    # The backup AI Task (Settings → AI, ws_house3d_photo.ask_ai): a photo or
    # plan read by the backup because the main one was away, and one the
    # backup then failed too. Never which AI Task.
    "ai_backup_used", "ai_backup_failed",
    # 0.38.160: a device's room held through a short gap (once per hold, so
    # whether the setting ever does anything in a real house), and a robot
    # vacuum's map imported / a walker point accepted into calibration.
    "room_hold_used", "vacuum_imported", "vacuum_point_accepted",
    "light_placed", "light_removed", "wall_placed", "wall_removed",
    "room_committed", "room_merged", "irk_added", "irk_add_refused", "irk_validate",
    "calibration_point_added", "capture_started", "forensics_query",
    "showcase_on", "showcase_forest_default", "backup_created", "backup_restored", "factory_reset",
    "bright_import",
    # A floor-plan image asked for with a link that no longer works (expired,
    # or signed before a restart): the panel renews its links every 10
    # minutes and on reconnect, so this should stay near zero (map_image_view.py).
    "map_image_stale",
    # A map's placement committed from the align editor, and one the writer
    # refused because it would have stranded the calibration pins. Both halves
    # matter: a refusal nobody ever hits is a guard nobody needs, and a
    # refusal everybody hits is a guard in the wrong place.
    "map_placement_committed", "map_placement_refused", "point_align_applied",
    # IRK resolution, cumulative over the window: a NEW address resolved to a
    # registered key; a NEW rotating address that matched no key.
    "irk_resolved", "irk_unresolved_rpa",
    # A radio's live scan mode CHANGED. Counted separately by what that radio
    # was asked to do, because the two carry opposite meanings and together
    # they say whether the reported mode means the same thing on every install.
    #
    #   ..._auto    expected and frequent. An AUTO scanner is promoted to
    #               active in short windows, so flips prove the field is
    #               tracking the radio rather than echoing a stored setting.
    #   ..._pinned  expected to be ~0. HA leaves an explicitly ACTIVE or
    #               PASSIVE scanner alone, so a pinned radio that keeps
    #               changing means the mode is NOT under the user's control
    #               there — the one result that would make the map indicator
    #               dishonest, and it cannot be seen from a single install.
    "scan_mode_flip_auto", "scan_mode_flip_pinned",
    # Issues #89/#91 (0.38.106-107), so the betas can be judged from the
    # field: Beacon Tune's save — a beacon that reached the fabric, a map
    # refused because it is not placed in metres, a write that failed; the
    # Lost & Found records the one-time stranger cleanup removed (by record);
    # and a Diag Export built on request.
    "beacon_tune_saved", "beacon_tune_save_refused", "beacon_tune_save_failed",
    "lost_and_found_pruned", "diag_export_built",
    # 0.38.108-110 fixed where Follow alerts go and when arrive/depart fire,
    # the phone wizard's BLE Transmitter command, and MQTT publishing; these
    # say whether that holds in houses the tests cannot see. Per event, counts
    # only: a tagged device's arrive/depart, a Follow alert sent or not, the
    # wizard's command sent / no phone service found / failed, a failed MQTT
    # publish.
    "tagged_arrived", "tagged_departed", "follow_alert_sent", "follow_alert_failed",
    "companion_tx_sent", "companion_tx_no_service", "companion_tx_failed",
    "mqtt_publish_failed",
    # 0.38.122's fixes, from the field: the IRK cache cleared because the keys
    # changed (#148: about 0 a day, it was every 5-minute reload); an auto
    # calibration point that dropped its pin's room (#149); a restore that
    # merged Lost & Found, and the records it kept because the one here was
    # newer (#150); Follow's Test sent or failed (#151); old Bermuda objects
    # removed from the object history (#152: once after an upgrade from
    # 0.38.105, then none).
    "irk_cache_cleared", "autocal_pin_room_dropped",
    "lost_and_found_restore_merged", "lost_and_found_restore_kept_current",
    "follow_test_sent", "follow_test_failed", "bermuda_history_purged",
    # The three guided wizards (v0.38.21): which step was REACHED, once per
    # distinct visit to that step (the wizard dedupes against its own last-
    # counted step, the same way a tab-open event never double-counts a
    # re-render). This is a funnel: comparing step counts against each other
    # shows where people stop advancing, on a feature that only exists in
    # the browser and that the developer's one house cannot exercise every
    # path of. "..._exited_early" is the explicit "Exit setup"/"Exit guide"
    # click before the Finish step — the funnel alone cannot tell a
    # deliberate exit from someone who just has not come back yet.
    "wizard_maps_step_upload", "wizard_maps_step_scale", "wizard_maps_step_rooms",
    "wizard_maps_step_scanners", "wizard_maps_step_finish", "wizard_maps_exited_early", "wizard_maps_step_floors",
    "wizard_calib_step_tune", "wizard_calib_step_setup", "wizard_calib_step_roam",
    "wizard_calib_step_model", "wizard_calib_step_finish", "wizard_calib_exited_early",
    # The Lights builder's guided tour: opened (button or auto-open on first
    # visit), reached its last card and closed via Done, or closed via the
    # ✕ before that. A tour with a high opened-to-dismissed ratio and a low
    # completed count is a tour worth shortening, not a tour working as meant.
    "lights_tour_opened", "lights_tour_completed", "lights_tour_dismissed_early",
    # The Free/Bright/Bright Pro/Pro onboarding wizard (Settings -> Features
    # -> PadSpan licence -> "What does each tier unlock?"): which step was
    # reached, once per distinct visit, and whether it was finished via Done
    # or abandoned before the last step — same funnel shape as the other
    # guided wizards above.
    "wizard_tiers_step_free", "wizard_tiers_step_ladder", "wizard_tiers_step_upgrade",
    "wizard_tiers_completed", "wizard_tiers_exited_early",
    # Apple Find My tags (AirTags and "works with Find My" tags) followed
    # across their address changes (findmy.py; runs with mac_rotation_bridging
    # on). 2026-09-27: "make sure the opt-in records how well tools for
    # this feature actually work" — the switch alone says it is on, not that
    # it follows anything, and one house cannot show how it fares in others.
    #
    #   findmy_linked         a hand-over followed: a tag carried onto its
    #                         next address. `_slow`: of those, the ones that
    #                         landed over 2 minutes after the old address's
    #                         last report (by design, about one minute).
    #   findmy_missed_...     a tag's hand-over window (HANDOVER_WINDOW_S)
    #                         closed with no link — once per tag per window,
    #                         by the strongest reason it came to
    #                         (findmy.MISS_REASONS):
    #     _ambiguous          a candidate fitted, but another pairing was too
    #                         close to call (MARGIN_DB): refused, not guessed;
    #     _late               a new address where the tag was, after the timing
    #                         rule allows (APPEAR_AFTER_S) but no later than a
    #                         real hand-over can be first heard on that
    #                         install (its reseed + poll gap) — a real one the
    #                         timing rule turned down. None at the defaults;
    #     _elsewhere          a new address at the hand-over moment, but not
    #                         where the tag was: another device's own change,
    #                         or the tag carried off as it changed;
    #     _no_candidate       neither: the tag most likely LEFT RANGE.
    #                         The last two are not matcher failures, and never
    #                         to be read as ones — the follow rate is (linked
    #                         − undone) / (linked − undone + ambiguous +
    #                         late), they beside it: a wrong link undone was
    #                         no hand-over due, and undone / linked is its own
    #                         number. A window the bridge did not watch whole
    #                         (a restart, bridging off) is never counted.
    #   findmy_moved_back     a wrong link undone by itself (the tag heard on
    #                         an earlier address again); `_addrs`: how many
    #                         links those undid.
    #   findmy_back_on_day_key  a separated tag back on its day key after
    #                         time near its owner: the Find My schedule, its
    #                         links right — kept apart from the above.
    #   findmy_not_this_tag   a wrong link undone by a person (the Bluetooth
    #                         tab's "Not <name>? Unlink").
    "findmy_linked", "findmy_linked_slow",
    "findmy_missed_ambiguous", "findmy_missed_late", "findmy_missed_elsewhere", "findmy_missed_no_candidate",
    "findmy_moved_back", "findmy_moved_back_addrs", "findmy_back_on_day_key", "findmy_not_this_tag",
    # A name following a rotating address, on screen only (label_follow.py).
    # 2026-11-02: the merge guard keeps a name on the first address, and
    # a guess can mix signal into calibration, so "find a better way". These say
    # whether the better way is right in homes other than his.
    #   label_link_linked     a name moved to a new address on evidence.
    #   label_link_asked      "This looks like <label>: same device?" put up.
    #   label_link_held       a question held back: one a day for each device,
    #                         none for a week after a No. Each address once.
    #   label_link_yes, _no   how that was answered.
    #   label_link_undone     a person's Undo.
    #   label_link_wrong_after_undo  an undone link the radio then proved wrong:
    #                         both addresses on the air at once.
    #   label_link_old_back   a link dropped by itself: an address it had left
    #                         came back, so that was no hand-over.
    #   label_link_capped     a poll reached the cap on walking the address list
    #                         (label_follow.SCAN_BUDGET), so some devices waited.
    "label_link_linked", "label_link_asked", "label_link_yes", "label_link_no", "label_link_undone",
    "label_link_wrong_after_undo", "label_link_old_back", "label_link_capped", "label_link_held",
    # The Atlas emergency lighting test (emergency_test.py): a test started,
    # ended (the lights already on left on), or ended with Force off.
    "emergency_test_on", "emergency_test_off", "emergency_force_off",
    # Bluetooth → Scanners → Find the one in your hand (0.38.132): started,
    # something got louder, and Tag was pressed on one of those.
    "hold_near_started", "hold_near_found", "hold_near_tagged",
    # Walk-to-Identify (objects.js): "Who's here?" pressed, and Tag pressed on
    # one of its candidates — the switch is on at a third of installs.
    "wti_who", "wti_tag",
    # Pure Live's switch while the Atlas is Overview (0.38.137): which side people pick.
    "live_switch_classic", "live_switch_purelive",
    # The Live Aboard setup wizard (views/aboard_wizard.js): opened, and
    # finished (its last step's "open Live Aboard").
    "wizard_la_opened", "wizard_la_finished",
    # The menu's More tools group opened (2026-10-30: modes stopped hiding
    # screens; the ones only Development listed sit there, closed by default).
    # Counted on opening only: whether anyone finds it.
    "menu_more_tools_open",
    # The Rooms page (views/rooms.js, 2026-10-30): a colour, ceiling height or
    # split level saved there (its opens are tab:rooms).
    "rooms_page_edit",
    # Settings → Suggest an idea: which way people take (0.38.140).
    "suggest_idea_posted", "suggest_idea_browsed", "suggest_idea_mail",
    # A Bluetooth proxy that suddenly hears far fewer advertisements than it
    # usually does while the others are normal (proxy_health.py; the 2026.7
    # ESPHome coexistence bug left proxies hearing ~9%). Counted per drop and
    # reported only as a bucket (PROXY_DROP_EVENTS), never the number.
    "proxy_rate_drop",
    # 0.38.171: Vacation Mode switched on (a new trip, or one resumed within
    # 3 weeks on the trip's own routine), and off from the panel or by a
    # factory reset; whether the turned-off notice reached an alert target
    # (vacation_mode.async_notify_turned_off). An accidental Disable mid-trip
    # left a house dark for 11 days with nobody told.
    "vacation_on", "vacation_resumed", "vacation_off_panel", "vacation_off_reset",
    "vacation_off_notified", "vacation_off_not_pushed",
    # 0.38.172, the trip options: ended on its end date, paused because
    # someone came home, and (once a day each) the after-dark, bedtime and
    # max on-time rules holding a light off the pattern asked for.
    "vacation_off_end_date", "vacation_paused_home",
    "vacation_rule_dark", "vacation_rule_bedtime", "vacation_rule_max_on",
    # The most-at-once cap holding a light off and an anchor light held on
    # (once a day each), and the preview opened — empty when it had nothing
    # to show (vacation_mode.async_preview).
    "vacation_rule_max_lights", "vacation_anchor_on", "vacation_preview", "vacation_preview_empty",
    # 0.38.177: why a calibration save failed (the floor has no metre scale,
    # or anything else), and the Calibration tab showing that a floor needs
    # measuring before points can go on it.
    "calibration_save_refused_no_scale", "calibration_save_failed_other", "calib_floor_unmeasured",
    # 0.38.177: calibration points cleared on purpose (Clear all, one map's
    # Clear) — so a house whose points went to zero can be told apart from one
    # that lost them (health.calibration_points_vanished).
    "calibration_cleared_all", "calibration_cleared_map",
    # and a floor plan deleted on purpose (plain, or after moving its work to
    # another map) — beside health.maps_vanished.
    "map_deleted", "map_deleted_migrated",
    # 0.38.178: a slim snapshot sent (Optimize for scale) — how many walls use it.
    "snapshot_slim_sent",
    # 0.38.178, guest tags (guest_tags.py): a tag made a guest tag, a stay
    # started and ended, notices sent / failed / held for quiet hours, an
    # off-limits room entered, a stay ended because its tag went unheard a
    # week (a high count says leaving is not being caught).
    "guest_tag_marked", "guest_session_started", "guest_session_ended",
    "guest_notice_sent", "guest_notice_failed", "guest_quiet_held",
    "guest_offlimits_sent", "guest_stale_ended",
    # Field warnings: a phone's BLE Transmitter Major/Minor that is not a
    # number (it used to fail the phone search), and an identity a device
    # could not take because another device already has it (was a warning).
    "companion_ids_unreadable", "device_identity_refused",
})
# A new install's first steps (onboarding.py): how long from setup to the
# first room and to the first calibration point, as buckets, once per
# install. Never bumped: build_payload adds them (count 1) until a report
# carrying them is accepted.
ONBOARDING_EVENTS: frozenset[str] = frozenset(f"{s}:{b}" for s in _ONB_STEPS for b in _ONB_BUCKETS)
# How long ago this install was first seen (settings first_seen_ts), as a
# word: whether a newly reporting install is new or an old one that just
# turned the report on. first_seen_ts exists from 0.38.87 (2026-09-28): an
# install older than that reads as first seen the day it updated past it.
INSTALL_AGE_WORDS: tuple[str, ...] = ("lt1d", "1_7d", "8_30d", "31_90d", "gt90d")


def install_age_word(first_seen_ts: Any, now_ts: float) -> str | None:
    if isinstance(first_seen_ts, bool) or not isinstance(first_seen_ts, (int, float)) or first_seen_ts <= 0:
        return None
    d = (now_ts - first_seen_ts) / 86400
    if d < 0:
        return None
    for edge, word in ((1, "lt1d"), (7, "1_7d"), (30, "8_30d"), (90, "31_90d")):
        if d < edge:
            return word
    return "gt90d"


# Where the person heard about PadSpan (settings telemetry_heard): their own
# one-tap answer to an optional question, asked once after they opt in and
# kept in Settings beside the switch. A word from this list, or not sent.
HEARD_WORDS: tuple[str, ...] = ("reddit", "youtube", "ha_forum", "forum", "marketplace",
                                "github", "discord", "search", "friend", "other")


def heard_word(v: Any) -> str | None:
    return v if isinstance(v, str) and v in HEARD_WORDS else None


# Room timing that is not the default, and a Home Assistant floor the outdoor
# rules now count as outside (0.38.182: a delay of 0 means 0, the outdoor rules
# read is_outdoor_floor). Sent only where one of them applies.
PRESENCE_CFG_WORDS: dict[str, tuple[str, ...]] = {
    "poll": ("1_4", "6_9", "10", "11_60"),
    "delay": ("0", "1_19", "21_60", "gt60"),
    "outdoor": ("ha",),
}


def presence_cfg_words(settings: dict, ha_floor_ids: Any = ()) -> dict[str, str]:
    from .presence_rules import is_outdoor_floor, room_change_delay_s  # noqa: PLC0415
    from .const import OUTSIDE_FLOOR_ID  # noqa: PLC0415
    out: dict[str, str] = {}
    try:
        poll = int(settings.get("presence_poll_interval_s") or 5)
    except (TypeError, ValueError):
        poll = 5
    if poll != 5:
        out["poll"] = "1_4" if poll < 5 else "6_9" if poll < 10 else "10" if poll == 10 else "11_60"
    d = room_change_delay_s(settings)
    if d != 20.0:
        out["delay"] = "0" if d == 0 else "1_19" if d < 20 else "21_60" if d <= 60 else "gt60"
    if any(f != OUTSIDE_FLOOR_ID and is_outdoor_floor(f) for f in (ha_floor_ids or ())):
        out["outdoor"] = "ha"
    return out


# The day's proxy_rate_drop count, as one of these instead of the number.
PROXY_DROP_BUCKETS: tuple[str, ...] = ("1", "2_5", "gt5")
PROXY_DROP_EVENTS: frozenset[str] = frozenset(f"proxy_rate_drops:{b}" for b in PROXY_DROP_BUCKETS)


def _proxy_drop_bucket(n: int) -> str:
    return "1" if n <= 1 else "2_5" if n <= 5 else "gt5"
# The panel's views (panel.js _VIEW_PATHS — tests/test_telemetry.py asserts
# equality) and the sub-tabs of the two views that have them.
VIEWS: frozenset[str] = frozenset({
    "follow", "overview", "purelive", "objects", "devices", "bluetooth", "presence",
    "history", "monitor", "maps", "events", "health", "settings", "manage", "debug",
    "diagnostics", "qa", "training", "calibration", "traceback", "forensics",
    "sandbox", "occupancy", "installbase", "guests", "rooms", "receivers", "setup", "ai_wizard",
})
SUBTABS: dict[str, frozenset[str]] = {
    "bluetooth": frozenset({"visualization", "monitor", "scanners", "irk_panel", "esphome_configs"}),
    "maps": frozenset({"library", "upload", "edit", "stack", "rooms", "lights", "export", "help"}),
}
TAB_EVENTS: frozenset[str] = frozenset(
    {f"tab:{v}" for v in VIEWS} | {f"tab:{v}/{s}" for v, subs in SUBTABS.items() for s in subs}
)
# Uncaught panel errors, counted by the PadSpan MODULE that threw
# (www/padspan-ha/views/ui_error.js). The panel is the half of PadSpan the
# Python log cannot see: v0.35.0 shipped a Mapping tab that threw before it
# re-rendered, so the previous tab stayed on screen and it read as a hang.
# A COUNT per module — never the message, never a stack, never anything the
# page happened to be holding.
#
# Before this, the name was the view that was OPEN, and every error on the
# page counted — Home Assistant's own, other cards', browser extensions' — so
# ui_error:overview meant "something threw while Overview was showing". Now
# only a throw with PadSpan code on its stack counts, as
#   ui_error:<view id>        a view module (views/<id>.js, id in VIEWS)
#   ui_error:<helper>         a shared helper in views/ (UI_ERROR_HELPERS)
#   ui_error:panel            panel.js, the shell around the views
#   ui_error:atlas_panel      lights_panel.js, the Atlas sidebar panel
#   ui_error:lib              the vendored Preact/htm, nothing of ours below it
#   ui_error:other            any other PadSpan file (help_content, sample_data)
# and, counted beside it, the tab that was on screen:
#   ui_error_while:<view id> | ui_error_while:atlas
# A report carrying ui_error:* WITHOUT any ui_error_while:* is from a build
# before the change (server/telemetry_summary.py splits them on that).
# tests/test_telemetry.py holds UI_ERROR_HELPERS to the files in views/.
UI_ERROR_HELPERS: frozenset[str] = frozenset({
    "device_name",
    "ai_wizard_offer", "plan_room_shapes",          # Let Claude draw your rooms (experimental; the view itself is in VIEWS)
    "rough_plan",                                   # "No floor plan? Ways to get one" and the phone's walk-through of a room scan
    "plan_carry",                                   # a moved plan's line in the Library, and what could move with it
    "room_snap",                                    # drawing rooms in Edit and Layout: corners that land, Straighten edges
    "person_home", "room_spot",                     # one rule for "is this person home"; where a room-only device stands
    "plan_measure", "scale_nudge",                  # the hand measurement (the helper's and the upload's "Set this plan's scale now")
    "atlas_weather", "fabric_compass", "live_aboard", "live_aboard_draft", "live_aboard_edit", "live_aboard_furniture",
    "live_aboard_house", "live_aboard_library", "live_aboard_use",
    "live_aboard_weather", "live_aboard_showcase", "live_aboard_fps",
    "live_aboard_studio",                           # Live Aboard's Studio look (atlas_3d_look "studio")
    "atlas_forest",                                 # the trees behind the flat map (Showcase theme "West Coast Forest")
    "live_aboard_forest",                           # the same theme's trees in Live Aboard
    "calibration_walk",                             # Calibration's Walk a room tab (calibration_room_walk)
    "power_teams",                                  # Settings → Atlas → Power teams (power_team.py)
    "calibration_results",                          # Calibration's Results tab (the one it opens on)
    "live_aboard_pieces", "live_aboard_furnish",   # Live Aboard P2 Furnish
    "live_aboard_import",
    "live_aboard_devices",                          # Live Aboard P5: furniture that is a device
    "live_aboard_tracked",                          # Live Aboard P6: beacons, scanners and people, live
    "people_trails",                                # Trails: where each person and tag went in the last half hour
    "iphone_irk",                                   # the iPhone setup path: IRK steps instead of BLE Transmitter
    "live_aboard_people", "live_aboard_photo",
    "live_aboard_runs", "live_aboard_strip",        # Live Aboard's Strip tool: strips and string lights
    "live_aboard_plans",                            # Add data via plans (experimental): the Plans tool's list
    "atlas_screen", "atlas_aboard",                 # the flat Atlas: the map alone, full screen; Live Aboard's on the map
    "map_text",                                     # the map as text for screen readers (Overview, the flat Atlas)
    "whos_where",                                   # Who's where now, before any room is drawn (Overview)
    "wizard_build",                                 # the Setup Wizard's "Put it on the map" (Mapping)
    "focus",                                        # Basic's focused views: a link opens just its part
    "atlas_heatmap",                                # the flat Atlas: temperature / humidity / CO2 heatmap
    "live_aboard_marks",                            # Live Aboard: the Atlas's leak sensors, locks, codes and class chips
    "live_aboard_motion",                           # Live Aboard: motion (the ring, the room's glow, markers, coverage, the chip)
    "live_aboard_raised",                           # Live Aboard: what stands on a line, clear of the words
    "live_aboard_show",                             # Live Aboard's ⋯ list: what this screen shows
    "live_aboard_looks",                            # Live Aboard's Views ▾ → Look: this screen's look, and one after sunset
    "live_aboard_rooms",                            # Live Aboard's room chips and a room's panel beside the house
    "scene_row",                                    # the scene row under the Atlas and in Live Aboard
    "live_aboard_panel",                            # Live Aboard on the wall panel: its home view, Follow, the People chip
    "live_aboard_director",                         # Live Aboard on the wall panel: flies to a doorbell, door or alarm that went off
    "live_aboard_storey",                           # Live Aboard: the house itself (each storey's floor, the roof, stair openings)
    "vacuum_import",                                # the Mapping tab's "Import from a robot vacuum"
    "door_types",                                   # doors: which way one swings, its type, its panels (the flat Atlas and Live Aboard)
    "outdoor_space",                                # outdoor rooms by name, and an outdoor room's surface (every look)
    "atlas_heights",                                # Mapping's Height row and Heights list (Live Aboard's heights)
    "wall_scale", "wall_card",                      # wall screens: the scale, and Settings' Wall screens card
    "busy_times", "calibration_matrix", "editions", "evidence_diagram", "house_activity",
    "insights", "iso_lights", "iso_motion", "light_codes", "lights_map", "locate",
    "pan_zoom", "path_loss", "plan_viewer", "push_subscription", "radio_map",
    "room_color", "setup_status", "stack_transform", "tune_save_plan", "ui_error",
    "wall_geom", "whatif_placement", "wled_advanced", "wled_model", "wled_tab_backup",
    "wled_tab_leds", "wled_tab_look", "wled_tab_presets", "wled_tab_settings",
    "wled_tab_sync", "wled_ui", "trial_offer", "release_notes", "pro_invite",
    "aboard_wizard",                                # the Live Aboard setup wizard (Settings, Mapping → Atlas builder)
    "i18n",                                         # the panel's translations helper (t / tn)
    "status_dot",                                   # the top bar's status dot (what is wrong, from the live poll)
})
UI_ERROR_SHELLS: frozenset[str] = frozenset({"panel", "atlas_panel", "lib", "other"})
# 0.38.177: beside each, the kind of error (views/ui_error.js UI_ERROR_KINDS)
# and the line it came from, ui_error_at:<module>:<line> — a line in
# PadSpan's own file, checked by ui_error_at_allowed.
UI_ERROR_KINDS: tuple[str, ...] = ("type", "reference", "range", "syntax", "rejection", "other")
UI_ERRORS: frozenset[str] = frozenset(
    {f"ui_error:{m}" for m in VIEWS | UI_ERROR_HELPERS | UI_ERROR_SHELLS}
    | {f"ui_error_while:{v}" for v in VIEWS | {"atlas"}}
    | {f"ui_error_kind:{k}" for k in UI_ERROR_KINDS}
)
_UI_ERROR_AT = re.compile(r"ui_error_at:([a-z0-9_]{1,40}):([1-9][0-9]{0,4})")


def ui_error_at_allowed(name: str) -> bool:
    """ui_error_at:<module>:<line> with a module from the closed list and a
    line number; nothing else of the error."""
    m = _UI_ERROR_AT.fullmatch(name)
    return bool(m) and m.group(1) in (VIEWS | UI_ERROR_HELPERS | UI_ERROR_SHELLS)
# The 90-day trial offer (views/trial_offer.js) and the Overview's Getting
# started card — a funnel, like the wizards above: where the offer was SEEN
# (once per surface per page), where it was STARTED, and where the licence
# server said no. The email never comes near this: an event is a surface's
# name, from this closed list, and nothing else. TRIAL_SURFACES is
# trial_offer.js's own list; GETTING_STARTED_STEPS is the card's step ids
# (panel.js), plus "trial" for its last line (tests/test_conversion.py
# holds both to the frontend's).
# update_banner / milestone / sidebar: the "updated to vX" banner's trial
# line, the one-time milestone card on Overview (trial_nudge_dismissed is its
# "No thanks" / ✕), and the quiet entry under the PadSpan sidebar menu.
TRIAL_SURFACES: tuple[str, ...] = ("overview", "atlas", "placement", "maps", "locate", "busy_times", "settings",
                                   "update_banner", "milestone", "sidebar", "ai_wizard")
GETTING_STARTED_STEPS: tuple[str, ...] = ("upload", "scale", "rooms", "floors", "scanners", "calibrate", "positioned", "trial")
# The free-Pro cards (views/pro_invite.js): an invite shown (once per page, on
# Overview or in Settings → PadSpan licence), put off, claimed, refused by the
# server, or declined; the one-time "test it, get Pro free" card shown, and
# its "No thanks" / ✕ (free_pro_card_*: no word of testing or signing up
# may enter the report, tests/test_tester.py). Whether anyone sees them, and
# what they do. Never who.
PRO_OFFER_EVENTS: frozenset[str] = frozenset(
    {"pro_invite_shown:overview", "pro_invite_shown:settings", "pro_invite_later", "pro_invite_claimed",
     "pro_invite_claim_failed", "pro_invite_declined", "free_pro_card_shown", "free_pro_card_no"}
)
OFFER_EVENTS: frozenset[str] = frozenset(
    {f"{what}:{s}" for what in ("trial_offer_shown", "trial_started", "trial_failed", "trial_optin") for s in TRIAL_SURFACES}
    | {f"getting_started_step:{s}" for s in GETTING_STARTED_STEPS}
    | {"getting_started_shown", "getting_started_dismissed", "trial_nudge_dismissed"}
    | PRO_OFFER_EVENTS
)
# Atlas outdoor weather (views/atlas_weather.js — the same four lists there,
# held equal by tests/test_atlas_weather.py). Each counted once per page load
# per name, so a count is "pages that saw it", not "renders":
#   weather_error:<kind>     the overlay caught its own failure and drew no
#                            weather (the map itself is never affected)
#                            — except `source`: a chosen entity that no
#                            longer exists (deleted or renamed); a fallback,
#                            where there is one, still draws
#   weather_shown:<state>    what was drawn; `still` = drawn without motion
#                            (the free map, or reduced motion)
#   weather_source:<source>  what made it wet (rain_sensor | condition), none
#                            (no sensor and no weather entity), and which
#                            warning integration made it heavy — whether the
#                            fallbacks work outside Canada.
#   weather_note:<kind>      what the decision set aside on purpose (0.38.142):
#                            sensor_overruled — a wet rain sensor under a
#                            clear sky (dew or frost, not rain); warning_ignored
#                            — the chosen warning entity is a leak detector;
#                            sensor_stale — a rain sensor whose device has
#                            stopped reporting.
# Words only: never an entity id, never alert text.
WEATHER_WARNING_PLATFORMS: tuple[str, ...] = ("env_canada", "meteoalarm", "dwd_weather_warnings", "nina",
                                              "meteo_france", "weatheralerts", "nws_alerts")
WEATHER_ERROR_KINDS: tuple[str, ...] = ("mask_build", "mask_unsupported", "tiles", "decision", "mount", "source")
WEATHER_SHOWN_STATES: tuple[str, ...] = ("light_rain", "heavy_rain", "light_snow", "heavy_snow", "still")
WEATHER_SOURCES: tuple[str, ...] = ("rain_sensor", "condition", "none",
                                    *(f"warning:{p}" for p in WEATHER_WARNING_PLATFORMS), "warning:other")
WEATHER_NOTE_KINDS: tuple[str, ...] = ("sensor_overruled", "warning_ignored", "sensor_stale")
WEATHER_EVENTS: frozenset[str] = frozenset(
    {f"weather_error:{k}" for k in WEATHER_ERROR_KINDS}
    | {f"weather_shown:{k}" for k in WEATHER_SHOWN_STATES}
    | {f"weather_source:{k}" for k in WEATHER_SOURCES}
    | {f"weather_note:{k}" for k in WEATHER_NOTE_KINDS}
)
# Live Aboard, the 3D house (views/live_aboard_house.js — the same lists
# there, held equal by tests/test_live_aboard_house.py). Each counted once per
# page load per name:
#   house3d_opened            the 3D view showed on a screen
#   house3d_fallback:<kind>   it could not, and the flat Atlas showed instead:
#                             no_webgl, slow_gpu (the frame-time check),
#                             context_lost, error
# Nothing is sent while the feature is off (settings.atlas_3d_enabled) or the
# tier is below Pro: the shared card draws no 3D at all then.
HOUSE3D_FALLBACK_KINDS: tuple[str, ...] = ("no_webgl", "slow_gpu", "context_lost", "error")
# house3d_wet_window: a window showed open while it rains or snows (Live
# Aboard's alert, 0.38.127), once per page load.
# house3d_loft_rail: an open (Loft) edge over a drop was drawn as a railing;
# house3d_mezzanine: a floor sits inside a taller one (a mezzanine in a hall,
# roofed by the hall). Both once per page load (0.38.147).
# house3d_wall_capped: a wall was stopped under a floor above it, or a
# needle-thin stretch of a tall room kept to its floor's height, once per
# page load (0.38.164).
# house3d_fallback_size:<band> (0.38.193), sent with each fallback: how many
# rooms the house has, so a slow screen can be told from a very big house.
HOUSE_SIZE_BANDS: tuple[str, ...] = ("lt20", "20_60", "60_150", "gt150")
# Stairs, once per page load where Live Aboard draws some (0.38.194,
# live_aboard.js countStairs): drawn; whether every flight lands in a room on
# the level it reaches, or some land in none, or some have nothing to reach;
# one reaching a split level or a few steps within a floor; each shape and
# style in use. Never where, how many or which.
STAIR_SHAPES: tuple[str, ...] = ("straight", "l", "u", "l2", "l3")
STAIR_STYLES: tuple[str, ...] = ("closed", "open", "treads", "floating")
STAIR_USE_EVENTS: frozenset[str] = frozenset(
    {"stairs_drawn", "stairs_reach:split_level", "stairs_reach:within"}
    | {f"stairs_outcome:{k}" for k in ("all_ok", "some_landing", "some_nofloor")}
    | {f"stairs_shape:{k}" for k in STAIR_SHAPES} | {f"stairs_style:{k}" for k in STAIR_STYLES}
)
# Live Aboard's ⋯ list, "Show on this screen" (2026-11-07, views/live_aboard_show.js
# SHOW_EVENTS, held equal by tests/test_live_aboard_show.py), counted each time:
# the list opened; each line hidden or shown again (by its key); Back to house
# defaults; a "not set up" line seen (once per page load) and followed; someone
# sent to where people or tags are switched on for the house. Counts only.
# And the scene row's (2026-11-07, views/scene_row.js SCENE_EVENTS): the row
# shown on the flat Atlas or in Live Aboard (once per page load), a scene run
# or turned off (a Home Assistant scene or a Whole house preset), a new scene
# opened in Home Assistant (from the row, the ⋯ list or Settings) and an edit
# opened (a scene, one not made in the editor, a preset). Never a name.
# And "Tap a light to switch it" (light_taps, on unless a screen unticks it: hide:light_taps): a light switched by a tap
# in Live Aboard (light_tap:ok), or one Home Assistant refused (light_tap:failed).
# And "Lights as buttons" (light_buttons, off unless a screen ticks it: show:light_buttons): a tap on one light's button
# (button_tap:light), on a button standing for several (:several), on a room's floor (:room).
# The list opened from the flat Map's own ⋯ (opened:flat), apart from the 3D look's (opened).
HOUSE3D_SHOW_ITEMS: tuple[str, ...] = (
    "lights", "glow", "strips", "fans", "scenes", "light_taps", "light_buttons", "room_switch", "motion_sensors", "motion_rooms", "motion_reach", "readouts",
    "doors", "windows", "covers", "locks", "railings", "radios", "tags", "people", "trails", "codes",
    "furniture", "devices", "scan_furniture", "stairs", "room_names", "room_outlines", "room_row", "floor_outlines", "other_floors", "glass_walls", "roof",
    "rain", "theme", "forest",
)
HOUSE3D_SHOW_EVENTS: frozenset[str] = frozenset(
    {"house3d_show:opened", "house3d_show:opened:flat", "house3d_show:reset", "house3d_show:permission:people", "house3d_show:permission:tags"}
    | {f"house3d_show:{a}:{k}" for a in ("hide", "show", "setup_seen", "setup_go") for k in HOUSE3D_SHOW_ITEMS}
    | {f"house3d_show:scene_{w}" for w in ("row:atlas", "row:aboard", "run:scene", "run:preset", "off:scene", "off:preset",
                                           "new:row", "new:show", "new:settings", "edit:scene", "edit:yaml", "edit:preset")}
    | {"house3d_show:light_tap:ok", "house3d_show:light_tap:failed"}
    | {f"house3d_show:button_tap:{w}" for w in ("light", "several", "room")}
    # "Rooms as light switches" (room_switch, off unless a screen ticks it): a room switched on, off or dimmed from its floor.
    | {f"house3d_show:room_tap:{w}" for w in ("on", "off", "dim")}
)
# The Look and the rooms (2026-11-19, views/live_aboard_house.js LOOK_KINDS and ROOM_WAYS, the same words), counted
# each time: a Look picked in Live Aboard's Views ▾, by its kind only (house3d_look:classic, :studio, :theme for any
# Showcase theme, :sun for By the sun turned on); a room gone to from Rooms ▾ (house3d_rooms:list) or a room chip
# (:chip); a room set placed in Furnish (house3d_room_set). Never which theme, room or set.
HOUSE3D_LOOK_KINDS: tuple[str, ...] = ("classic", "studio", "theme", "sun")
HOUSE3D_ROOM_WAYS: tuple[str, ...] = ("list", "chip")
HOUSE3D_EVENTS: frozenset[str] = frozenset(
    {"house3d_opened", "house3d_wet_window", "house3d_loft_rail", "house3d_mezzanine", "house3d_wall_capped",
     # Furnish, from a phone's room scan (2026-11-16): a piece sized to the scan's, and a room filled with the scan's guess.
     "house3d_scan_size", "house3d_scan_fill"}
    | {f"house3d_fallback:{k}" for k in HOUSE3D_FALLBACK_KINDS}
    | {f"house3d_wall_draw:{k}" for k in ("high", "high_still", "high_capped", "low")}
    | {f"house3d_fallback_size:{b}" for b in HOUSE_SIZE_BANDS}
    | STAIR_USE_EVENTS
    | HOUSE3D_SHOW_EVENTS
    | {f"house3d_look:{k}" for k in HOUSE3D_LOOK_KINDS}
    | {f"house3d_rooms:{w}" for w in HOUSE3D_ROOM_WAYS}
    | {"house3d_room_set"}
)
# Its photo step (ws_house3d_photo.py), counted by the server once per photo
# sent: photo_read:ok, :no_ai_task (none chosen, gone, can't read pictures, or
# Home Assistant older than 2025.8), :bad_answer (nothing usable in the
# answer) or :error (the AI Task failed). Never the photo, the AI Task or the
# answer; and nothing while the 3D house is off (the command refuses first).
PHOTO_READ_OUTCOMES: tuple[str, ...] = ("ok", "no_ai_task", "bad_answer", "error")
# And (0.38.187) what each photo sent to the AI Task was of (photo_subject:
# furniture, tag, scanner or person) and how long the AI took to answer
# (photo_secs:<band>, answered or failed). Never the photo or the answer.
PHOTO_SUBJECTS: tuple[str, ...] = ("furniture", "tag", "scanner", "person")
PHOTO_SECS: tuple[str, ...] = ("lt5", "5_15", "15_45", "gt45")
# And (2026-10-31) how a furniture photo with no kind picked was read: the
# quick look named its kind and that kind's own read answered (photo_quick:ok),
# or the full first read had to run after all (photo_quick:fallback). Once per
# such photo; neither when a read failed outright (photo_read:error says so).
PHOTO_QUICK_OUTCOMES: tuple[str, ...] = ("ok", "fallback")
# Stairs read off a floor plan (ws_house3d_stairs.py, 0.38.188), once per plan
# sent: stair_read:found (one or more), :none, :bad_answer, :error or
# :no_ai_task. Never the plan, the answer or where the stairs are.
STAIR_READ_OUTCOMES: tuple[str, ...] = ("found", "none", "bad_answer", "error", "no_ai_task")
# And (2026-11-02, the plan sent at the model's own frame) how each box in an
# answer fared: stair_box:kept (became a stair), :dropped (not a staircase's
# size or shape) or :past_edge (out past the picture: the AI answered in
# another frame than the one sent, as Ollama's Qwen did before the fix).
STAIR_BOX_OUTCOMES: tuple[str, ...] = ("kept", "dropped", "past_edge")
PHOTO_EVENTS: frozenset[str] = frozenset(
    {f"photo_read:{k}" for k in PHOTO_READ_OUTCOMES} | {f"photo_subject:{k}" for k in PHOTO_SUBJECTS}
    | {f"photo_secs:{k}" for k in PHOTO_SECS} | {f"photo_quick:{k}" for k in PHOTO_QUICK_OUTCOMES})
# And (0.38.193) how long the AI took over each plan, in the photo bands.
STAIR_EVENTS: frozenset[str] = frozenset(
    {f"stair_read:{k}" for k in STAIR_READ_OUTCOMES} | {f"stair_secs:{k}" for k in PHOTO_SECS}
    | {f"stair_box:{k}" for k in STAIR_BOX_OUTCOMES})
# The Open edges tool (2026-11-02, Mapping → Edit → Signal walls, ws_fabric.py
# ws_fabric_open_edges_apply), once per use: open_edge:tap (a stretch tapped
# open), :all (Open all edges on a room), :replaced (a signal wall gave way to
# an open edge, the one use that changes positioning) or :removed (Remove open
# edges). And how many Open edges from before had the railing they showed
# made their own word, after a Save: rail_stamped:glass or :none (ws_fabric.py
# ws_fabric_rf_barrier_rails_stamp). Never which room, wall or where.
OPEN_EDGE_ACTIONS: tuple[str, ...] = ("tap", "all", "replaced", "removed")
OPEN_EDGE_EVENTS: frozenset[str] = frozenset(
    {f"open_edge:{k}" for k in OPEN_EDGE_ACTIONS} | {"rail_stamped:glass", "rail_stamped:none"})
# Add data via plans (plan_ai.py, experimental, 2026-11), counts only: how a
# session ended and why one was cut short; whether the AI was local and in
# which frame it answers; how many plans and reads, and how long each read
# took (the photo bands); each AI failure by reason; a session in which no
# plan's whole read answered, apart from one that found nothing, and why; a
# time budget that ran out inside the reads, and in which; what the second look
# did to a find (kept it, placed it, dropped it); what was suggested and what was
# already in the house, per kind; a find with no floor to climb from; each
# verdict given (it looks right, wrong, later; a railing hint that went with its
# stair), each one taken back, and why an item was marked wrong, per kind;
# positions held as coarse; corrections aimed at a hand-placed or an AI-placed
# stair; a stacked stairwell offered and taken; an item whose target changed
# since; each item kept as new or as a correction, and whether a correction was
# taken on a hand-placed or an AI-placed stair; a stair moved after it was
# accepted; whose side a railing kept has; how each commit ended; each undo, by
# kind, and what it left; for lights, each plan's answer to whether it draws
# fixtures, how many tiles a session read, a slow AI's tiles skipped, and a
# symbol with no placed light (outside the AI's failures). Never a plan, an
# answer, a name or a position.
PLAN_AI_SESSION: tuple[str, ...] = ("started", "done", "no_read", "cancelled", "failed", "out_of_time")
PLAN_AI_NO_READ: tuple[str, ...] = ("no_media", "no_picture", "unreachable", "timeout", "bad_answer")
PLAN_AI_BUDGET_CUT: tuple[str, ...] = ("whole", "crop", "railing", "tiles", "light_crop")
PLAN_AI_CANCEL_WHY: tuple[str, ...] = ("user", "switch_off", "house3d_off", "licence", "plan_gone", "plan_changed", "restart")
PLAN_AI_MODEL: tuple[str, ...] = ("local", "cloud", "unknown")
PLAN_AI_FRAME: tuple[str, ...] = ("probed", "named")
PLAN_AI_PLAN_BANDS: tuple[str, ...] = ("1", "2_3", "4_6", "gt6")
PLAN_AI_READ_BANDS: tuple[str, ...] = ("1_5", "6_15", "16_40", "gt40")
PLAN_AI_ERRORS: tuple[str, ...] = ("no_ai_task", "bad_answer", "timeout", "unreachable", "no_media", "no_picture", "budget", "suspect_frame")
PLAN_AI_KINDS: tuple[str, ...] = ("stairs", "railing", "light")
PLAN_AI_FIXTURES: tuple[str, ...] = ("yes", "no", "unsure")
PLAN_AI_TILE_BANDS: tuple[str, ...] = ("none", "1_9", "10_27", "gt27")
PLAN_AI_VERDICTS: tuple[str, ...] = ("failure", "later", "right")
PLAN_AI_FAILURE_WHY: tuple[str, ...] = ("wrong_place", "nothing_there", "already_here", "wrong_kind", "cant_tell")
PLAN_AI_HELD: tuple[str, ...] = ("frame", "eye")
PLAN_AI_CROP: tuple[str, ...] = ("kept", "placed", "dropped", "light_kept", "light_placed", "light_dropped")
PLAN_AI_KEPT: tuple[str, ...] = ("new", "correction")
PLAN_AI_COMMIT: tuple[str, ...] = ("done", "rev_mismatch", "already_committed", "changed_since", "not_open", "stair_first", "invalid",
                                   "backup_failed", "save_failed")
PLAN_AI_UNDO: tuple[str, ...] = ("batch", "put_back", "item_skipped", "stairs", "railing", "light", "already_undone", "save_failed")
PLAN_AI_EVENTS: frozenset[str] = frozenset(
    {f"plan_ai_session:{k}" for k in PLAN_AI_SESSION} | {f"plan_ai_cancel_why:{k}" for k in PLAN_AI_CANCEL_WHY}
    | {f"plan_ai_model:{k}" for k in PLAN_AI_MODEL} | {f"plan_ai_frame:{k}" for k in PLAN_AI_FRAME}
    | {f"plan_ai_plans:{k}" for k in PLAN_AI_PLAN_BANDS} | {f"plan_ai_reads:{k}" for k in PLAN_AI_READ_BANDS}
    | {f"plan_ai_read_secs:{k}" for k in PHOTO_SECS} | {f"plan_ai_error:{k}" for k in PLAN_AI_ERRORS}
    | {f"plan_ai_suggested:{k}" for k in PLAN_AI_KINDS} | {f"plan_ai_duplicate:{k}" for k in PLAN_AI_KINDS}
    | {f"plan_ai_verdict:{k}_{v}" for k in PLAN_AI_KINDS for v in PLAN_AI_VERDICTS}
    | {f"plan_ai_taken_back:{k}_{v}" for k in PLAN_AI_KINDS for v in PLAN_AI_VERDICTS}
    | {f"plan_ai_failure_why:{k}_{w}" for k in PLAN_AI_KINDS for w in PLAN_AI_FAILURE_WHY} | {f"plan_ai_held:{k}" for k in PLAN_AI_HELD}
    | {f"plan_ai_crop:{k}" for k in PLAN_AI_CROP} | {f"plan_ai_no_read:{k}" for k in PLAN_AI_NO_READ}
    | {f"plan_ai_budget_cut:{k}" for k in PLAN_AI_BUDGET_CUT}
    | {f"plan_ai_verdict:{k}_{v}" for k in PLAN_AI_KINDS for v in PLAN_AI_KEPT}
    | {f"plan_ai_commit:{k}" for k in PLAN_AI_COMMIT} | {f"plan_ai_undo:{k}" for k in PLAN_AI_UNDO}
    | {"plan_ai_verdict:railing_settled", "plan_ai_taken_back:railing_settled", "plan_ai_no_floor",
       "plan_ai_correction_target:hand", "plan_ai_correction_target:ai", "plan_ai_correction_taken:hand", "plan_ai_correction_taken:ai",
       "plan_ai_stacked:offered", "plan_ai_stacked:taken", "plan_ai_stale", "plan_ai_moved_after_accept:stairs",
       "plan_ai_rail_side:ai", "plan_ai_rail_side:own", "plan_ai_light_unmatched", "plan_ai_tiles_slow"}
    | {f"plan_ai_fixtures:{k}" for k in PLAN_AI_FIXTURES} | {f"plan_ai_tiles:{k}" for k in PLAN_AI_TILE_BANDS}
    | {f"plan_ai_missing_added:{k}" for k in PLAN_AI_KINDS})
# The AI credit tracker (ai_usage.py, experimental, 2026-11; every feature's
# AI reads): each read by what it was for and who makes the AI; each read that
# failed or was refused, by its one reason (ai_usage.STOP_REASONS, the stall
# watch); once, when a month has ended, its reads and its estimated Claude
# dollars in coarse bands (none: no priced model read); the warning's share
# chosen (or off) and each notice it gave. Never an AI Task, a model, an
# amount typed in, a price or an exact figure.
from .ai_usage import (CREDIT_MONTH_BANDS as _AI_CREDIT_BANDS, KINDS as _AI_KINDS,  # noqa: E402
                       MAKERS as _AI_MAKERS, READS_MONTH_BANDS as _AI_READS_BANDS,
                       STOP_REASONS as _AI_STOPS, WARN_EVENTS as _AI_WARN)
AI_USAGE_EVENTS: frozenset[str] = frozenset(
    {f"ai_reads_kind:{k}" for k in _AI_KINDS} | {f"ai_reads_maker:{k}" for k in _AI_MAKERS}
    | {f"ai_reads_fail:{k}" for k in _AI_STOPS} | {f"ai_reads_month:{k}" for k in _AI_READS_BANDS}
    | {f"ai_credit_month:{k}" for k in _AI_CREDIT_BANDS} | {f"ai_credit_warn:{k}" for k in _AI_WARN})
# Build from plans: advanced plan alignment (plan_ai.py's line-up; Claude,
# experimental, 2026-11; design PadspanResearch plan-build-design-2026-11.md
# section 10, Stage 1 here). Counts and closed words only: never a plan, a
# title, a room, a floor, an AI Task, a map id, a coordinate, a size, a credit
# amount or a price. The stall watch (section 14): every stop by its one named
# reason (plan_ai.STOPS), the stress signals and how long a person waited.
PLAN_BUILD_STAGE: tuple[str, ...] = ("s0", "s1", "s2")      # s0: the rooms helper's scale read (design ai-wizard J.4)
PLAN_BUILD_SETTING: tuple[str, ...] = ("shown", "on", "off")
PLAN_BUILD_UNLOCK: tuple[str, ...] = ("opus", "fable", "other", "not_anthropic", "below_opus_5_5", "unknown_model", "sources_disagree", "no_ai_task")
PLAN_BUILD_RUN: tuple[str, ...] = ("started", "finished", "needs_help", "resumed", "cancelled", "failed", "out_of_time", "no_credit", "abandoned",
                                   "read_again")
PLAN_BUILD_RUN_SECS: tuple[str, ...] = ("lt1m", "1_3m", "3_10m", "gt10m")
PLAN_BUILD_PLAN_BANDS: tuple[str, ...] = ("1", "2_3", "4_6", "gt6")
PLAN_BUILD_CREDIT: tuple[str, ...] = ("lt0_10", "0_10_0_50", "0_50_2", "gt2")
PLAN_BUILD_READ: tuple[str, ...] = ("plan", "dimension", "retry", "reused")
PLAN_BUILD_READ_S2: tuple[str, ...] = ("plan", "retry")          # Stage 2 reads each plan whole, twice: no dimension crops, nothing reused
PLAN_BUILD_READ_FAIL: tuple[str, ...] = ("timeout", "refusal", "bad_answer", "unreachable", "no_credit", "no_media", "suspect_frame", "backup_used")
PLAN_BUILD_ANCHOR: tuple[str, ...] = ("gauge", "evidence", "none")
PLAN_BUILD_DIMS: tuple[str, ...] = ("agree", "disagree", "single", "none", "parse_mismatch")
PLAN_BUILD_FIT: tuple[str, ...] = ("lt70", "70_85", "85_95", "ge95", "ratio_disagree")
PLAN_BUILD_SEED: tuple[str, ...] = ("stairs", "search", "taps")
PLAN_BUILD_FIT_SECS: tuple[str, ...] = ("lt5", "5_20", "20_60", "capped")
PLAN_BUILD_PCT: tuple[str, ...] = ("lt1", "1_3", "3_10", "gt10")
# Stage 1a counts what it shows and the verdicts it takes; Stage 1b what is
# accepted (one by one or as a group), refiled by hand, undone, and how a save
# went (its checks, the calibration preflight, a save healed after a restart).
PLAN_BUILD_REFILE: tuple[str, ...] = ("suggested", "by_hand", "refused_drawn", "accepted", "wrong", "undone")
PLAN_BUILD_HELP: tuple[str, ...] = ("dimension_shown", "dimension_yes", "dimension_typed", "dimension_skipped", "taps_shown", "taps_done",
                                    "taps_skipped", "gave_up")
PLAN_BUILD_ITEM_KINDS: tuple[str, ...] = ("place", "refile", "anchor_scale", "room", "space", "door", "window", "stairs")
PLAN_BUILD_ITEM: tuple[str, ...] = ("shown", "accepted", "accepted_group", "not_now", "wrong", "undone", "stale", "maybe")
PLAN_BUILD_WRONG: tuple[str, ...] = ("wrong_match", "wrong_scale", "wrong_floor", "cant_tell")
PLAN_BUILD_M: tuple[str, ...] = ("lt0_3", "0_3_1", "1_3", "gt3")
PLAN_BUILD_FLAGS: tuple[str, ...] = ("calibration", "device", "room_trace")
PLAN_BUILD_STOPS: tuple[str, ...] = ("locked", "unreachable", "no_credit", "out_of_time", "no_media", "help_unanswered", "help_limit",
                                     "refile_refused", "measured_plan_protected", "anchor_error", "no_anchor", "no_metre_scale", "not_placed",
                                     "fit_rejected", "cancelled", "abandoned", "group_refused", "preflight_blocked", "backup_failed", "undo_failed",
                                     "changed_while_saving", "floor_gone", "plan_changed", "ai_changed", "restart", "bad_answer", "refusal", "error", "anchor_after_fit", "save_stands", "undo_stands", "room_gate",
                                     "rooms_changed", "name_taken")
PLAN_BUILD_SHOWN_ACCEPTED: tuple[str, ...] = ("shown", "accepted")
PLAN_BUILD_COMMIT: tuple[str, ...] = ("done", "changed_since", "points_out_of_range", "measured_plan_protected", "refile_refused", "group_refused",
                                      "backup_failed", "save_failed", "rolled_back", "anchor_after_fit")
PLAN_BUILD_PREFLIGHT: tuple[str, ...] = ("checked", "blocked")
PLAN_BUILD_UNDO: tuple[str, ...] = ("session", "item_skipped", "failed")
PLAN_BUILD_SETTLED: tuple[str, ...] = ("finished", "put_back", "stood")
PLAN_BUILD_STRESS: tuple[str, ...] = ("repeat", "help_over", "resumes", "quick_abandon")
PLAN_BUILD_WAIT: tuple[str, ...] = ("lt1m", "1_10m", "10_60m", "gt1h")
# Stage 2 (rooms, doors, windows and stairs read together; design section 5):
# the rooms gate on the calibration spots, whether a room's two reads agreed
# (or its parts didn't join), and
# what the person merged. Its items use plan_build_item's kinds above.
PLAN_BUILD_HELDOUT: tuple[str, ...] = ("up", "same", "down", "unscored")
PLAN_BUILD_AGREE: tuple[str, ...] = ("ready", "differ", "apart", "spots_out", "two_of_three", "three_differ")
PLAN_BUILD_MERGE: tuple[str, ...] = ("into_room", "together", "new_room", "separated")
PLAN_BUILD_EVENTS: frozenset[str] = frozenset(
    {f"plan_build_setting:{k}" for k in PLAN_BUILD_SETTING} | {f"plan_build_unlock:{k}" for k in PLAN_BUILD_UNLOCK}
    | {f"plan_build_run:{s}_{k}" for s in PLAN_BUILD_STAGE for k in PLAN_BUILD_RUN}
    | {f"plan_build_run_secs:{s}_{k}" for s in PLAN_BUILD_STAGE for k in PLAN_BUILD_RUN_SECS}
    | {f"plan_build_plans:{k}" for k in PLAN_BUILD_PLAN_BANDS}
    | {f"plan_build_credit_run:{s}_{k}" for s in PLAN_BUILD_STAGE for k in PLAN_BUILD_CREDIT}
    | {f"plan_build_read:{s}_{k}" for s in ("s0", "s1") for k in PLAN_BUILD_READ} | {f"plan_build_read:s2_{k}" for k in PLAN_BUILD_READ_S2}
    | {f"plan_build_read_fail:{s}_{k}" for s in PLAN_BUILD_STAGE for k in PLAN_BUILD_READ_FAIL}
    | {f"plan_build_read_secs:{k}" for k in PHOTO_SECS}
    | {f"plan_build_anchor:{k}" for k in PLAN_BUILD_ANCHOR} | {f"plan_build_dims:{k}" for k in PLAN_BUILD_DIMS}
    | {f"plan_build_fit:{k}" for k in PLAN_BUILD_FIT} | {f"plan_build_seed:{k}" for k in PLAN_BUILD_SEED}
    | {f"plan_build_fit_secs:{k}" for k in PLAN_BUILD_FIT_SECS} | {f"plan_build_shape_err:{k}" for k in PLAN_BUILD_PCT}
    | {f"plan_build_refile:{k}" for k in PLAN_BUILD_REFILE} | {f"plan_build_help:{k}" for k in PLAN_BUILD_HELP}
    | {f"plan_build_item:{i}_{k}" for i in PLAN_BUILD_ITEM_KINDS for k in PLAN_BUILD_ITEM}
    | {f"plan_build_wrong_why:{k}" for k in PLAN_BUILD_WRONG}
    | {f"plan_build_move:{s}_{k}" for s in PLAN_BUILD_SHOWN_ACCEPTED for k in PLAN_BUILD_M}
    | {f"plan_build_scale_change:{s}_{k}" for s in PLAN_BUILD_SHOWN_ACCEPTED for k in PLAN_BUILD_PCT}
    | {f"plan_build_commit:{k}" for k in PLAN_BUILD_COMMIT} | {f"plan_build_preflight:{k}" for k in PLAN_BUILD_PREFLIGHT}
    | {f"plan_build_undo:{k}" for k in PLAN_BUILD_UNDO} | {f"plan_build_settled:{k}" for k in PLAN_BUILD_SETTLED}
    | {f"plan_build_flags:{k}" for k in PLAN_BUILD_FLAGS} | {f"plan_build_flag_move:{k}" for k in PLAN_BUILD_M}
    | {f"plan_build_stop:{k}" for k in PLAN_BUILD_STOPS} | {f"plan_build_stress:{k}" for k in PLAN_BUILD_STRESS}
    | {f"plan_build_wait:{k}" for k in PLAN_BUILD_WAIT}
    | {f"plan_build_heldout:{k}" for k in PLAN_BUILD_HELDOUT} | {f"plan_build_agree:{k}" for k in PLAN_BUILD_AGREE}
    | {f"plan_build_merge:{k}" for k in PLAN_BUILD_MERGE})
# The Plans tool's walls the server never saw (views/live_aboard_plans.js,
# design ai-wizard J.6): the tool opened, each tab chosen, a floor picked in
# Line up (s1) or Rooms from plans (s2), and the stops the panel shows by
# itself: Rooms from plans on a floor with no plan placed, Line up with no
# floor that has a plan, and no tabs because Claude isn't unlocked or the
# Build from plans switch is off. And the next actions those walls offer,
# tapped: Measure a plan in Mapping, the rooms helper, Settings → AI. Counts
# only, never a floor or a plan.
PLANS_TOOL_TABS: tuple[str, ...] = ("add", "lineup", "rooms")
PLANS_TOOL_STOPS_UI: tuple[str, ...] = ("s2_not_placed", "s1_no_plans", "no_tabs_locked", "no_tabs_off")
PLANS_TOOL_GO: tuple[str, ...] = ("measure", "helper", "settings")
PLANS_TOOL_EVENTS: frozenset[str] = frozenset(
    {"plans_tool:opened"} | {f"plans_tab:{k}" for k in PLANS_TOOL_TABS} | {f"plans_floor:{s}" for s in ("s1", "s2")}
    | {f"plan_build_stop_ui:{k}" for k in PLANS_TOOL_STOPS_UI} | {f"plans_tool_go:{k}" for k in PLANS_TOOL_GO})
# Let Claude draw your rooms (ai_wizard.py, views/ai_wizard.js; design
# ai-wizard J.2, J.3, J.5): where it was offered and opened, each step
# reached and the step it was left at, how it ended, why a read or a save
# stopped, whether Claude was ready (and what the person did about it), the
# links tapped, the switches turned on, and per save how many rooms were
# offered and saved, where each saved room's name came from and how many of
# the floor's Home Assistant areas no room took. Counts only: never a name,
# a plan, a room, a floor or an amount.
AI_WIZARD_SURFACES: tuple[str, ...] = ("overview", "getting_started", "setup", "maps_wizard", "plans_tool")
AI_WIZARD_STEPS: tuple[str, ...] = ("intro", "trial", "connect", "consent", "scale_read", "scale_check", "scale_guided",
                                    "floor_pick", "rooms_read", "rooms_check", "saved", "next_floor", "handoff")
AI_WIZARD_OUTCOMES: tuple[str, ...] = ("finished", "dismissed", "snoozed", "came_back", "undone", "area_created", "area_failed",
                                       "with_rooms", "after_undo", "edits_back", "zoomed",
                                       "struggled_later", "struggled_left",   # the pull surfaces' trigger first met (2026-11-12)
                                       "undo_from_setup", "undo_from_settings", "undo_next_again", "undo_next_by_hand")   # the later undo, what next
AI_WIZARD_FAILS: tuple[str, ...] = ("no_credit", "unreachable", "out_of_time", "bad_answer", "refusal", "no_media", "daily_cap",
                                    "backup_failed", "changed_since")
AI_WIZARD_AI: tuple[str, ...] = ("no_ai_task", "not_anthropic", "below_opus_5_5", "unknown_model", "sources_disagree",
                                 "available_unchosen", "ok", "chosen", "check_again", "became_ok")
AI_WIZARD_LINKS: tuple[str, ...] = ("guide", "console", "ha_add", "ha_anthropic", "ha_areas")
# The one tiny read before anything is measured (ai_wizard.ws_ai_wizard_check_claude, 2026-11-12): how it ended.
AI_WIZARD_CHECK: tuple[str, ...] = ("ok", "no_credit", "unreachable", "no_media", "error", "not_ready")
# "The scale looks wrong" on the check list (ai_wizard.scale_signs, 2026-11-12): shown (and which signs), what the person
# did (checked it, said it is right, sent to Mapping's Measure because things in metres sit on it), the rooms redrawn.
AI_WIZARD_SCALE_NOTICE: tuple[str, ...] = ("shown", "checked", "dismissed", "elsewhere", "reprojected")
AI_WIZARD_SCALE_SIGNS: tuple[str, ...] = ("rooms", "printed")
ROOMS_BANDS: tuple[str, ...] = ("0", "1", "2_3", "4_6", "7_12", "gt12")
NAME_SOURCES: tuple[str, ...] = ("area_exact", "area_abbrev", "printed", "typed", "picked_area")
# The plan's scale (pieces 3 and 4, design J.4): the path its scale took (a
# printed dimension Claude read, double-checked across and down or not, none
# found, one guided measurement, or set already), how each save ended (the data-safety
# stops are plan_ai_write.SCALE_STOPS), how its undo ended, and a later hand
# Measure of a plan the helper scaled, by how far it moved the scale. Of
# Claude's reading: what the person did (yes, a number corrected, measured
# themselves instead, looked at a reading not double-checked), how far a corrected number was from Claude's, how many
# directions were read and how far across and down disagreed (PLAN_BUILD_PCT).
SCALE_PATHS: tuple[str, ...] = ("printed_checked", "printed_unchecked", "none_found", "guided", "already_set", "reused")
SCALE_CHECK: tuple[str, ...] = ("yes", "corrected", "guided_instead", "looked")
SCALE_AXES: tuple[str, ...] = ("two", "one", "none")
SCALE_SAVE: tuple[str, ...] = ("done", "already_placed", "points_on_plan", "plan_changed", "no_picture_size", "backup_failed", "floor_unknown")
SCALE_UNDO: tuple[str, ...] = ("done", "changed_since", "failed")
# The scale step, measure first (owner, 2026-11-12): the way the saved scale was made (the person's own line, or
# Claude's double-checked reading put down by Use it), and each time the person asked Claude to look (a paid read).
SCALE_TAKEN: tuple[str, ...] = ("measured", "used_reading", "asked_claude")
AI_WIZARD_EVENTS: frozenset[str] = frozenset(
    {f"ai_wizard_{w}:{s}" for w in ("offered", "opened") for s in AI_WIZARD_SURFACES}
    | {f"ai_wizard_{w}:{s}" for w in ("step", "left") for s in AI_WIZARD_STEPS}
    | {f"ai_wizard:{k}" for k in AI_WIZARD_OUTCOMES} | {f"ai_wizard_fail:{k}" for k in AI_WIZARD_FAILS}
    | {f"ai_wizard_ai:{k}" for k in AI_WIZARD_AI} | {f"ai_wizard_link:{k}" for k in AI_WIZARD_LINKS} | {"ai_wizard_switch:on"}
    | {f"ai_wizard_check:{k}" for k in AI_WIZARD_CHECK}
    | {f"ai_wizard_scale_notice:{k}" for k in AI_WIZARD_SCALE_NOTICE} | {f"ai_wizard_scale_sign:{k}" for k in AI_WIZARD_SCALE_SIGNS}
    | {f"plan_build_rooms_{w}:{b}" for w in ("offered", "saved") for b in ROOMS_BANDS}
    | {f"plan_build_name:{k}" for k in NAME_SOURCES} | {f"plan_build_unmatched_areas:{b}" for b in ROOMS_BANDS}
    | {f"plan_build_scale:{k}" for k in SCALE_PATHS} | {f"plan_build_scale_save:{k}" for k in SCALE_SAVE}
    | {f"plan_build_scale_undo:{k}" for k in SCALE_UNDO} | {f"plan_build_scale_remeasured:{k}" for k in PLAN_BUILD_PCT}
    | {f"plan_build_scale_check:{k}" for k in SCALE_CHECK} | {f"plan_build_scale_axes:{k}" for k in SCALE_AXES}
    | {f"plan_build_scale_taken:{k}" for k in SCALE_TAKEN}
    | {f"plan_build_scale_{w}:{k}" for w in ("fix", "stretch") for k in PLAN_BUILD_PCT})


def rooms_band(n: int) -> str:
    """ROOMS_BANDS for a count of rooms."""
    return "0" if n <= 0 else "1" if n == 1 else "2_3" if n <= 3 else "4_6" if n <= 6 else "7_12" if n <= 12 else "gt12"


# The Overview's accuracy tips (setup_checks.py, 0.38.193): each one shown,
# opened (gone to its fix) or hidden, and the whole card hidden. Whether the
# nudges move the three setup steps most homes skip.
TIP_IDS: tuple[str, ...] = ("floor_heights", "receiver_heights", "scale", "plan_shape")
TIP_EVENTS: frozenset[str] = frozenset(
    {f"tip_{a}:{t}" for a in ("shown", "opened", "hidden") for t in TIP_IDS} | {"tip_hidden:all"})
# Calibration → Results (views/calibration_results.js, 2026-10-30): each
# opening of the tab, and which button was used: the next best thing to do
# (by its kind) or Guided calibration. Whether opening on results gets
# people to the step that helps. Kinds only, never a room.
CAL_RESULTS_ACTIONS: tuple[str, ...] = (
    "scale", "start", "receiver_heights", "floor_heights", "compute",
    "room_empty", "room_weak", "stale", "matrix", "guided")
CAL_RESULTS_EVENTS: frozenset[str] = frozenset(
    {f"cal_results_action:{k}" for k in CAL_RESULTS_ACTIONS} | {"cal_results_opened"})
# The guided Setup (views/setup.js): each step reached (once per page), each
# step skipped, and the whole sequence finished (once per install, only by a
# house that used it). Where people stop, beside the two wizards' own funnels.
from .setup_checks import SETUP_STEPS  # noqa: E402
SETUP_NEXT: tuple[str, ...] = ("rooms", "floors", "receivers", "calibration")
SETUP_EVENTS: frozenset[str] = frozenset(
    {f"setup_{a}:{s}" for a in ("step", "skip") for s in SETUP_STEPS} | {"setup_done"}
    # "Put my receivers in their rooms" (ws_fabric.ws_receivers_to_rooms, 2026-11-12): pressed, how many it placed, undone.
    | {f"setup_receivers_rooms:{k}" for k in ("pressed", "undone")} | {f"setup_receivers_placed:{b}" for b in ROOMS_BANDS}
    # The "Next: …" buttons that lead a step on to the next in the product's order (2026-11-13): which was pressed.
    | {f"setup_next:{s}" for s in SETUP_NEXT})
# "Set this plan's scale now" right after Mapping → Upload (views/scale_nudge.js): shown, saved with one length or
# two, put off with Later, and the quiet "No scale yet" line's Measure (Mapping → Library, Setup) pressed. Since
# 2026-11-13 the same screen is every plan's first scale: at Save, which door it came through (via_<door>,
# scale_nudge.DOORS: after an upload, Setup, Getting started, the Setup Wizard, a "No scale yet" line, the Plans tool,
# 3D Stack).
SCALE_NUDGE_DOORS: tuple[str, ...] = ("upload", "setup", "getting_started", "wizard", "reminder", "plans", "stack")
# 2026-11-15: how far a person got on the screen, each once a page per plan: the first end tapped, both ends down, a
# length typed, a Save refused.
SCALE_NUDGE_STEPS: tuple[str, ...] = ("first_end", "both_ends", "typed", "refused")
# 2026-11-16: "This picture isn't to scale" pressed, and a scale saved with each direction its own (a sketch).
SCALE_NUDGE_SKETCH: tuple[str, ...] = ("not_to_scale", "per_axis")
SCALE_NUDGE_WORDS: tuple[str, ...] = (("shown", "measured_one", "measured_two", "later", "reminder_measure") + SCALE_NUDGE_STEPS + SCALE_NUDGE_SKETCH
                                      + tuple(f"via_{d}" for d in SCALE_NUDGE_DOORS))
SCALE_NUDGE_EVENTS: frozenset[str] = frozenset(f"scale_nudge:{k}" for k in SCALE_NUDGE_WORDS)
# Mapping → Upload (views/maps.js _upload, 2026-11-15): a picture picked, Upload pressed with none, and what came of
# an upload. Never the picture, its name or its size.
# 2026-11-16: "sketch": a picture uploaded with "my own sketch, not to scale" ticked.
PLAN_UPLOAD_WORDS: tuple[str, ...] = ("picked", "no_file", "ok", "bad_picture", "too_large", "failed", "sketch")
PLAN_UPLOAD_EVENTS: frozenset[str] = frozenset(f"plan_upload:{k}" for k in PLAN_UPLOAD_WORDS)
# "No floor plan? Ways to get one" (views/rough_plan.js, 2026-11-16): the list opened, each way opened (a drawing they
# have, a LiDAR room scan, the robot's map, their own sketch, a blank floor), the phone's walk-through started, and
# what came of a scan or a blank floor. Words only: never the file, a size or a name.
ROUGH_PLAN_WORDS: tuple[str, ...] = ("opened", "have", "scan", "vacuum", "sketch", "blank", "walk", "sketch_upload",
                                     "scan_made", "scan_refused", "blank_made", "blank_refused")
# Owner, 2026-11-16: "no maps means not purchasing", so how each way to a plan goes is told in full. The button shown
# on an upload screen (the base every count above is a share of); the walk-through opened from its address, each of
# its screens reached, closed before the end, finished, and gone round again for another floor; why a scan was refused
# (too large, not openable, opened but no room scan in it, nothing to draw); and of a scan that was read: the file's
# kind, how many walls it had as a band, whether the phone named its rooms, and whether it was given from a phone.
ROUGH_PLAN_WALK: tuple[str, ...] = ("seen", "walk_link", "walk_2", "walk_3", "walk_4", "walk_5", "walk_6", "walk_closed", "walk_done", "walk_again")
ROUGH_PLAN_SCAN: tuple[str, ...] = ("scan_refused_size", "scan_refused_unreadable", "scan_refused_not_scan", "scan_refused_empty",
                                    "scan_usdz", "scan_json", "scan_walls_1_4", "scan_walls_5_12", "scan_walls_13_30", "scan_walls_gt30",
                                    "scan_named", "scan_phone", "scan_snap", "scan_room_used",
                                    # Autoplace: put on the room it fits (its outline fitting both ways round or one), or
                                    # not placed; and a drawn room over a tenth off the scan's measured size.
                                    "scan_placed", "scan_placed_both", "scan_unplaced", "scan_size_differs")
# Carry-along (views/plan_carry.js, plan_carry.py; 2026-11-16): a moved plan's line shown, its list opened, what was
# ticked moved (and which kinds), left where it was, or a move refused (no backup). Words only.
PLAN_CARRY_WORDS: tuple[str, ...] = ("offered", "opened", "moved", "dismissed", "refused", "moved_rooms", "moved_receivers", "moved_points", "moved_devices", "moved_walls", "moved_beacons", "moved_zones")
PLAN_CARRY_EVENTS: frozenset[str] = frozenset(f"plan_carry:{k}" for k in PLAN_CARRY_WORDS)
# Align's "Suggest a fit" (views/maps.js; the server's fit_to_floor): a fit shown, or none to suggest.
FIT_SUGGEST_EVENTS: frozenset[str] = frozenset({"fit_suggest:shown", "fit_suggest:none"})
ROUGH_PLAN_EVENTS: frozenset[str] = frozenset(f"rough_plan:{k}" for k in ROUGH_PLAN_WORDS + ROUGH_PLAN_WALK + ROUGH_PLAN_SCAN)


# env.plans (2026-11-16): the house's plans by where they came from, and how far the furthest of each kind has got.
# A plan is a "picture" unless the person said otherwise (maps_store.PLAN_KINDS). Words only, a count as a band.
PLAN_SOURCES: tuple[str, ...] = ("picture", "sketch", "blank", "scan")
PLAN_STAGES: tuple[str, ...] = ("unscaled", "scaled", "receivers", "rooms", "full")       # in order: the furthest wins
PLAN_COUNT_WORDS: tuple[str, ...] = ("1", "2_3", "4_plus")


def plan_sources(maps: Any, transforms: Any) -> dict[str, str]:
    """{source: its furthest stage, source_n: how many, as a band} for the plans of the house, Outside's left out.
    unscaled: no scale; scaled: a scale and nothing on it; receivers / rooms: one of them placed or drawn on it; full:
    both. Empty with no plan."""
    from .presence_rules import is_outdoor_floor  # noqa: PLC0415
    got: dict[str, list[int]] = {}
    for m in maps or []:
        if not isinstance(m, dict) or is_outdoor_floor(m.get("floor_id")):
            continue
        t = (transforms or {}).get(m.get("id")) if isinstance(transforms, dict) else None
        scaled = isinstance(t, dict) and bool(t.get("scale_x_m")) and bool(t.get("scale_y_m"))
        rooms, rx = bool(m.get("room_bounds")), bool(m.get("receivers"))
        stage = "unscaled" if not scaled else "full" if rooms and rx else "rooms" if rooms else "receivers" if rx else "scaled"
        src = m.get("kind") if m.get("kind") in PLAN_SOURCES else "picture"
        got.setdefault(src, []).append(PLAN_STAGES.index(stage))
    out: dict[str, str] = {}
    for src, stages in got.items():
        out[src] = PLAN_STAGES[max(stages)]
        out[src + "_n"] = "1" if len(stages) == 1 else "2_3" if len(stages) <= 3 else "4_plus"
    return out
# Drawing rooms (views/maps.js, 2026-11-15): a room's name pressed above the plan in the Setup Wizard, the plan clicked
# with no room chosen, and rooms or receivers the wizard saved without Save Layout.
WIZARD_DRAW_WORDS: tuple[str, ...] = ("name", "no_room", "kept")
WIZARD_DRAW_EVENTS: frozenset[str] = frozenset(f"wizard_draw:{k}" for k in WIZARD_DRAW_WORDS)
# The AI Task chosen for photos (env.ai, 0.38.187), only where one is chosen:
# local (Ollama), cloud (OpenAI, Google, Anthropic, Home Assistant Cloud…),
# unknown (another integration) or unready (chosen, but gone, blind to
# pictures, or Home Assistant too old). Never its name or entity.
AI_TASK_WORDS: tuple[str, ...] = ("local", "cloud", "unknown", "unready")


def ai_task_word(hass: HomeAssistant) -> str | None:
    st = hass.data.get(DOMAIN, {}).get(DATA_SETTINGS)
    if not str(((st.data if st else {}) or {}).get("atlas_3d_ai_task_entity") or "").strip():
        return None
    try:
        from .ws_house3d_photo import ai_task  # noqa: PLC0415
        ai = ai_task(hass)
    except Exception:  # noqa: BLE001
        return None
    if not ai.get("ready"):
        return "unready"
    return "local" if ai.get("local") is True else "cloud" if ai.get("local") is False else "unknown"
# The panels' own measurements (www/padspan-ha/client_perf.js — the same lists
# there, held equal by tests/test_telemetry.py). Once a minute while a panel
# is on screen: its frame rate, and where the browser tells (Chromium) its
# JavaScript heap, by the kind of view showing — the Atlas, the 3D house
# ("sim"), anything else. Once per page load: the class of device it runs on
# (the browser's own coarse memory figure, CPU threads, WebGL 2, touch). What
# the Atlas and the 3D house need of the screen they run on — the half of the
# minimum requirements the HA machine's numbers cannot say. Buckets only.
CLIENT_VIEWS: tuple[str, ...] = ("atlas", "sim", "other")
CLIENT_FPS: tuple[str, ...] = ("lt10", "10_24", "24_45", "45up")
CLIENT_HEAP: tuple[str, ...] = ("lt128m", "128_256m", "256_512m", "512m_1g", "1g_up")
CLIENT_DEV: tuple[str, ...] = ("mem_lt1g", "mem_1g", "mem_2g", "mem_4g", "mem_8g_up", "mem_unknown",
                               "cores_1_2", "cores_3_4", "cores_5_8", "cores_9_up", "cores_unknown",
                               "webgl2_yes", "webgl2_no", "touch_yes", "touch_no",
                               # Do sensor states reach the panel with last_reported? (a steady
                               # room's temperature stays fresh by it, 0.38.126)
                               "lastrep_yes", "lastrep_no")
# The screen a panel runs on (client_perf.js CLIENT_SCREEN, held equal by
# tests/test_perf_memory.py): resolution by its long side in device pixels,
# orientation, pixel density, kind of screen, one monitor or more. Buckets
# only, never a size. client_screen_seen: one per screen per report window
# (note_screen), so the report says how many screens a house runs.
CLIENT_SCREEN: tuple[str, ...] = ("res_lt720", "res_720", "res_1080", "res_1440", "res_4k", "res_5k_up",
                                  "orient_land", "orient_port", "dpr_1", "dpr_1_5", "dpr_2", "dpr_3_up",
                                  "kind_phone", "kind_tablet", "kind_desktop", "kind_large",
                                  "screens_1", "screens_2up", "screens_unknown")
CLIENT_EVENTS: frozenset[str] = frozenset(
    {f"client_fps:{v}:{b}" for v in CLIENT_VIEWS for b in CLIENT_FPS}
    | {f"client_heap:{v}:{b}" for v in CLIENT_VIEWS for b in CLIENT_HEAP}
    | {f"client_dev:{d}" for d in CLIENT_DEV}
    | {f"client_screen:{w}" for w in CLIENT_SCREEN}
    | {"client_screen_seen"}
)

# Wall screens (panel.js, and lights_panel.js: the sidebar Atlas), once per
# page load after two and a half minutes. wall_screen:<panel>:kiosk (?kiosk=1),
# :fullscreen_idle (a window filling the screen, untouched for two minutes:
# what a self-reload after an update treats as a wall), :fullscreen_used, or
# :windowed. wall_reload:<panel>:kiosk|fullscreen: this page is the build a
# self-reload went for (0.38.145); :stuck: it reloaded and came back on the
# old build. view_link:kept|forensics_off|edition: a ?view= link (#93) stayed
# open, or went back to the menu (Forensics off, or no such view in this
# edition). Never the URL or the screen's size.
SCREEN_PANELS: tuple[str, ...] = ("panel", "atlas")
SCREEN_KINDS: tuple[str, ...] = ("kiosk", "fullscreen_idle", "fullscreen_used", "windowed")
RELOAD_OUTCOMES: tuple[str, ...] = ("kiosk", "fullscreen", "stuck")
VIEW_LINK_OUTCOMES: tuple[str, ...] = ("kept", "forensics_off", "edition")
SCREEN_EVENTS: frozenset[str] = frozenset(
    {f"wall_screen:{p}:{k}" for p in SCREEN_PANELS for k in SCREEN_KINDS}
    | {f"wall_reload:{p}:{k}" for p in SCREEN_PANELS for k in RELOAD_OUTCOMES}
    | {f"view_link:{k}" for k in VIEW_LINK_OUTCOMES}
    # Home Assistant's sidebar hidden or shown again from PadSpan's toolbar
    # (0.38.153): used at all, and whether people come back to it.
    | {"ha_sidebar:hidden", "ha_sidebar:shown"}
    # 4K wall mode (0.38.159, ?kiosk=1 on the sidebar Atlas): the scale it
    # runs at (the screen against 1080p, bucketed) and whether Wake Lock held
    # the screen on. Never the screen's size itself.
    | {f"wall_ui:{b}" for b in ("1", "1.5", "2", "3", "4", "6")}
    | {"wall_awake:on", "wall_awake:off"}
    # Sized from the screen's resolution (auto) or from its size and the
    # viewing distance (room: Settings → Wall screens, or the screen's link).
    | {"wall_fit:auto", "wall_fit:room"}
)

# What the Overview tab actually drew (views/overview.js OVERVIEW_SHOWN, held
# equal by tests/test_telemetry.py), once per page load per word, live data
# only (2026-10-22: the classic screen changes with how far a house
# got through setup, which settings alone cannot tell):
#   house        the isometric house with its beacons (rooms drawn)
#   house_empty  the house frame, but no floor holds a room yet
#   floor_plan   no rooms drawn: the uploaded floor-plan picture instead
#   room_grid    no rooms drawn and no picture: the plain room grid
#   flat         the flat 2D map (overview_2d_mode)
#   atlas        "Overview shows the Atlas" (Pro), on its Map side
#   atlas_3d     the same, with this browser's Map / 3D switch on 3D (picked:
#                a screen that can't draw it shows the flat map, counted
#                by house3d_fallback:*)
#   basic        the screen was in Basic mode (sent with one of the above)
# Words only. The Map / 3D choice is read, never written.
OVERVIEW_SHOWN: tuple[str, ...] = ("house", "house_empty", "floor_plan", "room_grid",
                                   "flat", "atlas", "atlas_3d", "basic")
OVERVIEW_EVENTS: frozenset[str] = frozenset(f"overview_shown:{k}" for k in OVERVIEW_SHOWN)

# The switches whose ON/OFF is reported (booleans only, by name). Every name
# here must be READ by something outside the settings plumbing — a switch
# that drives nothing is not a feature, and reporting it would put a fiction
# in the data (tests/test_telemetry.py holds the list to that).
_FEATURE_FLAGS: tuple[str, ...] = (
    "quiet_mode", "lights_showcase", "lights_fit_rooms", "lights_hide_untouched",
    "lights_hide_device_codes", "lights_isolux", "lights_automorph_enabled",
    "lights_show_beacons",
    "lights_panel_enabled", "radio_map_enabled", "distortion_map_enabled",
    "occupancy_hybrid_enabled", "rssi_capture_enabled", "forensics_enabled",
    "mac_rotation_bridging", "beacon_auto_calibrate", "beacon_profiling_enabled",
    "espresense_mqtt_enabled", "tasmota_ble_enabled", "mqtt_publish_enabled", "bermuda_ignore",
    "phone_wizard_enabled", "overview_show_walls", "overview_show_outdoor",
    "overview_2d_mode", "overview_persistent_pins",
    "walk_to_identify_enabled",
    "adaptive_floor_detection", "apple_auto_classify", "aggressive_ble_reseed",
    "ha_entity_tracker_enabled", "ha_entity_area_enabled", "ha_entity_distance_enabled",
    "ha_entity_scanner_distance_enabled", "ha_entity_occupancy_enabled",
    "tags_room_events_enabled", "tags_nfc_identify_enabled", "tags_phone_autolink_enabled",
    "update_check_enabled", "onboarding_completed",
    "atlas_3d_enabled", "low_memory_mode",
    # Pro: the Atlas as Overview (0.38.137) — whether anyone wants it as the front door.
    "overview_atlas",
)
# 0.38.160's switches, all off by default: whether anyone turns them on.
# Sent ONLY when on (true), so a house that never touches them sends exactly
# the report it always did. The last three are on when non-zero or non-empty,
# reported as on only, never the number or what's in them.
# Setting -> its word in the report (a word of its own: what a setting holds,
# such as the director's entities, never goes, only that it is on).
_FEATURE_ON_ONLY: dict[str, str] = {
    "atlas_live_colours": "live_colours", "atlas_alert_pulse": "alert_pulse",
    "atlas_heatmap_enabled": "heatmap", "subzones_enabled": "subzones",
    "room_reason_attribute": "room_reason", "roomplan_import_enabled": "plan_scan_import",
    "wall_fully": "wall_fully", "hold_last_room_s": "room_hold",
    "wall_floor_cycle_s": "wall_floor_cycle", "atlas_3d_director": "director",
    "enhanced_security": "enhanced_security",
    # A backup AI Task is set (Settings → AI): yes only, never which one.
    "atlas_3d_ai_task_backup_entity": "ai_backup",
    # AI map-building research (experimental, 2026-11): on only; an untouched house sends what it always did.
    "ai_plans_enabled": "ai_plans",
    # Build from plans: advanced plan alignment (Claude, experimental, 2026-11): on only.
    "ai_plan_build_enabled": "ai_plan_build",
    # 0.38.178: several wall screens (Settings → Optimize for scale).
    "optimize_for_scale": "scale",
    "guest_tags_enabled": "guest_tags",
    # 0.38.165's positioning settings, all off by default.
    "positioning_pick_better": "pick_better", "positioning_unsure": "unsure",
    "positioning_sensor_fusion": "fusion",
    # 0.38.167: Calibration's Walk a room tab, off by default.
    "calibration_room_walk": "room_walk",
    # Themes (0.38.157): Light for everyone, Day on Pro; the stored switch,
    # so a lapsed Pro still says day_theme. theme_palette is in the ENUMS.
    "day_theme": "day_theme", "light_theme": "light_theme",
    # Settings → "Show lengths in feet and inches" (2026-11-12), off by default: on only.
    "units_feet": "units_feet",
}
# Small enumerations reported by value (each from a fixed vocabulary in
# ws_settings; anything unexpected is dropped by assert_shareable's length rule).
_FEATURE_ENUMS: tuple[str, ...] = ("data_mode", "cpu_mode", "lights_automorph_style", "theme_palette")
# Quiet mode's share of objects hidden (env.quiet_hidden, only when it is on).
QUIET_HIDDEN_BUCKETS: tuple[str, ...] = ("lt25", "25_50", "50_75", "gt75")


def _num_or(v: Any, default: float) -> float:
    return float(v) if isinstance(v, (int, float)) and not isinstance(v, bool) else default


# What each Overview screen is set to (2026-10-22: "show what each
# screen uses if they vary, ... doesn't eat up too much room"): per screen, a
# list of words from OVERVIEW_SET, ONLY for settings changed from
# settings_store's default, and no key at all for a screen on its defaults,
# so most houses send nothing. Never the numbers behind a word. The 3D list
# only while the 3D house is on. Switches the report already sends on their
# own (walls, outdoor, pins, Showcase, live colours, the director...) are not
# repeated. Which screen the Overview actually shows is counted from the
# screen itself (OVERVIEW_EVENTS).
OVERVIEW_SET: dict[str, tuple[str, ...]] = {
    # The floor gap, offset and focus are shared with the Atlas's floor
    # stack; listed once, here.
    "ov_house": ("gap_tight", "gap_wide", "gap_custom", "offset", "one_floor", "trails"),
    "ov_atlas": ("zoom_lt1", "zoom_1_2", "zoom_gt2", "classic", "no_emergency", "no_weather",
                 "weather_lt1", "weather_gt1"),
    "ov_3d": ("q_low", "q_high", "people", "tags", "library", "no_weather", "look_own", "look_studio"),
}


def _overview_features(settings: dict[str, Any]) -> dict[str, Any]:
    """features' per-screen lists (see OVERVIEW_SET); {} on defaults."""
    g = settings.get
    gap = _num_or(g("overview_iso_floor_gap"), 150)
    zoom = _num_or(g("overview_iso_zoom"), 1.0)
    house = []
    if gap != 150:
        house.append("gap_tight" if gap < 120 else "gap_wide" if gap > 180 else "gap_custom")
    if _num_or(g("overview_iso_horiz_gap"), 0) != 0:
        house.append("offset")
    if _num_or(g("overview_iso_focus"), 0) != 0:   # 0 = All floors
        house.append("one_floor")
    if g("overview_show_trails") is True:
        house.append("trails")
    atlas = []
    if zoom != 1.0:
        atlas.append("zoom_lt1" if zoom < 1.0 else "zoom_1_2" if zoom <= 2.0 else "zoom_gt2")
    if g("atlas_layout_v2") is False:
        atlas.append("classic")
    if g("atlas_emergency_button") is False:
        atlas.append("no_emergency")
    if g("atlas_weather_enabled") is False:
        atlas.append("no_weather")
    else:
        ws = _num_or(g("atlas_weather_strength"), 1.0)
        if ws != 1.0:
            atlas.append("weather_lt1" if ws < 1.0 else "weather_gt1")
    d3 = []
    if g("atlas_3d_enabled") is True:
        q = g("atlas_3d_quality")
        if q in ("low", "high"):
            d3.append("q_" + q)
        d3 += [w for w, k in (("people", "atlas_3d_people"), ("tags", "atlas_3d_tags"),
                              ("library", "atlas_3d_library")) if g(k) is True]
        if g("atlas_3d_weather") is False:
            d3.append("no_weather")
        if g("atlas_3d_look") == "own":
            d3.append("look_own")
        elif g("atlas_3d_look") == "studio":
            d3.append("look_studio")
    return {k: v for k, v in (("ov_house", house), ("ov_atlas", atlas), ("ov_3d", d3)) if v}


def _quiet_hidden(obj_list: list[Any], followed: Any) -> str | None:
    """Share of the snapshot's objects quiet mode hides (not labelled,
    identified or followed), bucketed; None with no objects."""
    objs = [o for o in obj_list if isinstance(o, dict)]
    if not objs:
        return None
    fol = {str(a).upper() for a in (followed or []) if a}
    hidden = sum(1 for o in objs if not o.get("user_label") and not o.get("identified")
                 and str(o.get("address") or o.get("key") or "").upper() not in fol)
    share = hidden / len(objs)
    return "lt25" if share < 0.25 else "25_50" if share < 0.5 else "50_75" if share < 0.75 else "gt75"

# Saved Showcase "look" presets (Mapping -> Lights) — the owner: "add presets and
# their components into the opt-in records" so popular combinations across
# installs can surface as a shared "Top 10" pulldown (see popular_presets.py
# and server/popular_presets.php). Every one of these fields is already the
# same trust tier as the live lights_automorph_style/lights_showcase_theme
# ENUMS reported in `features` above — a theme key, a style key, a few
# booleans, three small numbers — just captured as a considered, SAVED
# combination rather than momentary state. A preset's user-typed NAME is
# never included: it is the one field on a preset a person could put
# something personal into, and popularity only needs the values.
_PRESET_VALUE_KEYS: tuple[str, ...] = (
    "lights_showcase", "lights_showcase_theme", "lights_fit_rooms",
    "lights_isolux", "lights_show_beacons", "lights_hide_device_codes",
    "lights_hide_untouched", "lights_automorph_enabled",
    "lights_automorph_room_pct", "lights_automorph_hardness",
    "lights_automorph_style", "lights_automorph_subtlety",
)
# Even though up to 50 presets can be saved, only a courtesy sample is
# shared — plenty for popularity counting, nowhere near the whole list.
_PRESET_SHARE_CAP = 10

# Load and hardware — 2026-09-29: "Add load numbers and CPU info to
# opt-in for this type of decision in future", "need to watch the pi installs
# for max outs". perf_sampler.py measures; this is what of it may leave, and
# assert_shareable holds env.hw and health.perf to exactly these keys and
# words (_check_load_sections) — a closed list, like EVENTS, and nested under
# keys the receiver already allows (server/telemetry.php refuses any new
# top-level key, and a receiver not redeployed would drop every report).
HW_VALUES: dict[str, tuple[str, ...]] = {
    "ram": ("1g", "2g", "4g", "8g", "16g", "16g+", "unknown"),      # up to N GB
    "arch": ("x86_64", "x86", "aarch64", "armv7", "armv6", "other", "unknown"),
    "install": ("os", "supervised", "container", "core", "other", "unknown"),
    "board": ("rpi2", "rpi3", "rpi4", "rpi5", "rpi_other", "green", "yellow", "odroid", "tinker",
              "khadas", "vm", "generic_x86_64", "generic_aarch64", "other", "unknown"),
}
HW_MAX_CPUS = 64                     # "64" reads "64 or more"
# Report name → (perf_sampler metric, statistics). `_pc` values are whole
# percents, everything else two significant figures; `per_h` is how many per
# hour over the window. Memory available reports its LOW end — that is where
# a machine runs out. A metric with nothing measured is left out (a machine
# without /proc has no memory figures); `samples` says how much of the window
# the once-a-minute sampler covered, and `over` how many of those samples hit
# each limit (perf_sampler.OVER_*: load above 1 per CPU, HA above 90% of one
# core, under 10% memory available, loop lag over 1 s).
PERF_METRICS: dict[str, tuple[str, tuple[str, ...]]] = {
    "load_pc": ("load", ("p50", "p95", "max")),        # 1-min load per CPU
    "cpu_pc": ("cpu", ("p50", "p95", "max")),          # HA's process, of one core
    "cpu_all_pc": ("cpu", ("p50", "p95", "max")),      # ... of all cores
    "rss_mb": ("rss", ("p50", "max")),                 # HA's process
    "mem_avail_pc": ("mem", ("p50", "p05", "min")),    # host
    "swap_mb": ("swap", ("p50", "max")),               # host, used
    "lag_ms": ("lag", ("p50", "p95", "max")),          # event loop
    "snap_ms": ("snap", ("p50", "p95", "max", "per_h")),    # live snapshot build
    "cycle_ms": ("cycle", ("p50", "p95", "max", "per_h")),  # presence poll (incl. its snapshot fetch)
    # Issue #91: the per-object pipeline inside that poll, how many objects
    # it smoothed and how many it listed as background (unidentified, not
    # heard for a minute), and the Lost & Found records held — whether the
    # skip is doing its job, and that nothing grows without end.
    "loop_ms": ("loop", ("p50", "p95", "max")),
    # The snapshot build by phase: Bluetooth fetch, the walk over Home
    # Assistant's states and registries, the object list (history replay,
    # dedup), enrichment — and how many HA states there are. A third of the
    # installs reporting take 1.4-18 s per build, all with Bermuda installed.
    "snap_ble_ms": ("snap_ble", ("p50", "p95")),
    "snap_ha_ms": ("snap_ha", ("p50", "p95")),
    "snap_objects_ms": ("snap_objects", ("p50", "p95")),
    "snap_enrich_ms": ("snap_enrich", ("p50", "p95")),
    # 0.38.133: "ha" was 90%+ of every slow build in the reports (13-16 s on
    # two VMs with ~5k states, where 12k states elsewhere take 60 ms). Its CPU
    # time (it never awaits) says whether that is PadSpan's own work or the
    # process starved by other threads; its parts say which walk it is.
    "snap_ha_cpu_ms": ("snap_ha_cpu", ("p50", "p95")),
    "snap_ha_areas_ms": ("snap_ha_areas", ("p50", "p95")),
    "snap_ha_tags_ms": ("snap_ha_tags", ("p50", "p95")),
    "snap_ha_radios_ms": ("snap_ha_radios", ("p50", "p95")),
    # HA's registries (devices, entity rows) and the most devices sharing one
    # name: the receiver match was quadratic in that (4,000 → 1.5 s a build,
    # fixed 0.38.136); whether that shape is what slows the "ha" phase.
    "ha_devices_n": ("ha_devices", ("max",)),
    "ha_entities_n": ("ha_entities", ("max",)),
    "dev_same_name_max": ("dev_dup", ("max",)),
    # Per-receiver minimum signal (opt-in, 0.38.139): readings each poll kept
    # out of positioning, while any receiver has a floor set.
    "floor_dropped_n": ("floor_drop", ("p50", "max")),
    # How steady the house's own (identified) objects sit, per poll: how many,
    # the share with no room, receivers hearing each in the last 30 s, and room
    # changes per hour (all of them; per object = that over pos_objects_n).
    # The first measure in the report of whether positioning is any good.
    "pos_objects_n": ("pos_n", ("p50",)),
    "pos_unknown_pc": ("pos_unk", ("p50", "p95")),
    "pos_heard_n": ("pos_heard", ("p50",)),
    "pos_room_changes": ("pos_chg", ("per_h",)),
    # 0.38.165, each only while its setting is on: the share of the house's
    # objects marked unsure per poll (positioning_unsure), and polls where
    # motion sensors / usual moves changed a room (positioning_sensor_fusion).
    "pos_unsure_pc": ("pos_unsure", ("p50", "p95")),
    "fusion_changes": ("fusion_chg", ("per_h",)),
    # Occupancy estimates: Unknown phones counted, and confidence (0 low,
    # 1 medium, 2 high) and estimates per hour — phones through a wall.
    "occ_unknown_n": ("occ_unk", ("p50", "max")),
    "occ_conf": ("occ_conf", ("p50", "per_h")),
    # What the corrected wearable company numbers moved: addresses an estimate
    # counted because of them, addresses it no longer counted, and how many
    # people more or fewer the estimate says than the old numbers would. Only
    # from a house where it happened.
    "occ_wear_gain_n": ("occ_wear_gain", ("max", "per_h")),
    "occ_wear_lost_n": ("occ_wear_lost", ("max", "per_h")),
    "occ_wear_more_n": ("occ_wear_more", ("max",)),
    "occ_wear_fewer_n": ("occ_wear_fewer", ("max",)),
    "ha_states_n": ("states", ("max",)),
    # Bermuda troubleshooting (perf_sampler.padspan_sizes): its entities and
    # receiver devices, HA entities taken as tag candidates, and saved tags
    # that resolve to nothing (each one a walk over every state, per build).
    "bermuda_entities_n": ("bermuda_ents", ("max",)),
    "bermuda_devices_n": ("bermuda_rcv", ("max",)),
    "tag_candidates_n": ("tag_cands", ("max",)),
    "saved_tags_missing_n": ("saved_missing", ("max",)),
    # BLE/private-BLE objects merged into an iBeacon by their HA device in one
    # build — the match that never fired before 0.38.109; a large number here
    # would mean it merges more than it should.
    "merged_by_device_n": ("dev_merged", ("max",)),
    # The merges that go by a guess (same name, same maker data), what the guard
    # kept out of one (labelled, saved, pinned or calibrated), and how many BLE
    # objects a radio has given an address type. Read these before the merge
    # test itself changes. A house with no merges sends only the last.
    "merge_same_name_n": ("merge_name", ("max",)),
    "merge_same_data_n": ("merge_data", ("max",)),
    "merge_held_n": ("merge_held", ("max",)),
    "type_known_pc": ("type_known_pc", ("p50",)),
    "smoothed_n": ("smoothed", ("p50", "max")),
    "background_n": ("background", ("max",)),
    "lostfound_n": ("lostfound", ("max",)),
    # PadSpan's own size (perf_sampler.padspan_sizes). 2026-10-05: the
    # low-memory version forces a safe maximum object count, and picking it
    # takes how many objects an install holds, what one costs and how fast a
    # busy street adds them — beside the RAM and memory figures above.
    "objects_n": ("objects", ("p50", "max")),          # in the live snapshot
    "history_n": ("history", ("p50", "max")),          # object history entries
    "obj_kb": ("obj_kb", ("p50", "max")),              # one history entry, estimated
    "history_mb": ("history_mb", ("p50", "max")),      # the whole history, estimated
    "ble_addrs_n": ("ble_addrs", ("p50", "max")),      # Bluetooth cache addresses
    "ble_mb": ("ble_mb", ("p50", "max")),              # the cache, estimated
    "ble_new_per_h": ("ble_new", ("p50", "max")),      # addresses new to it, per hour
    "ble_old_pc": ("ble_old", ("p50", "max")),         # share not heard for 15 min
    "esp_addrs_n": ("esp_addrs", ("p50", "max")),      # ESPresense cache addresses
    # The live snapshot: held between builds (a build holds a second one
    # while it runs), its size as JSON — what every open panel is sent every
    # 5 s — and how many of those requests an hour.
    "snap_held_mb": ("snap_mb", ("p50", "max")),
    "snap_json_mb": ("snap_json_mb", ("p50", "max")),
    "snap_req_per_h": ("snap_req", ("p50", "max")),
    # Home Assistant while each kind of view is on a screen (perf_sampler.
    # VIEW_CLASSES, from the panels' heartbeat; "none": no panel on a screen):
    # whether the Atlas or the 3D house (Live Aboard, "sim") costs the HA
    # machine anything, which decides whether a low-memory machine can keep
    # them. `n`: minutes, to the nearest 10.
    **{f"{v}_{m}": (f"{s}@{v}", st) for v in ("atlas", "sim", "other", "none")
       for m, s, st in (("cpu_pc", "cpu", ("p95", "n")), ("lag_ms", "lag", ("p95",)), ("rss_mb", "rss", ("max",)))},
}
PERF_OVER: tuple[str, ...] = ("load", "cpu", "mem", "lag")
# health.runs (perf_sampler.RunLog): Home Assistant starts since the last
# report, how many followed an unclean end (killed — out of memory, power),
# and the worst of each RUN_PEAKS value across all those runs. Kept on disk,
# because a run that dies takes the in-memory window with it.
RUNS_KEYS: tuple[str, ...] = ("starts", "unclean", "rss_mb", "mem_avail_pc", "swap_mb",
                              "objects_n", "history_n", "ble_addrs_n")

# What a report may contain at the top level — anything else is a bug.
_TOP_KEYS: frozenset[str] = frozenset({
    "schema", "install_id", "day", "version", "edition", "tier", "ha_version",
    "python", "env", "features", "usage", "health", "errors", "presets",
    "country", "language", "licence_group",
})
# One licence's homes, together: a code made from the key, never the key.
_GROUP_RE = re.compile(r"[0-9a-f]{16}")


def licence_group(key: str) -> str | None:
    """The licence's group code for the report (None without a key)."""
    k = str(key or "").strip().upper()
    if not k:
        return None
    import hashlib  # noqa: PLC0415
    return hashlib.sha256(("padspan-licence-group|" + k).encode()).hexdigest()[:16]
# HA's configured country (ISO 3166 alpha-2) and language (a short BCP 47
# tag: "en", "en-GB", "zh-Hant", "es-419"). Anything else is left out.
_COUNTRY_RE = re.compile(r"[A-Z]{2}")
_LANGUAGE_RE = re.compile(r"[a-z]{2,3}(?:-[A-Za-z0-9]{2,4})?")

# Identifier shapes that must never appear in any value.
_MAC_RE = re.compile(r"\b[0-9A-Fa-f]{2}(?:[:\-.][0-9A-Fa-f]{2}){5}\b|\b[0-9A-Fa-f]{12}\b")   # 48:87:…, 48-87-…, 48.87.…, 48872D9DBC88
_UUID_RE = re.compile(r"\b[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}\b")
_HEX32_RE = re.compile(r"\b[0-9A-Fa-f]{32}\b")
_KEY_RE = re.compile(r"\bPSPAN-[A-Z0-9-]{8,}\b", re.I)
_IPV4_RE = re.compile(r"\b\d{1,3}(?:\.\d{1,3}){3}\b")
_IPV6_RE = re.compile(r"\b(?:[0-9A-Fa-f]{1,4}:){2,7}[0-9A-Fa-f]{1,4}\b")
_ENTITY_RE = re.compile(r"\b[a-z_]{2,}\.[a-z0-9_]{2,}\b")          # light.kitchen_valance, sensor.x
# Contact details belong to "Become a tester" (tester.py), never to this report.
_EMAIL_RE = re.compile(r"[A-Za-z0-9._%+'-]+@[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)*\.[A-Za-z]{2,}")


# ── counting ─────────────────────────────────────────────────────────────────

def enabled(hass: HomeAssistant) -> bool:
    st = hass.data.get(DOMAIN, {}).get(DATA_SETTINGS)
    return bool((st.data if st else {}).get("telemetry_enabled", False))


def event_allowed(name: str) -> bool:
    return (name in EVENTS or name in TAB_EVENTS or name in UI_ERRORS or ui_error_at_allowed(name) or name in OFFER_EVENTS
            or name in WEATHER_EVENTS or name in HOUSE3D_EVENTS or name in PHOTO_EVENTS or name in STAIR_EVENTS
            or name in PLAN_AI_EVENTS or name in AI_USAGE_EVENTS or name in PLAN_BUILD_EVENTS
            or name in CLIENT_EVENTS or name in SCREEN_EVENTS or name in OVERVIEW_EVENTS or name in TIP_EVENTS
            or name in CAL_RESULTS_EVENTS or name in SETUP_EVENTS or name in OPEN_EDGE_EVENTS or name in PLANS_TOOL_EVENTS
            or name in AI_WIZARD_EVENTS or name in SCALE_NUDGE_EVENTS or name in PLAN_UPLOAD_EVENTS
            or name in WIZARD_DRAW_EVENTS or name in ROUGH_PLAN_EVENTS or name in PLAN_CARRY_EVENTS or name in FIT_SUGGEST_EVENTS)


def bump(hass: HomeAssistant, event: str, n: int = 1) -> bool:
    """Count one occurrence. Silently ignored when off or unknown.

    Cheap enough to call from any write path: a dict increment when on, one
    lookup when off. Returns whether it counted.
    """
    if not event_allowed(event) or not enabled(hass):
        return False
    dom = hass.data.setdefault(DOMAIN, {})
    counters: dict[str, int] = dom.setdefault(_DATA_COUNTERS, {})
    counters[event] = int(counters.get(event, 0)) + max(1, int(n))
    _persist_counters(hass)
    return True


_DATA_SCREENS = "telemetry_screens"
_DATA_SCREENS_TAKEN = "telemetry_screens_taken"   # the last window's, until its report is sent
# Each screen's own words (2026-10-22: "first 5 screens in a house"):
# what its Overview drew, its kind of panel window, its resolution and kind
# of device. Kept per screen id for the window; the report gets the lists
# only (env.screens), never an id, and only from a house with two or more.
_DATA_SCREEN_WORDS = "telemetry_screen_words"
_DATA_SCREEN_WORDS_TAKEN = "telemetry_screen_words_taken"
SCREENS_LISTED = 5
_SCREEN_WORDS_MAX = 12


def screen_word(event: str) -> str | None:
    """The word an event gives its screen's list, or None."""
    if event in OVERVIEW_EVENTS:
        return event.split(":", 1)[1]
    if event in CLIENT_EVENTS and event.startswith(("client_screen:res_", "client_screen:kind_")):
        return event.split(":", 1)[1]
    if event in SCREEN_EVENTS and event.startswith("wall_screen:"):
        _, panel, kind = event.split(":")
        return f"{'atlaspage' if panel == 'atlas' else panel}_{kind}"
    return None


SCREEN_WORDS: frozenset[str] = frozenset(
    w for w in (screen_word(e) for e in OVERVIEW_EVENTS | CLIENT_EVENTS | SCREEN_EVENTS) if w)


def note_screen_word(hass: HomeAssistant, screen: str, event: str) -> None:
    """Add `event`'s word to this screen's list (the first five screens)."""
    w = screen_word(event)
    if not w or not isinstance(screen, str) or not re.fullmatch(r"[0-9a-f]{16}", screen):
        return
    lists: dict[str, list[str]] = hass.data.setdefault(DOMAIN, {}).setdefault(_DATA_SCREEN_WORDS, {})
    if screen not in lists:
        if len(lists) >= SCREENS_LISTED:
            return
        lists[screen] = []
    if w not in lists[screen] and len(lists[screen]) < _SCREEN_WORDS_MAX:
        lists[screen].append(w)


def _screens_listed(lists: Any) -> list[list[str]] | None:
    """env.screens: each screen's words, sorted; None under two screens."""
    if not isinstance(lists, dict) or len(lists) < 2:
        return None
    return sorted(sorted(v) for v in lists.values())


def note_screen(hass: HomeAssistant, screen: str, event: str = "client_screen_seen") -> bool:
    """Whether this screen (a browser's random id) is new for `event` in
    this report's window: client_screen_seen and each client_screen:* word
    count a screen once per report. Only the counts leave the box; the ids
    are forgotten with the window."""
    if not isinstance(screen, str) or not re.fullmatch(r"[0-9a-f]{16}", screen):
        return False
    seen: set[str] = hass.data.setdefault(DOMAIN, {}).setdefault(_DATA_SCREENS, set())
    key = f"{event}|{screen}"
    if key in seen or len(seen) >= 2000:
        return False
    seen.add(key)
    return True


# The window's counters on disk too (0.38.177): they lived only in memory, so
# a restart before the day's report took them with it. A house restarted four
# times on the day its calibration points went to zero, and its report could
# not say whether anyone had cleared them. Saved two minutes after a count;
# taken and given back like the in-memory ones; read back once per start.
COUNTERS_STORE_KEY = "padspan_ha.telemetry_counters"
_DATA_COUNTERS_STORE = "_telemetry_counters_store"
COUNTERS_SAVE_DELAY_S = 120


def _counters_store(hass: HomeAssistant) -> Any:
    dom = hass.data.setdefault(DOMAIN, {})
    st = dom.get(_DATA_COUNTERS_STORE)
    if st is None:
        from homeassistant.helpers.storage import Store  # noqa: PLC0415
        st = dom[_DATA_COUNTERS_STORE] = Store(hass, 1, COUNTERS_STORE_KEY)
    return st


_DATA_COUNTERS_SAVE_DUE = "_telemetry_counters_save_due"


def _persist_counters(hass: HomeAssistant, now: bool = False) -> None:
    """Save the window now, or once within COUNTERS_SAVE_DELAY_S of a count.
    Not Store.async_delay_save: that restarts its wait on every call, and on
    a house counting every few seconds (irk_unresolved_rpa) it never saved."""
    # Only ever on Home Assistant's event loop. bump() can be called from code
    # running in a worker thread, and there async_call_later and
    # async_create_task are refused: the save was created and never run
    # (a real house, 2026-10-29: "calls hass.async_create_task from a thread
    # other than the event loop", telemetry.py _due, since 0.38.177).
    tid = getattr(hass, "loop_thread_id", None)
    if isinstance(tid, int) and threading.get_ident() != tid:
        hass.loop.call_soon_threadsafe(_persist_counters, hass, now)
        return
    try:
        dom = hass.data.setdefault(DOMAIN, {})
        st = _counters_store(hass)

        def _snap() -> dict:
            return {"counters": dict(dom.get(_DATA_COUNTERS) or {})}
        if now:
            hass.async_create_task(st.async_save(_snap()))
            return
        if dom.get(_DATA_COUNTERS_SAVE_DUE):
            return
        from homeassistant.helpers.event import async_call_later  # noqa: PLC0415

        # A callback: without it Home Assistant runs a plain function given
        # to async_call_later in a worker thread, where creating the task is refused.
        @callback
        def _due(_now: Any = None) -> None:
            dom[_DATA_COUNTERS_SAVE_DUE] = False
            hass.async_create_task(st.async_save(_snap()))
        dom[_DATA_COUNTERS_SAVE_DUE] = True
        async_call_later(hass, COUNTERS_SAVE_DELAY_S, _due)
    except Exception as err:  # noqa: BLE001 — counting must never fail anything
        _LOGGER.debug("Telemetry counters not saved: %s", err)


def merge_saved_counters(counters: dict[str, int], saved: Any) -> dict[str, int]:
    """The in-memory window plus what the last run had saved, names still on
    the closed list only (a name dropped from it since is not sent)."""
    out = dict(counters)
    raw = saved.get("counters") if isinstance(saved, dict) else None
    for k, v in (raw if isinstance(raw, dict) else {}).items():
        if isinstance(k, str) and event_allowed(k) and isinstance(v, int) and not isinstance(v, bool) and v > 0:
            out[k] = int(out.get(k, 0)) + v
    return out


async def async_restore_counters(hass: HomeAssistant) -> None:
    dom = hass.data.setdefault(DOMAIN, {})
    if dom.get("_telemetry_counters_restored"):
        return
    dom["_telemetry_counters_restored"] = True
    try:
        saved = await _counters_store(hass).async_load()
    except Exception as err:  # noqa: BLE001
        _LOGGER.debug("Telemetry counters not read back: %s", err)
        return
    if enabled(hass):
        dom[_DATA_COUNTERS] = merge_saved_counters(dom.get(_DATA_COUNTERS) or {}, saved)
    _persist_counters(hass, now=True)


def _take_counters(hass: HomeAssistant) -> dict[str, int]:
    """The counters since the last report — and reset them."""
    dom = hass.data.setdefault(DOMAIN, {})
    out = dict(dom.get(_DATA_COUNTERS) or {})
    dom[_DATA_COUNTERS] = {}
    dom[_DATA_SCREENS_TAKEN] = dom.get(_DATA_SCREENS) or set()
    dom[_DATA_SCREENS] = set()
    dom[_DATA_SCREEN_WORDS_TAKEN] = dom.get(_DATA_SCREEN_WORDS) or {}
    dom[_DATA_SCREEN_WORDS] = {}
    _persist_counters(hass, now=True)
    return out


def _take_windows(hass: HomeAssistant) -> tuple[dict[str, int], dict[str, int], set[str], Any]:
    """The usage counters, WARNING+ log counts, keys that resolved and the
    load window since the last report — and reset them."""
    usage = _take_counters(hass)
    errors: dict[str, int] = {}
    ids: set[str] = set()
    perf = None
    try:
        from .ws_common import _log_handler  # noqa: PLC0415
        if _log_handler is not None:
            errors = _log_handler.take_counts()
    except Exception:
        pass
    try:
        from .private_ble_resolver import _resolvers  # noqa: PLC0415
        _r = _resolvers.get(id(hass))
        if _r is not None:
            ids = _r.take_resolved_ids()
    except Exception:
        pass
    try:
        from . import perf_sampler  # noqa: PLC0415
        perf = perf_sampler.take_window(hass)
    except Exception:
        pass
    return usage, errors, ids, perf


def _give_back_windows(hass: HomeAssistant, taken: tuple[dict[str, int], dict[str, int], set[str], Any]) -> None:
    """A send that failed: what it took goes with the next report, on top of
    whatever was counted meanwhile."""
    usage, errors, ids, perf = taken
    try:
        from . import perf_sampler  # noqa: PLC0415
        perf_sampler.give_back_window(hass, perf)
    except Exception:
        pass
    counters = hass.data.setdefault(DOMAIN, {}).setdefault(_DATA_COUNTERS, {})
    for k, v in usage.items():
        counters[k] = int(counters.get(k, 0)) + int(v)
    _persist_counters(hass, now=True)
    # The screens it counted go back with their counts, so they aren't counted again.
    dom = hass.data[DOMAIN]
    dom.setdefault(_DATA_SCREENS, set()).update(dom.pop(_DATA_SCREENS_TAKEN, None) or set())
    # The screens' lists too: the taken ones first, then any new, five at most.
    merged = dict(dom.pop(_DATA_SCREEN_WORDS_TAKEN, None) or {})
    for sid, words in (dom.get(_DATA_SCREEN_WORDS) or {}).items():
        if sid in merged:
            merged[sid] = (merged[sid] + [w for w in words if w not in merged[sid]])[:_SCREEN_WORDS_MAX]
        elif len(merged) < SCREENS_LISTED:
            merged[sid] = words
    dom[_DATA_SCREEN_WORDS] = merged
    try:
        from .ws_common import _log_handler  # noqa: PLC0415
        if _log_handler is not None:
            for k, v in errors.items():
                _log_handler.counts[k] = _log_handler.counts.get(k, 0) + v
    except Exception:
        pass
    try:
        from .private_ble_resolver import _resolvers  # noqa: PLC0415
        _r = _resolvers.get(id(hass))
        if _r is not None:
            _r._resolved_ids_window |= ids
    except Exception:
        pass


# ── the report ───────────────────────────────────────────────────────────────

def _uptime_bucket(seconds: float) -> str:
    if seconds < 3600:
        return "<1h"
    if seconds < 86400:
        return "<1d"
    if seconds < 7 * 86400:
        return "1-7d"
    return ">7d"


def _len(x: Any) -> int:
    try:
        return len(x)
    except Exception:
        return 0


def _sig2(v: Any) -> int | float | None:
    """Two significant figures: 4123 → 4100, 3.456 → 3.5, 0.0123 → 0.012."""
    try:
        v = float(v)
    except (TypeError, ValueError):
        return None
    if not math.isfinite(v):
        return None
    if v <= 0:
        return 0
    r = round(v, 1 - math.floor(math.log10(v)))
    return int(r) if r >= 10 else r


def _hw_payload(hass: HomeAssistant) -> dict[str, Any]:
    """env.hw: the hardware class, each word from HW_VALUES."""
    from . import perf_sampler  # noqa: PLC0415
    raw = perf_sampler.hw_class(hass)
    cpus = raw.get("cpus")
    hw: dict[str, Any] = {"cpus": min(cpus, HW_MAX_CPUS) if isinstance(cpus, int) and cpus > 0 else 0}
    for k, allowed in HW_VALUES.items():
        v = raw.get(k)
        hw[k] = v if v in allowed else "unknown"
    return hw


# How Home Assistant keeps a placed temperature or humidity readout fresh.
# The Atlas and Live Aboard show a reading only while it is under an hour old
# (lights_map.js gatherLights: last_reported, else last_updated). HA moves
# last_changed only when the number changes, last_updated also on an attribute
# change, last_reported (2024.3+) on every report, so a steady room goes stale
# by the first two while its sensor keeps reporting. Counted by each clock
# (under an hour), how many states carry last_reported at all, and how old
# the newest report is: whether 0.38.126's switch to last_reported holds in
# real houses, and how often sensors report. Counts only.
TEMP_AGES: tuple[str, ...] = ("lt5m", "5_15m", "15_60m", "1_6h", "6h_up")


def _temp_fresh_note(st: Any, now: Any, tf: dict[str, Any]) -> None:
    try:
        float(st.state)
    except (TypeError, ValueError, AttributeError):
        return
    try:
        ages = {}
        for key, attr in (("changed", "last_changed"), ("updated", "last_updated"), ("reported", "last_reported")):
            t = getattr(st, attr, None)
            ages[key] = (now - t).total_seconds() if isinstance(t, datetime) else None
    except Exception:
        return
    tf["n"] += 1
    for key, a in ages.items():
        if a is not None and 0 <= a < 3600:
            tf[key] += 1
    if ages["reported"] is not None:
        tf["has_lr"] += 1
    a = ages["reported"] if ages["reported"] is not None else ages["updated"]
    if a is not None:
        b = "lt5m" if a < 300 else "5_15m" if a < 900 else "15_60m" if a < 3600 else "1_6h" if a < 21600 else "6h_up"
        tf["age"][b] = tf["age"].get(b, 0) + 1


def _history_days(hass: HomeAssistant) -> float | None:
    try:
        from .ws_common import _object_history_ttl_s  # noqa: PLC0415
        return round(_object_history_ttl_s(hass) / 86400.0, 2)
    except Exception:
        return None


def _ble_max_age_s(settings: dict[str, Any]) -> int:
    """As the live snapshot reads it (snapshot_builder): 60 s to 4 h, default 4 h."""
    try:
        v = settings.get("ble_max_age_s")
        return 14400 if v is None else max(60, min(14400, int(v)))
    except (TypeError, ValueError):
        return 14400


def _to_hour(n: int) -> int:
    """To the nearest 60 once-a-minute samples (an hour), halves up."""
    return (int(n) + 30) // 60 * 60


def _perf_payload(w: Any, cpus: int, now: float | None = None) -> dict[str, Any]:
    """health.perf from a perf_sampler.PerfWindow, shaped by PERF_METRICS.

    `samples` is to the nearest hour (60 samples): to the minute, a window
    shorter than a day would say when Home Assistant last restarted. So is
    each `over` count of 30 or more — a machine over a limit the whole time
    counts every sample — while a smaller one says nothing of the uptime
    and stays exact; with no sample count to stand beside (under half an
    hour) there are none."""
    out: dict[str, Any] = {"samples": _to_hour(w.samples)}
    hours = w.hours(now)
    for name, (metric, stats) in PERF_METRICS.items():
        h = w.hists.get(metric)
        if h is None or not h.n:
            continue
        scale = 1.0
        if name == "cpu_all_pc":
            if not cpus:
                continue
            scale = 1.0 / cpus
        d: dict[str, Any] = {}
        for s in stats:
            if s == "per_h":
                if hours > 0:
                    d[s] = _sig2(h.n / hours)
                continue
            if s == "n":
                d[s] = (h.n + 5) // 10 * 10
                continue
            v = h.hi if s == "max" else h.lo if s == "min" else h.quantile(int(s[1:]) / 100)
            if v is None:
                continue
            v *= scale
            d[s] = int(round(v)) if name.endswith("_pc") else _sig2(v)
        out[name] = d
    if out["samples"]:
        over = {k: int(w.over.get(k, 0)) for k in PERF_OVER}
        out["over"] = {k: c if c < 30 else _to_hour(c) for k, c in over.items()}
    return out


def _runs_payload(raw: dict[str, Any]) -> dict[str, Any]:
    """health.runs from a RunLog's counts: whole counts, whole percents,
    everything else two significant figures; a peak never measured is left
    out."""
    out: dict[str, Any] = {}
    for k in RUNS_KEYS:
        v = raw.get(k)
        if isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v) or v < 0:
            continue
        out[k] = int(v) if k in ("starts", "unclean") else int(round(v)) if k.endswith("_pc") else _sig2(v)
    return out


# bluetooth_live.receiver_type's words, and the two MQTT feeds, told by source.
RECEIVER_TYPES: tuple[str, ...] = ("esphome", "shelly", "ha_adapter", "ruuvi", "other")


def _object_detail(obj_list: list) -> dict[str, int]:
    """How much the house's objects say about themselves: of `total` Bluetooth
    objects, how many have a real name, a maker, and a type. `maker_*` splits
    the makers by how they are known (one level deep, so stats.php adds them
    up), "guess" being the built-in address list with no receiver's word that
    the address is fixed. `name_*` says where each best name came from, `what`
    how many have a type read from the broadcast, `addr_*` how many a radio says
    are fixed or rotating. Counts only, never a name, a maker or an address."""
    out = {"total": 0, "named": 0, "maker": 0, "type": 0}
    for o in obj_list:
        if not isinstance(o, dict) or o.get("kind") not in ("ble", "ibeacon", "private_ble"):
            continue
        out["total"] += 1
        # A label, or what a plain device broadcasts: an iBeacon's `name` is mostly
        # PadSpan's own "iBeacon xxxxxxxx".
        name = str(o.get("user_label") or (o.get("name") if o.get("kind") == "ble" else "") or "").strip()
        if name and name.upper() != str(o.get("address") or "").upper():
            out["named"] += 1
        how = o.get("maker_source") if o.get("company_name") else "guess" if o.get("maker_guess") else None
        if how:
            out["maker"] += 1
            out[f"maker_{how}"] = out.get(f"maker_{how}", 0) + 1
        if o.get("service_owner") and not o.get("company_name"):  # not a maker, so not in `maker`
            out["maker_service_uuid"] = out.get("maker_service_uuid", 0) + 1
        if o.get("device_type") or o.get("auto_class"):
            out["type"] += 1
        source = o.get("name_source") or ("maker" if o.get("best_name") else None)  # left off when it's maker
        if source:
            k = f"name_{source}"
            out[k] = out.get(k, 0) + 1
        if o.get("what_it_is"):
            out["what"] = out.get("what", 0) + 1
        if o.get("address_kind"):
            k = f"addr_{o['address_kind']}"
            out[k] = out.get(k, 0) + 1
    return out


def _padspan_device_ids(hass: HomeAssistant) -> dict[str, int]:
    """PadSpan's devices in HA's registry, and the ids each has built up (0.38.105
    and older added one each time an object's id changed). Counts only. Near
    zero on any install that never ran those versions."""
    from homeassistant.helpers import device_registry as _dr  # noqa: PLC0415
    from .util import ha_devices as _ha_devices  # noqa: PLC0415
    counts: list[int] = []
    names: dict[str, int] = {}
    for dev in _ha_devices(_dr.async_get(hass)):
        ids = [i for i in dev.identifiers if i and i[0] == DOMAIN]
        if not ids:
            continue
        counts.append(len(ids))
        name = str(dev.name_by_user or dev.name or "")
        names[name] = names.get(name, 0) + 1
    if not counts:
        return {}
    return {"devices": len(counts), "ids": sum(counts), "most": max(counts),
            "over_10": sum(1 for n in counts if n > 10),
            "same_name": sum(n for name, n in names.items() if name and n > 1)}


def _positioning_now(coord) -> dict[str, int]:
    """What the engine did with the house's own objects this poll.

    Read from the coordinator's poll result — the same dict the live
    snapshot overlays onto objects — because the cached snapshot never
    carries `outside` or the solver's counts: both are attached per request
    inside ws_live_snapshot, so reading them off the cache reported 0 on
    every install, forever. Gated on is_identified_object, the engine's own
    test, so the count is of the house and not of the neighbourhood.
    """
    out = {"positioned": 0, "outside": 0}
    data = getattr(coord, "data", None)
    ident = getattr(coord, "is_identified_object", None)
    if not isinstance(data, dict) or not callable(ident):
        return out
    for key, v in data.items():
        if not isinstance(v, dict):
            continue
        try:
            if not ident(key):
                continue
        except Exception:
            continue
        if v.get("x_m") is not None and v.get("y_m") is not None:
            out["positioned"] += 1
        if v.get("outside"):
            out["outside"] += 1
    return out


def build_payload(hass: HomeAssistant, *, consume: bool = False) -> dict[str, Any]:
    """The report. `consume` resets the usage counters (a real send does;
    the Preview does not, so previewing never loses a day's counts)."""
    from .licence import edition as _edition, hass_tier as _tier  # noqa: PLC0415
    dom = hass.data.get(DOMAIN, {})
    st = dom.get(DATA_SETTINGS)
    settings: dict[str, Any] = (st.data if st else {}) or {}

    try:
        from homeassistant.const import __version__ as _HA_VERSION  # noqa: PLC0415
        ha_version = str(_HA_VERSION)
    except Exception:
        ha_version = ""

    # Environment — sizes of things, from the stores that own them.
    fab = getattr(dom.get(DATA_FABRIC), "data", None) or {}
    floors = fab.get("floors") if isinstance(fab.get("floors"), dict) else {}
    rooms = sum(_len(f.get("rooms") or {}) for f in floors.values() if isinstance(f, dict))
    mdl = getattr(dom.get(DATA_MODEL), "data", None) or {}
    maps = getattr(dom.get(DATA_MAPS), "data", None) or {}
    _mw_moved, _mw_left = (
        n if isinstance(n, int) else 0
        for n in (getattr(dom.get(DATA_MAPS), "legacy_moved", 0), getattr(dom.get(DATA_MAPS), "legacy_left", 0)))
    snap_entry = dom.get("snapshot_cache")
    snap = snap_entry[1] if isinstance(snap_entry, tuple) and len(snap_entry) == 2 and isinstance(snap_entry[1], dict) else {}
    ble = snap.get("ble") if isinstance(snap.get("ble"), dict) else {}
    objects = snap.get("objects") if isinstance(snap.get("objects"), dict) else {}
    summary = objects.get("summary") if isinstance(objects.get("summary"), dict) else {}
    resolver = summary.get("resolver") if isinstance(summary.get("resolver"), dict) else {}
    diag = ble.get("diag") if isinstance(ble.get("diag"), dict) else {}
    obj_list = objects.get("list") if isinstance(objects.get("list"), list) else []

    integrations = {}
    for name in ("private_ble_device", "bermuda", "esphome", "mqtt", "bluetooth", "mobile_app", "ibeacon", "espresense"):
        try:
            integrations[name] = _len(hass.config_entries.async_entries(name))
        except Exception:
            integrations[name] = 0

    radios = [r for r in (ble.get("radios") or []) if isinstance(r, dict)]
    scanner_kinds = {
        # "ip_known" = the scanner exposes diagnostic sensors PadSpan reads
        # (an ESPHome proxy set up with the config library); "espresense" by
        # source; the rest are proxies without diagnostics or local adapters.
        "ip_known": sum(1 for r in radios if r.get("ip")),
        "espresense": sum(1 for r in radios if str(r.get("source") or "").lower().startswith("espresense")),
    }
    scanner_kinds["tasmota"] = sum(1 for r in radios if not r.get("ip")
                                   and str(r.get("source") or "").lower().startswith("tasmota_"))
    scanner_kinds["other"] = max(0, len(radios) - scanner_kinds["ip_known"] - scanner_kinds["espresense"]
                                 - scanner_kinds["tasmota"])
    # What each receiver is (bluetooth_live.receiver_type): the split "other"
    # above can't give, which says how many homes' receivers pass on an address
    # type or a full broadcast. Fixed words and counts, zeros left out.
    scanner_types: dict[str, int] = {}
    for r in radios:
        src = str(r.get("source") or "").lower()
        k = ("espresense" if src.startswith("espresense") else "tasmota" if src.startswith("tasmota_")
             else r.get("receiver_type") if r.get("receiver_type") in RECEIVER_TYPES else "other")
        scanner_types[k] = scanner_types.get(k, 0) + 1
    # Where each receiver's one name came from (ws_common.radio_display,
    # 0.38.132): the user's HA name, HA's device name, the scanner's own, its
    # area, or nothing but its source. Fixed words and counts, zeros left out.
    from .ws_common import NAME_FROM  # noqa: PLC0415
    scanner_names: dict[str, int] = {}
    for r in radios:
        k = r.get("name_from")
        if k in NAME_FROM:
            scanner_names[k] = scanner_names.get(k, 0) + 1
    scanner_state = {
        "lost": sum(1 for r in radios if r.get("lost")),
        "disabled": sum(1 for r in radios if r.get("disabled")),
        "excluded": _len(settings.get("excluded_scanners") or []),
    }
    # BLE scan mode. HA 2026.6 changed the default for every proxy from active
    # to auto, overriding what each device's own firmware config asked for, and
    # most people will not have noticed. Counting what installs actually run is
    # the only way to see whether the fleet at large is now scanning passively.
    #
    # BOTH are reported because they answer different questions. `requested` is
    # the CHOICE — the ESPHome config-entry option, or a deliberate pin. `mode`
    # is the momentary state, and an AUTO scanner reads "passive" almost all of
    # the time because it is only promoted to active in short windows. Reading
    # one for the other is the mistake this whole feature came out of.
    #
    # Counts only. A scan mode is one of four fixed words and says nothing about
    # the device, the house, or the person.
    _MODES = ("active", "passive", "auto")

    def _mode_counts(field: str) -> dict[str, int]:
        out = {m: 0 for m in _MODES}
        out["unknown"] = 0
        for r in radios:
            v = r.get(field)
            v = str(v).lower() if v is not None else ""
            out[v if v in out and v != "unknown" else "unknown"] += 1
        return out

    scan_modes = _mode_counts("scan_mode")
    scan_modes_requested = _mode_counts("requested_scan_mode")
    by_kind: dict[str, int] = {}
    for o in obj_list:
        if isinstance(o, dict):
            k = str(o.get("kind") or "?")[:16]
            by_kind[k] = by_kind.get(k, 0) + 1
    cal = getattr(dom.get("calibration"), "data", None) or {}
    cal_points = cal.get("points") if isinstance(cal.get("points"), list) else []
    # Beacon auto-calibration marks its points in the LABEL (`[auto] …`,
    # presence_coordinator / calibration_store.prune_auto_points); there has
    # never been a `source` key, and reading one counted zero on every install.
    cal_auto = sum(1 for p in cal_points if isinstance(p, dict) and str(p.get("label") or "").startswith("[auto]"))
    # Points that never got a floor. Since #54 such a point is no longer
    # assumed to be on the ground — it stays 2D — which fixed the phantom
    # elevation but left the point contributing nothing to the storey it was
    # actually captured on. That is invisible from the panel: the point is
    # there, it looks captured, and the floor quietly has fewer than it shows.
    # `async_backfill_floors` repairs them; this is how an install that needs
    # repairing says so without anyone having to notice first.
    cal_no_floor = sum(1 for p in cal_points if isinstance(p, dict)
                       and not str(p.get("floor_id") or "").strip())

    # Is the building described, or is it defaults wearing a building's shape?
    # A floor with no explicit floor_to_floor_m or base_elevation_m falls back
    # to DEFAULT_FLOOR_TO_FLOOR_M, and a scanner with no z_m has no mounting
    # height — either one leaves cross-floor positioning with nothing to
    # separate storeys by. PadSpan is developed against one house, where both
    # are always set, so this is the case the developer cannot see at all.
    mdl_floors = [f for f in (mdl.get("floors") or []) if isinstance(f, dict)]

    def _explicit(f: dict[str, Any]) -> bool:
        for k in ("floor_to_floor_m", "base_elevation_m"):
            v = f.get(k)
            if isinstance(v, (int, float)) and not isinstance(v, bool):
                return True
        return False

    floors_with_height = sum(1 for f in mdl_floors if _explicit(f))
    # Rooms given their own height (room_meta height_m, Live Aboard's tall
    # rooms): whether anyone uses it. A count, never which rooms.
    _rm = mdl.get("room_meta") if isinstance(mdl.get("room_meta"), dict) else {}
    rooms_with_height = sum(1 for v in _rm.values() if isinstance(v, dict) and isinstance(v.get("height_m"), (int, float))
                            and not isinstance(v.get("height_m"), bool))
    _z_vals = [float(v["z_m"]) for v in (fab.get("scanner_positions_m") or {}).values()
               if isinstance(v, dict) and isinstance(v.get("z_m"), (int, float))
               and not isinstance(v.get("z_m"), bool)]
    scanner_z_distinct = len({round(z, 2) for z in _z_vals})
    coord = dom.get("presence_coordinator")
    _pos = _positioning_now(coord)
    # Registered keys that resolved at least one address in the window — the
    # answer to "does the IRK path work anywhere". Read without resetting on
    # a preview; a send resets it with the other windows.
    resolving = 0
    _identity = {"total": 0, "resolving": 0, "silent": 0, "by_source": {}, "has_any": False}
    try:
        from .private_ble_resolver import _resolvers  # noqa: PLC0415
        _res = _resolvers.get(id(hass))
        if _res is not None:
            _ids = _res.take_resolved_ids() if consume else set(_res._resolved_ids_window)
            resolving = len(_ids)
            _identity = _res.identity_breakdown(_ids)
    except Exception:
        resolving = 0

    # Read-only self-check: maps this install cannot draw.
    #
    # It used to count DISAGREEMENT — the gap between a map's metric record
    # and its stack — under four headings. There is one placement now, so all
    # four read zero on every install and are gone rather than reported as a
    # clean bill of health nobody earned. What is left is a record that is not
    # a placement, a map with no placement at all, and a house with no metre
    # scale (which draws nothing, silently, and had no counter at all).
    _geometry_faults = 0
    _fault_unreadable = 0
    _fault_unplaced = 0
    _no_world_frame = False
    _has_anchor = False
    try:
        from . import fabric_truth as _ft  # noqa: PLC0415
        _mdl_store = dom.get(DATA_MODEL)
        _maps_list = maps.get("maps") or []
        if _mdl_store is not None:
            _faults = _ft.map_geometry_faults(_maps_list, _mdl_store)
            _geometry_faults = len(_faults)
            for _f in _faults:
                # The terms the gate fired on, as the gate named them.
                _terms = _f.get("terms") or []
                if "unreadable" in _terms:
                    _fault_unreadable += 1
                if "unplaced" in _terms:
                    _fault_unplaced += 1
                if "no_world_frame" in _terms:
                    _no_world_frame = True
            # "Does this house have a metre scale" is whether the GAUGE is
            # readable, not whether it remembers which picture it came from.
            _has_anchor = _ft.metre_gauge(_mdl_store) is not None
    except Exception:
        pass

    # A floor whose rooms are a different size than the map they were built
    # from — possible even when the map itself is now perfectly measured,
    # because rooms are traced once and never re-derive. Counts only; no
    # floor names, no coordinates. No total field: every fault is exactly one
    # of the two terms, so the total is just their sum and a third number
    # would only spend budget saying so.
    _room_undersized = 0
    _room_oversized = 0
    _maps_divergent = 0
    try:
        from . import fabric_truth as _ft  # noqa: PLC0415
        _mdl_store = dom.get(DATA_MODEL)
        _maps_list = maps.get("maps") or []
        if _mdl_store is not None:
            _rfaults = _ft.room_footprint_faults(_mdl_store.room_geometry_m(), _maps_list, _mdl_store)
            for _rf in _rfaults:
                _terms = _rf.get("terms") or []
                if "undersized" in _terms:
                    _room_undersized += 1
                if "oversized" in _terms:
                    _room_oversized += 1
            # Maps whose trace and committed fabric drifted apart as a group
            # — the state that hid rjbutler's trimmed floors for weeks. A
            # count of maps, nothing about the building.
            _maps_divergent = len(_ft.room_divergence_faults(
                _mdl_store.room_geometry_m(), _maps_list, _mdl_store))
    except Exception:
        pass

    # Placement adoption by CLASS, not just a single "placed_lights" total —
    # which of the newer classes (motion, flood, humidity, air quality,
    # lock...) people have actually started using since they shipped, a
    # question "placed_lights" alone could never answer. Counts only:
    # entity_id strings themselves never leave this function
    # (assert_shareable refuses anything entity-id-shaped).
    #
    # CORRECTED 2026-09-19 (Phase 2a registry audit): this used to bucket by
    # bare domain prefix alone — binary_sensor.* was ALL counted as
    # "motion_sensor" even though that domain also covers door/window and
    # flood/moisture sensors, and sensor.* was ALL counted as "temp_sensor"
    # even though it also covers humidity and air-quality; lock.* wasn't
    # counted in any bucket. Now looks up each placed entity's real
    # device_class from hass.states — the same test light_codes.js's own
    # classifiers use, kept intentionally approximate here (no enum-sensor-
    # by-name heuristic for the bathroom-outlet air-quality case) since this
    # is a telemetry bucket, not the source of truth for what the map draws.
    _AQ_DEVICE_CLASSES = {
        "aqi", "pm25", "pm10", "pm1",
        "volatile_organic_compounds", "volatile_organic_compounds_parts",
        "carbon_dioxide", "carbon_monoxide",
        "nitrogen_dioxide", "nitrogen_monoxide", "ozone", "sulphur_dioxide",
    }
    _light_ids = list((fab.get("light_positions_m") or {}).keys())
    placed_by_domain = {
        "light": 0, "fan": 0, "lock": 0, "motion_sensor": 0, "door_sensor": 0,
        "flood_sensor": 0, "alarm_sensor": 0, "temp_sensor": 0, "humidity_sensor": 0,
        "air_quality_sensor": 0, "other": 0,
    }
    _tf: dict[str, Any] = {"n": 0, "changed": 0, "updated": 0, "reported": 0, "has_lr": 0, "age": {}}
    _tf_now = datetime.now(timezone.utc)
    for _eid in _light_ids:
        _eid = str(_eid)
        if _eid.startswith("light."):
            placed_by_domain["light"] += 1
        elif _eid.startswith("fan."):
            placed_by_domain["fan"] += 1
        elif _eid.startswith("lock."):
            placed_by_domain["lock"] += 1
        elif _eid.startswith("binary_sensor.") or _eid.startswith("sensor."):
            _st = hass.states.get(_eid)
            _dc = _st.attributes.get("device_class") if _st else None
            if _dc in ("motion", "occupancy"):
                placed_by_domain["motion_sensor"] += 1
            elif _dc in ("door", "window"):
                placed_by_domain["door_sensor"] += 1
            elif _dc == "moisture":
                placed_by_domain["flood_sensor"] += 1
            elif _dc in ("smoke", "gas", "carbon_monoxide"):
                placed_by_domain["alarm_sensor"] += 1
            elif _dc == "humidity":
                placed_by_domain["humidity_sensor"] += 1
                _temp_fresh_note(_st, _tf_now, _tf)
            elif _dc in _AQ_DEVICE_CLASSES:
                placed_by_domain["air_quality_sensor"] += 1
            elif _dc == "temperature" or (_eid.startswith("sensor.") and _dc is None):
                placed_by_domain["temp_sensor"] += 1
                if _st is not None:
                    _temp_fresh_note(_st, _tf_now, _tf)
            else:
                placed_by_domain["other"] += 1
        else:
            placed_by_domain["other"] += 1

    # Pro-only per-light type override (WLED/partition/plain) — one of the
    # few settings that only does anything at pro tier (see light_codes.js
    # isWledLight/isPartitionLight honouring it first), so counting it by
    # chosen kind is a direct read on advanced-tier feature adoption rather
    # than just "is this install on pro".
    _overrides = settings.get("light_type_overrides") or {}
    type_overrides_by_kind: dict[str, int] = {}
    if isinstance(_overrides, dict):
        for v in _overrides.values():
            k = str(v)[:16] if v else "?"
            type_overrides_by_kind[k] = type_overrides_by_kind.get(k, 0) + 1

    # Apple Find My tags (findmy.py). `on_air` / `separated`: Find My
    # addresses heard in the last LIVE_S by type, and how many of them are
    # away from their owner — read off the snapshot's own adverts, so it says
    # whether following tags would matter here with bridging OFF too.
    # `tracked`: the tags the bridge follows, by type; `tracked_live` on the
    # air now; `tracked_carried` on an address other than the one they were
    # first known by — only while bridging is ON: the bridge stays in memory
    # after the switch goes off ("Not this tag" loads it too), holding tags
    # nothing follows any more. Zeros are left out, as the cap refuses the
    # whole report; an empty `findmy` is "counted, none here", no key at all
    # a report from before it. Fixed type keys and counts; no address leaves
    # findmy.py.
    from . import findmy as _fm  # noqa: PLC0415
    _fm_parts: dict[str, Any] = dict(_fm.on_air(ble.get("advertisements")))
    _fm_bridge = dom.get("findmy_bridge")        # snapshot_builder._FINDMY: there once bridging has run
    if settings.get("mac_rotation_bridging") and isinstance(_fm_bridge, _fm.FindMyBridge):
        _fm_parts.update(_fm_bridge.stats(time.time()))
    findmy: dict[str, Any] = {}
    for _part, _v in _fm_parts.items():
        if isinstance(_v, dict):
            _v = {k: n for k, n in _v.items() if n}
        if _v:
            findmy[_part] = _v

    env = {
        "scanners": len(radios),
        "scanner_kinds": scanner_kinds,
        "scanner_types": scanner_types,
        "scanner_names": scanner_names,
        # Receivers with a minimum signal set (opt-in; a count, never which).
        "scanner_floors": len(settings.get("scanner_min_rssi") or {}) if isinstance(settings.get("scanner_min_rssi"), dict) else 0,
        "scanner_state": scanner_state,
        "scan_modes": scan_modes,
        "scan_modes_requested": scan_modes_requested,
        "floors": _len(floors) or _len(mdl.get("floors") or []),
        "rooms": rooms,
        "placed_lights": _len(fab.get("light_positions_m") or {}),
        "placed_by_domain": placed_by_domain,
        "temp_fresh": _tf if _tf["n"] else None,
        "light_type_overrides_by_kind": type_overrides_by_kind,
        "walls": _len(fab.get("rf_barriers_m") or []),
        "maps": _len(maps.get("maps") or []),
        # This start's move of floor plans out of the public www/ folder
        # (0.38.143): images moved, and any left because a file of the same
        # name was already in the new folder. Only when one is not zero.
        **({"maps_www": {"moved": _mw_moved, "left": _mw_left}} if (_mw_moved or _mw_left) else {}),
        "scanner_positions": _len(fab.get("scanner_positions_m") or {}),
        "beacon_positions": _len(fab.get("beacon_positions_m") or {}),
        "calibration_points": _len(cal_points),
        "calibration_auto_points": cal_auto,
        "calibration_no_floor": cal_no_floor,
        "floors_with_height": floors_with_height,
        "rooms_with_height": rooms_with_height,
        "scanners_with_z": len(_z_vals),
        "irks": _len(settings.get("irk_devices") or []),
        "followed": _len(settings.get("followed_addrs") or []),
        "findmy": findmy,
        # The two settings that size the object list: days an unidentified
        # object stays in the history, and the oldest advert a snapshot takes.
        "object_history_days": _history_days(hass),
        "ble_max_age_s": _ble_max_age_s(settings),
        "objects_total": _len(obj_list),
        "objects_identified": sum(1 for o in obj_list if isinstance(o, dict) and o.get("identified")),
        "objects_by_kind": by_kind,
        "object_detail": _object_detail(obj_list),
        "integrations": integrations,
    }
    # The hardware class and the load it runs at (perf_sampler.py) — so a
    # question like "does this feature max out a Pi" is answered per class
    # of machine rather than from the developer's one VM.
    try:
        env["hw"] = _hw_payload(hass)
    except Exception:
        pass
    # Split levels (room_meta floor_raise_m, 0.38.190), only from a house
    # with one: how many rooms are raised and how many sunk. Counts, never
    # which rooms or by how much.
    _up = sum(1 for v in _rm.values() if isinstance(v, dict) and isinstance(v.get("floor_raise_m"), (int, float))
              and not isinstance(v.get("floor_raise_m"), bool) and v["floor_raise_m"] > 0)
    _down = sum(1 for v in _rm.values() if isinstance(v, dict) and isinstance(v.get("floor_raise_m"), (int, float))
                and not isinstance(v.get("floor_raise_m"), bool) and v["floor_raise_m"] < 0)
    if _up or _down:
        env["split_levels"] = {"raised": _up, "sunk": _down}
    # Outdoor surfaces (room_meta surface), only from a house with one: how
    # many rooms have each. Counts, never which rooms.
    _paved = sum(1 for v in _rm.values() if isinstance(v, dict) and v.get("surface") == "pavers_2ft")
    if _paved:
        env["room_surfaces"] = {"pavers_2ft": _paved}
    # Live Aboard's stairs (0.38.193), only from a house with some and its 3D
    # file loaded: how many, how many the AI read off a plan and were kept,
    # how many are a few steps within one floor. Counts only.
    try:
        from .setup_checks import house3d_pieces, stairs_summary  # noqa: PLC0415
        _stairs = stairs_summary(house3d_pieces(hass))
        if _stairs:
            env["stairs"] = _stairs
    except Exception:
        pass
    # Quiet mode on only (a panel filter the backend never applies): how much
    # of the house it hides. A quiet-off report is exactly what it was.
    if settings.get("quiet_mode") is True:
        _qh = _quiet_hidden(obj_list, settings.get("followed_addrs"))
        if _qh:
            env["quiet_hidden"] = _qh
    # Held-out accuracy (heldout.py), only where calibration gave one: each
    # method's rooms-right and median error as bucket words, and which did
    # better. The last result the coordinator has; never computed here.
    try:
        from .heldout import report_buckets  # noqa: PLC0415
        _ho = report_buckets(getattr(dom.get("presence_coordinator"), "_heldout", None))
        if _ho:
            env["heldout"] = _ho
    except Exception:
        pass
    # Walk a room (room_walk.py), only while it is on and a walk was saved:
    # rooms walked as a bucket word, and whether the last walk moved k-NN's
    # held-out rooms-right up, down or not at all: the pair stored at walk
    # time, never today's score against it.
    try:
        from .room_walk import report_buckets as _rw_buckets  # noqa: PLC0415
        _cal = dom.get(DATA_CALIBRATION)
        _cd = getattr(_cal, "data", None) or {}
        from .room_walk import change_word as _rw_change  # noqa: PLC0415
        _rwd = _cd.get("room_walk") or {}
        _chg = _rw_change(_rwd.get("before"), _rwd.get("after"))
        _rw = _rw_buckets(settings, list(_cd.get("points") or []), _chg)
        if _rw:
            env["room_walk"] = _rw
    except Exception:
        pass
    _age = install_age_word(settings.get("first_seen_ts"), time.time())
    if _age:
        env["install_age"] = _age
    _heard = heard_word(settings.get("telemetry_heard"))
    if _heard:
        env["heard_from"] = _heard
    # Guest tags (guest_tags.report_buckets): words only, never a name, only where on and used.
    try:
        from .guest_tags import report_buckets as _guest_buckets  # noqa: PLC0415
        _gb = _guest_buckets(hass, time.time())
        if _gb:
            env["guest"] = _gb
    except Exception:
        pass
    # Room timing off the default, and a registry floor named outside (presence_cfg_words).
    try:
        try:
            from homeassistant.helpers import floor_registry as _fr  # noqa: PLC0415
            _fids = [f.floor_id for f in _fr.async_get(hass).async_list_floors()]
        except Exception:
            _fids = []
        _pc = presence_cfg_words(settings, _fids)
        if _pc:
            env["presence_cfg"] = _pc
    except Exception:
        pass
    # The plans by where they came from and how far each kind has got (plan_sources), only with a plan.
    try:
        _ps = plan_sources((getattr(dom.get(DATA_MAPS), "data", None) or {}).get("maps"),
                           (getattr(dom.get(DATA_MODEL), "data", None) or {}).get("map_transforms"))
        if _ps:
            env["plans"] = _ps
    except Exception:
        pass
    # The AI Task chosen for photos (ai_task_word), only where one is chosen.
    try:
        _ai = ai_task_word(hass)
        if _ai:
            env["ai"] = {"task": _ai}
    except Exception:
        pass
    # Getting to a map (ai_wizard.report_env), only from a house with a plan
    # whose setup isn't finished, or that used the helper: the step it is stuck
    # at, how old its plan is, and the AI helper's rule as words. Those houses
    # also say whether Claude can read their plans (plan_ai.unlock_event, the
    # master switch on or not) and whether a usable Claude is set up but not
    # chosen. A house that finished setup sends exactly what it sent before.
    try:
        from . import ai_wizard as _wiz  # noqa: PLC0415
        _mp = _wiz.report_env(hass, time.time())
        if _mp:
            env["mapping"] = _mp
            from . import plan_ai as _pa  # noqa: PLC0415
            _u = _pa.unlock(hass)
            env.setdefault("ai", {})["claude"] = _pa.unlock_event(_u)
            if not _u.get("ok") and _pa.claude_unchosen(hass):
                env["ai"]["claude_available"] = "yes"
    except Exception:
        pass
    # Vacation Mode (vacation_mode.report_buckets), only where it was used.
    try:
        from .vacation_mode import _VM_LOG, report_buckets as _vac_buckets  # noqa: PLC0415
        _vlog = dom.get(_VM_LOG)
        _vac = _vac_buckets(settings, list(getattr(_vlog, "entries", None) or []), time.time())
        if _vac:
            env["vacation"] = _vac
    except Exception:
        pass
    features = {k: bool(settings.get(k)) for k in _FEATURE_FLAGS}
    features.update(_overview_features(settings))
    for k, word in _FEATURE_ON_ONLY.items():
        if settings.get(k):
            features[word] = True
    for k in _FEATURE_ENUMS:
        v = settings.get(k)
        if isinstance(v, str) and 0 < len(v) <= 16:
            features[k] = v
    presets: list[dict[str, Any]] = []
    for p in (settings.get("lights_showcase_presets") or [])[:_PRESET_SHARE_CAP]:
        if not isinstance(p, dict):
            continue
        vals = p.get("values")
        if not isinstance(vals, dict):
            continue
        presets.append({k: vals[k] for k in _PRESET_VALUE_KEYS if k in vals})
    started = dom.get(_DATA_STARTED)
    health = {
        "crypto_ok": bool(resolver.get("crypto_ok", True)),
        "ble_callback_active": diag.get("callback_active") is not False,
        "ble_diag_ok": diag.get("ok") is not False,
        # NOT a resolution health metric, whatever the ratio looks like.
        # count_rpas() counts every structurally-resolvable address on the
        # air, which is every rotating device in radio range and therefore
        # mostly other people's phones. This describes the radio ENVIRONMENT
        # — how crowded it is, which bears on history size and CPU. Read
        # identity health from irks_* below, never from these two.
        "rpas_seen": int(resolver.get("rpa_count") or 0),
        "rpas_resolved": int(resolver.get("resolved") or 0),
        "resolver_errors": _len(resolver.get("errors") or []),
        "irk_devices_resolving": resolving,
        # Registered identities, and how many of them produced nothing at all.
        # `irks_silent` is the failure this report previously could not see: a
        # key that never matches looked exactly like a key nobody added.
        "irks_total": int(_identity.get("total") or 0),
        "irks_silent": int(_identity.get("silent") or 0),
        # Zeros above are only readable next to this. "None configured" and
        # "none working" are the same number and completely different bugs.
        "has_any_identity": bool(_identity.get("has_any")),
        # Which door the identities came in by, and which door actually works.
        # Fixed labels from PrivateBLEResolver.IDENTITY_SOURCES — no names.
        # "irk_capture" is a key saved from an irk-capture ESP32 (the phone
        # wizard, or the IRK Manager after Auto-detect); irk_capture_boards
        # below counts the ESP32s themselves.
        "irks_by_source": {k: v.get("total", 0)
                           for k, v in (_identity.get("by_source") or {}).items()},
        "irks_resolving_by_source": {k: v.get("resolving", 0)
                                     for k, v in (_identity.get("by_source") or {}).items()},
        "outside_now": _pos["outside"],
        "coverage_floor_active": getattr(coord, "_coverage_floor", None) is not None,
        # Identified objects the engine placed this poll, and judged outside.
        "positioned_now": _pos["positioned"],
        # How long since HA (re)started, coarsely — restart churn is a health
        # signal; a start time finer than that would be one thing too many.
        "uptime": _uptime_bucket(time.monotonic() - started) if isinstance(started, (int, float)) else "unknown",
        # Maps whose stored scale and stored placement no longer describe the
        # same picture, and whether one of them is the map anchoring the house
        # (which makes rooms wrong on every OTHER floor too). A COUNT and a
        # flag — no map names, no coordinates, nothing about the building.
        # This class of bug cost a user weeks of screenshots to surface once.
        "maps_geometry_faulted": _geometry_faults,
        "geometry_fault_unreadable": _fault_unreadable,
        "geometry_fault_unplaced": _fault_unplaced,
        # The one condition that blanks a working house: placements on disk
        # and no scale to draw them at.
        "geometry_no_world_frame": _no_world_frame,
        # Floors whose rooms are a different size than the map they were
        # built from — the failure mode `maps_geometry_faulted` above cannot
        # see, because it only checks a map against itself. Rooms are traced
        # once and never re-derive, so a map can be fixed today and its rooms
        # can still be wrong from before. Counts only.
        "room_footprint_undersized": _room_undersized,
        "room_footprint_oversized": _room_oversized,
        # Maps whose two room records disagree by one shared factor.
        "maps_divergent": _maps_divergent,
        # NULL, not zero, and deliberately still here. It counted maps whose
        # solved matrix and whose decomposed fields described different
        # footprints — a state that needed two stored copies of one placement
        # to exist in. There is one copy, so the question has no answer, and a
        # ZERO in a series that used to carry real counts reads as "fixed"
        # rather than "unaskable". `maps_affine` and `anchor_is_affine` went
        # the other way: they described which KIND of stack a map had, and a
        # map does not have a stack.
        "stack_desync": None,
        # The three "is it set up at all" flags. Each is only meaningful on a
        # multi-storey house, so each carries the floor test in it rather than
        # leaving a bare False to be misread as a fault on a bungalow.
        "has_metre_anchor": _has_anchor,
        "floors_all_default": bool(len(mdl_floors) > 1 and floors_with_height == 0),
        "scanner_z_uniform": bool(len(mdl_floors) > 1 and len(radios) > 1
                                  and scanner_z_distinct <= 1),
        # How each scanner was matched to its HA device. `ambiguous` is the
        # one that matters: it means two scanners are named so that one
        # contains the other, which is the condition that used to assign an
        # area to the wrong radio (issue #65) and now refuses instead. A count
        # of installs carrying that naming is the only way to know whether the
        # refusal is rare or whether people hit it constantly and need the
        # names checked at setup. `unresolved` says the scanner has no HA
        # device at all, which is a different problem wearing the same face.
        # Counts by outcome only — never which radios, never their names.
        "radios_ambiguous": sum(1 for r in radios if r.get("device_match") == "ambiguous"),
        "radios_unresolved": sum(1 for r in radios if r.get("device_match") == "none"),
        "radios_matched_partial": sum(1 for r in radios if r.get("device_match") == "partial"),
    }
    # The Shelly rules' use (0.38.175: a scanner matched to its Shelly by its
    # network MAC + 2; 0.38.176: a scanner device with no area takes its
    # Shelly's), in the last snapshot built. Only from a house where one did.
    _sr = ble.get("shelly_rules") if isinstance(ble.get("shelly_rules"), dict) else {}
    for _k, _key in (("mac", "radios_shelly_mac"), ("area_via", "radios_area_via")):
        if isinstance(_sr.get(_k), int) and _sr[_k] > 0:
            health[_key] = _sr[_k]
    # Forensics switched on, in live mode, but not recording because the
    # licence no longer reaches Pro (0.38.191: it used to go on recording).
    # Only from a house with Forensics on.
    try:
        if settings.get("forensics_enabled") is True and settings.get("data_mode") == "live":
            from .forensics_store import _recording_enabled  # noqa: PLC0415
            health["forensics_paused_licence"] = not _recording_enabled(hass)
    except Exception:
        pass
    # Rooms on one floor drawn over each other by more than 10 cm (0.38.193):
    # a hand-traced outline past its wall, which can put a flight of stairs
    # or a device in the wrong room. Pairs counted; only with rooms drawn.
    try:
        from .setup_checks import rooms_overlapping  # noqa: PLC0415
        _geo = dom.get(DATA_MODEL).room_geometry_m() if dom.get(DATA_MODEL) is not None else {}
        if _geo:
            health["rooms_overlap"] = rooms_overlapping(_geo)
    except Exception:
        pass
    # Plans placed out of shape (setup_checks.plans_out_of_shape, 2026-11-16): a count, only with a plan placed.
    try:
        from .setup_checks import plans_out_of_shape  # noqa: PLC0415
        _tf = (getattr(dom.get(DATA_MODEL), "data", None) or {}).get("map_transforms") or {}
        if _tf:
            health["plans_out_of_shape"] = len(plans_out_of_shape((getattr(dom.get(DATA_MAPS), "data", None) or {}).get("maps"), _tf))
    except Exception:
        pass
    # 0.38.122's fixes, read at the report. Each is left out, not a 0, when
    # what it reads is not there, and a failure leaves out only that one.
    # #149: calibration points whose room is no room (an [auto] point with a
    # pin's device label) — should stop growing.
    try:
        if dom.get("calibration") is not None:
            from homeassistant.helpers import area_registry as _ar  # noqa: PLC0415
            _known = {str(r) for f in floors.values() if isinstance(f, dict) for r in (f.get("rooms") or {})}
            _known |= {str(a.name) for a in _ar.async_get(hass).async_list_areas()}
            _pt_rooms = (str(p.get("room") or "") for p in cal_points if isinstance(p, dict))
            health["cal_points_phantom_room_n"] = sum(1 for r in _pt_rooms if r and r not in _known)
            # 0.38.177: the last report had points, this one none, and no
            # clear was recorded in between (calibration_points_seen, kept by
            # send_now and by every clear) — calibration lost, not cleared.
            # Only with the calibration store loaded, as above.
            _seen = settings.get("calibration_points_seen")
            if isinstance(_seen, int) and not isinstance(_seen, bool) and _seen > 0 and not cal_points:
                health["calibration_points_vanished"] = True
    except Exception as err:
        _LOGGER.debug("Telemetry: calibration health left out: %s", err)
    # 0.38.177: fewer maps than the last report, with no delete recorded in
    # between (maps_seen, kept by send_now and by every delete).
    try:
        _maps_seen = settings.get("maps_seen")
        _maps_now = _len(maps.get("maps") or [])
        if isinstance(_maps_seen, int) and not isinstance(_maps_seen, bool) and _maps_now < _maps_seen \
                and dom.get(DATA_MAPS) is not None:
            health["maps_vanished"] = True
    except Exception as err:
        _LOGGER.debug("Telemetry: cal_points_phantom_room_n left out: %s", err)
    # #147: Beacon Tune pins on a device that moves (tune_save_plan.js
    # tuneBeaconHeld: private_ble or followed; a Bermuda entity is a fixed
    # beacon too, so not counted) —
    # should not grow.
    try:
        if isinstance(objects.get("list"), list):
            _live = {o.get("key"): o for o in obj_list if isinstance(o, dict)}
            _followed = {str(f).upper() for f in (settings.get("followed_addrs") or []) if f}
            _movers = 0
            for _k in (fab.get("beacon_positions_m") or {}):
                _o = _live.get(_k)
                if _o is not None and (_o.get("kind") == "private_ble" or any(
                        str(_o.get(f) or "").upper() in _followed
                        for f in ("key", "address", "entity_id", "canonical_id"))):
                    _movers += 1
            health["pinned_movers_n"] = _movers
    except Exception as err:
        _LOGGER.debug("Telemetry: pinned_movers_n left out: %s", err)
    # #153: PadSpan trackers and sensors registered again as <entity_id>_2 —
    # should not grow.
    try:
        from homeassistant.helpers import entity_registry as _er  # noqa: PLC0415
        _ids = {str(e.entity_id) for e in _er.async_get(hass).entities.values()
                if e.platform == DOMAIN and str(e.entity_id).startswith(("device_tracker.", "sensor."))}
        _bases = (re.fullmatch(r"(.+)_\d+", _eid) for _eid in _ids)
        health["entity_dup_n"] = sum(1 for _m in _bases if _m and _m.group(1) in _ids)
    except Exception as err:
        _LOGGER.debug("Telemetry: entity_dup_n left out: %s", err)
    try:
        _ids = _padspan_device_ids(hass)
        if _ids:
            health["device_ids"] = _ids
    except Exception as err:
        _LOGGER.debug("Telemetry: device_ids left out: %s", err)
    # How many irk-capture ESP32s (github.com/DerekSeaman/irk-capture) this
    # Home Assistant has. With irks_by_source["irk_capture"] above: how many
    # homes get phone keys that way, and whether those keys work. A count
    # only, read here once per report; never a name, an entity id or a key.
    try:
        from .ws_irk import _irk_capture_devices  # noqa: PLC0415
        health["irk_capture_boards"] = len(_irk_capture_devices(hass))
    except Exception as err:
        _LOGGER.debug("Telemetry: irk_capture_boards left out: %s", err)
    try:
        from . import perf_sampler as _ps  # noqa: PLC0415
        _pw = _ps.take_window(hass) if consume else _ps.window(hass)
        health["perf"] = _perf_payload(_pw, _ps.cached_cpus(hass) or 0)
        _log = _ps.run_log(hass)
        _runs = _pw.runs if consume else (_log.peek() if _log is not None else None)
        if _runs is not None:
            health["runs"] = _runs_payload(_runs)
    except Exception:
        pass
    usage = _take_counters(hass) if consume else dict(dom.get(_DATA_COUNTERS) or {})
    _drops = usage.pop("proxy_rate_drop", 0)
    if isinstance(_drops, int) and _drops > 0:
        usage[f"proxy_rate_drops:{_proxy_drop_bucket(_drops)}"] = 1
    try:
        from .onboarding import report_events as _onb_events  # noqa: PLC0415
        for _ev in _onb_events(settings):
            usage[_ev] = 1
    except Exception as err:
        _LOGGER.debug("Telemetry: onboarding left out: %s", err)
    _screens = _screens_listed(dom.get(_DATA_SCREEN_WORDS_TAKEN if consume else _DATA_SCREEN_WORDS))
    if _screens:
        env["screens"] = _screens
    # WARNING+ log lines by module since the last report — the "what broke"
    # signal for the parts of the code the developer cannot exercise.
    errors: dict[str, int] = {}
    try:
        from .ws_common import _log_handler  # noqa: PLC0415
        if _log_handler is not None:
            errors = _log_handler.take_counts() if consume else dict(_log_handler.counts)
    except Exception:
        errors = {}

    import sys as _sys  # noqa: PLC0415
    payload = {
        "schema": SCHEMA,
        "install_id": str(settings.get("telemetry_install_id") or ""),
        "day": time.strftime("%Y-%m-%d", time.gmtime()),
        "version": BUILD_VERSION,
        "edition": _edition(),
        "tier": _tier(hass),
        "ha_version": ha_version,
        "python": f"{_sys.version_info.major}.{_sys.version_info.minor}",
        "env": env,
        "features": features,
        "usage": usage,
        "health": health,
        "errors": errors,
        "presets": presets,
    }
    # Where installs are and which translations matter: only what the person
    # set in Home Assistant, never anything looked up from the address.
    cfg = getattr(hass, "config", None)
    country, language = getattr(cfg, "country", None), getattr(cfg, "language", None)
    if isinstance(country, str) and _COUNTRY_RE.fullmatch(country.strip().upper()):
        payload["country"] = country.strip().upper()
    if isinstance(language, str) and _LANGUAGE_RE.fullmatch(language.strip()):
        payload["language"] = language.strip()
    # Only from a key on more than two homes (the ones that need the report):
    # a house with one or two sends exactly what it always did.
    _sd = (lambda s: s.data if s else {})(hass.data.get(DOMAIN, {}).get(DATA_SETTINGS))
    _grp = licence_group(str(_sd.get("forensics_license_key") or ""))
    if _grp and int(_sd.get("license_homes_used") or 0) > 2:
        payload["licence_group"] = _grp
    # The cap refuses the WHOLE report, and a refused one keeps its counters,
    # so the next is no smaller: one busy day silenced an install until HA
    # restarted. The presets are a courtesy sample (popular_presets.py) — on
    # a day too full for all ten, fewer go, and the counts still do.
    while presets and len(json.dumps(payload)) > _MAX_BYTES:
        presets.pop()
    # Then the rarest usage counters (fewest counts first), so a day with
    # more kinds of event than fit still reports; how many went is said.
    if len(json.dumps(payload)) > _MAX_BYTES and usage:
        dropped = 0
        for k in sorted(usage, key=lambda k: (usage[k], k)):
            del usage[k]
            dropped += 1
            health["usage_dropped"] = dropped
            if len(json.dumps(payload)) <= _MAX_BYTES:
                break
    return payload


def assert_shareable(payload: dict[str, Any]) -> None:
    """Refuse a report that carries anything identifier-shaped.

    Walks every key and value. Raises ValueError naming the offence. The
    install id is exempt from the UUID rule by position (it IS a UUID, by
    design, and nothing else); every other UUID/MAC/32-hex/key/IP anywhere
    is a bug — the report is built from counts, so there is no honest way
    for one to be there.
    """
    if not isinstance(payload, dict):
        raise ValueError("payload is not a dict")
    extra = set(payload.keys()) - _TOP_KEYS
    if extra:
        raise ValueError(f"unexpected top-level keys: {sorted(extra)}")

    def walk(node: Any, path: str) -> None:
        if isinstance(node, dict):
            for k, v in node.items():
                walk(str(k), path + "." + str(k) + "<key>")
                walk(v, path + "." + str(k))
        elif isinstance(node, (list, tuple)):
            for i, v in enumerate(node):
                walk(v, f"{path}[{i}]")
        elif isinstance(node, str):
            if path == ".install_id":
                if node and not _UUID_RE.fullmatch(node):
                    raise ValueError("install_id is not a UUID")
                return
            if path == ".country" and not _COUNTRY_RE.fullmatch(node):
                raise ValueError("country is not a two-letter code")
            if path == ".language" and not _LANGUAGE_RE.fullmatch(node):
                raise ValueError("language is not a language tag")
            if path == ".licence_group":
                if not _GROUP_RE.fullmatch(node):
                    raise ValueError("licence_group is not a group code")
                return
            # Most specific first, so the message names the real shape (a
            # UUID's tail is also twelve hex digits).
            for name, rx in (("UUID", _UUID_RE), ("32-hex", _HEX32_RE), ("licence key", _KEY_RE),
                             ("MAC address", _MAC_RE), ("IP address", _IPV4_RE),
                             ("IPv6 address", _IPV6_RE), ("email address", _EMAIL_RE),
                             ("entity id", _ENTITY_RE)):
                if rx.search(node):
                    raise ValueError(f"{name} in {path}")
            if len(node) > 64:
                raise ValueError(f"string too long in {path}")
        elif node is None or isinstance(node, (bool, int, float)):
            return
        else:
            raise ValueError(f"unexpected value type {type(node).__name__} in {path}")

    walk(payload, "")
    _check_load_sections(payload)
    if len(json.dumps(payload)) > _MAX_BYTES:
        raise ValueError("payload too large")


def _check_load_sections(payload: dict[str, Any]) -> None:
    """env.hw and health.perf carry only the keys and words listed in
    HW_VALUES / PERF_METRICS / PERF_OVER, and only finite, non-negative
    numbers — the generic walk refuses identifier SHAPES; this refuses
    anything that is not on the list at all (a board's model string, a
    hostname, a NaN the receiver could not parse)."""
    def _num(v: Any, path: str, *, allow_none: bool = False) -> None:
        if v is None and allow_none:
            return
        if isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v) or v < 0:
            raise ValueError(f"not a count in {path}")

    env = payload.get("env")
    if isinstance(env, dict) and "quiet_hidden" in env and env["quiet_hidden"] not in QUIET_HIDDEN_BUCKETS:
        raise ValueError("env.quiet_hidden not in the vocabulary")
    if isinstance(env, dict) and "heldout" in env:
        from .heldout import BETTER_WORDS, MEDIAN_BUCKETS, ROOM_BUCKETS  # noqa: PLC0415
        ho = env["heldout"]
        words = {"knn_room": ROOM_BUCKETS, "sp_room": ROOM_BUCKETS, "knn_med": MEDIAN_BUCKETS,
                 "sp_med": MEDIAN_BUCKETS, "better": BETTER_WORDS}
        if not isinstance(ho, dict) or not all(k in words and v in words[k] for k, v in ho.items()):
            raise ValueError("env.heldout not in the vocabulary")
    if isinstance(env, dict) and "room_walk" in env:
        from .room_walk import CHANGE_WORDS, WALKS_BUCKETS  # noqa: PLC0415
        rw = env["room_walk"]
        words = {"walks": WALKS_BUCKETS, "change": CHANGE_WORDS}
        if not isinstance(rw, dict) or not all(k in words and v in words[k] for k, v in rw.items()):
            raise ValueError("env.room_walk not in the vocabulary")
    if isinstance(env, dict) and "install_age" in env and env["install_age"] not in INSTALL_AGE_WORDS:
        raise ValueError("env.install_age not in the vocabulary")
    if isinstance(env, dict) and "heard_from" in env and env["heard_from"] not in HEARD_WORDS:
        raise ValueError("env.heard_from not in the vocabulary")
    if isinstance(env, dict) and "guest" in env:
        from .guest_tags import REPORT_WORDS as _GW  # noqa: PLC0415
        gst = env["guest"]
        if not isinstance(gst, dict) or not all(k in _GW and v in _GW[k] for k, v in gst.items()):
            raise ValueError("env.guest not in the vocabulary")
    if isinstance(env, dict) and "ai" in env:
        a = env["ai"]
        words = {"task": AI_TASK_WORDS, "claude": PLAN_BUILD_UNLOCK, "claude_available": ("yes",)}
        if not isinstance(a, dict) or not a or not all(k in words and v in words[k] for k, v in a.items()):
            raise ValueError("env.ai not in the vocabulary")
    if isinstance(env, dict) and "mapping" in env:
        from .ai_wizard import MAPPING_WORDS  # noqa: PLC0415
        mp = env["mapping"]
        if not isinstance(mp, dict) or "stuck" not in mp or not all(k in MAPPING_WORDS and v in MAPPING_WORDS[k] for k, v in mp.items()):
            raise ValueError("env.mapping not in the vocabulary")
    if isinstance(env, dict) and "plans" in env:
        pl = env["plans"]
        if not isinstance(pl, dict) or not pl or not all(
                (k in PLAN_SOURCES and v in PLAN_STAGES) or (k.endswith("_n") and k[:-2] in PLAN_SOURCES and v in PLAN_COUNT_WORDS)
                for k, v in pl.items()):
            raise ValueError("env.plans not in the vocabulary")
    if isinstance(env, dict) and "presence_cfg" in env:
        pc = env["presence_cfg"]
        if not isinstance(pc, dict) or not all(k in PRESENCE_CFG_WORDS and v in PRESENCE_CFG_WORDS[k] for k, v in pc.items()):
            raise ValueError("env.presence_cfg not in the vocabulary")
    if isinstance(env, dict) and "vacation" in env:
        from .vacation_mode import REPORT_WORDS as _VW  # noqa: PLC0415
        vac = env["vacation"]
        if not isinstance(vac, dict) or not all(k in _VW and v in _VW[k] for k, v in vac.items()):
            raise ValueError("env.vacation not in the vocabulary")
    if isinstance(env, dict) and "screens" in env:
        scr = env["screens"]
        if (not isinstance(scr, list) or len(scr) > SCREENS_LISTED
                or not all(isinstance(s, list) and len(s) <= _SCREEN_WORDS_MAX
                           and all(w in SCREEN_WORDS for w in s) for s in scr)):
            raise ValueError("env.screens not lists of screen words")
    feats = payload.get("features")
    if isinstance(feats, dict):
        for k, words in OVERVIEW_SET.items():
            if k in feats and not (isinstance(feats[k], list) and all(w in words for w in feats[k])):
                raise ValueError(f"features.{k} not in the vocabulary")
    hw = env.get("hw") if isinstance(env, dict) else None
    if hw is not None:
        if not isinstance(hw, dict):
            raise ValueError("env.hw is not a dict")
        for k, v in hw.items():
            if k == "cpus":
                if isinstance(v, bool) or not isinstance(v, int) or not 0 <= v <= HW_MAX_CPUS:
                    raise ValueError("env.hw.cpus out of range")
            elif k in HW_VALUES:
                if v not in HW_VALUES[k]:
                    raise ValueError(f"env.hw.{k} not in the vocabulary")
            else:
                raise ValueError(f"unexpected key in env.hw: {str(k)[:32]}")
    health = payload.get("health")
    perf = health.get("perf") if isinstance(health, dict) else None
    if perf is not None:
        if not isinstance(perf, dict):
            raise ValueError("health.perf is not a dict")
        for k, v in perf.items():
            if k == "samples":
                _num(v, "health.perf.samples")
            elif k == "over":
                if not isinstance(v, dict):
                    raise ValueError("health.perf.over is not a dict")
                for ok, ov in v.items():
                    if ok not in PERF_OVER:
                        raise ValueError(f"unexpected key in health.perf.over: {str(ok)[:32]}")
                    _num(ov, f"health.perf.over.{ok}")
            elif k in PERF_METRICS:
                if not isinstance(v, dict):
                    raise ValueError(f"health.perf.{k} is not a dict")
                for sk, sv in v.items():
                    if sk not in PERF_METRICS[k][1]:
                        raise ValueError(f"unexpected key in health.perf.{k}: {str(sk)[:32]}")
                    _num(sv, f"health.perf.{k}.{sk}", allow_none=True)
            else:
                raise ValueError(f"unexpected key in health.perf: {str(k)[:32]}")
    runs = health.get("runs") if isinstance(health, dict) else None
    if runs is not None:
        if not isinstance(runs, dict):
            raise ValueError("health.runs is not a dict")
        for k, v in runs.items():
            if k not in RUNS_KEYS:
                raise ValueError(f"unexpected key in health.runs: {str(k)[:32]}")
            _num(v, f"health.runs.{k}")


# ── the schedule ─────────────────────────────────────────────────────────────

async def ensure_install_id(hass: HomeAssistant) -> str:
    """Mint the anonymous id on first use; return it."""
    st = hass.data.get(DOMAIN, {}).get(DATA_SETTINGS)
    if not st:
        return ""
    cur = str(st.data.get("telemetry_install_id") or "")
    if cur and _UUID_RE.fullmatch(cur):
        return cur
    new = str(uuid.uuid4())
    await st.async_set(telemetry_install_id=new)
    return new


def _today() -> str:
    return time.strftime("%Y-%m-%d", time.gmtime())


def _days_since_report(hass: HomeAssistant) -> int:
    """Whole UTC days since the last report went (a large number: never)."""
    st = hass.data.get(DOMAIN, {}).get(DATA_SETTINGS)
    try:
        last = date.fromisoformat(str((st.data if st else {}).get("telemetry_last_day") or ""))
        return (date.fromisoformat(_today()) - last).days
    except ValueError:
        return 10_000


async def ensure_snapshot(hass: HomeAssistant) -> None:
    """Make sure there IS a snapshot to read the environment from.

    Half the report — scanners, objects, resolver health — comes from the
    live snapshot, which is built on demand and cached. A report sent ten
    minutes after a restart, with nobody looking at the panel, would
    otherwise say "0 scanners, 0 objects" about a full house. Measured on
    the first real send: exactly that. The builder serves its own cache when
    one is fresh, so this costs nothing when the panel is open.
    """
    try:
        from .snapshot_builder import _live_snapshot  # noqa: PLC0415
        await _live_snapshot(hass)
    except Exception as err:
        _LOGGER.debug("Telemetry could not build a snapshot: %s", err)


async def ensure_hw(hass: HomeAssistant) -> None:
    """Make sure env.hw names the installation type and board, not
    "unknown" because the sampler's first tick has not come yet. Detected
    once; a no-op after that."""
    try:
        from . import perf_sampler  # noqa: PLC0415
        await perf_sampler.async_ensure_hw(hass)
    except Exception as err:
        _LOGGER.debug("Telemetry could not read the hardware class: %s", err)


async def ensure_plan_ai(hass: HomeAssistant) -> None:
    """Load the plan AI's store in a house with a plan (it loads on first use),
    so env.mapping's rule knows whether Line up or Rooms from plans was used
    when nobody has opened the Plans tool since the restart."""
    try:
        if (getattr(hass.data.get(DOMAIN, {}).get(DATA_MAPS), "data", None) or {}).get("maps"):
            from .plan_ai import async_get_store  # noqa: PLC0415
            await async_get_store(hass)
    except Exception as err:
        _LOGGER.debug("Telemetry could not read the plan AI's store: %s", err)


async def send_now(hass: HomeAssistant, *, force: bool = False) -> dict[str, Any]:
    """Build, check, POST. Returns {"sent": bool, "reason": str, "bytes": n}.

    At most one report per UTC day: the day of the last successful send is
    persisted (`telemetry_last_day`), so a restart or reload does not send
    again — the scheduler fires after every start (async_setup_telemetry). `force` is the
    "Send a report now" button. The windows (counters, log counts, resolved
    keys) are taken once the report has passed the gate, before the POST is
    awaited — what is counted while it is in flight belongs to the next
    report (review, 2026-09-27: taken after the await, it went with neither)
    — and a failed send gives them back, so a refused or failed send keeps
    the day's counts for the next attempt.
    """
    if not enabled(hass):
        return {"sent": False, "reason": "disabled", "bytes": 0}
    st = hass.data.get(DOMAIN, {}).get(DATA_SETTINGS)
    if not force and st and str(st.data.get("telemetry_last_day") or "") == _today():
        return {"sent": False, "reason": "already sent today", "bytes": 0}
    await ensure_install_id(hass)
    await ensure_snapshot(hass)
    await ensure_hw(hass)
    await ensure_plan_ai(hass)
    payload = build_payload(hass, consume=False)
    try:
        assert_shareable(payload)
    except ValueError as err:
        _LOGGER.error("Telemetry report refused before sending: %s", err)
        return {"sent": False, "reason": f"refused: {err}", "bytes": 0}
    body = json.dumps(payload).encode()
    # Nothing awaited since build_payload: these are what the report holds.
    taken = _take_windows(hass)
    try:
        from homeassistant.helpers.aiohttp_client import async_get_clientsession  # noqa: PLC0415
        session = async_get_clientsession(hass)
        async with session.post(TELEMETRY_URL, data=body,
                                headers={"Content-Type": "application/json"}, timeout=15) as resp:
            ok = 200 <= resp.status < 300
            if not ok:
                _LOGGER.debug("Telemetry HTTP %s", resp.status)
                _give_back_windows(hass, taken)
                return {"sent": False, "reason": f"http {resp.status}", "bytes": len(body)}
            try:
                reply = await resp.json(content_type=None)
            except Exception:
                reply = None
    except Exception as err:  # network errors are expected and non-fatal
        _LOGGER.debug("Telemetry send failed: %s", err)
        _give_back_windows(hass, taken)
        return {"sent": False, "reason": "network", "bytes": len(body)}
    if st:
        try:
            await st.async_set(telemetry_last_day=_today(),
                               calibration_points_seen=int((payload.get("env") or {}).get("calibration_points") or 0),
                               maps_seen=int((payload.get("env") or {}).get("maps") or 0))
        except Exception:
            pass
    # A new install's first steps went: never again (onboarding.py).
    try:
        from .onboarding import async_mark_reported  # noqa: PLC0415
        await async_mark_reported(hass, [k for k in payload.get("usage") or {} if k in ONBOARDING_EVENTS])
    except Exception as err:
        _LOGGER.debug("Telemetry: onboarding not marked sent: %s", err)
    # The reply may carry a free-year Pro invite (pro_invite.py). Never fatal.
    try:
        from .pro_invite import store_from_reply  # noqa: PLC0415
        await store_from_reply(hass, reply)
    except Exception as err:
        _LOGGER.debug("Pro invite from the report reply not kept: %s", err)
    return {"sent": True, "reason": "", "bytes": len(body)}


def reset_windows(hass: HomeAssistant) -> None:
    """Start the usage and error windows now — called at opt-in, so the first
    report carries nothing from before the person said yes."""
    hass.data.setdefault(DOMAIN, {})[_DATA_COUNTERS] = {}
    hass.data[DOMAIN][_DATA_SCREENS] = set()
    hass.data[DOMAIN][_DATA_SCREEN_WORDS] = {}
    _persist_counters(hass, now=True)
    try:
        from .ws_common import _log_handler  # noqa: PLC0415
        if _log_handler is not None:
            _log_handler.take_counts()
    except Exception:
        pass
    try:
        from .private_ble_resolver import _resolvers  # noqa: PLC0415
        _r = _resolvers.get(id(hass))
        if _r is not None:
            _r.take_resolved_ids()
    except Exception:
        pass
    try:
        from . import perf_sampler  # noqa: PLC0415
        perf_sampler.reset_window(hass)
    except Exception:
        pass


def async_setup_telemetry(hass: HomeAssistant) -> None:
    """Schedule the daily report (idempotent across reloads). Runs only when on.

    Also starts the load sampler (perf_sampler.py): one 60 s timer, itself
    idempotent, that measures only while the report is on."""
    from homeassistant.helpers.event import async_call_later, async_track_time_interval  # noqa: PLC0415

    dom = hass.data.setdefault(DOMAIN, {})
    dom.setdefault(_DATA_STARTED, time.monotonic())
    try:
        hass.async_create_task(async_restore_counters(hass))
    except Exception as err:  # noqa: BLE001
        _LOGGER.debug("Telemetry counters not restored: %s", err)
    try:
        from . import perf_sampler  # noqa: PLC0415
        perf_sampler.async_start(hass)
    except Exception as err:
        _LOGGER.debug("Load sampler not started: %s", err)
    if dom.get(_DATA_UNSUBS):
        return

    async def _run(_now: Any = None) -> None:
        if enabled(hass):
            await send_now(hass)

    async def _first(_now: Any = None) -> None:
        if _days_since_report(hass) >= _STALE_DAYS:
            await _run()
            return
        unsubs = hass.data.get(DOMAIN, {}).get(_DATA_UNSUBS)
        if unsubs is not None:          # not stopped meanwhile
            unsubs.append(async_call_later(hass, _STEADY_S - _FIRST_DELAY_S, _run))

    dom[_DATA_UNSUBS] = [
        async_call_later(hass, _FIRST_DELAY_S, _first),
        async_track_time_interval(hass, _run, _INTERVAL),
    ]


def async_stop_telemetry(hass: HomeAssistant) -> None:
    for unsub in hass.data.get(DOMAIN, {}).pop(_DATA_UNSUBS, []) or []:
        try:
            unsub()
        except Exception:
            pass
    try:
        from . import perf_sampler  # noqa: PLC0415
        perf_sampler.async_stop(hass)
    except Exception:
        pass
