# PadSpan HA — BLE Room-Presence Tracking for Home Assistant
# Copyright (C) 2026 Garry Broeckling
# Licensed under the GNU General Public License v3.0
# See LICENSE file or https://www.gnu.org/licenses/gpl-3.0.html
"""The live snapshot: one build of every object the system currently sees, cached for a short TTL and shared by every view. This is the largest single piece of PadSpan and it has its own file for that reason.

Split out of websocket.py; registration stays there.
"""

from __future__ import annotations

import logging
import time as _time
import asyncio

import voluptuous as vol
import time
from typing import Any
from homeassistant.components import websocket_api
from homeassistant.core import HomeAssistant, State
from homeassistant.helpers import area_registry, device_registry, entity_registry
from homeassistant.util import dt as dt_util
from .const import (
    DOMAIN,
    DATA_SETTINGS,
    DATA_OBJECTS,
    DATA_OBJECT_HISTORY,
    OBJECT_HISTORY_STORE_KEY,
    DATA_BEACON_LAST_MACS,
    DATA_COORDINATOR,
    DATA_CALIBRATION,
    DATA_TRACEBACK,
    DATA_LOST_AND_FOUND,
    DATA_ESPRESENSE_MQTT,
    DATA_DEVICE_REGISTRY,
)
from .bluetooth_live import get_bluetooth_live
from .private_ble_resolver import PrivateBLEResolver, get_resolver as _get_ble_resolver
from .ingest_policy import Identity as _IngestIdentity, IngestPolicy
from .beacon_identity import (
    decide_split as _decide_beacon_split,
    durable_addresses as _durable_addresses,
    memory_is_settled as _memory_is_settled,
    rotation_bridge_allowed,
    same_device_by_address,
    update_address_memory as _update_address_memory,
)

# How many polls an identity must be watched before the ABSENCE of a durable
# address counts as evidence of rotation rather than of not having looked long
# enough. Three polls is ~15s at the default interval — long enough for any
# real beacon to have re-advertised once, short enough that a rotator is not
# minting objects for long.
_SETTLED_POLLS = 3
from .ble_enrichment import enrich_object as _enrich_ble_object
from . import low_memory as _low_memory
from .perf_sampler import record_duration
from .presence_rules import away_timeout_s, is_away
from .util import ha_device_config_entries, ha_devices
from .ws_common import (
    RadioDeviceIndex,
    radio_display,
    _ALL_ADDR_CAP,
    _DATA_SNAPSHOT_CACHE,
    _DATA_SNAPSHOT_CACHE_LOCK,
    _DEFAULT_IBEACON_UUIDS,
    _SNAPSHOT_CACHE_TTL_S,
    _XREF_ADDR_SAMPLE,
    _capped_mac_history,
    _get_settings,
    _invalidate_snapshot_cache,  # noqa: F401  re-exported: the cache is owned here
    _is_rpa_addr,
    _object_history_ttl_s,
)

_LOGGER = logging.getLogger(__name__)


_FINDMY = "findmy_bridge"
_FINDMY_STORE = "findmy_bridge_store"


async def _findmy_bridge(hass: HomeAssistant):
    """The Find My bridge, its links loaded from their Store once."""
    from .findmy import FindMyBridge  # noqa: PLC0415
    dom = hass.data.setdefault(DOMAIN, {})
    bridge = dom.get(_FINDMY)
    if bridge is None:
        from homeassistant.helpers.storage import Store  # noqa: PLC0415
        from .const import FINDMY_STORE_KEY  # noqa: PLC0415
        store = Store(hass, 1, FINDMY_STORE_KEY)
        try:
            state = await store.async_load()
        except Exception:  # noqa: BLE001 — a bad file starts empty, never blocks the snapshot
            state = None
        bridge = dom[_FINDMY] = FindMyBridge(state if isinstance(state, dict) else None)
        dom[_FINDMY_STORE] = store
    return bridge


def _findmy_forget_in_history(dom: dict, ident: str, addr: str) -> None:
    """An address unlinked from a Find My tag leaves the tag's cached object
    too: the history cache replays that object (with its address list and
    live address) every poll, and it went on claiming the address (round 10)."""
    entry = (dom.get(DATA_OBJECT_HISTORY) or {}).get(f"ble:{ident}")
    if isinstance(entry, dict):
        entry["all_addresses"] = [a for a in (entry.get("all_addresses") or []) if str(a).upper() != addr.upper()]
        entry.pop("current_address", None)


async def _findmy_step(hass: HomeAssistant, ble_by_addr: dict, canonical_by_addr: dict,
                       addr_to_device: dict, addr_to_entities: dict, now_ts: float | None = None,
                       reseed_s: float | None = None) -> list:
    """Carry each known Find My tag onto its next address (findmy.py).

    A Find My address is static random (0xC0-0xFF), never a resolvable
    private one, so the fingerprint bridge above never sees it. A tag the
    person labelled, followed or linked starts an identity, keyed by the
    address it was first known by. Once it has moved, EVERY address it has
    used that is still in the snapshot — the old ones linger in HA's list for
    up to ble_max_age_s — maps to that one identity: one object, keeping the
    key, the address the person named and followed it by (B2 below), its
    room and Traceback key. followed_addrs is never rewritten (open panels
    hold their own copy and would undo it — round 8). Returns this poll's
    links as (identity, old address, new address). `reseed_s`: the reseed
    interval bluetooth_live used (its diag), for the report's "late"."""
    import time as _t  # noqa: PLC0415
    from .findmy import LIVE_S, RESEED_S, is_findmy_address, parse_findmy  # noqa: PLC0415
    now_ts = _t.time() if now_ts is None else now_ts
    bridge = await _findmy_bridge(hass)
    dom = hass.data.get(DOMAIN, {})
    st = dom.get(DATA_SETTINGS)
    followed = {str(f).upper() for f in ((st.data if st else {}).get("followed_addrs") or [])}
    dev_reg = dom.get(DATA_DEVICE_REGISTRY)
    obj_store = dom.get(DATA_OBJECTS)
    known: dict[str, str] = {}
    for addr, rec in ble_by_addr.items():
        if addr in canonical_by_addr or not is_findmy_address(addr) or bridge.identity_of(addr):
            continue          # an address a tag has used is that tag's, never a new one
        age = rec.get("age_s")
        if isinstance(age, (int, float)) and age > LIVE_S:
            continue          # a lingering address nobody is using
        if parse_findmy(rec.get("manufacturer_data")) is None:
            continue
        if (addr in followed or addr in addr_to_device or addr in addr_to_entities
                or (obj_store and obj_store.get_label(addr))
                or (dev_reg and dev_reg.get_label_by_key(addr))):
            known[addr] = addr
    res = bridge.step(now_ts, {a: r for a, r in ble_by_addr.items() if a not in canonical_by_addr}, known,
                      float(reseed_s) if isinstance(reseed_s, (int, float)) else RESEED_S)
    for ident in list(bridge.tags):
        if bridge.tags[ident].get("addr") == ident:
            continue            # still on the address it was first known by: an ordinary object
        # "current": the address the bridge says the tag uses now — the
        # object's live address comes from it, never from whichever of the
        # tag's addresses was heard last (round 10: two live at once made it
        # flip every poll and the room never settled).
        entry = {"canonical_id": ident, "key": f"ble:{ident}", "name": ident,
                 "kind": "private_ble", "bridge_match": True, "findmy": True,
                 "current": bridge.tags[ident].get("addr")}
        for addr in bridge.addresses_of(ident):
            if addr in ble_by_addr and addr not in canonical_by_addr:
                canonical_by_addr[addr] = entry
    for ident, wrong, _back in res.get("unlinked") or []:
        _findmy_forget_in_history(dom, ident, wrong)
    # How well it works, for the opt-in report (telemetry.py EVENTS). "Slow":
    # a link that landed over 2 minutes after the old address's last report
    # (by design one lands in about a minute).
    from .telemetry import bump  # noqa: PLC0415
    for after_s in res.get("linked_after_s") or []:
        bump(hass, "findmy_linked")
        if after_s > 120:
            bump(hass, "findmy_linked_slow")
    for _ident, reason in res.get("missed") or []:
        if reason == "ambiguous":
            bump(hass, "findmy_missed_ambiguous")
        elif reason == "late":
            bump(hass, "findmy_missed_late")
        elif reason == "elsewhere":
            bump(hass, "findmy_missed_elsewhere")
        else:
            bump(hass, "findmy_missed_no_candidate")
    # A tag back on its day key is the schedule, its links right; any other
    # move back undid wrong links (findmy.py step()).
    day_key = set(res.get("back_on_day_key") or [])
    for _ident in day_key:
        bump(hass, "findmy_back_on_day_key")
    for _ident in {u[0] for u in res.get("unlinked") or []} - day_key:
        bump(hass, "findmy_moved_back")
    for u in res.get("unlinked") or []:
        if u[0] not in day_key:
            bump(hass, "findmy_moved_back_addrs")
    if res["linked"] or res.get("unlinked"):
        store = dom.get(_FINDMY_STORE)
        if store is not None:
            store.async_delay_save(bridge.to_state, 5)
    return res["linked"]


async def _live_snapshot(hass: HomeAssistant) -> dict:
    """Return the live snapshot, serving a shared cached build when fresh.

    The full pipeline (_build_live_snapshot) is expensive and is invoked by the
    panel poll (per connected client), the presence coordinator, and several
    handlers — often within the same second.  A short TTL collapses those into
    a single build; the lock prevents concurrent duplicate builds.

    IMPORTANT: the returned dict is SHARED between callers.  Treat it as
    read-only — copy any dict (including the object dicts in objects.list)
    before mutating it, as ws_live_snapshot does.
    """
    dom = hass.data.setdefault(DOMAIN, {})
    ttl = snapshot_ttl_s(hass)
    cached = dom.get(_DATA_SNAPSHOT_CACHE)
    if cached and (time.monotonic() - cached[0]) < ttl:
        return cached[1]
    lock = dom.get(_DATA_SNAPSHOT_CACHE_LOCK)
    if lock is None:
        lock = dom[_DATA_SNAPSHOT_CACHE_LOCK] = asyncio.Lock()
    async with lock:
        cached = dom.get(_DATA_SNAPSHOT_CACHE)
        if cached and (time.monotonic() - cached[0]) < ttl:
            return cached[1]
        _t0 = time.perf_counter()
        snap = await _build_live_snapshot(hass)
        # What a build costs on this machine, for the opt-in report
        # (perf_sampler.py; a no-op while the report is off, never raises).
        record_duration(hass, "snap", (time.perf_counter() - _t0) * 1000.0)
        dom[_DATA_SNAPSHOT_CACHE] = (time.monotonic(), snap)
        # A new install's first room and first calibration point
        # (onboarding.py): one lookup anywhere else, never raises.
        from .onboarding import note_snapshot  # noqa: PLC0415
        note_snapshot(hass, snap)
        return snap


async def _build_live_snapshot(hass: HomeAssistant) -> dict:
    """Build a comprehensive snapshot of all PadSpan-relevant HA data.

    Discovers:
      - BLE scanners (radios) and advertisements from bluetooth_live
      - Rooms from the HA Area Registry
      - Tag/entity candidates (Bermuda, device_tracker, sensor)
      - BLE objects grouped by identity (MAC, iBeacon, private_ble/IRK)
      - Room assignments via RSSI-to-scanner-area mapping
      - Object history cache (7-day rolling, disk-backed)
      - Traceback position recording for playback

    IMPORTANT: This function must never raise.  If any subsection fails, it
    logs and continues so the UI always gets a renderable (possibly sparse) result.
    """
    snapshot: dict[str, Any] = {
        "source": "live",
        "generated_at": dt_util.utcnow().isoformat(),
        "rooms_discovered": [],
        "receivers": [],
        "tags": [],
        "room_tag_map": {},
        "room_tag_map_live": {},
        "room_tag_map_missing": {},
        "room_tag_map_saved": {},
        "raw_counts": {},
    }

    # Each phase's time, for the opt-in report (perf_sampler "snap_<phase>";
    # a no-op while it is off). The whole build has been timed since 0.38.103,
    # and a third of the installs reporting take 1.4-18 s for it, all of them
    # with Bermuda — this says which part.
    _phase_t = [time.perf_counter()]
    # The "ha" phase never awaits, so this thread's CPU time over it is
    # PadSpan's own work: next to its wall time it says whether a slow build
    # is PadSpan's code or the process starved by other threads (0.38.133;
    # 13-16 s "ha" phases on two VMs with only ~5k states).
    _phase_c = [time.thread_time()]
    _sub_t = [time.perf_counter()]

    def _phase_done(name: str) -> None:
        now = time.perf_counter()
        record_duration(hass, "snap_" + name, (now - _phase_t[0]) * 1000.0)
        if name == "ha":
            record_duration(hass, "snap_ha_cpu", (time.thread_time() - _phase_c[0]) * 1000.0)
            record_duration(hass, "snap_ha_radios", (now - _sub_t[0]) * 1000.0)
        _phase_t[0] = now
        _phase_c[0] = time.thread_time()
        _sub_t[0] = now

    def _sub_done(name: str) -> None:
        now = time.perf_counter()
        record_duration(hass, "snap_" + name, (now - _sub_t[0]) * 1000.0)
        _sub_t[0] = now

    # --- Bluetooth (scanners + advertisements) ---
    # Fetched FIRST because downstream sections (objects, room assignment) depend on it.
    try:
        bl = get_bluetooth_live(hass)
        if bl is not None:
            # Max age is user-configurable (Settings → Presence).  Clamped to
            # [60s, 4h]; the cache itself keeps no longer, and low-memory mode
            # caps both (low_memory.py).
            _ble_age = _low_memory.ble_age_s(hass)
            bl.cache_age_s = _ble_age
            bl.cache_max_addrs = _low_memory.ble_max_addrs(hass)
            snapshot["ble"] = bl.get_snapshot(max_ads=_low_memory.snapshot_ads(hass), max_age_s=_ble_age)
        else:
            snapshot["ble"] = {"radios": [], "advertisements": [], "diag": {"ok": False, "errors": ["no_bluetooth_live"]}}
    except Exception as e:
        snapshot["ble"] = {"radios": [], "advertisements": [], "diag": {"ok": False, "errors": ["ble_snapshot_error"]}}


    # --- ESPresense MQTT (merge into BLE snapshot if enabled) ---
    try:
        esp_mqtt = hass.data.get(DOMAIN, {}).get(DATA_ESPRESENSE_MQTT)
        if esp_mqtt is not None:
            esp_mqtt.cache_age_s = _low_memory.ble_age_s(hass)
            esp_snap = esp_mqtt.get_snapshot(max_age_s=_ble_age if "_ble_age" in dir() else 900)
            ble = snapshot.setdefault("ble", {"radios": [], "advertisements": [], "diag": {}})
            ble["radios"].extend(esp_snap.get("radios", []))
            ble["advertisements"].extend(esp_snap.get("advertisements", []))
            ble["diag"]["espresense"] = esp_snap.get("diag", {})
            # Re-sort merged advertisements by age
            ble["advertisements"].sort(key=lambda x: x.get("age_s", 1e9))
    except Exception:
        pass

    # --- Tasmota BLE over MQTT (merged the same way, if enabled) ---
    try:
        from .tasmota_ble import DATA_TASMOTA_BLE  # noqa: PLC0415
        _tas = hass.data.get(DOMAIN, {}).get(DATA_TASMOTA_BLE)
        if _tas is not None:
            _tas.cache_age_s = _low_memory.ble_age_s(hass)
            _tas.max_addrs = min(5000, _low_memory.ble_max_addrs(hass) or 5000)
            _tas_snap = _tas.get_snapshot(max_age_s=_low_memory.ble_age_s(hass))
            ble = snapshot.setdefault("ble", {"radios": [], "advertisements": [], "diag": {}})
            ble.setdefault("radios", []).extend(_tas_snap.get("radios", []))
            ble.setdefault("advertisements", []).extend(_tas_snap.get("advertisements", []))
            ble.setdefault("diag", {})["tasmota"] = _tas_snap.get("diag", {})
            ble["advertisements"].sort(key=lambda x: x.get("age_s", 1e9))
    except Exception:
        pass

    _phase_done("ble")

    # --- Areas (rooms) ---
    area_by_id: dict[str, str] = {}
    try:
        ar = area_registry.async_get(hass)
        area_by_id = {a.id: a.name for a in ar.async_list_areas()}
        snapshot["rooms_discovered"] = sorted(area_by_id.values())
    except Exception:
        pass

    # --- Find Bermuda config entries (if installed) ---
    # Bermuda is a popular BLE presence integration.  We auto-detect its entities
    # as "tag candidates" unless the user has set bermuda_ignore=true.
    bermuda_entry_ids: set[str] = set()
    _bermuda_ignore = False
    try:
        _st = hass.data.get(DOMAIN, {}).get(DATA_SETTINGS)
        if _st and _st.get("bermuda_ignore"):
            _bermuda_ignore = True
    except Exception:
        pass
    # Always discover Bermuda entry IDs (needed for both include and exclude logic)
    _all_bermuda_entry_ids: set[str] = set()
    try:
        for ent in hass.config_entries.async_entries():
            if ent.domain == "bermuda":
                _all_bermuda_entry_ids.add(ent.entry_id)
    except Exception:
        pass
    if not _bermuda_ignore:
        bermuda_entry_ids = set(_all_bermuda_entry_ids)

    # --- Receivers (devices belonging to Bermuda entries) ---
    try:
        dr = device_registry.async_get(hass)
        receivers: list[dict[str, Any]] = []
        for dev in ha_devices(dr):
            if bermuda_entry_ids and not bermuda_entry_ids.isdisjoint(ha_device_config_entries(dev)):
                receivers.append(
                    {
                        "id": dev.id,
                        "name": dev.name_by_user or dev.name or dev.model or "Receiver",
                        "manufacturer": dev.manufacturer or "",
                        "model": dev.model or "",
                        "sw_version": dev.sw_version or "",
                    }
                )
        snapshot["receivers"] = sorted(receivers, key=lambda d: (d.get("name") or "").lower())
    except Exception:
        snapshot["receivers"] = []

    _sub_done("ha_areas")   # areas, Bermuda entries, receivers

    # --- Tag candidates + room mapping ---
    # Walk every HA entity and heuristically determine which ones represent
    # BLE trackable objects and which room they're currently in.
    er = entity_registry.async_get(hass)

    def _norm(s: str) -> str:
        """Case-fold + strip for fuzzy room name matching."""
        return (s or "").strip().casefold()

    known_rooms = {_norm(r): r for r in snapshot.get("rooms_discovered", [])}

    def _room_from_state(entity_id: str, st: State) -> str | None:
        """Determine which room an entity is in, trying 4 strategies in priority order."""
        # 1) state string equals a room name
        room = known_rooms.get(_norm(st.state))
        if room:
            return room

        # 2) explicit attribute hints
        for key in ("room", "area", "area_name"):
            v = st.attributes.get(key)
            if isinstance(v, str):
                room = known_rooms.get(_norm(v))
                if room:
                    return room

        # 3) entity registry area assignment
        ent = er.async_get(entity_id)
        if ent and ent.area_id and ent.area_id in area_by_id:
            return area_by_id[ent.area_id]

        # 4) attribute area_id
        aid = st.attributes.get("area_id")
        if isinstance(aid, str) and aid in area_by_id:
            return area_by_id[aid]

        return None

    def _is_candidate(entity_id: str, st: State) -> bool:
        """Return True if the entity looks like a BLE presence-tracking entity.

        Accepts: Bermuda config_entry entities, entities with *_area_last_seen
        naming patterns, entities with receiver/rssi/distance attributes, and
        entities with bluetooth-ish keywords in their entity_id or name.
        """
        ent = er.async_get(entity_id)
        # When bermuda_ignore is on, reject any entity from a Bermuda config entry
        if _bermuda_ignore and ent and ent.config_entry_id in _all_bermuda_entry_ids:
            return False
        if ent and ent.config_entry_id in bermuda_entry_ids:
            return True

        dom = entity_id.split('.', 1)[0]
        if dom not in ('device_tracker', 'sensor', 'binary_sensor', 'tag', 'text_sensor'):
            return False

        n = _norm(getattr(st, 'name', '') or st.attributes.get('friendly_name', ''))
        eidn = _norm(entity_id)

        # Strong patterns for 'current room/area' entities (Bermuda-style and similar).
        if any(p in eidn for p in ('_area_last_seen', 'area_last_seen', '_room_last_seen', 'room_last_seen', 'nearest_area', 'nearest_room')):
            return True
        if 'last_seen' in eidn and ('area' in eidn or 'room' in eidn):
            return True

        # Attribute hints (many BLE/RTLS integrations expose receiver/rssi fields).
        for k in ('nearest_receiver', 'receiver', 'receivers', 'rssi', 'distance', 'gateway', 'bermuda'):
            if k in (st.attributes or {}):
                return True

        # Bluetooth-ish heuristics (fallback), as whole words: substrings made
        # sensor.kitchen_voltage ("tag") and binary_sensor.dining_table_occupancy
        # ("ble") tracked objects, present in their area.
        return bool(_BT_WORD.search(eidn) or _BT_WORD.search(n))

    import re as _re  # noqa: PLC0415
    # Digits are a boundary (beacon1, tag1_room, ble01) and a tag can carry
    # its maker's prefix (airtag, smarttag2, ibeacon, bletag); a word inside
    # another word (kitchen_voltage, dining_table) is not one.
    _BT_WORD = _re.compile(r"(?:^|[^a-z])(?:air|smart|i|ble)?(?:ble|bluetooth|bermuda|tags?|beacons?)(?:[^a-z]|$)")

    def _looks_like_room_tracker(entity_id: str, st: State) -> bool:
        """Safety net for live mode: accept entities whose id/attrs look like location trackers."""
        eidn = _norm(entity_id)
        if any(p in eidn for p in ('_area_last_seen', 'area_last_seen', '_room_last_seen', 'room_last_seen', 'nearest_area', 'nearest_room')):
            return True
        if 'last_seen' in eidn and ('area' in eidn or 'room' in eidn):
            return True
        for k in ('nearest_receiver', 'receiver', 'receivers', 'rssi', 'distance', 'gateway'):
            if k in (st.attributes or {}):
                return True
        return False

    tags: list[dict[str, Any]] = []
    room_tag_map_live: dict[str, list[str]] = {r: [] for r in (snapshot.get('rooms_discovered') or [])}
    room_tag_map_missing: dict[str, list[str]] = {r: [] for r in (snapshot.get('rooms_discovered') or [])}

    # --- Saved (configured) room→tag map (from coordinator) ---
    # In many setups, you curate your rooms/tags here. We keep this separately
    # from live-discovered tags so 'live' views don't get polluted by placeholders.
    saved_room_tag_map: dict[str, list[str]] = {r: [] for r in (snapshot.get('rooms_discovered') or [])}
    try:
        coord = hass.data.get(DOMAIN, {}).get(DATA_COORDINATOR)
        if coord and getattr(coord, 'room_tag_map', None):
            saved_room_tag_map = {str(k): list(v) for k, v in (coord.room_tag_map or {}).items() if isinstance(v, (list, tuple))}
    except Exception:
        saved_room_tag_map = {}
    def _resolve_saved_entity_id(tag_id: str) -> str:
        """Resolve a saved tag ID (which may be a tag.* placeholder) to a real HA entity.

        The coordinator's room_tag_map may contain tag.* entries from sample mode
        or user configuration.  We try common Bermuda/BLE naming patterns and
        finally do a fuzzy search across all HA states.
        """
        if hass.states.get(tag_id):
            return tag_id
        if "." not in tag_id:
            return tag_id
        dom, obj = tag_id.split(".", 1)
        if dom != "tag":
            return tag_id

        # Common Bermuda / presence naming patterns
        guesses = [
            f"sensor.{obj}_area_last_seen",
            f"sensor.{obj}_area",
            f"sensor.{obj}_room",
            f"device_tracker.{obj}",
            f"text_sensor.{obj}_area_last_seen",
            f"text_sensor.{obj}_area",
        ]
        for g in guesses:
            if hass.states.get(g):
                return g

        # Fuzzy fallback: find an entity id containing the object id. The
        # location-like entity ids are gathered ONCE per build and shared by
        # every saved tag that gets here: it was a walk over every HA state
        # per missing tag, per build — and a Bermuda house has tens of
        # thousands of states.
        objn = _norm(obj)
        if not objn:
            return tag_id
        if _fuzzy_eids is None:
            _fuzzy_eids_init()
        for eid, eidn in _fuzzy_eids or ():
            if objn in eidn:
                return eid

        return tag_id

    _fuzzy_eids: list[tuple[str, str]] | None = None

    def _fuzzy_eids_init() -> None:
        nonlocal _fuzzy_eids
        _fuzzy_eids = []
        for st in hass.states.async_all():
            eidn = _norm(st.entity_id)
            if any(k in eidn for k in ("area", "room", "bermuda", "ble", "beacon", "tag")):
                _fuzzy_eids.append((st.entity_id, eidn))

    mapped = 0

    def _add_tag(entity_id: str, st: Any, room: str) -> None:
        nonlocal mapped
        tag_label = st.attributes.get('friendly_name') or entity_id.split('.', 1)[-1]

        extra: dict[str, Any] = {}
        for k in ('nearest_receiver', 'receiver', 'rssi', 'distance', 'gateway',
                   'mac_address', 'address', 'mac', 'scanner', 'scanners'):
            if k in (st.attributes or {}):
                extra[k] = st.attributes.get(k)

        tags.append({
            'entity_id': entity_id,
            'name': str(tag_label),
            'room': room,
            'state': st.state,
            **extra,
        })

        room_tag_map_live.setdefault(room, []).append(entity_id)
        mapped += 1

    cand = 0
    _bermuda_best: dict[str, tuple[int, str, Any, str]] = {}   # device_id -> best entity
    # Bermuda devices that have an Area sensor (whatever it reads right now).
    _bermuda_area_devices: set[str] = set()
    if _all_bermuda_entry_ids:
        try:
            for _st0 in hass.states.async_all("sensor"):
                if _st0.entity_id.endswith("_area"):
                    _e0 = er.async_get(_st0.entity_id)
                    if _e0 and _e0.device_id and _e0.config_entry_id in _all_bermuda_entry_ids:
                        _bermuda_area_devices.add(_e0.device_id)
        except Exception:
            pass

    def _bermuda_never_an_object(entity_id: str, attrs: Any, device_id: str) -> bool:
        """A Bermuda device's entity that never becomes its object. The
        selection below and the object-history purge both ask this, so what
        one skips the other cannot replay."""
        if "area_scanner_name" in attrs or "_distance_to_" in entity_id:
            return True
        # A device with an Area sensor is that sensor alone: it reads
        # the current room, and "unknown" when the device is out of
        # range - absent, not moved. Picking by state swapped to Area
        # Last Seen while away and back again on return, leaving a
        # second object in the old room.
        return device_id in _bermuda_area_devices and not entity_id.endswith("_area")

    try:
        for st in hass.states.async_all():
            entity_id = st.entity_id
            _ent_entry = None

            # Skip our own derived sensor/tracker entities (area, distance) — they are
            # characteristics of BLE objects already in section B/C of the objects list.
            # Including them would show "Dog Distance" and "Dog Area" as separate "objects".
            try:
                _ent_entry = er.async_get(entity_id)
                if _ent_entry and _ent_entry.platform == DOMAIN:
                    continue
            except Exception:
                pass

            # Determine room/area first (state often contains the room name).
            room = _room_from_state(entity_id, st)
            if not room:
                continue

            # Bermuda Ignore covers both checks: the room-tracker one matched
            # every sensor.*_area_last_seen, so ignored Bermuda still came in.
            _from_bermuda = bool(_ent_entry and _ent_entry.config_entry_id in _all_bermuda_entry_ids)
            if _bermuda_ignore and _from_bermuda:
                continue

            # Candidate filter: accept Bermuda (by config_entry), common '*_area_last_seen' patterns, or receiver/rssi hints.
            if not (_is_candidate(entity_id, st) or _looks_like_room_tracker(entity_id, st)):
                continue
            cand += 1

            # One Bermuda device, one object. Its Area and Floor sensors both
            # carry area_name, and each per-scanner "Distance to" sensor carries
            # the SCANNER's area: one phone became two objects, or two per
            # scanner (devices x scanners x 2) - each in a room of its own.
            if _from_bermuda and getattr(_ent_entry, "device_id", None):
                if _bermuda_never_an_object(entity_id, st.attributes or {}, _ent_entry.device_id):
                    continue
                _by_state = known_rooms.get(_norm(st.state)) is not None
                _rank = (0 if _by_state and "last_seen" not in entity_id
                         else 1 if _by_state else 2)
                _prev = _bermuda_best.get(_ent_entry.device_id)
                if _prev is not None and (_prev[0], _prev[1]) <= (_rank, entity_id):
                    continue
                _bermuda_best[_ent_entry.device_id] = (_rank, entity_id, st, room)
                continue

            _add_tag(entity_id, st, room)
        for _rank, entity_id, st, room in _bermuda_best.values():
            _add_tag(entity_id, st, room)
    except Exception:
        # If anything weird happens, keep the UI alive with whatever we collected.
        pass

    # --- Merge in configured tags (even if heuristics didn't find them) ---
    saved_total = 0
    saved_found = 0
    saved_missing = 0
    try:
        for room, ids in (saved_room_tag_map or {}).items():
            if not isinstance(ids, (list, tuple)):
                continue
            for tag_id in ids:
                if not isinstance(tag_id, str):
                    continue
                saved_total += 1
                resolved = _resolve_saved_entity_id(tag_id)
                st = hass.states.get(resolved)
                if st is None:
                    saved_missing += 1
                    tags.append(
                        {
                            "entity_id": resolved,
                            "name": tag_id,
                            "room": room,
                            "state": "unavailable",
                            "missing": True,
                            "source": "saved_map",
                        }
                    )
                    room_tag_map_missing.setdefault(room, []).append(resolved)
                    mapped += 1
                    continue

                saved_found += 1
                label = st.attributes.get("friendly_name") or getattr(st, "name", None) or tag_id
                tags.append(
                    {
                        "entity_id": resolved,
                        "name": str(label),
                        "room": room,
                        "state": st.state,
                        "source": "saved_map",
                    }
                )
                room_tag_map_live.setdefault(room, []).append(resolved)
                mapped += 1
    except Exception:
        pass

    # De-dupe tags by entity_id while keeping first occurrence
    seen = set()
    deduped: list[dict[str, Any]] = []
    for t in tags:
        eid = t.get("entity_id")
        if eid in seen:
            continue
        seen.add(eid)
        deduped.append(t)

    snapshot["tags"] = deduped
    snapshot["room_tag_map_saved"] = saved_room_tag_map
    snapshot["room_tag_map_missing"] = room_tag_map_missing
    snapshot["room_tag_map_live"] = room_tag_map_live
    snapshot["room_tag_map"] = room_tag_map_live
    snapshot["raw_counts"] = {
        "areas": len(snapshot.get("rooms_discovered") or []),
        "receivers": len(snapshot.get("receivers") or []),
        "candidate_entities": cand,
        "mapped_entities": mapped,
        "saved_entities_total": saved_total if 'saved_total' in locals() else 0,
        "saved_entities_found": saved_found if 'saved_found' in locals() else 0,
        "saved_entities_missing": saved_missing if 'saved_missing' in locals() else 0,
    }


    _sub_done("ha_tags")    # the walk over every state, saved tags

    # NOTE: snapshot["ble"] was already set at the top of this function.
    # Do NOT overwrite it here — a second bl.get_snapshot() call could return
    # empty data if get_bluetooth_live() returns None, wiping all BLE ads.

    # Attach area_name and device_id to radios (best-effort, from HA device_registry).
    #
    # Identity goes through RadioDeviceIndex, which matches whole names rather
    # than substrings of them. This used to take the first device whose name
    # merely appeared in the radio's, out of an unordered registry, so a proxy
    # called "btproxy" claimed "btproxy_livingroom" and "btproxy_kitchen" too
    # and all three showed the same area (issue #65). The area shown here is
    # also the area written by radio_area_set, which is why one bad rule moved
    # scanners in pairs.
    #
    # `device_match` records how each radio was identified, so the Health view
    # and the usage report can count collisions without anyone having to notice
    # and report one. It carries the reason only, never the colliding names.
    try:
        ar_reg = area_registry.async_get(hass)
        area_names = {a.id: a.name for a in ar_reg.async_list_areas()}
        index = RadioDeviceIndex(hass)
        # The registries' size, and the most devices sharing one name: the
        # match above was quadratic in that (fixed 0.38.136), and a slow "ha"
        # phase on some Bermuda houses is still unexplained (opt-in report).
        # Counted only while the report is on: each is a pass over every device.
        from .telemetry import enabled as _telemetry_on  # noqa: PLC0415
        if _telemetry_on(hass):
            record_duration(hass, "ha_devices", float(index.devices_n))
            record_duration(hass, "dev_dup", float(index.same_name_max))
            record_duration(hass, "ha_entities", float(len(entity_registry.async_get(hass).entities)))
        for radio in ((snapshot.get("ble") or {}).get("radios") or []):
            match = index.resolve(radio.get("source"), radio.get("name"))
            radio["device_match"] = match.reason
            if match.device is not None:
                if not radio.get("device_id"):
                    radio["device_id"] = match.device.id
                area_id = index.area_id_of(match.device)
                if not radio.get("area_name") and area_id:
                    area = area_names.get(area_id, "")
                    if area:
                        radio["area_name"] = area
            radio["display_name"], radio["name_from"] = radio_display(radio, match.device)
        # The two Shelly rules' use, for the opt-in report (telemetry.py
        # health.radios_shelly_mac / radios_area_via). Counts, never names.
        (snapshot.setdefault("ble", {}))["shelly_rules"] = {"mac": index.shelly_matched, "area_via": index.area_from_via}
    except Exception:
        pass

    # Attach network info (IP, WiFi SSID) from entity states for each radio's device
    try:
        import re as _re
        er_net = entity_registry.async_get(hass)

        # Strategy 1: device_id based lookup (most reliable when device_id is set)
        dev_entities: dict[str, list] = {}
        for ent in er_net.entities.values():
            if ent.device_id:
                dev_entities.setdefault(ent.device_id, []).append(ent)

        # Strategy 2: entity slug prefix lookup (works even without device_id)
        # ESPHome entities follow the pattern: sensor.<slug>_ip_address, etc.
        # Build a map from slug prefix → list of entity entries
        # Radio name "Office Proxy" → slug "office_proxy"
        def _name_to_slug(name: str) -> str:
            return _re.sub(r"[^a-z0-9]+", "_", name.lower()).strip("_")

        def _find_net_entities(radio: dict) -> list:
            """Find network-related entities for a radio via device_id or name/source slug."""
            candidates: list = []
            # Try device_id first
            did = radio.get("device_id")
            if did and did in dev_entities:
                candidates = dev_entities[did]
            # Fallback: search by entity slug prefix matching radio name or source
            if not candidates:
                slugs_to_try = set()
                rname = radio.get("name") or ""
                rsource = radio.get("source") or ""
                if rname:
                    slugs_to_try.add(_name_to_slug(rname))
                if rsource:
                    slugs_to_try.add(_name_to_slug(rsource))
                for slug in slugs_to_try:
                    if slug and len(slug) >= 3:
                        candidates.extend(_net_by_slug().get(slug, ()))
                    if candidates:
                        break
            return candidates

        # sensor./text_sensor. network entities by every "_"-prefix of their
        # object id, built once per build: the fallback walked the whole entity
        # registry per slug per radio (Bermuda adds devices x scanners x 2
        # rows; 25,000 rows x 20 radios was 240 ms a build). Only entities
        # _apply_net_info can use are indexed.
        _net_idx: dict[str, list] = {}
        _net_idx_built: list[bool] = [False]

        def _net_by_slug() -> dict[str, list]:
            if not _net_idx_built[0]:
                _net_idx_built[0] = True
                for ent in er_net.entities.values():
                    eid = ent.entity_id or ""
                    dom, _, obj_id = eid.partition(".")
                    if dom not in ("sensor", "text_sensor"):
                        continue
                    low = obj_id.lower()
                    if not any(k in low for k in ("ip", "ssid", "signal", "connection_type", "network_type")):
                        continue
                    parts = obj_id.split("_")
                    for i in range(1, len(parts)):
                        _net_idx.setdefault("_".join(parts[:i]), []).append(ent)
            return _net_idx

        def _apply_net_info(radio: dict, entities: list) -> None:
            """Copy IP/SSID/signal/connection-type fields onto `radio` from
            whichever candidate entities matched it, first-match-wins per
            field (radio.get(...) is only falsy the first time a field is
            filled). unknown/unavailable states are skipped so a proxy that
            hasn't reported yet doesn't stamp a permanent blank over a value
            a later entity in the list would have supplied.
            """
            for ent in entities:
                eid = ent.entity_id or ""
                eid_lower = eid.lower()
                st = hass.states.get(eid)
                if not st or st.state in ("unknown", "unavailable", ""):
                    continue
                val = st.state
                # IP address sensor
                if not radio.get("ip") and ("ip_address" in eid_lower or eid_lower.endswith("_ip")):
                    radio["ip"] = val
                # WiFi SSID sensor
                elif not radio.get("ssid") and ("ssid" in eid_lower):
                    radio["ssid"] = val
                # WiFi signal strength
                elif not radio.get("wifi_signal") and ("wifi_signal" in eid_lower or "signal_strength" in eid_lower):
                    try:
                        radio["wifi_signal"] = int(float(val))
                    except (ValueError, TypeError):
                        pass
                # Connection type (wired/wireless)
                elif not radio.get("connection_type") and ("connection_type" in eid_lower or "network_type" in eid_lower):
                    radio["connection_type"] = val

        for radio in ((snapshot.get("ble") or {}).get("radios") or []):
            ents = _find_net_entities(radio)
            if ents:
                _apply_net_info(radio, ents)
    except Exception:
        pass

    # Mark radios flagged as "lost" or "disabled" in PadSpan settings.
    # These sources are excluded from location math downstream (per-object
    # per-scanner RSSI maps + strongest-scanner fallback room assignment),
    # but stay in the radios list so the UI can show them as lost/disabled.
    _excluded_radio_srcs: set[str] = set()
    try:
        from .presence_rules import excluded_sources  # noqa: PLC0415

        _st = hass.data.get(DOMAIN, {}).get(DATA_SETTINGS, None)
        _settings_d = (_st.data if _st else {}) or {}
        lost_set     = _settings_d.get("lost_radios",     {}) or {}
        disabled_set = _settings_d.get("disabled_radios", {}) or {}
        # All three masks, not just the two that carry a UI badge. This set
        # decides which receivers may assign a room downstream, and it used to
        # omit `excluded_scanners` — so a receiver the user had explicitly
        # masked because it had physically MOVED went on placing objects.
        # lost_set/disabled_set stay separate below purely for the badges.
        _excluded_radio_srcs = set(excluded_sources(_settings_d))
        for radio in ((snapshot.get("ble") or {}).get("radios") or []):
            src = str(radio.get("source") or "")
            if src in lost_set:
                radio["lost"] = True
                radio["lost_since"] = lost_set[src].get("marked_at", "")
            if src in disabled_set:
                radio["disabled"] = True
                radio["disabled_since"] = disabled_set[src].get("marked_at", "")
    except Exception:
        pass

    # ---- Backwards-compatible aliases for the frontend ----
    # Some UI modules (overview, legacy panels) expect these keys.
    if "rooms" not in snapshot:
        snapshot["rooms"] = [{"name": r} for r in (snapshot.get("rooms_discovered") or [])]

    # Preserve the older "receivers" device list under a clearer name too.
    if "bermuda_devices" not in snapshot:
        snapshot["bermuda_devices"] = snapshot.get("receivers") or []

    _phase_done("ha")

    # --- Derived "objects" list (entities + BLE addresses) ---
    # This is the core data structure the UI consumes.  It merges three sources:
    #   (A) Entity-based objects (Bermuda device_trackers, sensors with area states)
    #   (B) Raw BLE advertisement objects (deduplicated by MAC address)
    #   (B2) Private BLE objects (rotating-MAC phones merged by IRK canonical_id)
    #   (C) iBeacon objects (merged by UUID:major:minor across rotating MACs)
    # After building, we run aggressive deduplication (D1-D7) to collapse duplicates
    # from MAC rotation, multi-protocol broadcasts, and Apple continuity noise.
    try:
        dr2 = device_registry.async_get(hass)
        er2 = entity_registry.async_get(hass)
        # Main devices by id (see util.ha_devices for why not dr2.async_get).
        dev_by_id = {dev.id: dev for dev in ha_devices(dr2)}

        # Build a quick map of Bluetooth address -> HA device (device_registry)
        addr_to_device: dict[str, dict[str, Any]] = {}
        for dev in dev_by_id.values():
            try:
                for (ctype, cid) in (dev.connections or set()):
                    if str(ctype) == "bluetooth" and isinstance(cid, str):
                        addr_to_device[cid.upper()] = {
                            "device_id": dev.id,
                            "name": dev.name_by_user or dev.name or dev.model or "",
                            "manufacturer": dev.manufacturer or "",
                            "model": dev.model or "",
                        }
            except Exception:
                continue

        # Map Bluetooth address -> tag entities that belong to the same HA device.
        addr_to_entities: dict[str, list[str]] = {}
        for t in (snapshot.get("tags") or []):
            eid = t.get("entity_id")
            if not eid:
                continue
            ent = er2.async_get(eid)
            if not ent or not ent.device_id:
                continue
            dev = dev_by_id.get(ent.device_id)
            if not dev:
                continue
            for (ctype, cid) in (dev.connections or set()):
                if str(ctype) == "bluetooth" and isinstance(cid, str):
                    addr_to_entities.setdefault(cid.upper(), []).append(eid)

        # Deduplicate advertisements by address (HA often reports same address via multiple scanners).
        ads = ((snapshot.get("ble") or {}).get("advertisements") or [])
        ble_by_addr: dict[str, dict[str, Any]] = {}
        from .findmy import is_findmy_address as _fm_addr, separated_report as _fm_separated  # noqa: PLC0415
        for a in ads:
            addr = str(a.get("address") or "").upper()
            if not addr:
                continue
            rec = ble_by_addr.get(addr)
            if not rec:
                rec = {
                    "address": addr,
                    "name": a.get("name") or "",
                    "rssi": a.get("rssi"),
                    "last_seen": a.get("last_seen"),
                    "age_s": a.get("age_s"),
                    "sources": {},  # source_name → {"rssi": ..., "age_s": ...}
                    "connectable": a.get("connectable"),
                    # Extra fields for identification hints (mirrors HA advertisement monitor).
                    # Copies: the rows are bluetooth_live's cached records
                    # (get_snapshot's rows share their dicts), and the merge
                    # below wrote every older row's payload INTO the freshest
                    # one — the report read an AirTag's hours-old payload as
                    # its latest (Find My review, 2026-09-27).
                    "manufacturer_data": dict(a.get("manufacturer_data") or {}),
                    "service_data": dict(a.get("service_data") or {}),
                    "service_uuids": list(a.get("service_uuids") or []),
                }
                ble_by_addr[addr] = rec

            src = a.get("source")
            # Scanners marked lost/disabled don't contribute to per-scanner
            # RSSI maps (excluded from location math; radios list unaffected).
            if src and str(src) not in _excluded_radio_srcs:
                src_key = str(src)
                a_rssi = a.get("rssi")
                a_age = a.get("age_s")
                prev = rec["sources"].get(src_key)
                if prev is None or (a_rssi is not None and (prev.get("rssi") is None or a_rssi > prev["rssi"])):
                    rec["sources"][src_key] = {"rssi": a_rssi, "age_s": a_age}

            # Merge identification hints (keep the richest set we have)
            try:
                # Name: prefer a real name over the MAC address
                ad_name = a.get("name") or ""
                cur_name = rec.get("name") or ""
                if ad_name and ad_name != addr and (not cur_name or cur_name == addr):
                    rec["name"] = ad_name

                md = a.get("manufacturer_data") or {}
                sd = a.get("service_data") or {}
                su = a.get("service_uuids") or []
                # Merge (not replace) so multi-protocol devices keep all data
                # e.g. same MAC broadcasting iBeacon + Eddystone
                if md:
                    rec.setdefault("manufacturer_data", {}).update(md)
                if sd:
                    rec.setdefault("service_data", {}).update(sd)
                if su:
                    existing = rec.setdefault("service_uuids", [])
                    for _u in su:
                        if _u not in existing:
                            existing.append(_u)
                # Connectable: prefer True over None
                ac = a.get("connectable")
                if ac is True or rec.get("connectable") is None:
                    rec["connectable"] = ac
                # A Find My device is away from its owner when ANY report
                # heard within LIVE_S says so — not the merged payload, one
                # arbitrary row's (findmy.separated_report()).
                if _fm_addr(addr) and _fm_separated(md, a.get("age_s")):
                    rec["findmy_separated"] = True
            except Exception:
                pass

            # Keep the most "useful" RSSI (largest / closest to 0).
            try:
                rssi = a.get("rssi")
                if rssi is not None and (rec.get("rssi") is None or rssi > rec.get("rssi")):
                    rec["rssi"] = rssi
            except Exception:
                pass

            # Keep newest last_seen (ISO8601 string; lexicographic compare works for same-format UTC stamps)
            try:
                ls = a.get("last_seen")
                if ls and (not rec.get("last_seen") or str(ls) > str(rec.get("last_seen"))):
                    rec["last_seen"] = ls
            except Exception:
                pass

            # Keep minimum age_s (lower == newer)
            try:
                age = a.get("age_s")
                if isinstance(age, (int, float)):
                    if rec.get("age_s") is None or age < rec.get("age_s"):
                        rec["age_s"] = age
            except Exception:
                pass

        # Count how often each OUI/prefix appears (useful heuristic: repeated prefixes often mean "a bunch of the same device type").
        prefix_counts: dict[str, int] = {}
        for addr in ble_by_addr.keys():
            parts = addr.split(":")
            if len(parts) >= 3:
                pfx = ":".join(parts[:3])
                prefix_counts[pfx] = prefix_counts.get(pfx, 0) + 1

        # --- Private BLE Device / IRK resolution ---
        # Modern phones (iOS 8+, Android 8+) rotate their BLE MAC every ~15 minutes.
        # The only way to identify them stably is via an IRK (Identity Resolving Key)
        # registered in HA's private_ble_device integration or in PadSpan settings.
        # We also parse Apple iBeacon UUIDs from manufacturer_data for Companion App phones.
        canonical_by_addr: dict[str, dict[str, Any]] = {}   # addr → {canonical_id, name, kind}
        ibeacon_groups: dict[str, dict[str, Any]] = {}       # "ibeacon:uuid:major:minor" → merged group
        ibeacon_addrs: set[str] = set()                      # MAC addresses absorbed into an iBeacon group
        # Memory per beacon identity. A pack keeps advertising the same
        # addresses; a rotator abandons each one after using it, so what is
        # still IN USE is what tells them apart. Read here, written once the
        # groups are built, so a mid-loop exception cannot leave a half-updated
        # view that makes the next poll's answer worse.
        #
        # Shape: {uuid_key: {"polls": int, "addrs": {mac: {"age": float,
        #                                                 "durable": bool}}}}
        #
        # This used to be a bare set of "addresses seen in the last 60s", and
        # that is issue #63. A rotator's abandoned address stays inside a 60s
        # staleness window for a dozen polls after it stops advertising, so
        # consecutive windows overlapped almost completely and every rotation
        # read as persistence. The unit tests never caught it because they pass
        # the previous POLL's addresses, which is the honest thing; only the
        # caller was lying.
        #
        # "Durable" is a property of an ADDRESS, not of a poll: an address is
        # durable once its age has been observed to DROP, which means the
        # device advertised on it again. A rotator's address is used once and
        # abandoned, so its age only ever climbs and it can never become
        # durable, at any rotation rate. A real beacon re-advertises whatever
        # its interval, so it becomes durable within a poll or two and STAYS
        # durable while it remains in the window — monotone, so a slow
        # advertiser cannot oscillate in and out of being a separate device.
        _beacon_last_macs: dict = hass.data.get(DOMAIN, {}).get(DATA_BEACON_LAST_MACS) or {}
        _beacon_seen_now: dict = {}
        # Ingest policy — the single point that decides whether an advertiser
        # becomes an object at all. Rebuilt every poll, like the excluded-
        # scanner set, so a change takes effect on the next snapshot rather
        # than at the next restart. See ingest_policy.py for why this is a
        # module: the cost of a device is its churn RATE, and a site cannot
        # enumerate MACs that change every second.
        try:
            _st_ing = hass.data.get(DOMAIN, {}).get(DATA_SETTINGS)
            _ingest = IngestPolicy.from_settings((_st_ing.data if _st_ing else {}) or {})
        except Exception:
            _ingest = IngestPolicy()
        _resolver_diag: dict[str, Any] = {"irk_devices": 0, "resolved": 0, "ibeacon_groups": 0, "rpa_count": 0, "crypto_ok": True, "errors": []}
        try:
            from .private_ble_resolver import crypto_available as _crypto_avail
            _resolver_diag["crypto_ok"] = _crypto_avail()
            resolver = await _get_ble_resolver(hass)
            _resolver_diag["irk_devices"] = resolver.device_count
            _resolver_diag["rpa_count"] = resolver.count_rpas(ble_by_addr.keys())
            if resolver.has_devices():
                for addr, rec in ble_by_addr.items():
                    resolved = resolver.resolve_address(addr)
                    if resolved:
                        canonical_by_addr[addr] = resolved
                _resolver_diag["resolved"] = len(canonical_by_addr)
        except Exception as _res_err:
            _resolver_diag["errors"].append(f"resolver: {_res_err}")
            _LOGGER.warning("Private BLE resolver error: %s", _res_err)

        # ── MAC Rotation Bridging ─────────────────────────────────────────
        # When an RPA disappears and a new one appears with matching advertisement
        # characteristics, tentatively link them so the UI can track continuity.
        # Only runs when the user has enabled the mac_rotation_bridging setting.
        try:
            _st_bridge = hass.data.get(DOMAIN, {}).get(DATA_SETTINGS)
            if _st_bridge and _st_bridge.get("mac_rotation_bridging"):
                _bridge_cache_key = "rotation_bridge_cache"
                _domain_data = hass.data.setdefault(DOMAIN, {})
                _bridge_cache: dict = _domain_data.setdefault(_bridge_cache_key, {})
                # {fingerprint_str: {"canonical": canonical_id, "addr": last_addr, "ts": timestamp}}

                import time as _time_mod
                _now_ts = _time_mod.time()
                _BRIDGE_STALE_S = 30  # only bridge if disappeared within last 30s

                # Purge stale entries (older than 30s)
                _stale_keys = [k for k, v in _bridge_cache.items() if _now_ts - v.get("ts", 0) > _BRIDGE_STALE_S]
                for _sk in _stale_keys:
                    del _bridge_cache[_sk]

                def _build_bridge_fingerprint(rec: dict) -> str | None:
                    """Build a fingerprint from advertisement characteristics.

                    None for an advertiser that names its own identity: an
                    iBeacon carries UUID/major/minor, and iBeacon grouping —
                    with the persistence-based pack/rotator split — owns that
                    identity. Bridging those by fingerprint duplicated that
                    machinery with a weaker test and, on a four-pack of CP27s
                    sharing one fingerprint, chained live beacons into one
                    object; and once bridged they were EXCLUDED from iBeacon
                    grouping as "IRK-resolved", so the right identity never
                    got its turn.
                    """
                    manuf = rec.get("manufacturer_data") or {}
                    if manuf and PrivateBLEResolver.parse_ibeacon(manuf):
                        return None  # an iBeacon has an identity; the bridge is for anonymous rotators
                    company_ids = sorted(str(k) for k in manuf.keys()) if manuf else []
                    svc_uuids = sorted(rec.get("service_uuids") or [])
                    connectable = rec.get("connectable")
                    if not company_ids and not svc_uuids:
                        return None  # not enough info to fingerprint
                    # Every Apple device shares company 76: its message type
                    # (0x10 an iPhone's Nearby Info, 0x07 AirPods, ...) keeps
                    # an iPhone from being chained onto AirPods.
                    from .findmy import apple_payload  # noqa: PLC0415
                    _ap = apple_payload(manuf)
                    _atype = f"|apple:{_ap[0]:02x}" if _ap else ""
                    return f"{','.join(company_ids)}|{','.join(svc_uuids)}|{connectable}{_atype}"

                # Update cache with currently-resolved addresses (so when they disappear, we remember)
                for addr, canonical in canonical_by_addr.items():
                    rec = ble_by_addr.get(addr)
                    if rec:
                        fp = _build_bridge_fingerprint(rec)
                        if fp:
                            _bridge_cache[fp] = {
                                "canonical": canonical["canonical_id"],
                                "addr": addr,
                                "ts": _now_ts,
                            }

                # Also seed from identified/labelled rotating devices WITHOUT an
                # IRK (AirTag/SmartTag-class trackers).  These rotate their MAC
                # too but never appear in canonical_by_addr, so without this
                # they could never be bridged.  Canonical id = the labelled MAC
                # itself: the label re-apply pass looks objects up in the
                # ObjectStore by canonical_id, so a bridged rotation keeps its
                # user label.
                _obj_store_br = hass.data.get(DOMAIN, {}).get(DATA_OBJECTS)
                for addr, rec in ble_by_addr.items():
                    if addr in canonical_by_addr:
                        continue  # IRK-resolved — seeded above
                    if not _is_rpa_addr(addr):
                        continue  # static MAC — nothing to bridge
                    if not (
                        addr in addr_to_device
                        or addr in addr_to_entities
                        or (_obj_store_br and _obj_store_br.get_label(addr))
                    ):
                        continue  # unidentified — no stable identity to carry over
                    _seed_age = rec.get("age_s")
                    if isinstance(_seed_age, (int, float)) and _seed_age > _BRIDGE_STALE_S:
                        continue  # long silent — outside the bridge window
                    fp = _build_bridge_fingerprint(rec)
                    if not fp:
                        continue
                    _existing = _bridge_cache.get(fp)
                    if _existing and _existing.get("canonical") != addr:
                        continue  # entry belongs to another device or a fired bridge
                    _bridge_cache[fp] = {"canonical": addr, "addr": addr, "ts": _now_ts}

                # Try to bridge unresolved RPAs
                for addr, rec in ble_by_addr.items():
                    if addr in canonical_by_addr:
                        continue  # already resolved
                    if not _is_rpa_addr(addr):
                        continue  # not a rotating address
                    # An address with its own identity (a label, an HA device
                    # or entity) is its own device: bridged, Bob's labelled tag
                    # was shown as "Alice tag" at Bob's location whenever
                    # Alice's tag was quiet for a few seconds.
                    if (addr in addr_to_device or addr in addr_to_entities
                            or (_obj_store_br and _obj_store_br.get_label(addr))):
                        continue
                    fp = _build_bridge_fingerprint(rec)
                    if not fp:
                        continue
                    cached_entry = _bridge_cache.get(fp)
                    if not cached_entry:
                        continue
                    if cached_entry["addr"] == addr:
                        # Same address seen again — refresh ts so the entry
                        # doesn't purge as stale after _BRIDGE_STALE_S while
                        # the device is still advertising.
                        cached_entry["ts"] = _now_ts
                        if cached_entry["canonical"] == addr:
                            continue  # self-seeded entry — no rotation yet
                        # Previously-fired bridge: fall through and re-apply
                        # the canonical mapping (canonical_by_addr is rebuilt
                        # from scratch every snapshot).
                    else:
                        # A bridge is a HAND-OVER: the address it bridges from
                        # must have stopped. Two addresses live at once are two
                        # devices, whatever their fingerprints say — see
                        # beacon_identity.rotation_bridge_allowed.
                        _old_rec = ble_by_addr.get(cached_entry["addr"])
                        _old_age = _old_rec.get("age_s") if _old_rec else None
                        if rotation_bridge_allowed(
                                _old_age if isinstance(_old_age, (int, float)) else None).split:
                            continue
                    # Sources is a dict {source_name: {rssi, age_s}} at this point
                    # Bridge if fingerprint matches (RSSI overlap is best-effort)
                    canonical_by_addr[addr] = {
                        "canonical_id": cached_entry["canonical"],
                        "name": cached_entry["canonical"],
                        "kind": "private_ble",
                        "bridge_match": True,
                    }
                    # Update cache with the new address
                    _bridge_cache[fp] = {
                        "canonical": cached_entry["canonical"],
                        "addr": addr,
                        "ts": _now_ts,
                    }
        except Exception as _bridge_err:
            _LOGGER.debug("MAC rotation bridging error: %s", _bridge_err)

        # ── Find My tags across address changes (findmy.py) ──────────────
        try:
            _st_fm = hass.data.get(DOMAIN, {}).get(DATA_SETTINGS)
            if _st_fm and _st_fm.get("mac_rotation_bridging"):
                await _findmy_step(hass, ble_by_addr, canonical_by_addr, addr_to_device, addr_to_entities,
                                   reseed_s=((snapshot.get("ble") or {}).get("diag") or {}).get("reseed_interval_s"))
            elif hass.data.get(DOMAIN, {}).get(_FINDMY) is not None:
                # Off: a hand-over now is one the bridge never sees — the
                # report must not file it as a miss once it is back on.
                hass.data[DOMAIN][_FINDMY].unwatched(time.time())
        except Exception as _fm_err:
            _LOGGER.debug("Find My bridging error: %s", _fm_err)

        # Parse iBeacon from every advertisement; group by stable UUID/major/minor key.
        # This is deliberately OUTSIDE the resolver try/except so iBeacon detection
        # never gets silently skipped if the private BLE resolver has issues.
        # IMPORTANT: MACs that resolve to a private_ble device (via IRK) are NOT
        # absorbed into iBeacon groups — the IRK identity is authoritative.  The
        # iBeacon metadata (UUID/major/minor) is attached to the private_ble object
        # later instead.  This prevents the phone from existing as two separate
        # objects (one iBeacon, one private_ble) and getting "lost" on MAC rotation.
        _ibeacon_meta_for_private: dict[str, dict[str, Any]] = {}  # canonical_id → iBeacon info
        try:
            _ib_resolver = await _get_ble_resolver(hass)
            for addr, rec in ble_by_addr.items():
                ib = _ib_resolver.parse_ibeacon(rec.get("manufacturer_data") or {})
                if ib:
                    # If this MAC also resolves to a private_ble device, DON'T absorb
                    # it into the iBeacon group — let private_ble grouping handle it.
                    canonical = canonical_by_addr.get(addr)
                    if canonical:
                        cid = canonical["canonical_id"]
                        _ibeacon_meta_for_private[cid] = ib
                        continue
                    uuid_key = f"ibeacon:{ib['uuid']}:{ib['major']}:{ib['minor']}"
                    # Masked BEFORE the group is built, so a device rotating its
                    # address every 1.6 seconds costs nothing rather than being
                    # filtered out later at full price. Marked absorbed too, or
                    # it would simply reappear as a bare MAC object.
                    if _ingest.active and _ingest.is_masked(_IngestIdentity(
                            addr=addr, key=uuid_key, uuid=str(ib.get("uuid") or ""))):
                        ibeacon_addrs.add(addr)
                        continue
                    ibeacon_addrs.add(addr)
                    if uuid_key not in ibeacon_groups:
                        ibeacon_groups[uuid_key] = {
                            "uuid": ib["uuid"],
                            "major": ib["major"],
                            "minor": ib["minor"],
                            "tx_power": ib.get("tx_power"),  # factory-calibrated TX power from iBeacon payload
                            "addrs": set(),
                            "sources": [],
                            "_rssi_list": [],
                        }
                    g = ibeacon_groups[uuid_key]
                    g["addrs"].add(addr)
                    for src_key, src_info in (rec.get("sources") or {}).items():
                        g["sources"].append({"source": src_key, **(src_info if isinstance(src_info, dict) else {})})
                    rssi = rec.get("rssi")
                    if rssi is not None:
                        g["_rssi_list"].append((rssi, rec.get("age_s")))
            # Finalise each group: pick best RSSI, sort addrs, deduplicate sources
            # Split groups where multiple MACs are simultaneously active (separate
            # physical devices sharing factory-default UUID:major:minor, e.g. CP27).
            _split_groups: dict[str, dict] = {}
            for uuid_key, g in list(ibeacon_groups.items()):
                rssi_list = g.pop("_rssi_list")
                if rssi_list:
                    # age_s = freshest reading (lowest age) across all MACs.
                    # rssi  = strongest signal among recent readings (within 60s
                    #         of freshest) so stale rotated-out MACs don't win.
                    ages = [a for _, a in rssi_list if a is not None]
                    min_age = min(ages) if ages else None
                    g["age_s"] = min_age
                    if min_age is not None:
                        cutoff = min_age + 60
                        recent = [r for r, a in rssi_list if a is not None and a <= cutoff]
                        g["rssi"] = max(recent) if recent else max(r for r, _ in rssi_list)
                    else:
                        g["rssi"] = max(r for r, _ in rssi_list)
                else:
                    g["rssi"] = None; g["age_s"] = None
                g["addrs"] = sorted(g["addrs"])
                # Deduplicate sources by scanner — prefer freshest reading per
                # source (consistent with private_ble merge strategy). Stale
                # strong readings from old MACs shouldn't win over fresh ones.
                dedup_map: dict[str, dict] = {}
                for s in g["sources"]:
                    sk = s.get("source", "")
                    prev = dedup_map.get(sk)
                    if prev is None:
                        dedup_map[sk] = s
                    else:
                        s_age = s.get("age_s")
                        p_age = prev.get("age_s")
                        # Prefer fresher (lower age_s); tie-break on stronger RSSI
                        if s_age is not None and (p_age is None or s_age < p_age):
                            dedup_map[sk] = s
                        elif s_age == p_age:
                            s_rssi = s.get("rssi")
                            if s_rssi is not None and (prev.get("rssi") is None or s_rssi > prev["rssi"]):
                                dedup_map[sk] = s
                g["sources"] = sorted(dedup_map.values(), key=lambda x: x.get("source", ""))

                # Detect simultaneous MACs → split into per-MAC objects.
                # If multiple MACs are all recently seen (age < 60s), they are
                # distinct physical devices, not MAC rotation on a single device.
                # EXCEPTION: Phones rotate their MAC every ~15 min.  During the
                # rotation window both old and new MACs are age < 60s.  If ALL
                # recent MACs are RPAs (Resolvable Private Addresses = rotating),
                # they almost certainly belong to a single phone — do NOT split.
                # Recorded for EVERY identity, not only the ones that are
                # ambiguous today. A beacon showing one address this poll and
                # three the next is exactly the case the persistence test
                # exists for, and it can only answer if the quiet poll was
                # written down too.
                _recent_all = [
                    a for a in g["addrs"]
                    if (ble_by_addr.get(a, {}).get("age_s") or 9999) < 60
                ]
                # Carry each address's durability forward, and set it the
                # first time the address is seen to have re-advertised.
                _beacon_seen_now[uuid_key] = _update_address_memory(
                    _beacon_last_macs.get(uuid_key),
                    _recent_all,
                    {a: ble_by_addr.get(a, {}).get("age_s") for a in _recent_all},
                )
                if len(g["addrs"]) > 1:
                    recent_macs = _recent_all
                    # One beacon wearing many addresses, or many beacons sharing
                    # one identity? The address heuristics below cannot tell
                    # those apart on their own — see beacon_identity.py — so the
                    # decision is made from whether the addresses PERSIST across
                    # polls, and the heuristics are what it falls back to before
                    # there is any history to read.
                    _all_rpa = all(_is_rpa_addr(m) for m in recent_macs) if recent_macs else False
                    _is_default_uuid = str(g.get("uuid") or "").lower() in _DEFAULT_IBEACON_UUIDS
                    _same_oui = len({m[:9] for m in recent_macs}) == 1 if len(recent_macs) > 1 else False
                    # Only DURABLE addresses count as persistence. An identity
                    # never seen before has no memory at all (None -> the
                    # first-sighting heuristics); one seen only briefly has
                    # memory but nothing durable yet, which is indistinguishable
                    # from a rotator until it has been watched a few polls —
                    # `settled` is what stops a real pack being merged for a
                    # second before it splits again.
                    _prev = _beacon_last_macs.get(uuid_key)
                    _split_decision = _decide_beacon_split(
                        recent_macs,
                        _durable_addresses(_prev),
                        all_rpa=_all_rpa,
                        default_uuid=_is_default_uuid,
                        same_oui=_same_oui,
                        settled=_memory_is_settled(_prev, _SETTLED_POLLS),
                    )
                    _resolver_diag.setdefault("split_reasons", {})[uuid_key[:48]] = _split_decision.reason
                    if _split_decision.split:
                        # Multiple distinct devices — split each MAC into its own object
                        for idx, mac in enumerate(recent_macs):
                            rec = ble_by_addr.get(mac, {})
                            split_key = f"{uuid_key}:{mac}"
                            # Use the sources from this specific MAC's advertisement
                            mac_src_dict = rec.get("sources") or {}
                            mac_sources = [{"source": k, **(v if isinstance(v, dict) else {})} for k, v in mac_src_dict.items()]
                            _split_groups[split_key] = {
                                "uuid": g["uuid"],
                                "major": g["major"],
                                "minor": g["minor"],
                                "tx_power": g.get("tx_power"),
                                "addrs": [mac],
                                "sources": mac_sources,
                                "rssi": rec.get("rssi"),
                                "age_s": rec.get("age_s"),
                                "_split_from": uuid_key,
                            }
                        # Also keep stale MACs (age >= 60s) in the original group
                        stale = [a for a in g["addrs"] if a not in recent_macs]
                        if stale:
                            g["addrs"] = stale
                        else:
                            # All MACs split out — remove original group
                            del ibeacon_groups[uuid_key]
                        continue
            # Merge split groups into main dict
            ibeacon_groups.update(_split_groups)
            _resolver_diag["ibeacon_groups"] = len(ibeacon_groups)
            # Commit this poll's view for the next one to compare against.
            # Only identities seen this poll are carried forward, so a beacon
            # that goes away stops occupying memory and is treated as new when
            # it returns — which is the right answer after an unknown gap.
            if _beacon_seen_now:
                hass.data.setdefault(DOMAIN, {})[DATA_BEACON_LAST_MACS] = _beacon_seen_now
        except Exception as _ib_err:
            _resolver_diag["errors"].append(f"ibeacon: {_ib_err}")

        # (B) BLE advertisement objects (what HA Bluetooth "Advertisement monitor" shows)
        # Group private_ble addresses by canonical_id so rotating MACs merge
        # into ONE object per physical device (like iBeacon merging above).
        # NOTE: _private_groups MUST be initialized before section A because
        # section A references it to link entity objects to private_ble devices.
        _private_groups: dict[str, dict[str, Any]] = {}  # canonical_id → merged info
        for addr, rec in ble_by_addr.items():
            if addr in ibeacon_addrs:
                continue  # absorbed into a merged iBeacon group (section C)
            # A device with no beacon identity can still be masked — by its own
            # MAC if it is static, or by vendor prefix. Checked here as well as
            # at the iBeacon grouping because these are two separate ways to
            # become an object, and a mask that only covered one of them would
            # look like it had stopped working.
            if _ingest.active:
                canonical_for_mask = canonical_by_addr.get(addr) or {}
                if _ingest.is_masked(_IngestIdentity(
                        addr=addr,
                        key=str(canonical_for_mask.get("canonical_id") or ""),
                        name=str(rec.get("name") or ""))):
                    continue
            canonical = canonical_by_addr.get(addr)
            if canonical:
                cid = canonical["canonical_id"]
                if cid not in _private_groups:
                    _private_groups[cid] = {
                        "canonical": canonical,
                        "addrs": [],
                        "all_sources": {},  # source_name → {"rssi": ..., "age_s": ...}
                        "all_linked": set(),
                        "best_rssi": -999,
                        "best_rec": rec,
                        "best_addr": addr,
                        "freshest_age": None,   # minimum age_s across all rotating MACs
                        "freshest_rec": None,    # record with the freshest observation
                        "device": None,
                        "manufacturer_data": {},
                        "service_data": {},
                        "service_uuids": [],
                    }
                pg = _private_groups[cid]
                # A group is a bridge guess only if none of its addresses
                # resolved for real: a bridged address met first made an IRK
                # phone heard on its own address a guess (unidentified, and
                # dropped from occupancy's people).
                if pg["canonical"].get("bridge_match") and not canonical.get("bridge_match"):
                    pg["canonical"] = canonical
                pg["addrs"].append(addr)
                # Per-source merge: prefer the FRESHEST (lowest age_s) reading
                # per scanner source across all rotating MACs — not the strongest
                # RSSI, which may come from a stale MAC the phone stopped using.
                for src_key, src_info in (rec.get("sources") or {}).items():
                    prev = pg["all_sources"].get(src_key)
                    si = src_info if isinstance(src_info, dict) else {"rssi": None, "age_s": None}
                    if prev is None:
                        pg["all_sources"][src_key] = si
                    else:
                        s_age = si.get("age_s")
                        p_age = prev.get("age_s")
                        # Prefer lower age (fresher); fall back to stronger RSSI if ages equal/missing
                        if s_age is not None and (p_age is None or s_age < p_age):
                            pg["all_sources"][src_key] = si
                        elif s_age == p_age:
                            s_rssi = si.get("rssi")
                            if s_rssi is not None and (prev.get("rssi") is None or s_rssi > prev["rssi"]):
                                pg["all_sources"][src_key] = si
                for e in addr_to_entities.get(addr, []):
                    pg["all_linked"].add(e)
                # Track best RSSI for address/signal display
                rssi = rec.get("rssi")
                if rssi is not None and rssi > pg["best_rssi"]:
                    pg["best_rssi"] = rssi
                    pg["best_rec"] = rec
                    pg["best_addr"] = addr
                # Track freshest record (minimum age_s) for last_seen/age reporting.
                # This is the critical fix: a phone's newest rotating MAC has age≈0
                # even if an older MAC with stronger RSSI has age>>0.
                age = rec.get("age_s")
                if age is not None and (pg["freshest_age"] is None or age < pg["freshest_age"]):
                    pg["freshest_age"] = age
                    pg["freshest_rec"] = rec
                if not pg["device"] and addr in addr_to_device:
                    pg["device"] = addr_to_device[addr]
                # Merge BLE metadata
                pg["manufacturer_data"].update(rec.get("manufacturer_data") or {})
                pg["service_data"].update(rec.get("service_data") or {})
                for u in (rec.get("service_uuids") or []):
                    if u not in pg["service_uuids"]:
                        pg["service_uuids"].append(u)

        objects: list[dict[str, Any]] = []

        # (A) Entity-based objects (bermuda tags, device_trackers, etc.)
        _MAC_RE = __import__("re").compile(r"^([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}$")
        for t in (snapshot.get("tags") or []):
            eid = t.get("entity_id") or ""
            addr = ""
            all_addrs: list[str] = []
            canonical_id = ""
            try:
                ent = er2.async_get(eid)
                if ent and ent.device_id:
                    dev = dev_by_id.get(ent.device_id)
                    if dev:
                        # 1) Check device connections for a static BLE MAC
                        for (ctype, cid) in (dev.connections or set()):
                            if str(ctype) == "bluetooth" and isinstance(cid, str):
                                addr = cid.upper()
                                break

                        # 2) Check device identifiers — Bermuda stores MAC as
                        #    ("bermuda", "AA:BB:CC:DD:EE:FF") identifier
                        if not addr:
                            for (domain, ident) in (dev.identifiers or set()):
                                ident_s = str(ident)
                                if _MAC_RE.match(ident_s):
                                    addr = ident_s.upper()
                                    break

                        # 3) Match to private_ble objects by device_id
                        if not addr:
                            for _cid, pg in _private_groups.items():
                                # pg["device"] is an addr_to_device entry: its
                                # id is "device_id" (it read "id", never there)
                                _pg_dev = pg.get("device")
                                if _pg_dev and _pg_dev.get("device_id") == ent.device_id:
                                    canonical_id = _cid
                                    addr = pg["best_addr"].upper() if pg.get("best_addr") else ""
                                    all_addrs = sorted(pg.get("addrs") or [])
                                    break

                        # (A "4) match regular BLE objects by device_id" step
                        # stood here: a walk over every Bluetooth device in
                        # addr_to_device for each tag, comparing a "id" key
                        # those entries do not have ("device_id"). It never
                        # matched — and could add nothing if it did: the map
                        # is built from the same dev.connections step 1 just
                        # read for this device. With Bermuda, tags and devices
                        # both run to the thousands; removed in 0.38.108.)

                # 5) Check entity state attributes for MAC address hints
                #    Bermuda entities often expose mac_address/address in attributes
                if not addr:
                    _st = hass.states.get(eid)
                    if _st:
                        for _attr_key in ("mac_address", "address", "mac"):
                            _attr_val = (_st.attributes or {}).get(_attr_key)
                            if isinstance(_attr_val, str) and _MAC_RE.match(_attr_val):
                                addr = _attr_val.upper()
                                break
            except Exception:
                addr = ""

            prefix = ":".join(addr.split(":")[:3]) if addr else ""
            _ent_obj: dict[str, Any] = {
                "key": f"entity:{eid}",
                "kind": "entity",
                "entity_id": eid,
                "name": t.get("name") or eid,
                "state": t.get("state"),
                "room": t.get("room"),
                "missing": bool(t.get("missing")),
                "address": addr or None,
                "prefix": prefix or None,
                "prefix_count": prefix_counts.get(prefix, 0) if prefix else 0,
                "identified": True,
            }
            if canonical_id:
                _ent_obj["canonical_id"] = canonical_id
            if all_addrs:
                _ent_obj["all_addresses"] = all_addrs
            objects.append(_ent_obj)

        # (B-cont) Regular (non-rotating, non-iBeacon) BLE advertisement objects
        for addr, rec in ble_by_addr.items():
            if addr in ibeacon_addrs:
                continue  # absorbed into a merged iBeacon group (section C)
            if canonical_by_addr.get(addr):
                continue  # handled by _private_groups (section B2)
            # Skip unresolved RPAs (rotating MACs from phones/watches that
            # aren't resolved by IRK and aren't part of an iBeacon group).
            # These are noise — duplicate entries from the same phone's non-
            # iBeacon advertisements, or from neighbors' devices.  Without
            # IRK they can't be merged and just clutter the device list.
            # EXEMPTION: keep devices that advertise a local name.  Phones'
            # rotating-RPA adverts are anonymous; a named advertiser is almost
            # always real hardware whose public OUI (0x40-0x7F first octet)
            # false-positives in _is_rpa_addr() — e.g. DX-brand 48:87:2D gear.
            if (
                _is_rpa_addr(addr)
                and addr not in addr_to_device
                and addr not in addr_to_entities
                and not str(rec.get("name") or "").strip()
            ):
                continue

            # Regular (non-rotating) BLE object
            parts = addr.split(":")
            prefix = ":".join(parts[:3]) if len(parts) >= 3 else ""
            identified = (addr in addr_to_device) or (addr in addr_to_entities)

            obj: dict[str, Any] = {
                "key": f"ble:{addr}",
                "kind": "ble",
                "address": addr,
                "name": rec.get("name") or addr,
                "rssi": rec.get("rssi"),
                "last_seen": rec.get("last_seen"),
                "age_s": rec.get("age_s"),
                "sources": sorted(
                    [{"source": k, "rssi": v.get("rssi"), "age_s": v.get("age_s")} for k, v in (rec.get("sources") or {}).items()],
                    key=lambda x: x["source"],
                ),
                "manufacturer_data": rec.get("manufacturer_data") or {},
                "service_data": rec.get("service_data") or {},
                "service_uuids": rec.get("service_uuids") or [],
                "connectable": rec.get("connectable"),
                "prefix": prefix or None,
                "prefix_count": prefix_counts.get(prefix, 0),
                "identified": bool(identified),
                "linked_entities": sorted(list(set(addr_to_entities.get(addr, [])))),
                "device": addr_to_device.get(addr),
            }
            objects.append(obj)

        # (B2) Merged private_ble objects — one per canonical_id (phone identity)
        for cid, pg in _private_groups.items():
            canonical = pg["canonical"]
            # Use the freshest record for age/last_seen (not the strongest RSSI record)
            # — a phone's newest rotating MAC has age≈0 but may have weaker RSSI.
            freshest = pg.get("freshest_rec")
            rec = freshest if freshest else pg["best_rec"]
            addr = pg["best_addr"]
            # A Find My tag (findmy.py) is the address the person named and
            # followed it by — every view keys Follow, alerts and pins on
            # o.address — with its live address beside it. Its lingering old
            # addresses hold frozen, often stronger, readings: signal comes
            # from the freshest record, never the strongest (round 8).
            _fm_obj = bool(canonical.get("findmy"))
            _fm_cur = None
            if _fm_obj:
                from .findmy import LIVE_S as _FM_LIVE_S  # noqa: PLC0415
                addr = cid
                # Signal, age and sources from the address the bridge says is
                # current, while it is being heard — a lingering old one holds
                # frozen readings. Not heard: the freshest of the tag's own
                # addresses that is (a tag back on an earlier key before the
                # bridge has confirmed it — round 11).
                _fm_cur = canonical.get("current") or rec.get("address")
                _cur_rec = ble_by_addr.get(_fm_cur)
                if not (_cur_rec and float(_cur_rec.get("age_s") or 0) <= _FM_LIVE_S):
                    _fr = pg.get("freshest_rec")
                    if _fr and float(_fr.get("age_s") if _fr.get("age_s") is not None else 1e9) <= _FM_LIVE_S:
                        _cur_rec, _fm_cur = _fr, _fr.get("address") or _fm_cur
                if _cur_rec:
                    rec = _cur_rec
            parts = addr.split(":")
            prefix = ":".join(parts[:3]) if len(parts) >= 3 else ""
            obj_pb: dict[str, Any] = {
                # STABLE key — survives address rotation. A Find My tag keeps
                # the key it had on its first address (findmy.py).
                "key": canonical.get("key") or cid,
                "kind": "private_ble",
                "address": addr,  # current best (strongest signal) rotating MAC
                "canonical_id": cid,
                "private_ble_name": canonical["name"],
                "all_addresses": sorted(pg["addrs"]),  # all rotating MACs seen this cycle
                "name": canonical.get("name") or rec.get("name") or addr,
                "rssi": rec.get("rssi") if _fm_obj else (pg["best_rssi"] if pg["best_rssi"] > -999 else rec.get("rssi")),
                "last_seen": rec.get("last_seen"),
                "age_s": rec.get("age_s") if _fm_obj else (pg["freshest_age"] if pg["freshest_age"] is not None else rec.get("age_s")),
                "sources": sorted(
                    [{"source": k, "rssi": v.get("rssi"), "age_s": v.get("age_s")}
                     for k, v in ((rec.get("sources") or {}) if _fm_obj else pg["all_sources"]).items()
                     if isinstance(v, dict)],
                    key=lambda x: x["source"],
                ),
                "manufacturer_data": pg["manufacturer_data"],
                "service_data": pg["service_data"],
                "service_uuids": pg["service_uuids"],
                "connectable": rec.get("connectable"),
                "prefix": prefix or None,
                "prefix_count": prefix_counts.get(prefix, 0),
                "identified": bool(pg["device"] or pg["all_linked"]),
                "linked_entities": sorted(pg["all_linked"]),
                "device": pg["device"],
            }
            # Mark bridge-matched objects so the UI knows they're probabilistic
            # — and that a guess is not an identity: a device link found under
            # one of its addresses does not make the bridge "identified".
            if canonical.get("bridge_match"):
                obj_pb["bridge_match"] = True
                obj_pb["identified"] = False
            if _fm_obj:
                obj_pb["findmy"] = True
                obj_pb["current_address"] = _fm_cur
            # Attach iBeacon metadata if this private_ble device also broadcasts
            # as an iBeacon (e.g. HA Companion App "Track Phone").
            _ib_meta = _ibeacon_meta_for_private.get(cid)
            if _ib_meta:
                obj_pb["ibeacon_uuid"] = _ib_meta["uuid"]
                obj_pb["ibeacon_major"] = _ib_meta["major"]
                obj_pb["ibeacon_minor"] = _ib_meta["minor"]
                if _ib_meta.get("tx_power") is not None:
                    obj_pb["tx_power"] = _ib_meta["tx_power"]
            objects.append(obj_pb)

        # (C) iBeacon objects — one per UUID/major/minor key, merged from all rotating MACs
        _obj_store_c = hass.data.get(DOMAIN, {}).get(DATA_OBJECTS)
        for uuid_key, g in ibeacon_groups.items():
            all_linked: list[str] = sorted({
                e for a in g["addrs"] for e in addr_to_entities.get(a, [])
            })
            identified_ib = any(a in addr_to_device for a in g["addrs"]) or bool(all_linked)
            # Use persisted user label as display name if available (prevents flickering)
            _ib_label = None
            if _obj_store_c:
                _ib_entry = _obj_store_c.get(uuid_key)
                if _ib_entry:
                    _ib_label = _ib_entry.get("label") or None
            # Merge BLE metadata from all underlying MAC addresses so that
            # service_data (e.g. Eddystone), manufacturer_data, and service_uuids
            # are preserved on the merged iBeacon object instead of being lost.
            _ib_ble_name = None
            _ib_manuf: dict[str, Any] = {}
            _ib_svcdata: dict[str, Any] = {}
            _ib_svcuuids: list[str] = []
            _ib_connectable = None
            _ib_device = None
            for _ib_mac in (g.get("addrs") or []):
                _ib_rec = ble_by_addr.get(_ib_mac)
                if not _ib_rec:
                    continue
                _n = _ib_rec.get("name") or ""
                if _n and _n != _ib_mac and not _ib_ble_name:
                    _ib_ble_name = _n
                _ib_manuf.update(_ib_rec.get("manufacturer_data") or {})
                _ib_svcdata.update(_ib_rec.get("service_data") or {})
                for _u in (_ib_rec.get("service_uuids") or []):
                    if _u not in _ib_svcuuids:
                        _ib_svcuuids.append(_u)
                if _ib_rec.get("connectable") is True:
                    _ib_connectable = True
                elif _ib_connectable is None:
                    _ib_connectable = _ib_rec.get("connectable")
                if not _ib_device and _ib_mac in addr_to_device:
                    _ib_device = addr_to_device[_ib_mac]
            # For split groups (multiple physical devices sharing same UUID:major:minor),
            # append the MAC suffix so the user can distinguish them.
            _is_split = "_split_from" in g
            _default_name = _ib_ble_name or f"iBeacon {g['uuid'][:8]}"
            if _is_split and g["addrs"]:
                _mac_short = g["addrs"][0][-8:]  # last 8 chars of MAC (XX:XX:XX)
                _default_name = f"{_default_name} ({_mac_short})"
            obj_ib: dict[str, Any] = {
                "key": uuid_key,
                "kind": "ibeacon",
                "address": uuid_key,           # stable key — used by label store & tagging
                "all_addresses": g["addrs"],   # rotating MACs this beacon was seen from
                "name": _ib_label or _default_name,
                "ble_name": _ib_ble_name,      # original BLE broadcast name for display
                "rssi": g.get("rssi"),
                "age_s": g.get("age_s"),
                "sources": g.get("sources") or [],
                "ibeacon_uuid": g["uuid"],
                "ibeacon_major": g["major"],
                "ibeacon_minor": g["minor"],
                "tx_power": g.get("tx_power"),  # factory TX power dBm at 1m (from iBeacon payload)
                "manufacturer_data": _ib_manuf,
                "service_data": _ib_svcdata,
                "service_uuids": _ib_svcuuids,
                "connectable": _ib_connectable,
                "identified": bool(identified_ib) or bool(_ib_label),
                "linked_entities": all_linked,
                "device": _ib_device,
            }
            if _ib_label:
                obj_ib["user_label"] = _ib_label
            objects.append(obj_ib)

        # ── Cross-link MAC ↔ iBeacon ↔ entity for the same physical device ──
        # Build lookup maps so labels/tags propagate across all representations.
        _mac_to_ibeacon_key: dict[str, str] = {}   # MAC → ibeacon:uuid:major:minor
        _ibeacon_to_macs: dict[str, list[str]] = {}  # ibeacon key → [MAC, ...]
        for uuid_key, g in ibeacon_groups.items():
            macs = list(g.get("addrs") or [])
            _ibeacon_to_macs[uuid_key] = macs
            for mac in macs:
                _mac_to_ibeacon_key[mac] = uuid_key

        # Tag entity objects with their iBeacon key if their MAC matches
        for obj in objects:
            if obj.get("kind") == "entity":
                eaddr = (obj.get("address") or "").upper()
                ib_key = _mac_to_ibeacon_key.get(eaddr)
                if ib_key:
                    obj["ibeacon_key"] = ib_key

        # ── Merge duplicate objects that represent the same physical device ──
        # A device can broadcast multiple BLE protocols (iBeacon + Eddystone,
        # iBeacon + regular BLE, etc.) on different MACs. When they share the
        # same HA device_id, merge the secondary into the primary (iBeacon wins).
        try:
            # Index iBeacon objects by device_id and by all their MAC addresses
            _ib_by_devid: dict[str, dict[str, Any]] = {}
            _ib_by_mac: dict[str, dict[str, Any]] = {}
            for obj in objects:
                if obj.get("kind") != "ibeacon":
                    continue
                # obj["device"] is an addr_to_device entry, keyed "device_id"
                # — this read "id", so the device match below never fired.
                dev = obj.get("device")
                if isinstance(dev, dict) and dev.get("device_id"):
                    _ib_by_devid[dev["device_id"]] = obj
                for mac in (obj.get("all_addresses") or []):
                    _ib_by_mac[mac.upper()] = obj

            _absorbed_keys: set[str] = set()  # keys of objects merged into an iBeacon
            _merged_by_device = 0             # of those, matched by HA device (opt-in report)
            for obj in objects:
                if obj.get("kind") not in ("ble", "private_ble"):
                    continue
                # Match by HA device_id
                target_ib = None
                dev = obj.get("device")
                if isinstance(dev, dict) and dev.get("device_id"):
                    target_ib = _ib_by_devid.get(dev["device_id"])
                    if target_ib:
                        _merged_by_device += 1
                # Match by MAC address overlap
                if not target_ib:
                    obj_addr = (obj.get("address") or "").upper()
                    if obj_addr:
                        target_ib = _ib_by_mac.get(obj_addr)
                    if not target_ib:
                        for mac in (obj.get("all_addresses") or []):
                            target_ib = _ib_by_mac.get(mac.upper())
                            if target_ib:
                                break
                if not target_ib:
                    continue
                # Merge: fold BLE/private_ble data into the iBeacon object
                _absorbed_keys.add(obj.get("key", ""))
                # Merge metadata (don't overwrite existing non-empty fields)
                for _mf in ("manufacturer_data", "service_data"):
                    src_d = obj.get(_mf) or {}
                    if src_d:
                        target_ib.setdefault(_mf, {}).update(src_d)
                for _u in (obj.get("service_uuids") or []):
                    target_uuids = target_ib.setdefault("service_uuids", [])
                    if _u not in target_uuids:
                        target_uuids.append(_u)
                # Merge MAC addresses
                for _ma in (obj.get("all_addresses") or [obj.get("address")]):
                    if _ma:
                        existing_addrs = list(target_ib.get("all_addresses") or [])
                        if _ma not in existing_addrs:
                            existing_addrs.append(_ma)
                        target_ib["all_addresses"] = sorted(existing_addrs)
                # Merge linked entities
                for _le in (obj.get("linked_entities") or []):
                    existing_le = target_ib.setdefault("linked_entities", [])
                    if _le not in existing_le:
                        existing_le.append(_le)
                # Merge sources
                existing_srcs = target_ib.get("sources") or []
                for _s in (obj.get("sources") or []):
                    sk = _s.get("source") if isinstance(_s, dict) else str(_s)
                    if sk not in {(s.get("source") if isinstance(s, dict) else str(s)) for s in existing_srcs}:
                        existing_srcs.append(_s)
                target_ib["sources"] = existing_srcs
                # Prefer better RSSI
                if obj.get("rssi") is not None:
                    if target_ib.get("rssi") is None or obj["rssi"] > target_ib["rssi"]:
                        target_ib["rssi"] = obj["rssi"]
                        target_ib["age_s"] = obj.get("age_s")
                # Connectable
                if obj.get("connectable") is True:
                    target_ib["connectable"] = True
                # Device info
                if not target_ib.get("device") and obj.get("device"):
                    target_ib["device"] = obj["device"]
                # BLE name
                obj_name = obj.get("name") or ""
                if obj_name and obj_name != obj.get("address") and not target_ib.get("ble_name"):
                    target_ib["ble_name"] = obj_name
                # Mark iBeacon as identified if the absorbed object was
                if obj.get("identified"):
                    target_ib["identified"] = True
                # Track merged protocols
                _merged = target_ib.setdefault("merged_protocols", ["ibeacon"])
                obj_kind = obj.get("kind", "ble")
                if obj_kind not in _merged:
                    _merged.append(obj_kind)

            # Remove absorbed objects from the list
            if _absorbed_keys:
                objects = [o for o in objects if o.get("key", "") not in _absorbed_keys]
            (snapshot.get("raw_counts") or {})["merged_by_device"] = _merged_by_device
        except Exception as _merge_err:
            _LOGGER.debug("Object merge error: %s", _merge_err)

        # ── Aggressive beacon deduplication (D1–D7) ─────────────────────────
        # A typical home sees 200-700+ BLE addresses, many of which are the same
        # physical device broadcasting under different MACs or protocols.
        # Strategies (in order):
        #   D1: Entity absorbs its raw BLE counterpart (same MAC)
        #   D2: Eddystone-UID namespace grouping (same namespace+instance)
        #   D3: Same BLE broadcast name on random MACs
        #   D4: Identical manufacturer_data fingerprint (excl. Apple continuity)
        #   D5: Apple continuity subtype + same scanner set
        #   D6: Identical service_uuids + same scanner set
        #   D7: Bare random MACs with zero distinguishing data → collapse by scanner set
        # Runs twice: once on current objects, again after cache reintroduction.
        _dedup_absorbed: set[str] = set()

        # Helper: merge obj_src into obj_dst (like the iBeacon merge above)
        def _merge_into(dst: dict, src: dict) -> None:
            for _mf in ("manufacturer_data", "service_data"):
                sd = src.get(_mf) or {}
                if sd:
                    dst.setdefault(_mf, {}).update(sd)
            for _u in (src.get("service_uuids") or []):
                tl = dst.setdefault("service_uuids", [])
                if _u not in tl:
                    tl.append(_u)
            # all_addresses holds MAC addresses ONLY.  For ibeacon/private_ble
            # objects the "address" field is a key string ("ibeacon:uuid:...")
            # — appending those poisons the list (and the 7-day cache) with
            # pseudo-addresses that later match nothing.
            def _is_mac(s: Any) -> bool:
                return isinstance(s, str) and len(s) == 17 and s.count(":") == 5
            ea = [a for a in dst.setdefault("all_addresses", []) if _is_mac(a)]
            if _is_mac(dst.get("address")) and dst["address"] not in ea:
                ea.append(dst["address"])
            for _ma in (src.get("all_addresses") or [src.get("address")]):
                if _is_mac(_ma) and _ma not in ea:
                    ea.append(_ma)
            dst["all_addresses"] = sorted(ea)
            for _le in (src.get("linked_entities") or []):
                el2 = dst.setdefault("linked_entities", [])
                if _le not in el2:
                    el2.append(_le)
            es = dst.setdefault("sources", [])
            es_set = {(s.get("source") if isinstance(s, dict) else str(s)) for s in es}
            for _s in (src.get("sources") or []):
                sk = _s.get("source") if isinstance(_s, dict) else str(_s)
                if sk not in es_set:
                    es.append(_s)
                    es_set.add(sk)
            if src.get("rssi") is not None:
                if dst.get("rssi") is None or src["rssi"] > dst["rssi"]:
                    dst["rssi"] = src["rssi"]
                    dst["age_s"] = src.get("age_s")
            if src.get("connectable") is True:
                dst["connectable"] = True
            if not dst.get("device") and src.get("device"):
                dst["device"] = src["device"]
            sn = src.get("name") or ""
            if sn and sn != src.get("address") and not dst.get("ble_name"):
                dst["ble_name"] = sn
            if src.get("identified"):
                dst["identified"] = True
            _mp = dst.setdefault("merged_protocols", [dst.get("kind", "ble")])
            sk2 = src.get("kind", "ble")
            if sk2 not in _mp:
                _mp.append(sk2)

        def _run_dedup(objects: list, absorbed: set) -> list:
            """Run D1-D7 dedup strategies. Mutates absorbed set, returns filtered list."""
            # --- (D1) Entity absorbs its BLE counterpart ─────────────────────
            # Entity objects that share a MAC with a ble/private_ble/ibeacon
            # object → absorb the raw BLE object (entity is the richer representation)
            _ent_macs: dict[str, dict[str, Any]] = {}  # MAC → entity obj
            for obj in objects:
                if obj.get("kind") == "entity" and obj.get("address"):
                    _ent_macs[obj["address"].upper()] = obj
            for obj in objects:
                if obj.get("kind") not in ("ble",):
                    continue
                obj_addr = (obj.get("address") or "").upper()
                ent_obj = _ent_macs.get(obj_addr) if obj_addr else None
                if ent_obj:
                    absorbed.add(obj.get("key", ""))
                    # Copy BLE metadata into the entity object
                    for _mf in ("manufacturer_data", "service_data", "service_uuids",
                                "company_name", "device_type", "service_names"):
                        v = obj.get(_mf)
                        if v and not ent_obj.get(_mf):
                            ent_obj[_mf] = v
                    if obj.get("rssi") is not None and ent_obj.get("rssi") is None:
                        ent_obj["rssi"] = obj["rssi"]
                    if obj.get("sources"):
                        ent_obj.setdefault("sources", [])
                        for _s in obj["sources"]:
                            if _s not in ent_obj["sources"]:
                                ent_obj["sources"].append(_s)

            # --- (D2) Eddystone-UID namespace grouping ───────────────────────
            # Eddystone-UID beacons broadcast service_data under UUID 0xFEAA.
            # Frame type 0x00 = UID frame: 10-byte namespace + 6-byte instance.
            # Group by namespace+instance (like iBeacon UUID/major/minor).
            _eddystone_groups: dict[str, list[dict[str, Any]]] = {}  # "eddy:ns:inst" → [objs]
            for obj in objects:
                if obj.get("key", "") in absorbed:
                    continue
                if obj.get("kind") not in ("ble", "private_ble"):
                    continue
                sd = obj.get("service_data") or {}
                for sdk in ("0000feaa-0000-1000-8000-00805f9b34fb", "feaa", "0xFEAA"):
                    raw = sd.get(sdk)
                    if not raw:
                        continue
                    try:
                        if isinstance(raw, str):
                            payload = bytes(int(x, 16) for x in raw.split())
                        elif isinstance(raw, (bytes, bytearray)):
                            payload = bytes(raw)
                        else:
                            continue
                        if len(payload) >= 18 and payload[0] == 0x00:
                            # UID frame: byte 0 = frame type, byte 1 = tx power,
                            # bytes 2-11 = namespace (10 bytes), bytes 12-17 = instance (6 bytes)
                            ns = payload[2:12].hex()
                            inst = payload[12:18].hex()
                            eddy_key = f"eddy:{ns}:{inst}"
                            _eddystone_groups.setdefault(eddy_key, []).append(obj)
                    except Exception:
                        pass

            for eddy_key, group in _eddystone_groups.items():
                if len(group) <= 1:
                    continue
                # Keep the one with best RSSI as primary
                group.sort(key=lambda o: o.get("rssi") or -999, reverse=True)
                primary = group[0]
                primary["eddystone_uid"] = eddy_key
                for secondary in group[1:]:
                    absorbed.add(secondary.get("key", ""))
                    _merge_into(primary, secondary)

            # --- (D3) Same BLE name merging ──────────────────────────────────
            # Devices with identical non-generic broadcast names and random MACs
            # are very likely the same device with rotating addresses.
            # Generic names (empty, MAC-like, short hex) are excluded.
            _GENERIC_NAME_RE = __import__("re").compile(
                r"^$|^([0-9A-Fa-f]{2}[:\-]){2,}|^[0-9A-Fa-f]{4,}$|^BLE$|^Unknown$"
            )
            _name_groups: dict[str, list[dict[str, Any]]] = {}
            for obj in objects:
                if obj.get("key", "") in absorbed:
                    continue
                if obj.get("kind") not in ("ble",):
                    continue
                name = (obj.get("name") or "").strip()
                addr = (obj.get("address") or "").upper()
                # Skip if name is generic or IS the MAC address
                if not name or name.upper() == addr or _GENERIC_NAME_RE.match(name):
                    continue
                # Only merge random-address MACs (bit 1 of first octet set = random)
                try:
                    first_octet = int(addr.split(":")[0], 16)
                    is_random = bool(first_octet & 0x02)  # locally administered bit
                except Exception:
                    is_random = False
                if not is_random:
                    continue
                _name_groups.setdefault(name, []).append(obj)

            for name, group in _name_groups.items():
                if len(group) <= 1:
                    continue
                # All share the same broadcast name + have random MACs → likely same device
                group.sort(key=lambda o: o.get("rssi") or -999, reverse=True)
                primary = group[0]
                for secondary in group[1:]:
                    absorbed.add(secondary.get("key", ""))
                    _merge_into(primary, secondary)
                primary.setdefault("merged_protocols", [primary.get("kind", "ble")])
                primary["_dedup_reason"] = f"same_name:{name}"

            # --- (D4) Manufacturer data fingerprint dedup ────────────────────
            # Devices with identical manufacturer_data payloads on different
            # random MACs are the same rotating device.  Only for random MACs.
            # Exclude Apple (76) continuity data which changes frequently.
            _manuf_groups: dict[str, list[dict[str, Any]]] = {}
            for obj in objects:
                if obj.get("key", "") in absorbed:
                    continue
                if obj.get("kind") not in ("ble",):
                    continue
                md = obj.get("manufacturer_data") or {}
                if not md:
                    continue
                addr = (obj.get("address") or "").upper()
                try:
                    first_octet = int(addr.split(":")[0], 16)
                    is_random = bool(first_octet & 0x02)
                except Exception:
                    is_random = False
                if not is_random:
                    continue
                # Build a fingerprint from manufacturer_data, excluding Apple
                # continuity (company 76) which rotates frequently
                fp_parts = []
                for k, v in sorted(md.items()):
                    if str(k) in ("76", "0x004c", "0x004C"):
                        continue  # skip Apple continuity — too variable
                    fp_parts.append(f"{k}={v}")
                if not fp_parts:
                    continue
                fp = "|".join(fp_parts)
                _manuf_groups.setdefault(fp, []).append(obj)

            for fp, group in _manuf_groups.items():
                if len(group) <= 1:
                    continue
                group.sort(key=lambda o: o.get("rssi") or -999, reverse=True)
                primary = group[0]
                for secondary in group[1:]:
                    absorbed.add(secondary.get("key", ""))
                    _merge_into(primary, secondary)
                primary["_dedup_reason"] = "same_manuf_data"

            # --- (D5) Apple continuity dedup ─────────────────────────────────
            # Apple devices rotate MACs but broadcast company 76 with a
            # consistent subtype byte (byte 0 after company ID).  Devices
            # from the same scanners with the same subtype are grouped.
            _apple_groups: dict[str, list[dict[str, Any]]] = {}
            for obj in objects:
                if obj.get("key", "") in absorbed:
                    continue
                if obj.get("kind") not in ("ble",):
                    continue
                md = obj.get("manufacturer_data") or {}
                apple_raw = None
                for k in ("76", "0x004c", "0x004C"):
                    if k in md:
                        apple_raw = md[k]
                        break
                if not apple_raw:
                    continue
                addr = (obj.get("address") or "").upper()
                try:
                    first_octet = int(addr.split(":")[0], 16)
                    is_random = bool(first_octet & 0x02)
                except Exception:
                    is_random = False
                if not is_random:
                    continue
                # Parse subtype from Apple continuity data
                try:
                    if isinstance(apple_raw, str):
                        raw_bytes = [int(x, 16) for x in apple_raw.split()]
                    elif isinstance(apple_raw, (bytes, bytearray)):
                        raw_bytes = list(apple_raw)
                    else:
                        continue
                    if len(raw_bytes) < 2:
                        continue
                    subtype = raw_bytes[0]
                    data_len = raw_bytes[1]
                except Exception:
                    continue
                # Skip iBeacon subtype (already handled)
                if subtype == 0x02 and data_len == 0x15:
                    continue
                # Group by subtype + data length + scanner set
                srcs = obj.get("sources") or []
                src_key = ",".join(sorted(str(s) for s in srcs)) if srcs else "_"
                apple_key = f"apple:{subtype:02x}:{data_len:02x}:{src_key}"
                _apple_groups.setdefault(apple_key, []).append(obj)

            for apple_key, group in _apple_groups.items():
                if len(group) <= 1:
                    continue
                # Same Apple subtype + same scanners → likely same device rotating MACs
                group.sort(key=lambda o: o.get("rssi") or -999, reverse=True)
                primary = group[0]
                for secondary in group[1:]:
                    absorbed.add(secondary.get("key", ""))
                    _merge_into(primary, secondary)
                primary["_dedup_reason"] = f"apple_continuity:{apple_key}"

            # --- (D6) Identical service_uuids + same scanners dedup ──────────
            # Random-MAC devices advertising identical service_uuids from the
            # same set of scanners are very likely the same rotating device.
            _svcuuid_groups: dict[str, list[dict[str, Any]]] = {}
            for obj in objects:
                if obj.get("key", "") in absorbed:
                    continue
                if obj.get("kind") not in ("ble",):
                    continue
                su = obj.get("service_uuids") or []
                if not su:
                    continue
                addr = (obj.get("address") or "").upper()
                try:
                    first_octet = int(addr.split(":")[0], 16)
                    is_random = bool(first_octet & 0x02)
                except Exception:
                    is_random = False
                if not is_random:
                    continue
                name = (obj.get("name") or "").strip()
                # Only group unnamed or generic-named devices
                if name and name.upper() != addr and not _GENERIC_NAME_RE.match(name):
                    continue  # named devices already handled by D3
                srcs = obj.get("sources") or []
                src_key = ",".join(sorted(str(s) for s in srcs)) if srcs else "_"
                uuid_key = "+".join(sorted(su)) + "@" + src_key
                _svcuuid_groups.setdefault(uuid_key, []).append(obj)

            for uuid_key, group in _svcuuid_groups.items():
                if len(group) <= 1:
                    continue
                group.sort(key=lambda o: o.get("rssi") or -999, reverse=True)
                primary = group[0]
                for secondary in group[1:]:
                    absorbed.add(secondary.get("key", ""))
                    _merge_into(primary, secondary)
                primary["_dedup_reason"] = "same_svc_uuids_scanners"

            # --- (D7) Bare random MACs with no data ──────────────────────────
            # Random-address devices with no name, no manufacturer_data, no
            # service_data, no service_uuids → group by scanner set.
            # These are typically the same device rotating its address.
            _bare_groups: dict[str, list[dict[str, Any]]] = {}
            for obj in objects:
                if obj.get("key", "") in absorbed:
                    continue
                if obj.get("kind") not in ("ble",):
                    continue
                addr = (obj.get("address") or "").upper()
                try:
                    first_octet = int(addr.split(":")[0], 16)
                    is_random = bool(first_octet & 0x02)
                except Exception:
                    is_random = False
                if not is_random:
                    continue
                name = (obj.get("name") or "").strip()
                if name and name.upper() != addr:
                    continue  # has a real name
                md = obj.get("manufacturer_data") or {}
                sd = obj.get("service_data") or {}
                su = obj.get("service_uuids") or []
                if md or sd or su:
                    continue  # has some distinguishing data
                srcs = obj.get("sources") or []
                src_key = ",".join(sorted(str(s) for s in srcs)) if srcs else "_"
                _bare_groups.setdefault(src_key, []).append(obj)

            for src_key, group in _bare_groups.items():
                if len(group) <= 1:
                    continue
                # Group all bare random-MAC devices per scanner set into one
                group.sort(key=lambda o: o.get("rssi") or -999, reverse=True)
                primary = group[0]
                primary["name"] = f"Unknown BLE ({len(group)} rotations)"
                for secondary in group[1:]:
                    absorbed.add(secondary.get("key", ""))
                    _merge_into(primary, secondary)
                primary["_dedup_reason"] = "bare_random_mac"

            # Remove all absorbed objects
            if absorbed:
                _pre = len(objects)
                objects = [o for o in objects if o.get("key", "") not in absorbed]
                _LOGGER.debug(
                    "Aggressive dedup: %d → %d objects (-%d)",
                    _pre, len(objects), _pre - len(objects),
                )
            return objects

        try:
            objects = _run_dedup(objects, _dedup_absorbed)
        except Exception as _dedup_err:
            _LOGGER.debug("Aggressive dedup error: %s", _dedup_err)

        # Attach user labels — DeviceRegistry is the primary source (resolved later
        # in the DeviceRegistry enrichment block). ObjectStore is a thin fallback for
        # any labels not yet migrated to DeviceRegistry.
        try:
            obj_store = hass.data.get(DOMAIN, {}).get(DATA_OBJECTS)
            if obj_store:
                for obj in objects:
                    if obj.get("user_label"):
                        continue  # already labeled
                    kind = obj.get("kind", "")
                    addr = obj.get("address", "") or ""
                    lookup_key = obj.get("canonical_id") or obj.get("key") or addr
                    if not lookup_key:
                        continue
                    entry = obj_store.get(lookup_key)
                    if not entry and lookup_key != addr:
                        entry = obj_store.get(addr)
                    if entry:
                        label = entry.get("label", "")
                        if label:
                            obj["user_label"] = label
                            if kind in ("ble", "ibeacon", "private_ble"):
                                obj["identified"] = True
        except Exception:
            pass

        # BLE enrichment: decode company names, device types, service names
        for obj in objects:
            if obj.get("kind") in ("ble", "private_ble", "ibeacon"):
                try:
                    _enrich_ble_object(obj)
                except Exception:
                    pass

        # ── Persistent object history (rolling, disk-backed) ───────────────
        # WHY: Objects disappear from BLE when out of range or MAC rotates.
        # Without history, they'd vanish from the UI.  This cache preserves
        # every object with all metadata so they reappear with correct labels.
        # Tagged/identified objects NEVER expire, whatever this TTL says.
        # The cache is loaded from disk on first access and saved every 15s.
        #
        # The TTL only governs objects that were never identified — in a busy
        # BLE environment that is passing phones and neighbours' devices, one
        # new object per MAC rotation.  It used to be a hard-coded 7 days,
        # which accumulated ~16.4k objects (only ~50 seen in the last five
        # minutes).  Since the whole cache ships in every live_snapshot, and
        # the panel polls that every 5s, a week of strangers' phones meant a
        # 19.5MB / 2-7s poll on a 5s interval — polls overlapping and backing
        # up.  Now user-selectable (Settings -> Object History): 1 day keeps it
        # at ~2.8k objects / 3.8MB / sub-second, 14 days is the pack-rat end.
        import time as _time
        _HISTORY_TTL = _object_history_ttl_s(hass)
        _SAVE_INTERVAL = 15         # save to disk at most every 15 s
        _now_ts = _time.time()      # real wall-clock time (survives restarts)

        _dom = hass.data.setdefault(DOMAIN, {})
        _cache: dict[str, dict[str, Any]] = _dom.get(DATA_OBJECT_HISTORY)

        # First access: load from disk
        if _cache is None:
            from homeassistant.helpers.storage import Store as _Store
            _hist_store = _dom.setdefault("_obj_hist_store", _Store(hass, 1, OBJECT_HISTORY_STORE_KEY))
            _loaded = await _hist_store.async_load()
            _cache = _loaded if isinstance(_loaded, dict) else {}
            _dom[DATA_OBJECT_HISTORY] = _cache
            _dom["_obj_hist_last_save"] = _now_ts
            _LOGGER.debug("Object history loaded from disk: %d entries", len(_cache))

        # Fields to merge (never overwrite good data with empty values)
        _MERGE_FIELDS = (
            "company_name", "device_type", "service_names", "service_uuid_map",
            "name", "private_ble_name", "ibeacon_uuid", "ibeacon_major",
            "ibeacon_minor", "tx_power", "manufacturer_data", "service_data",
            "service_uuids", "all_addresses", "linked_entities", "device",
            "prefix", "prefix_count",
        )

        # Index current objects by key for fast lookup
        _current_keys: set[str] = set()
        for obj in objects:
            key = obj.get("key") or ""
            if not key:
                continue
            _current_keys.add(key)

            # Merge: keep previously-discovered metadata if current is empty
            prev = _cache.get(key)
            if prev:
                for fld in _MERGE_FIELDS:
                    cur_val = obj.get(fld)
                    prev_val = prev.get(fld)
                    if not cur_val and prev_val:
                        obj[fld] = prev_val
                # Preserve first_seen from history
                obj["_first_seen"] = prev.get("_first_seen") or _now_ts
                # Merge all_addresses (accumulate over time).  Current-cycle
                # addresses go first so the retained head is the freshest.
                # Not a Find My tag's: its addresses are exactly the ones the
                # bridge gives it (an unlinked one must not come back — round 10).
                if prev.get("all_addresses") and obj.get("all_addresses") and not obj.get("findmy"):
                    obj["all_addresses"] = _capped_mac_history(
                        list(obj["all_addresses"]) + list(prev["all_addresses"])
                    )
            else:
                obj["_first_seen"] = _now_ts

            # Split iBeacon objects own exactly ONE MAC — the one in their key.
            # Never union sibling MACs from merged-era cache entries; the cache
            # rewrite below then self-heals old entries that claimed the pack.
            if obj.get("kind") == "ibeacon":
                _kparts = str(obj.get("key") or "").split(":")
                if len(_kparts) > 4:
                    _own_mac = ":".join(_kparts[-6:])
                    if len(_own_mac) == 17 and _own_mac.count(":") == 5:
                        obj["all_addresses"] = [_own_mac]

            # Update cache entry
            obj["_last_seen_ts"] = _now_ts
            obj["_cache_age_s"] = obj.get("age_s") or 0
            _cache[key] = dict(obj)  # snapshot copy

        # Count cap (low_memory.py): next to a busy street a day of strangers
        # is tens of thousands of entries (one install: 80,000), all held in
        # memory, saved every 15 s and replayed into every build. Past the
        # cap the unidentified entries heard longest ago go first; someone's
        # object, and anything heard this cycle, never does.
        cap_object_history(_cache, _low_memory.history_max(hass), _current_keys)

        # Merge cached objects not seen this cycle back into the list
        # Skip keys absorbed by deduplication — they are ghosts of merged objects
        _cached_added = 0
        _bermuda_purged = 0
        for key, cached_obj in list(_cache.items()):
            if key in _current_keys:
                continue  # already in this cycle's list
            if key in _dedup_absorbed:
                del _cache[key]  # purge absorbed ghost from cache
                continue
            # When bermuda_ignore is on, purge cached entity objects from Bermuda
            # so they don't keep resurrecting after being filtered out
            if _bermuda_ignore and _all_bermuda_entry_ids and cached_obj.get("kind") == "entity":
                _cached_eid = cached_obj.get("entity_id") or ""
                if _cached_eid:
                    try:
                        _cached_ent = er.async_get(_cached_eid)
                        if _cached_ent and _cached_ent.config_entry_id in _all_bermuda_entry_ids:
                            del _cache[key]
                            continue
                    except Exception:
                        pass
            # A plain object whose address now belongs to a merged identity
            # (an IRK phone, a bridged rotation, a Find My tag's next address
            # seen on its own before the link landed) is a ghost of it: it
            # would claim that live address in every view (round 10).
            # Only an authoritative claim (an IRK, a Find My tag's own
            # bridge) — never the fingerprint bridge's per-poll guess — and a
            # named device's history is never deleted, only held back while
            # its address is claimed (round 11).
            _claim = (canonical_by_addr.get(str(cached_obj.get("address") or "").upper())
                      if cached_obj.get("kind") == "ble" else None)
            if _claim and (_claim.get("findmy") or not _claim.get("bridge_match")):
                if cached_obj.get("identified") or cached_obj.get("user_label"):
                    continue
                del _cache[key]
                continue
            stale_s = _now_ts - (cached_obj.get("_last_seen_ts") or _now_ts)
            # A bridge is a per-poll INFERENCE ("this new address is probably
            # that phone"), not an identity. It must never be immortalised:
            # a CP27 beacon that was once wrongly bridged sat in this cache
            # for 20 hours as "Private BLE: 1 device tracked", identified by
            # PadSpan's own device link, resurrected every poll. A cached
            # bridge expires like any unidentified object — and if its
            # address is on the air right now under a real identity (an
            # iBeacon group owns it), it is a ghost of a superseded guess and
            # goes at once.
            if cached_obj.get("bridge_match"):
                _ghost_addr = str(cached_obj.get("address") or key).upper()
                if _ghost_addr in ibeacon_addrs or _ghost_addr in ble_by_addr:
                    del _cache[key]
                    continue
                if stale_s > _HISTORY_TTL:
                    del _cache[key]
                    continue
                cached_obj.pop("identified", None)
            is_identified = cached_obj.get("identified") or cached_obj.get("user_label")
            # Verify label still exists — if deleted from obj_store, clear the
            # cached flags so the ghost can expire normally instead of lingering
            # forever as a phantom identified object.
            if is_identified and obj_store and stale_s > 60:
                _cache_label_key = cached_obj.get("canonical_id") or key
                _cache_entry = obj_store.get(_cache_label_key) or obj_store.get(key)
                if not _cache_entry or not _cache_entry.get("label"):
                    cached_obj.pop("identified", None)
                    cached_obj.pop("user_label", None)
                    is_identified = False
            # Tagged/identified objects never expire from history
            if not is_identified and stale_s > _HISTORY_TTL:
                del _cache[key]
                continue
            # 0.38.105 made a Bermuda device's Floor, Area Last Seen and each
            # "Distance to" sensor objects of their own. The selection never
            # makes them now; replayed, they sat frozen in their old rooms
            # (an entity is never away), a labelled copy for good. Dropped by
            # the selection's own rule, and saved with the history.
            if _all_bermuda_entry_ids and cached_obj.get("kind") == "entity":
                _cached_eid = cached_obj.get("entity_id") or ""
                if _cached_eid:
                    try:
                        _cached_ent = er.async_get(_cached_eid)
                        if (_cached_ent and _cached_ent.device_id
                                and _cached_ent.config_entry_id in _all_bermuda_entry_ids):
                            _cached_st = hass.states.get(_cached_eid)
                            if _bermuda_never_an_object(
                                    _cached_eid, (_cached_st.attributes or {}) if _cached_st else {},
                                    _cached_ent.device_id):
                                del _cache[key]
                                _bermuda_purged += 1
                                continue
                    except Exception:
                        pass
            # Heal pre-cap poisoned address histories in place: cache entries
            # persisted before _ALL_ADDR_CAP existed can carry tens of
            # thousands of addresses, and resurrection shipped them uncapped —
            # re-bloating the snapshot the cap was added to shrink.
            _aa = cached_obj.get("all_addresses")
            if isinstance(_aa, list) and len(_aa) > _ALL_ADDR_CAP:
                cached_obj["all_addresses"] = _capped_mac_history(_aa)
            # Bring it back — compute age_s = original age + time since last seen
            obj_copy = dict(cached_obj)
            # Not heard this cycle: it has no live address (a Find My tag's
            # cached current_address would steer the room tracker onto an
            # address that may be someone else's now — round 10).
            obj_copy.pop("current_address", None)
            base_age = cached_obj.get("_cache_age_s") or 0
            obj_copy["age_s"] = base_age + stale_s
            # Update per-source age_s values too (they were frozen at cache time)
            if obj_copy.get("sources"):
                obj_copy["sources"] = [
                    {**s, "age_s": (s.get("age_s") or 0) + stale_s}
                    if isinstance(s, dict) else s
                    for s in obj_copy["sources"]
                ]
            objects.append(obj_copy)
            _cached_added += 1
        if _bermuda_purged:
            # The opt-in report (#152): once after an upgrade from 0.38.105, then none.
            from .telemetry import bump as _bump  # noqa: PLC0415
            _bump(hass, "bermuda_history_purged", _bermuda_purged)

        # Second dedup pass: catch cached objects that were reintroduced
        if _cached_added > 0:
            try:
                objects = _run_dedup(objects, _dedup_absorbed)
            except Exception as _dedup2_err:
                _LOGGER.debug("Post-cache dedup error: %s", _dedup2_err)

        # Re-apply user labels to any cached objects that were merged back
        # without labels (e.g. labelled via companion_follow after initial cache)
        try:
            _obj_store2 = hass.data.get(DOMAIN, {}).get(DATA_OBJECTS)
            if _obj_store2:
                for obj in objects:
                    if obj.get("user_label"):
                        continue  # already labelled
                    kind = obj.get("kind", "")
                    if kind not in ("ble", "private_ble", "ibeacon"):
                        continue
                    # Try the object's key, address, canonical_id, ibeacon key variants
                    _lbl = None
                    _try_keys = [obj.get("key"), obj.get("address"), obj.get("canonical_id")]
                    # Split iBeacon objects (key = ibeacon:uuid:major:minor:MAC) are
                    # DISTINCT physical devices sharing a factory-default UUID.  They
                    # must NOT inherit the unsplit group key's label — that resurrects
                    # a stale label onto every beacon in the pack AND shadows per-MAC
                    # renames made in the Bluetooth tab.
                    _is_split_ib = kind == "ibeacon" and len(str(obj.get("key") or "").split(":")) > 4
                    # Also try ibeacon key from metadata (unsplit objects only)
                    _ib_u = obj.get("ibeacon_uuid")
                    if _ib_u is not None and not _is_split_ib:
                        _ibk = f"ibeacon:{_ib_u}:{obj.get('ibeacon_major', 0)}:{obj.get('ibeacon_minor', 0)}"
                        _try_keys.extend([_ibk, _ibk.upper()])
                    # Also try all_addresses
                    for _a in (obj.get("all_addresses") or []):
                        _try_keys.append(_a)
                    for _try_key in _try_keys:
                        if _try_key:
                            _e = _obj_store2.get(_try_key)
                            if _e and _e.get("label"):
                                _lbl = _e["label"]
                                break
                    if _lbl:
                        obj["user_label"] = _lbl
                        obj["identified"] = True
        except Exception:
            pass

        # ── Same-label dedup (post-labelling safety net) ───────────────────
        # WHY: A device can exist as multiple object kinds simultaneously
        # (e.g. ble MAC + ibeacon key, or cached stale + fresh live).
        # If the user labelled both halves, they'd see the same name twice.
        # This pass merges objects sharing the same user_label into one.
        try:
            _label_groups: dict[str, list[dict]] = {}
            for obj in objects:
                ul = obj.get("user_label", "")
                if ul and obj.get("key", "") not in _dedup_absorbed:
                    _label_groups.setdefault(ul, []).append(obj)

            for _lbl, _grp in _label_groups.items():
                if len(_grp) <= 1:
                    continue
                # The LIVE one is primary — freshest first, RSSI only to break
                # a tie. Sorting by RSSI let a stale cached ghost, whose RSSI
                # was frozen at whatever it last was, win over the object that
                # is actually advertising, and the live one was absorbed into
                # the ghost every poll.
                _grp.sort(key=lambda o: ((o.get("age_s") if o.get("age_s") is not None else 1e9),
                                         -(o.get("rssi") if o.get("rssi") is not None else -999)))
                _primary = _grp[0]
                for _sec in _grp[1:]:
                    # A label is a display string, NOT an identity. Two objects
                    # are one device only if they share an ADDRESS — the case
                    # this pass exists for (a bare MAC and its iBeacon key). A
                    # beacon multi-pack split per MAC merely shares an inherited
                    # label, and merging it here silently undid the split.
                    if not same_device_by_address(_primary, _sec):
                        continue
                    _sec_key = _sec.get("key", "")
                    if _sec_key:
                        _dedup_absorbed.add(_sec_key)
                    _merge_into(_primary, _sec)
                _primary.setdefault("_dedup_reason", "same_user_label")
                _LOGGER.debug(
                    "Same-label dedup: merged %d objects with label '%s'",
                    len(_grp), _lbl,
                )

            if _dedup_absorbed:
                objects = [o for o in objects if o.get("key", "") not in _dedup_absorbed]
        except Exception as _sld_err:
            _LOGGER.debug("Same-label dedup error: %s", _sld_err)

        # Periodic disk save (at most every 60 s)
        _last_save = _dom.get("_obj_hist_last_save") or 0
        if _now_ts - _last_save >= _SAVE_INTERVAL:
            _hist_store = _dom.get("_obj_hist_store")
            if _hist_store is None:
                from homeassistant.helpers.storage import Store as _Store
                _hist_store = _Store(hass, 1, OBJECT_HISTORY_STORE_KEY)
                _dom["_obj_hist_store"] = _hist_store
            # Strip non-serializable fields before saving. Scheduled, not
            # awaited: the save (~6 MB at 7,800 entries: serialise, write,
            # fsync - far slower on an SD card) ran inside the snapshot lock
            # every interval, holding up the panel's and the presence poll's
            # builds. HA calls the data function when it writes.
            def _hist_data(cache=_cache) -> dict:
                out = {}
                for _k, _v in cache.items():
                    _sv = dict(_v)
                    _sv.pop("_smoothed", None)
                    _sv.pop("_stale", None)
                    out[_k] = _sv
                return out
            _hist_store.async_delay_save(_hist_data, 1)
            _dom["_obj_hist_last_save"] = _now_ts

        # Send first_seen to frontend, strip internal cache fields
        for obj in objects:
            # Convert _first_seen to ISO string for frontend
            fs = obj.pop("_first_seen", None)
            if fs:
                from datetime import datetime, timezone
                obj["first_seen"] = datetime.fromtimestamp(fs, tz=timezone.utc).isoformat()
            obj.pop("_last_seen_ts", None)
            obj.pop("_cache_age_s", None)

        # Ghost injection removed — if a device isn't broadcasting, it
        # shouldn't appear in the object list.  Followed devices are tracked
        # via alerts/history, not by faking their presence on the map.

        unidentified = [o for o in objects if o.get("kind") in ("ble", "private_ble", "ibeacon") and not o.get("identified")]
        identified = [o for o in objects if not (o.get("kind") in ("ble", "private_ble", "ibeacon") and not o.get("identified"))]
        common_prefixes = {p: c for p, c in prefix_counts.items() if c >= 3}

        snapshot["objects"] = {
            "list": objects,
            "summary": {
                "total": len(objects),
                "identified": len(identified),
                "unidentified": len(unidentified),
                "entities": len([o for o in objects if o.get("kind") == "entity"]),
                "ble": len([o for o in objects if o.get("kind") in ("ble", "private_ble")]),
                "private_ble": len([o for o in objects if o.get("kind") == "private_ble"]),
                "ibeacon": len([o for o in objects if o.get("kind") == "ibeacon"]),
                "common_prefixes": common_prefixes,  # prefix -> count (>=3)
                "resolver": _resolver_diag,
                # What the ingest policy hid this poll, and why. A mask that
                # cannot be seen is indistinguishable from a bug, and this is
                # also the number that answers "what is it saving me".
                "ingest": _ingest.diagnostics(),
                "cached_objects": _cached_added,
                "dedup_absorbed": len(_dedup_absorbed),
            },
        }
    except Exception as _obj_err:
        _LOGGER.warning("Objects list build failed: %s", _obj_err, exc_info=True)
        snapshot["objects"] = {"list": [], "summary": {"total": 0, "identified": 0, "unidentified": 0, "entities": 0, "ble": 0, "common_prefixes": {}}}

    _phase_done("objects")

    # ── Enrich objects with stable padspan_id from DeviceRegistry ──
    try:
        from .const import DATA_DEVICE_REGISTRY
        _dev_reg = hass.data.get(DOMAIN, {}).get(DATA_DEVICE_REGISTRY)
        if _dev_reg:
            for _o in (snapshot.get("objects") or {}).get("list") or []:
                _okey = _o.get("key", "")
                if not _okey:
                    continue
                # Try resolving by key, address, canonical_id, all_addresses
                _pid = _dev_reg.resolve(_okey)
                if not _pid:
                    _pid = _dev_reg.resolve(_o.get("address") or "")
                if not _pid and _o.get("canonical_id"):
                    _pid = _dev_reg.resolve(_o["canonical_id"])
                if not _pid:
                    for _alt in (_o.get("all_addresses") or []):
                        _pid = _dev_reg.resolve(str(_alt))
                        if _pid:
                            break
                if _pid:
                    _o["padspan_id"] = _pid
                    _plbl = _dev_reg.get_label(_pid)
                    if _plbl and not _o.get("user_label"):
                        _o["user_label"] = _plbl
                        _o["identified"] = True
                else:
                    # Auto-register in ephemeral cache (not persisted)
                    _kind = "ibeacon" if _okey.startswith("ibeacon:") else "irk" if _okey.startswith("irk:") else "mac"
                    _pid = _dev_reg.resolve_or_create(_okey, kind=_kind, persist=False)
                    _o["padspan_id"] = _pid
    except Exception as _dr_err:
        _LOGGER.debug("DeviceRegistry enrichment: %s", _dr_err)

    # ── Apple Device Classification (setting: apple_auto_classify) ──
    # A Find My advertisement's status byte says what sent it: an AirTag,
    # another brand's Find My tag, AirPods or an Apple device (findmy.py).
    # The panel shows that in place of the plain "Find My". Nothing else Apple
    # sends names the model — the iPhone/iPad/Watch table this replaced read
    # Nearby Info's status flags, and called one device in Garry's office an
    # "iPad" all night and an "iPhone" at 08:09 (2026-09-27). Display-only.
    # Runs over the FINAL lists: objects replayed from history carry whatever
    # an older build stored, so off (or not Find My) clears it.
    try:
        from .findmy import DEVICE_TYPES as _FM_TYPES, parse_findmy  # noqa: PLC0415
        _st_apple = hass.data.get(DOMAIN, {}).get(DATA_SETTINGS)
        _classify = bool(_st_apple and _st_apple.get("apple_auto_classify"))
        for _o in (((snapshot.get("objects") or {}).get("list") or [])
                   + ((snapshot.get("ble") or {}).get("advertisements") or [])):
            _fm = parse_findmy(_o.get("manufacturer_data")) if _classify else None
            if _fm:
                _o["auto_class"] = _FM_TYPES[_fm["device_type"]]
            else:
                _o.pop("auto_class", None)
    except Exception as _apple_err:
        _LOGGER.debug("Apple auto-classify error: %s", _apple_err)

    # ── Enrich raw advertisements with decoded metadata + object cross-reference ──
    try:
        from .ble_enrichment import enrich_object as _enrich_ad
        _obj_by_addr: dict[str, dict[str, Any]] = {}
        for _o in (snapshot.get("objects") or {}).get("list") or []:
            for _a in ([_o.get("address")] + (_o.get("all_addresses") or [])):
                if _a:
                    _obj_by_addr[str(_a).upper()] = _o
        _raw_ads = (snapshot.get("ble") or {}).get("advertisements") or []
        for _ad in _raw_ads:
            _enrich_ad(_ad)  # adds company_name, device_type, service_names, service_uuid_map
            _ad_addr = str(_ad.get("address") or "").upper()
            _xobj = _obj_by_addr.get(_ad_addr)
            if _xobj:
                _ad["_xref"] = {
                    "key": _xobj.get("key"),
                    "kind": _xobj.get("kind"),
                    "label": _xobj.get("user_label") or _xobj.get("name"),
                    "identified": _xobj.get("identified", False),
                    "room": _xobj.get("room"),
                }
                if _xobj.get("canonical_id"):
                    _ad["_xref"]["canonical_id"] = _xobj["canonical_id"]
                if _xobj.get("findmy"):
                    _ad["_xref"]["findmy"] = True      # the Monitor list's Find My badge (round 9)
                if _xobj.get("all_addresses"):
                    _ad["_xref"]["all_addresses"] = list(
                        _xobj["all_addresses"]
                    )[:_XREF_ADDR_SAMPLE]
                if _xobj.get("ibeacon_uuid"):
                    _ad["_xref"]["ibeacon_uuid"] = _xobj["ibeacon_uuid"]
                    _ad["_xref"]["ibeacon_major"] = _xobj.get("ibeacon_major")
                    _ad["_xref"]["ibeacon_minor"] = _xobj.get("ibeacon_minor")
                if _xobj.get("entity_id"):
                    _ad["_xref"]["entity_id"] = _xobj["entity_id"]
            else:
                _ad["_xref"] = None
    except Exception:
        pass

    snapshot["bermuda_devices"] = snapshot.get("receivers") or []

    # Frontend "radios" should reflect actual Bluetooth scanners/adapters (not Bermuda tag devices).
    if "radios" not in snapshot:
        snapshot["radios"] = (snapshot.get("ble") or {}).get("radios") or []

    # --- BLE room assignment (strongest-scanner heuristic) ---
    # Unlike entity-based objects (which get their room from HA state), raw BLE
    # objects have no inherent room.  We assign one by finding which scanner
    # hears the device with the strongest RSSI, then using that scanner's HA area.
    # Scanner RSSI offsets (user-configured corrections for hot/cold scanners)
    # are applied before comparison.
    try:
        radios = (snapshot.get("ble") or {}).get("radios") or []
        source_to_area: dict[str, str] = {}
        for r in radios:
            src = r.get("source")
            area = r.get("area_name") or r.get("area")
            # Lost/disabled scanners are excluded from location math
            if src and area and str(src) not in _excluded_radio_srcs:
                source_to_area[str(src)] = str(area)

        if source_to_area:
            ads_raw = (snapshot.get("ble") or {}).get("advertisements") or []
            # Build {addr: {source: rssi}} from raw advertisements.
            # Skip readings older than 60s so a scanner that heard the device
            # long ago can't win (same recency cutoff as the iBeacon merge),
            # and skip scanners marked lost/disabled.
            addr_src_rssi: dict[str, dict[str, float]] = {}
            for ad in ads_raw:
                addr = str(ad.get("address") or "").upper()
                src  = ad.get("source")
                rssi = ad.get("rssi")
                if not (addr and src and rssi is not None):
                    continue
                if str(src) in _excluded_radio_srcs:
                    continue
                _age = ad.get("age_s")
                if isinstance(_age, (int, float)) and _age > 60:
                    continue
                addr_src_rssi.setdefault(addr, {})[str(src)] = float(rssi)

            # Apply per-scanner RSSI offsets (corrects scanners that read consistently high/low)
            _scanner_offsets: dict[str, float] = {}
            try:
                _st = hass.data.get(DOMAIN, {}).get(DATA_SETTINGS)
                _scanner_offsets = ((_st.data if _st else {}).get("scanner_offsets") or {})
                if _scanner_offsets:
                    for _am in addr_src_rssi.values():
                        for _src in _am:
                            _off = _scanner_offsets.get(_src)
                            if _off:
                                _am[_src] = _am[_src] + float(_off)
            except Exception:
                pass
            snapshot["scanner_offsets"] = _scanner_offsets

            objects_list = (snapshot.get("objects") or {}).get("list") or []
            for obj in objects_list:
                if obj.get("room"):
                    continue
                kind = obj.get("kind")
                if kind == "ibeacon":
                    # Merge RSSI from all rotating MACs for this iBeacon group
                    best_rssi_ib: float | None = None
                    best_area_ib: str | None = None
                    for a in (obj.get("all_addresses") or []):
                        for src, rssi in addr_src_rssi.get(str(a).upper(), {}).items():
                            area = source_to_area.get(src)
                            if area and (best_rssi_ib is None or rssi > best_rssi_ib):
                                best_rssi_ib = rssi
                                best_area_ib = area
                    if best_area_ib:
                        obj["room"] = best_area_ib
                elif kind == "private_ble":
                    # Check ALL rotating MACs for strongest signal (like iBeacon)
                    best_rssi_pb: float | None = None
                    best_area_pb: str | None = None
                    _pb_addrs = (obj.get("all_addresses") or [])
                    if not _pb_addrs:
                        _pb_addr = str(obj.get("address") or "").upper()
                        if _pb_addr:
                            _pb_addrs = [_pb_addr]
                    for a in _pb_addrs:
                        for src, rssi in addr_src_rssi.get(str(a).upper(), {}).items():
                            area = source_to_area.get(src)
                            if area and (best_rssi_pb is None or rssi > best_rssi_pb):
                                best_rssi_pb = rssi
                                best_area_pb = area
                    if best_area_pb:
                        obj["room"] = best_area_pb
                elif kind == "ble":
                    addr = str(obj.get("address") or "").upper()
                    if not addr:
                        continue
                    src_map = addr_src_rssi.get(addr, {})
                    # Pick source with highest RSSI that has an area mapping
                    best_rssi: float | None = None
                    best_area: str | None = None
                    for src, rssi in src_map.items():
                        area = source_to_area.get(src)
                        if area and (best_rssi is None or rssi > best_rssi):
                            best_rssi = rssi
                            best_area = area
                    if best_area:
                        obj["room"] = best_area
    except Exception:
        pass

    # ── Traceback recording moved to ws_live_snapshot (after k-NN overlay) ──

    # ── Scanner health (Phase 3) ─────────────────────────────────────────────
    try:
        _pc_sh = hass.data.get(DOMAIN, {}).get("presence_coordinator")
        if _pc_sh and _pc_sh.data:
            _sh = _pc_sh.data.get("__scanner_health__")
            if _sh:
                snapshot["scanner_health"] = _sh
    except Exception:
        pass

    _phase_done("enrich")
    return snapshot


def cap_object_history(cache: dict[str, dict[str, Any]], cap: int, current_keys: set[str]) -> int:
    """Hold the object history to `cap` unidentified entries (low_memory.py).
    Past it, the ones heard longest ago go, down to 90% of the cap so the sort
    is not paid every build. Someone's object, and anything heard this build
    (`current_keys`), is never dropped. Returns how many went."""
    if len(cache) <= cap:
        return 0
    # An IRK phone is someone's too, labelled or not (low_memory.py says so).
    unid = [(o.get("_last_seen_ts") or 0, k) for k, o in cache.items()
            if not (o.get("identified") or o.get("user_label")
                    or o.get("kind") == "private_ble" or str(k).startswith("irk:"))]
    if len(unid) <= cap:
        return 0
    excess = len(unid) - int(cap * 0.9)
    drop = sorted(t for t in unid if t[1] not in current_keys)[:excess]
    for _ts, k in drop:
        del cache[k]
    return len(drop)


_LF_PRUNED = "_lost_and_found_strangers_pruned"


def _prune_lost_and_found_strangers(hass: HomeAssistant, lf: Any, objects: list) -> None:
    """Once per start: drop the Lost & Found records of plain-MAC objects that
    nobody labelled, followed or registered — the strangers that versions
    before 0.38.106 recorded (lost_and_found_store.record). Every other key
    (iBeacon, IRK, a Find My identity, an entity) is kept, whatever it is.
    Waits until the label stores are loaded: without them a labelled tag
    would look like a stranger."""
    dom = hass.data.get(DOMAIN, {})
    dev_reg = dom.get(DATA_DEVICE_REGISTRY)
    obj_store = dom.get(DATA_OBJECTS)
    if dom.get(_LF_PRUNED) or dev_reg is None or obj_store is None:
        return
    dom[_LF_PRUNED] = True
    from .presence_coordinator import obj_is_identified  # noqa: PLC0415
    st = dom.get(DATA_SETTINGS)
    followed = {str(f).upper() for f in ((st.data if st else {}).get("followed_addrs") or [])}
    ident_now = {o.get("key") for o in objects if isinstance(o, dict) and obj_is_identified(o)}

    def keep(key: str, rec: dict[str, Any]) -> bool:
        if rec.get("identified"):
            return True     # recorded for someone's device (lost_and_found_store)
        mac = key[4:].upper() if key.startswith("ble:") else ""
        if len(mac) != 17 or mac.count(":") != 5:
            return True
        return bool(
            key in ident_now or mac in followed or key.upper() in followed
            or obj_store.get_label(mac)
            or dev_reg.get_label_by_key(key) or dev_reg.get_label_by_key(mac)
            or dev_reg.get(str(rec.get("padspan_id") or ""))
            or dev_reg.get(dev_reg.resolve(key) or "")
        )

    try:
        n = lf.prune(keep)
        if n:
            _LOGGER.info("Lost & Found: removed %d records of devices nobody tracks", n)
            from .telemetry import bump as _bump  # noqa: PLC0415
            _bump(hass, "lost_and_found_pruned", n)
    except Exception as err:
        _LOGGER.debug("Lost & Found stranger prune: %s", err)


# ── Optimize for scale (0.38.178, Settings; off by default) ──────────────────
# Several wall screens each fetched the whole snapshot every 5 s: 2.2 MB in a
# real house of 1,108 objects, nine of them anyone's, about 14 Mbit/s and 150
# GB a day for four screens. With the setting on, a screen that only draws
# people asks for the slim copy, and polls that land within 4.5 s of a build
# share it (four screens out of step: about one build per 5 s instead of 1.8).
SCALE_SNAPSHOT_TTL_S = 4.5


def _scale_on(hass: HomeAssistant) -> bool:
    st = (hass.data.get(DOMAIN) or {}).get(DATA_SETTINGS)
    return bool(st and (st.data or {}).get("optimize_for_scale"))


def snapshot_ttl_s(hass: HomeAssistant) -> float:
    """How long one build is shared: _SNAPSHOT_CACHE_TTL_S, or longer with Optimize for scale."""
    try:
        return SCALE_SNAPSHOT_TTL_S if _scale_on(hass) else _SNAPSHOT_CACHE_TTL_S
    except Exception:  # noqa: BLE001
        return _SNAPSHOT_CACHE_TTL_S


def slim_snapshot(snap: dict, followed: set[str]) -> dict:
    """The snapshot a screen that draws people needs: every object that is
    not a bare Bluetooth address, and every bare one that is identified,
    labelled, followed or placed in a room; the counts (objects.summary)
    untouched; the raw advertisement list left out. Pure; the input is not
    changed."""
    objs = dict(snap.get("objects") or {})
    full = objs.get("list") or []

    def keep(o: Any) -> bool:
        if not isinstance(o, dict):
            return False
        if o.get("kind") != "ble" or o.get("identified") or o.get("user_label") or o.get("room"):
            return True
        return any(str(o.get(f) or "").upper() in followed for f in ("key", "address", "entity_id", "canonical_id"))
    objs["list"] = [o for o in full if keep(o)]
    out = dict(snap)
    out["objects"] = objs
    ble = dict(snap.get("ble") or {})
    if isinstance(ble.get("advertisements"), list):
        ble["advertisements"] = []
    out["ble"] = ble
    out["slim"] = {"objects_kept": len(objs["list"]), "objects_total": len(full)}
    return out


@websocket_api.websocket_command({"type": "padspan_ha/live_snapshot", vol.Optional("slim"): bool})
@websocket_api.async_response
async def ws_live_snapshot(hass: HomeAssistant, connection, msg) -> None:
    """Return the full live snapshot to the panel, enriched with presence + calibration data.

    This is called every 5s by the panel's poll loop.  It:
      1. Builds the raw snapshot via _live_snapshot()
      2. Overlays smoothed k-NN positions from the presence coordinator
      3. Injects stale followed objects that are missing from BLE
      4. Attaches calibration status metadata for the Setup tab
    """
    snap = await _live_snapshot(hass)
    from .perf_sampler import note_snapshot_request  # noqa: PLC0415
    note_snapshot_request(hass)

    # The snapshot is shared via the TTL cache — shallow-copy the envelope and
    # the object dicts before the overlays below so mutations never leak into
    # other callers (notably the presence coordinator's next poll).
    snap = dict(snap)
    try:
        _objs_env = dict(snap.get("objects") or {})
        _objs_env["list"] = [dict(_o) for _o in (_objs_env.get("list") or [])]
        snap["objects"] = _objs_env
    except Exception:
        pass
    # Guest tags (guest_tags.py): a lent tag's objects carry the guest.
    try:
        from .guest_tags import snapshot_overlay  # noqa: PLC0415
        snapshot_overlay(hass, snap["objects"]["list"])
    except Exception:  # noqa: BLE001
        pass

    # Overlay presence-coordinator smoothed data (x_frac, y_frac,
    # knn_confidence, room, room_confidence) so the UI can show
    # calibration-derived positions and stable room assignments.
    try:
        pc = hass.data.get(DOMAIN, {}).get("presence_coordinator")
        if pc and pc.data:
            # The pin fields too (issue #89): a pinned beacon's declared
            # position and its drift from the solve. The coordinator has
            # always set them; left off this list, Overview could not draw a
            # pinned beacon at its pin, and Calibration's matrix never got
            # its anchor rows.
            _MERGE_KEYS = ("x_m", "y_m", "floor_id", "knn_confidence",
                           "room", "room_confidence", "rssi_margin_confidence",
                           "outside", "_smoothed", "_stale", "room_unsure",
                           "_pinned", "anchor_true_x_m", "anchor_true_y_m",
                           "anchor_true_floor_id", "anchor_drift_m", "anchor_drift_severity")
            obj_list = (snap.get("objects") or {}).get("list") or []
            for obj in obj_list:
                key = obj.get("key", "")
                if not key:
                    continue
                smoothed = pc.data.get(key)
                if not smoothed:
                    continue
                for mk in _MERGE_KEYS:
                    val = smoothed.get(mk)
                    if val is not None:
                        obj[mk] = val
    except Exception as _overlay_err:
        _LOGGER.warning("Coordinator overlay failed — positioning data may be stale: %s", _overlay_err, exc_info=True)

    # ── `room` is PRESENT TENSE, once, here ──────────────────────────────────
    # An object keeps its last known room forever, which is deliberate: it is
    # how "last seen in the Garage" survives a dropout. But leaving that value
    # in `room` meant every surface that printed the field asserted the device
    # was THERE, and each one had to remember to check the age. They did not:
    # the same car showed as being in the Garage on five separate surfaces,
    # hours after it left, while its own entities correctly read not_home —
    # and each was fixed only when someone happened to spot it.
    #
    # So the snapshot answers it instead of asking every caller to. A departed
    # object has no current room; where it was last seen moves to `last_room`,
    # and `away` says so outright. Anything that reads `room` is now correct by
    # construction, including code not written yet.
    try:
        from .presence_coordinator import obj_is_identified  # noqa: PLC0415
        _away_s = away_timeout_s(hass)
        _lost_and_found = hass.data.get(DOMAIN, {}).get(DATA_LOST_AND_FOUND)
        _lf_st = hass.data.get(DOMAIN, {}).get(DATA_SETTINGS)
        _lf_followed = {str(f).upper() for f in ((_lf_st.data if _lf_st else {}).get("followed_addrs") or [])}
        if _lost_and_found:
            _prune_lost_and_found_strangers(hass, _lost_and_found,
                                            (snap.get("objects") or {}).get("list") or [])
        for _obj in (snap.get("objects") or {}).get("list") or []:
            if not is_away(_obj, _away_s):
                continue
            if _obj.get("room"):
                _obj["last_room"] = _obj["room"]
                # Persistent lost-and-found (gap #10, best-in-class
                # roadmap): the same one-time-per-transition moment
                # `last_room` is set is exactly when a confirmation is
                # worth persisting — the underlying room already goes
                # blank right after, so this does not re-fire every poll.
                if _lost_and_found:
                    _key = _obj.get("key") or ""
                    if _key:
                        await _lost_and_found.record(
                            _key, _obj["room"],
                            label=_obj.get("user_label") or _obj.get("name"),
                            padspan_id=_obj.get("padspan_id"),
                            seen_at=time.time() - float(_obj.get("age_s") or 0),
                            # Followed counts too: the Follow button needs
                            # no label, and the prune keeps followed devices.
                            identified=(obj_is_identified(_obj)
                                        or str(_obj.get("address") or "").upper() in _lf_followed
                                        or _key.upper() in _lf_followed),
                        )
            _obj["room"] = ""
            _obj["away"] = True
    except Exception as _away_err:
        _LOGGER.warning("Away marking failed: %s", _away_err, exc_info=True)

    # ── Hold the room through a short signal gap (hold_last_room_s) ─────────
    # Display only, OFF by default (0). A device back from a short gap has
    # its room cleared until the vote confirms one again; with the setting on,
    # the room it had before the gap is shown meanwhile, marked room_held.
    # The vote, smoothing, gate and re-entry reset are untouched.
    try:
        _hold_st = hass.data.get(DOMAIN, {}).get(DATA_SETTINGS)
        _hold_s = float(((_hold_st.data if _hold_st else {}).get("hold_last_room_s") or 0.0))
        _hold_pc = hass.data.get(DOMAIN, {}).get("presence_coordinator")
        if _hold_s > 0 and _hold_pc is not None and hasattr(_hold_pc, "held_room"):
            # Counted once per hold (opt-in report: room_hold_used), not per snapshot.
            _was = hass.data.setdefault(DOMAIN, {}).setdefault("_room_held_keys", set())
            _now: set = set()
            for _obj in (snap.get("objects") or {}).get("list") or []:
                if _obj.get("room") or _obj.get("away"):
                    continue
                _held = _hold_pc.held_room(_obj.get("key") or "", _hold_s)
                if _held:
                    _obj["room"] = _held
                    _obj["room_held"] = True
                    _now.add(_obj.get("key") or "")
            if _now - _was:
                from .telemetry import bump as _bump  # noqa: PLC0415
                _bump(hass, "room_hold_used", len(_now - _was))
            hass.data[DOMAIN]["_room_held_keys"] = _now
    except Exception as _hold_err:
        _LOGGER.warning("Room hold failed: %s", _hold_err, exc_info=True)

    # Rebuild room_tag_map from overlaid objects so the map matches the
    # presence coordinator's smoothed room assignments (spatial centroid).
    # Without this, the map uses pre-overlay raw RSSI rooms while the
    # object list uses post-overlay smoothed rooms → mismatch.
    # A room lists who is IN it. An object keeps its last known room forever —
    # that is deliberate, it is how "last seen in the Garage" survives a
    # dropout — but occupancy is a present-tense question, so anything past the
    # away timeout is not an occupant. Without this filter a car that left an
    # hour ago stayed listed in the Garage beside devices seen 20 seconds ago.
    try:
        _away_s = away_timeout_s(hass)
        _rtm_fresh: dict[str, list[str]] = {}
        for _obj in (snap.get("objects") or {}).get("list") or []:
            _r = _obj.get("room")
            _eid = _obj.get("entity_id") or _obj.get("key") or ""
            if _r and _eid and not is_away(_obj, _away_s):
                _rtm_fresh.setdefault(_r, []).append(_eid)
        if _rtm_fresh:
            snap["room_tag_map_live"] = _rtm_fresh
            snap["room_tag_map"] = _rtm_fresh
    except Exception:
        pass

    # Inject calibration status so the UI knows the state of the cal store
    try:
        _cal = hass.data.get(DOMAIN, {}).get(DATA_CALIBRATION)
        if _cal:
            _pts = _cal.data.get("points", [])
            _auto = sum(1 for p in _pts if str(p.get("label", "")).startswith("[auto]"))
            _empty = sum(1 for p in _pts if not (p.get("scanner_readings") or []))
            _knn_active_count = 0
            _spatial_active_count = 0
            _pc3 = hass.data.get(DOMAIN, {}).get("presence_coordinator")
            if _pc3:
                _knn_active_count = len(getattr(_pc3, "_knn_position", {}))
                _spatial_active_count = len(getattr(_pc3, "_spatial_position", {}))
            # Collect all scanner source names used in calibration data
            _cal_sources = set()
            for _p in _pts:
                for _r in (_p.get("scanner_readings") or []):
                    if _r.get("source"):
                        _cal_sources.add(_r["source"])

            # Live k-NN diagnostic: pick up to 3 objects with EMA data from the
            # presence coordinator and test them against the calibration store
            _knn_diag = []
            _ema_sources = set()
            if _pc3:
                _ema_dict = getattr(_pc3, "_ema_rssi", {})
                for _ek, _ev in list(_ema_dict.items())[:5]:
                    _ema_sources.update(_ev.keys())
                    _shared = set(_ev.keys()) & _cal_sources
                    _result = _cal.knn_locate(dict(_ev)) if _shared else None
                    _knn_diag.append({
                        "key": _ek[:40],
                        "ema_scanners": len(_ev),
                        "ema_sources": sorted(list(_ev.keys()))[:5],
                        "shared_with_cal": len(_shared),
                        "knn_result": {
                            "confidence": _result.get("confidence") if _result else None,
                            "room": _result.get("nearest_room") if _result else None,
                            "map_id": (_result.get("map_id") or "")[:20] if _result else None,
                            "k_used": _result.get("k_used") if _result else None,
                            "shared_scanners": _result.get("shared_scanners") if _result else None,
                        } if _result else None,
                    })
            snap["calibration_status"] = {
                "total_points": len(_pts),
                "auto_points": _auto,
                "manual_points": len(_pts) - _auto,
                "empty_points": _empty,
                "maps": len({p.get("map_id") for p in _pts if p.get("map_id")}),
                "scanners": len({r.get("source") for p in _pts for r in (p.get("scanner_readings") or [])}),
                "knn_min_required": 5,
                "knn_active": len(_pts) >= 5,
                "knn_positioned_objects": _knn_active_count,
                "spatial_positioned_objects": _spatial_active_count,
                "store_initialized": True,
                "rf_trained": getattr(_cal, "rf_trained", False),
                "positioning_algorithm": (
                    (hass.data.get(DOMAIN, {}).get(DATA_SETTINGS).data.get("positioning_algorithm", "knn"))
                    if hass.data.get(DOMAIN, {}).get(DATA_SETTINGS) else "knn"
                ),
                "cal_sources": sorted(list(_cal_sources))[:20],
                "ema_sources": sorted(list(_ema_sources))[:20],
                "source_overlap": len(_cal_sources & _ema_sources),
                "knn_diag": _knn_diag,
            }
        else:
            snap["calibration_status"] = {
                "total_points": 0,
                "store_initialized": False,
                "knn_active": False,
                "knn_positioned_objects": 0,
                "spatial_positioned_objects": 0,
            }
    except Exception:
        pass

    # (Traceback recorded here, from a panel's request — so nothing was
    # recorded while no PadSpan panel was open, and overnight playback was
    # empty. It records from the presence poll now, which always runs:
    # PresenceCoordinator._async_update_data.)

    # ── Expose suspend status ──────────────────────────────────────────────
    try:
        _pc_sus = hass.data.get(DOMAIN, {}).get("presence_coordinator")
        if _pc_sus:
            snap["suspended"] = _pc_sus.suspended
            if _pc_sus.suspended:
                import time as _time_mod
                if _pc_sus._suspend_permanent:
                    snap["suspend_remaining_s"] = 0  # permanent until unsuspended
                else:
                    _remaining = max(0, _pc_sus._suspend_until - _time_mod.monotonic())
                    snap["suspend_remaining_s"] = round(_remaining)
            # The panel's status dot (views/status_dot.js): positioning's last
            # update failed. Only then; a working house's snapshot is as before.
            if getattr(_pc_sus, "last_update_success", True) is False:
                snap["positioning_failed"] = True
    except Exception:
        pass

    # A linked robot vacuum's spot (vacuum_import.py) — only while the user
    # has its link on; otherwise the snapshot has no such key at all.
    try:
        from .vacuum_import import live_position
        _vac = live_position(hass)
        if _vac:
            snap["vacuum"] = _vac
    except Exception:
        pass

    # Optimize for scale: the slim copy, only while the setting is on.
    if msg.get("slim") and _scale_on(hass):
        try:
            _st = hass.data.get(DOMAIN, {}).get(DATA_SETTINGS)
            _fol = {str(f).upper() for f in ((_st.data if _st else {}).get("followed_addrs") or []) if f}
            snap = slim_snapshot(snap, _fol)
            from .telemetry import bump  # noqa: PLC0415
            bump(hass, "snapshot_slim_sent")
        except Exception as err:  # noqa: BLE001 — the full one goes instead
            _LOGGER.debug("Slim snapshot not made: %s", err)
    connection.send_result(msg["id"], {"snapshot": snap})
