# PadSpan HA — BLE Room-Presence Tracking for Home Assistant
# Copyright (C) 2026 Garry Broeckling
# Licensed under the GNU General Public License v3.0
# See LICENSE file or https://www.gnu.org/licenses/gpl-3.0.html
"""Shared helpers for the websocket handlers: settings access, the Pro licence gate, the RPA heuristic, the snapshot cache keys, the log ring buffer, geometry helpers.

Split out of websocket.py; registration stays there.
"""

from __future__ import annotations

import functools
import logging
import re
from typing import Any, NamedTuple
from homeassistant.core import HomeAssistant, callback
from .const import (
    DOMAIN,
    DATA_SETTINGS,
    DATA_MAPS,
    DATA_MODEL,
    DATA_FABRIC,
    DATA_OBJECTS,
    DATA_OBJECT_HISTORY,
    OBJECT_HISTORY_STORE_KEY,
    DATA_CALIBRATION,
    DATA_ADAPTIVE,
    DATA_ALERTS,
    DATA_MOVEMENT,
    SETTINGS_STORE_KEY,
    CALIBRATION_STORE_KEY,
    ADAPTIVE_STORE_KEY,
    OBJECT_STORE_KEY,
    MAPS_STORE_KEY,
    MODEL_STORE_KEY,
    FABRIC_STORE_KEY,
    ALERTS_STORE_KEY,
    MOVEMENT_STORE_KEY,
    DATA_TRACEBACK,
    TRACEBACK_STORE_KEY,
    DATA_FORENSICS,
    FORENSICS_STORE_KEY,
    DATA_DEVICE_REGISTRY,
    DATA_WLED_LOOKS,
    WLED_LOOKS_STORE_KEY,
    DATA_HOUSE3D,
    HOUSE3D_STORE_KEY,
    DATA_SUBZONES,
    SUBZONES_STORE_KEY,
    DATA_PLAN_AI,
    PLAN_AI_STORE_KEY,
    DATA_LOST_AND_FOUND,
    LOST_AND_FOUND_STORE_KEY,
    LIGHT_SHAPE_KINDS,
)
from . import low_memory as _low_memory
from .device_registry import DEVICE_REGISTRY_STORE_KEY
from .tester import SETTINGS_KEY as _TESTER_KEY
from .util import ha_devices


# ── In-memory ring buffer for PadSpan logs ────────────────────────────────────
# Captures WARNING+ from all padspan_ha loggers so the UI can show them.
_LOG_BUFFER_SIZE = 500


# Max rotating-MAC addresses retained per tracked object.  Bounds the persisted
# cache and the live-snapshot payload (an unbounded list reached 42k addresses /
# ~900KB on a single phone, ballooning the snapshot past the websocket limit).
_ALL_ADDR_CAP = 96


# Max addresses copied onto a single advertisement's _xref.  The frontend keys
# off canonical_id; only a cosmetic detail row ever reads these, so a sample is
# enough.  Shipping the full list on 1000+ ads grew the snapshot to ~300MB.
_XREF_ADDR_SAMPLE = 8


# Retention windows offered for object history, in days.  Anything else the
# user or a hand-edited settings file supplies falls back to the default.
_OBJECT_HISTORY_DAY_CHOICES = (1, 2, 7, 14)


# Marker shapes a light can be pinned to: const.LIGHT_SHAPE_KINDS ("auto" is
# absent as an override by design: it means "no override", which is stored
# as the entity simply not being present).
_LIGHT_SHAPE_KINDS = LIGHT_SHAPE_KINDS


_OBJECT_HISTORY_DAYS_DEFAULT = 1


def _object_history_ttl_s(hass) -> int:
    """Seconds an unidentified object is kept, from the object_history_days setting.

    Identified/tagged objects never expire, so this only bounds anonymous
    rotating-MAC churn.  Longer windows are paid for on every live_snapshot
    poll, which is why this is a small fixed set of choices rather than free
    input — see the retention note in _build_live_snapshot.
    """
    days = _OBJECT_HISTORY_DAYS_DEFAULT
    try:
        st = hass.data.get(DOMAIN, {}).get(DATA_SETTINGS)
        if st:
            raw = st.get("object_history_days")
            if raw in _OBJECT_HISTORY_DAY_CHOICES:
                days = raw
    except Exception:
        pass
    if _low_memory.enabled(hass):
        days = min(days, _low_memory.LOW_MEM_HISTORY_DAYS)
    return days * 86400


def _capped_mac_history(addrs: list) -> list:
    """De-duplicate, MAC-filter, and cap a rotating-MAC address history.

    Order is preserved and callers pass the freshest addresses first, so the
    retained head is the most recent rotations.  Stale MACs are no longer
    broadcast, making the dropped tail unreachable anyway.

    The MAC-shape filter also scrubs historic cache entries poisoned with key
    strings ("ibeacon:...") appended by older merge code.
    """
    return [
        a for a in dict.fromkeys(addrs)
        if isinstance(a, str) and len(a) == 17 and a.count(":") == 5
    ][:_ALL_ADDR_CAP]


class _RingLogHandler(logging.Handler):
    """Captures log records into a bounded list for UI display."""
    def __init__(self, maxlen: int = _LOG_BUFFER_SIZE) -> None:
        super().__init__(level=logging.DEBUG)
        self._maxlen = maxlen
        self.records: list[dict[str, Any]] = []
        # WARNING+ counts by "LEVEL:module" since last taken — the opt-in
        # usage report reads and resets these (telemetry.py). Module names
        # only, never a message: a message can carry an address or a name.
        self.counts: dict[str, int] = {}

    def emit(self, record: logging.LogRecord) -> None:
        mod = record.name[len("custom_components.padspan_ha"):].lstrip(".") \
            if record.name.startswith("custom_components.padspan_ha") else record.name
        if not mod:
            mod = "__init__"
        entry = {
            "ts": record.created,
            "level": record.levelname,
            "logger": mod,
            "message": self.format(record),
        }
        self.records.append(entry)
        if len(self.records) > self._maxlen:
            self.records = self.records[-self._maxlen:]
        if record.levelno >= logging.WARNING:
            k = f"{record.levelname}:{mod.split('.')[0][:32]}"
            self.counts[k] = self.counts.get(k, 0) + 1

    def take_counts(self) -> dict[str, int]:
        out = dict(self.counts)
        self.counts = {}
        return out


_log_handler: _RingLogHandler | None = None


def _ensure_log_handler() -> _RingLogHandler:
    global _log_handler
    if _log_handler is None:
        _log_handler = _RingLogHandler()
        _log_handler.setFormatter(logging.Formatter("%(message)s"))
        # Attach to the padspan_ha root logger to capture all sub-modules
        root = logging.getLogger("custom_components.padspan_ha")
        root.addHandler(_log_handler)
    return _log_handler


@callback
def _get_settings(hass: HomeAssistant) -> dict:
    """Read current settings for the frontend, with the licence key redacted.

    Settings go to ANY authenticated Home Assistant user — the panel has to
    work for non-admins, so this payload cannot be admin-gated without
    breaking them. The licence key therefore never travels in it: callers get
    `pro_active` (the gate's own answer, so the frontend never re-implements
    the rule) plus the expiry, and an admin who needs the key itself asks for
    it explicitly via padspan_ha/forensics_license_reveal.
    """
    st = hass.data.get(DOMAIN, {}).get(DATA_SETTINGS)
    if not st:
        return {"data_mode": "sample"}
    out = dict(st.data)
    state = _pro_expiry_state(hass)
    from .licence import edition as _edition, effective_tier as _eff  # noqa: PLC0415
    from .build_info import TIER_FLOOR as _floor  # noqa: PLC0415
    out["forensics_license_key"] = ""          # never leaves the backend
    out["license_home_token"] = ""             # nor this home's token (licence_homes.py)
    # A free licence holding the usage report on: its end, never the key's hash.
    from .settings_store import report_locked_until as _rlu  # noqa: PLC0415
    out["report_locked"] = _rlu(st.data if st else {})
    out.pop("report_locked_key", None)
    # Vacation Mode's learned patterns are backend-only and the biggest
    # thing in the store (hundreds of KiB): never sent on every settings
    # read and reply (round 6).
    out.pop("vacation_mode_pattern", None)
    out.pop("vacation_mode_pattern_prev", None)
    # "Become a tester" holds contact details a person typed (tester.py):
    # never for every user of this Home Assistant. Whether there is one is
    # all the panel needs here; an administrator reads the rest through
    # padspan_ha/tester_status.
    _signup = out.pop(_TESTER_KEY, None)
    out["tester_signed_up"] = bool(isinstance(_signup, dict) and _signup.get("signed_up_at"))
    # A Pro invite's token is what claims it: never for every user either.
    from .pro_invite import SETTINGS_KEY as _INVITE_KEY, public_state as _invite_state  # noqa: PLC0415
    out.update(_invite_state({_INVITE_KEY: out.pop(_INVITE_KEY, None)}))
    # The free-Pro offers' server switches (update_check._keep_offers): the
    # panel hides an offer that is off.
    from .update_check import offer_on as _offer_on  # noqa: PLC0415
    _switches = {"server_offers": out.pop("server_offers", None)}
    out["offer_tester"] = _offer_on(_switches, "tester")
    out["offer_invite"] = _offer_on(_switches, "invite")
    out["pro_has_key"] = state["has_key"]
    out["pro_active"] = state["active"]        # a valid key of any tier
    out["pro_days_left"] = state["days_left"]
    # The tier model (licence.py): the frontend reads these and never
    # re-implements the ladder.
    out["tier"] = _eff(st.data, bool(state["active"]))
    out["tier_floor"] = _floor
    out["edition"] = _edition()
    return out


# ── Enhanced security (Settings → Users & access) ──────────────────────────
# One switch, `enhanced_security`, off by default. While it is on, a command
# that changes this home's shared setup or state answers a non-admin with
# ENHANCED_SECURITY_MESSAGE instead of doing it; household members can still
# view and use PadSpan. Every protection that belongs to the switch goes
# through require_admin_if_enhanced() (or @admin_if_enhanced_security, its
# decorator form), so later ones layer on the same setting and the Settings
# card's list stays true. With the switch off nothing here does anything:
# each command behaves exactly as it did before the switch existed.
ENHANCED_SECURITY_CODE = "admin_only"
ENHANCED_SECURITY_MESSAGE = "Only an admin can change this while Enhanced security is on"


def enhanced_security_on(hass: HomeAssistant) -> bool:
    """Whether the Enhanced security switch is on (True only, never a guess)."""
    st = hass.data.get(DOMAIN, {}).get(DATA_SETTINGS)
    data = getattr(st, "data", None)
    return isinstance(data, dict) and data.get("enhanced_security") is True


def require_admin_if_enhanced(hass: HomeAssistant, connection, msg) -> bool:
    """True when the command may go on. With Enhanced security on and a
    caller who is not a Home Assistant admin, answers the command with the
    polite refusal the panel shows, and returns False."""
    if not enhanced_security_on(hass):
        return True
    user = getattr(connection, "user", None)
    if user is not None and getattr(user, "is_admin", False) is True:
        return True
    connection.send_error(msg["id"], ENHANCED_SECURITY_CODE, ENHANCED_SECURITY_MESSAGE)
    return False


def admin_if_enhanced_security(func):
    """require_admin_if_enhanced() for a whole command. Goes directly above
    the handler's `async def`, under @websocket_api.async_response."""
    @functools.wraps(func)
    async def _gated(hass: HomeAssistant, connection, msg) -> None:
        if not require_admin_if_enhanced(hass, connection, msg):
            return
        await func(hass, connection, msg)
    _gated.enhanced_security_gated = True
    return _gated


# Days a lapsed or unverifiable licence keeps working. Covers a house that is
# simply offline, a card that failed on renewal day, and the gap between a
# renewal and the next daily revalidation — none of which should cost someone
# access to a feature they paid for.
PRO_GRACE_DAYS = 14


def _pro_expiry_state(hass: HomeAssistant) -> dict[str, Any]:
    """Licence state without the secret: {has_key, active, expires, days_left}.

    `active` is the single source of truth for every Pro gate, and it stays
    True through PRO_GRACE_DAYS past expiry. An unparseable or absent expiry
    is treated as NOT expiring: older activations pre-date the expiry field,
    and a date we cannot read is not evidence that someone stopped paying.
    """
    st = hass.data.get(DOMAIN, {}).get(DATA_SETTINGS)
    if not st:
        return {"has_key": False, "active": False, "expires": "", "days_left": None}
    from datetime import datetime as _dt, timezone as _tzinfo  # noqa: PLC0415

    has_key = bool(str(st.data.get("forensics_license_key") or "").strip())
    expires = str(st.data.get("forensics_license_expires") or "").strip()
    days_left: int | None = None
    active = has_key
    if has_key and expires:
        # Parsed with the stdlib, not dt_util: the expiry is an ISO string
        # produced by our own licence server, and this way the rule that
        # decides whether a customer keeps access has no dependency that can
        # be stubbed, patched or mocked into answering differently.
        try:
            exp = _dt.fromisoformat(expires.replace("Z", "+00:00"))
            if exp.tzinfo is None:
                exp = exp.replace(tzinfo=_tzinfo.utc)
            from datetime import timedelta as _td  # noqa: PLC0415
            left = exp - _dt.now(_tzinfo.utc)
            days_left = left.days
            # .days rounds down, so comparing it cut the grace to 13 days.
            active = left > -_td(days=PRO_GRACE_DAYS)
        except Exception:
            days_left = None      # unreadable date → treat as non-expiring
    return {"has_key": has_key, "active": active, "expires": expires, "days_left": days_left}


def _padspan_pro_active(hass: HomeAssistant) -> bool:
    """True when this install runs at the `pro` tier (key active, tier pro).

    The gate for the presence-side Pro features (Forensics, ...). Lighting
    features gate at `bright` — see _tier_at_least — because a Bright Pro key
    unlocks them and a Pro key is a superset. One ladder, one comparison.

    Soft degrade by design: this gate governs Pro EDITING and Forensics
    recording (forensics_store._recording_enabled) only. Data a user
    already created stays readable and exportable when a licence lapses —
    losing access to your own recorded history because a card expired is not
    something this product does.
    """
    return _tier_at_least(hass, "pro")


def _tier_at_least(hass: HomeAssistant, want: str) -> bool:
    """The one gate: does the effective tier reach `want`? (licence.py)"""
    from .licence import hass_tier_at_least  # noqa: PLC0415
    return hass_tier_at_least(hass, want)


def _is_rpa_addr(address: str) -> bool:
    """Return True if a BLE address is a Resolvable Private Address (rotating MAC).

    CAUTION: this MSB heuristic is only meaningful for addresses that are
    actually of the *random* type.  HA's snapshot does not expose the HCI
    address-type bit, so any PUBLIC IEEE-assigned MAC whose OUI starts with
    0x40-0x7F (~25% of vendor space, e.g. 48:87:2D = Shen Zhen Da Xia "DX"
    beacons) false-positives here.  Callers must not treat a True result as
    proof of rotation on its own — see the named-device exemption in the
    objects build and the same-OUI guard in the iBeacon split.
    """
    try:
        msb = int(address.upper().split(":")[0], 16)
        return (msb & 0xC0) == 0x40
    except Exception:
        return False


# iBeacon UUIDs that ship as factory defaults on cheap beacon hardware.
# Beacons sold in multi-packs all broadcast the same uuid:major:minor out of
# the box, so these UUIDs must never be trusted as a unique device identity —
# the simultaneous-MAC split below always separates them per MAC.
_DEFAULT_IBEACON_UUIDS = frozenset({
    "e2c56db5-dffb-48d2-b060-d0f5a71096e0",  # AprilBrother / textbook demo UUID (DX CP27 and many clones)
    "fda50693-a4e2-4fb1-afcf-c6eb07647825",  # common Chinese default (HM-10 clones, iTag)
    "b9407f30-f5f8-466e-aff9-25556b57fe6d",  # Estimote factory default
    "f7826da6-4fa2-4e98-8024-bc5b71e0893e",  # Kontakt.io factory default
    "74278bda-b644-4520-8f0c-720eaf059935",  # Glimworm / generic example UUID
})


_SNAPSHOT_CACHE_TTL_S = 2.0


_DATA_SNAPSHOT_CACHE = "snapshot_cache"


_DATA_SNAPSHOT_CACHE_LOCK = "snapshot_cache_lock"


def _invalidate_snapshot_cache(hass: HomeAssistant) -> None:
    """Drop the cached live snapshot so the next fetch rebuilds.

    Called by mutating handlers whose effect the panel re-reads immediately
    (labels, radio areas, settings) — without this, a rename could appear to
    do nothing until the cache TTL expires.
    """
    hass.data.get(DOMAIN, {}).pop(_DATA_SNAPSHOT_CACHE, None)


_ALL_STORE_KEYS = [
    SETTINGS_STORE_KEY,
    CALIBRATION_STORE_KEY,
    ADAPTIVE_STORE_KEY,
    OBJECT_STORE_KEY,
    MAPS_STORE_KEY,
    MODEL_STORE_KEY,
    FABRIC_STORE_KEY,
    ALERTS_STORE_KEY,
    MOVEMENT_STORE_KEY,
    TRACEBACK_STORE_KEY,
    OBJECT_HISTORY_STORE_KEY,
    WLED_LOOKS_STORE_KEY,
    HOUSE3D_STORE_KEY,
    LOST_AND_FOUND_STORE_KEY,
    SUBZONES_STORE_KEY,
    PLAN_AI_STORE_KEY,
    "padspan_ha.vacuum",          # vacuum_import.VACUUM_STORE_KEY: the robot link, walker and review pile
]


# Maps HA Storage file keys → in-memory hass.data[DOMAIN] keys.
# Used by both backup (read live data) and restore (hot-patch in-memory stores).
_DATA_KEY_MAP = {
    SETTINGS_STORE_KEY: DATA_SETTINGS,
    CALIBRATION_STORE_KEY: DATA_CALIBRATION,
    ADAPTIVE_STORE_KEY: DATA_ADAPTIVE,
    OBJECT_STORE_KEY: DATA_OBJECTS,
    MAPS_STORE_KEY: DATA_MAPS,
    MODEL_STORE_KEY: DATA_MODEL,
    FABRIC_STORE_KEY: DATA_FABRIC,
    ALERTS_STORE_KEY: DATA_ALERTS,
    MOVEMENT_STORE_KEY: DATA_MOVEMENT,
    TRACEBACK_STORE_KEY: DATA_TRACEBACK,
    OBJECT_HISTORY_STORE_KEY: DATA_OBJECT_HISTORY,
    # A Pro customer's forensics sessions are the data they paid to collect —
    # omitting them from "full backup" meant a restore silently lost the
    # paid-for feature's entire history. The device registry is the stable
    # identity map everything else references; without it a restore comes
    # back with correct data attached to unrecognisable devices.
    FORENSICS_STORE_KEY: DATA_FORENSICS,
    DEVICE_REGISTRY_STORE_KEY: DATA_DEVICE_REGISTRY,
    # Each WLED device's remembered look and the sync settings PadSpan
    # switched off (wled_exact.py) — what puts a strip back after a rebuild.
    WLED_LOOKS_STORE_KEY: DATA_WLED_LOOKS,
    # Live Aboard's own file (house3d_store.py): furniture, 3D-only light
    # heights and door swings. A file that was never written is left out of
    # backups (_BACKUP_ONLY_ONCE_WRITTEN below). A backup carrying
    # "padspan_ha.house3d": {} comes only from commit e8a10ada, which was
    # never installed anywhere.
    HOUSE3D_STORE_KEY: DATA_HOUSE3D,
    # Lost & Found (lost_and_found_store.py): each tracked object's last
    # confirmed room, kept so it "never resets to Unknown" — and a restore
    # reset all of it, because it was never in a backup. Its live data is
    # `records` (ws_backup handles the attribute).
    LOST_AND_FOUND_STORE_KEY: DATA_LOST_AND_FOUND,
    # Sub-zones (subzones.py): no file until one is added, like Live Aboard's.
    SUBZONES_STORE_KEY: DATA_SUBZONES,
    # The plan AI's suggestions, verdicts and remembered rejects (plan_ai.py): no file until a session runs.
    PLAN_AI_STORE_KEY: DATA_PLAN_AI,
    # The robot vacuum's link, walker and review pile (vacuum_import.py): no file until an import.
    "padspan_ha.vacuum": "vacuum_import",
}


# Stores a backup takes only once their file exists. Live Aboard is normally
# off: an install that never used it has no file, and its backups must carry
# no entry for it, or a later restore would create the file, or empty one that
# has furniture in it by then (house3d_store.py).
_BACKUP_ONLY_ONCE_WRITTEN = frozenset({HOUSE3D_STORE_KEY, SUBZONES_STORE_KEY, PLAN_AI_STORE_KEY, "padspan_ha.vacuum"})

# "There was no file": what a safety backup taken right before an operation
# that may CREATE one of those stores records for it (the Bright import's;
# _auto_backup(mark_absent=True)), so that restoring it can take that file
# away again. Ordinary backups never record it: restoring an older backup
# must not wipe furniture placed since (house3d_store.async_restore_data).
ABSENT_MARKER = "__padspan_absent__"


def _is_absent_marker(data) -> bool:
    return isinstance(data, dict) and len(data) == 1 and data.get(ABSENT_MARKER) is True


async def _store_file_written(hass, store_key: str) -> bool:
    """Does Home Assistant hold this store's file (.storage/<key>)? If the
    check itself fails, the answer is yes: a backup that carries an empty
    entry is the old behaviour, one that silently drops a real file loses
    data."""
    import os  # noqa: PLC0415
    try:
        path = hass.config.path(".storage", store_key)
        return bool(await hass.async_add_executor_job(os.path.isfile, path))
    except Exception:  # noqa: BLE001
        return True


_MAX_BACKUPS = 3  # Oldest backup is dropped when a new one exceeds this limit
# Automatic backups (ws_backup._auto_backup, marked "auto") have their own cap
# and never push out a backup a person made, nor the other way round. One with
# a slot of its own (the plan AI's net) stands outside this cap.
_MAX_AUTO_BACKUPS = 3


def _room_from_bounds(room_bounds: dict, x: float, y: float) -> str:
    """Determine which room a point (x,y) falls in using room boundary shapes.

    Supports two shape types:
      - "circle": center (cx,cy) + radius r — simple distance check
      - "poly": list of [x,y] vertices — ray-casting point-in-polygon test
    Returns the room name or '' if the point is outside all boundaries.
    """
    for room_name, b in room_bounds.items():
        if not isinstance(b, dict):
            continue
        btype = b.get("type", "poly")
        if btype == "circle":
            cx = float(b.get("cx", 0.5))
            cy = float(b.get("cy", 0.5))
            r = float(b.get("r", 0.12))
            if (x - cx) ** 2 + (y - cy) ** 2 <= r ** 2:
                return str(room_name)
        elif btype == "poly":
            pts = b.get("points") or []
            if len(pts) < 3:
                continue
            # Ray-casting point-in-polygon test
            inside = False
            n = len(pts)
            j = n - 1
            for i in range(n):
                xi, yi = float(pts[i][0]), float(pts[i][1])
                xj, yj = float(pts[j][0]), float(pts[j][1])
                if ((yi > y) != (yj > y)) and (x < (xj - xi) * (y - yi) / (yj - yi) + xi):
                    inside = not inside
                j = i
            if inside:
                return str(room_name)
    return ""


def _point_in_polygon(x: float, y: float, polygon: list) -> bool:
    """Ray-casting point-in-polygon test for [x,y] coordinate lists."""
    n = len(polygon)
    if n < 3:
        return False
    inside = False
    j = n - 1
    for i in range(n):
        xi, yi = float(polygon[i][0]), float(polygon[i][1])
        xj, yj = float(polygon[j][0]), float(polygon[j][1])
        if ((yi > y) != (yj > y)) and (x < (xj - xi) * (y - yi) / (yj - yi) + xi):
            inside = not inside
        j = i
    return inside


# ── Resolving a BLE radio to its HA device ──────────────────────────────────
#
# A radio arrives from HA's bluetooth manager carrying a `source` (an ESPHome
# node slug like "btproxy_livingroom", a bare adapter name like "hci0", or a
# MAC) and a display `name`. Neither is an HA device id, so the device has to
# be found before a scanner can be given an area.
#
# It used to be found with a two-way substring test against every device name,
# taking the first hit out of an unordered registry:
#
#     if key in src or src in key or key in rname or rname in key:
#
# A device called "btproxy" therefore answers to "btproxy_livingroom" and
# "btproxy_kitchen" as well, and which of the three won depended on dict order.
# Assigning an area to one scanner wrote it to another, and because the same
# rule also filled in every radio's displayed area, they appeared to move
# together (issue #65).
#
# Containment is not identity: a name that contains another name is a DIFFERENT
# device. Resolution here is exact, and a collision is refused rather than
# broken by arbitrary order. A scanner with no area is a visible gap someone
# can fix; a scanner holding another scanner's area is a wrong answer that
# looks right.

_SLUG_RE = re.compile(r"[^a-z0-9]+")
_MAC_RE = re.compile(r"^[0-9A-F]{2}(:[0-9A-F]{2}){5}$")
# Shorter than this is not a name, it is a coincidence. Same floor the entity
# slug lookup in snapshot_builder already uses.
_MIN_PARTIAL_LEN = 3


def radio_slug(value: Any) -> str:
    """Lowercase, with every run of non-alphanumerics collapsed to one '_'."""
    return _SLUG_RE.sub("_", str(value or "").lower()).strip("_")


def _norm_mac(value: Any) -> str:
    mac = str(value or "").upper().replace("-", ":")
    return mac if _MAC_RE.match(mac) else ""


def _device_label(dev: Any) -> str:
    return str(getattr(dev, "name_by_user", None) or getattr(dev, "name", None)
               or getattr(dev, "id", "") or "")


def _is_shelly(dev: Any) -> bool:
    for ident in (getattr(dev, "identifiers", None) or set()):
        try:
            if ident[0] == "shelly":
                return True
        except (IndexError, TypeError):
            continue
    return False


def _shelly_bluetooth_mac(network_mac: str) -> str:
    """The MAC a Shelly's Bluetooth scanner goes by, from its network MAC.

    Home Assistant's Shelly integration registers the scanner under the
    device's Bluetooth MAC, its network MAC + 2 (aioshelly's
    bluetooth_mac_from_primary_mac), but its device lists the network MAC
    alone. So the scanner matched no device by MAC: its room was left to a
    name match, and "set this scanner's room", which looks up the source
    only, found no device at all. ESPHome lists its Bluetooth MAC among the
    device's connections itself, so only Shelly needs this.
    """
    n = int(network_mac.replace(":", ""), 16) + 2
    if n > 0xFFFFFFFFFFFF:
        return ""
    h = f"{n:012X}"
    return ":".join(h[i:i + 2] for i in range(0, 12, 2))


_NAME_MAC_TAIL_RE = re.compile(r"\s*\((?:[0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2}\)\s*$")


NAME_FROM: tuple[str, ...] = ("ha_user", "ha", "scanner", "area", "source")


def radio_display(radio: dict, device: Any = None, parent: Any = None) -> tuple[str, str]:
    """The one name a receiver goes by everywhere in the panel, and where it
    came from (one of NAME_FROM, for the opt-in report).

    Home Assistant files a remote scanner as its own device, named "X (AA:BB:..)",
    via the ESPHome or Shelly device that provides it (`parent`). A name set on
    that device wins: the one the user gave it in Home Assistant, then the
    scanner device's, then the device's own name (what's set in ESPHome), then
    the scanner device's. No "(AA:BB:..)" tail on any of them. Then the scanner's
    name, then "<area> receiver", then the raw source.
    """
    src = str(radio.get("source") or "")
    for dev, attr, origin in ((parent, "name_by_user", "ha_user"), (device, "name_by_user", "ha_user"),
                              (parent, "name", "ha"), (device, "name", "ha")):
        v = _NAME_MAC_TAIL_RE.sub("", str(getattr(dev, attr, None) or "")).strip()
        if v:
            return v, origin
    raw = str(radio.get("name") or "").strip()
    if raw and raw != src:
        cleaned = _NAME_MAC_TAIL_RE.sub("", raw).strip()
        if cleaned and _norm_mac(cleaned) == "":
            return cleaned, "scanner"
    area = str(radio.get("area_name") or "").strip()
    if area:
        return f"{area} receiver", "area"
    return src, "source"


def radio_display_name(radio: dict, device: Any = None) -> str:
    return radio_display(radio, device)[0]


class RadioMatch(NamedTuple):
    """device is None unless exactly one device was identified.

    reason is one of: "mac", "name", "partial", "ambiguous", "none".
    candidates carries the colliding device labels when reason is "ambiguous",
    so a caller can tell the user which names to change. It is for the user's
    own screen — never put it in anything that leaves the install.
    """

    device: Any | None
    reason: str
    candidates: list


class RadioDeviceIndex:
    """Device-registry lookup for BLE radios.

    Built once per pass and queried per radio: the old code walked the whole
    registry for every radio, and resolving one at a time would do the same.
    """

    def __init__(self, hass: HomeAssistant) -> None:
        self._by_slug: dict[str, list] = {}
        self._by_mac: dict[str, list] = {}
        self._by_shelly_bt: dict[str, list] = {}   # _shelly_bluetooth_mac
        # How often the two Shelly rules (0.38.175 and 0.38.176) decided a
        # radio, read by the snapshot for the opt-in report. Counts only.
        self.shelly_matched = 0
        self.area_from_via = 0
        self._by_id: dict[str, Any] = {}           # area_id_of's via device
        # Membership by id, beside each list: `dev not in bucket` compared
        # whole DeviceEntry objects, quadratic in devices sharing a name
        # (4,000 same-named devices took 1.5 s, on every snapshot build).
        seen_slug: dict[str, set[int]] = {}
        seen_mac: dict[str, set[int]] = {}
        seen_bt: dict[str, set[int]] = {}
        try:
            from homeassistant.helpers import device_registry  # noqa: PLC0415
            devices = ha_devices(device_registry.async_get(hass))
        except Exception:
            devices = []
        # Sorted by id so a run is reproducible. Ties are refused rather than
        # broken, but determinism means the same install answers the same way.
        for dev in sorted(devices, key=lambda d: str(getattr(d, "id", ""))):
            if getattr(dev, "id", None):
                self._by_id[str(dev.id)] = dev
            for cand in (getattr(dev, "name_by_user", None), getattr(dev, "name", None)):
                slug = radio_slug(cand)
                if slug and id(dev) not in seen_slug.setdefault(slug, set()):
                    seen_slug[slug].add(id(dev))
                    self._by_slug.setdefault(slug, []).append(dev)
            shelly = _is_shelly(dev)
            for conn in (getattr(dev, "connections", None) or set()):
                try:
                    mac = _norm_mac(conn[1])
                except (IndexError, TypeError):
                    continue
                if mac and id(dev) not in seen_mac.setdefault(mac, set()):
                    seen_mac[mac].add(id(dev))
                    self._by_mac.setdefault(mac, []).append(dev)
                if shelly and mac and conn[0] == "mac":
                    bt = _shelly_bluetooth_mac(mac)
                    if bt and id(dev) not in seen_bt.setdefault(bt, set()):
                        seen_bt[bt].add(id(dev))
                        self._by_shelly_bt.setdefault(bt, []).append(dev)

    def parent_of(self, dev: Any) -> Any:
        """The device a scanner device belongs to, its "via" device, or None.
        Only a scanner device (see area_id_of): any other device's via device
        is something else, a hub for one."""
        if not any(isinstance(c, (tuple, list)) and c and c[0] == "bluetooth" for c in (getattr(dev, "connections", None) or ())):
            return None
        return self._by_id.get(str(getattr(dev, "via_device_id", None) or ""))

    def area_id_of(self, dev: Any) -> str | None:
        """A radio device's area, else the area of the device it belongs to.

        Since 2025.2 Home Assistant files each remote Bluetooth scanner as its
        own device under the Bluetooth integration, via the device that
        provides it, and copies that device's area to it only when the
        scanner's device is set up and has none. A Shelly given its area after
        its scanner appeared therefore had a scanner with no area, and so no
        room, until Home Assistant's next start. A scanner device with no area
        takes its via device's, as that next start would; one with an area of
        its own keeps it.
        """
        area = getattr(dev, "area_id", None)
        if area:
            return area
        # Only a scanner device Home Assistant's Bluetooth integration made
        # (connections {("bluetooth", <its MAC>)}, via the proxy's device) takes
        # its via device's area, as HA itself does at setup; any other device
        # with no area stays without one (the stable review, 2026-10-29: the
        # rule reached every device with a via device).
        if not any(isinstance(c, (tuple, list)) and c and c[0] == "bluetooth" for c in (getattr(dev, "connections", None) or ())):
            return None
        via = self._by_id.get(str(getattr(dev, "via_device_id", None) or ""))
        area = (getattr(via, "area_id", None) or None) if via is not None else None
        if area:
            self.area_from_via += 1           # for the opt-in report (0.38.176's field signal)
        return area

    @property
    def devices_n(self) -> int:
        return len({id(d) for b in self._by_slug.values() for d in b})

    @property
    def same_name_max(self) -> int:
        """The most devices sharing one name (for the opt-in report)."""
        return max((len(b) for b in self._by_slug.values()), default=0)

    def _result(self, hits: list, reason: str) -> RadioMatch | None:
        if len(hits) == 1:
            return RadioMatch(hits[0], reason, [])
        if len(hits) > 1:
            return RadioMatch(None, "ambiguous", [_device_label(d) for d in hits])
        return None

    def resolve(self, source: Any, name: Any = "") -> RadioMatch:
        """Identify the HA device behind one radio."""
        # 1. A MAC is the only identifier here that is unique by construction.
        mac = _norm_mac(source)
        if mac:
            found = self._result(self._by_mac.get(mac) or [], "mac")
            if found:
                return found
            # A Shelly's scanner: its Bluetooth MAC, which its device doesn't
            # list (_shelly_bluetooth_mac). Still a MAC, so still before names.
            found = self._result(self._by_shelly_bt.get(mac) or [], "mac")
            if found:
                self.shelly_matched += 1      # for the opt-in report (0.38.175's field signal)
                return found

        keys = {k for k in (radio_slug(source), radio_slug(name)) if k}
        if not keys:
            return RadioMatch(None, "none", [])

        # 2. The whole name, not part of one. "btproxy_livingroom" matches the
        #    device of that name and does not match "btproxy".
        exact: list = []
        seen: set[int] = set()
        for key in sorted(keys):
            for dev in self._by_slug.get(key, []):
                if id(dev) not in seen:
                    seen.add(id(dev))
                    exact.append(dev)
        found = self._result(exact, "name")
        if found:
            return found

        # 3. Last resort: containment, accepted ONLY when it names exactly one
        #    device. This is what keeps an install working where the device
        #    name and the scanner source are related but not equal ("Living
        #    Room Hub BLE Proxy" against "living_room_hub"). Demanding
        #    uniqueness is what stops a shared prefix claiming three scanners.
        partial: list = []
        seen = set()
        for slug, devs in self._by_slug.items():
            if len(slug) < _MIN_PARTIAL_LEN:
                continue
            if any(slug in k or (len(k) >= _MIN_PARTIAL_LEN and k in slug) for k in keys):
                for dev in devs:
                    if id(dev) not in seen:
                        seen.add(id(dev))
                        partial.append(dev)
        found = self._result(partial, "partial")
        if found:
            return found

        return RadioMatch(None, "none", [])
