# PadSpan HA — BLE Room-Presence Tracking for Home Assistant
# Copyright (C) 2026 Garry Broeckling
# Licensed under the GNU General Public License v3.0
# See LICENSE file or https://www.gnu.org/licenses/gpl-3.0.html
"""Websocket handler for the factory reset.

Split out of websocket.py; registration stays there.
"""

from __future__ import annotations

import logging
import voluptuous as vol
from homeassistant.components import websocket_api
from homeassistant.core import HomeAssistant
from .telemetry import bump as _bump
from .const import (
    DOMAIN,
    DATA_SETTINGS,
    DATA_MAPS,
    DATA_MODEL,
    DATA_FABRIC,
    DATA_OBJECTS,
    DATA_OBJECTS_CACHE,
    DATA_OBJECT_HISTORY,
    OBJECT_HISTORY_STORE_KEY,
    DATA_BEACON_LAST_MACS,
    DATA_COORDINATOR,
    DATA_CALIBRATION,
    DATA_ADAPTIVE,
    DATA_ALERTS,
    DATA_MOVEMENT,
    BACKUPS_STORE_KEY,
    SETTINGS_STORE_KEY,
    CALIBRATION_STORE_KEY,
    ADAPTIVE_STORE_KEY,
    OBJECT_STORE_KEY,
    FINDMY_STORE_KEY,
    MAPS_STORE_KEY,
    MODEL_STORE_KEY,
    FABRIC_STORE_KEY,
    ALERTS_STORE_KEY,
    MOVEMENT_STORE_KEY,
    DATA_TRACEBACK,
    TRACEBACK_STORE_KEY,
)
from .bluetooth_live import get_bluetooth_live

_LOGGER = logging.getLogger(__name__)


@websocket_api.websocket_command({
    "type": "padspan_ha/factory_reset",
    vol.Required("confirm"): str,
})
@websocket_api.require_admin
@websocket_api.async_response
async def ws_factory_reset(hass: HomeAssistant, connection, msg) -> None:
    """Erase every PadSpan HA persistent store and reset to factory defaults.

    Requires confirm="FACTORY RESET" as a safety latch.  Admin-only.

    Resets 12 stores, each to its correct empty/default state:
      - SettingsStore → DEFAULT_SETTINGS (not {}, which would break the UI)
      - MapsStore → {"maps": []} + deletes uploaded image files from disk
      - CalibrationStore → {"points": [], "model": {}}
      - AdaptiveStore → empty room fingerprints / stats
      - ModelStore → DEFAULT_DATA
      - FabricStore → {"floors": {}, "history": []}
      - ObjectStore, AlertStore → {}
      - MovementStore → []
      - TracebackStore → {"frames": []}
      - ObjectHistory → {} (in-memory dict, re-initialized on next snapshot)
      - BackupsStore → {}

    Also clears in-memory caches: presence coordinator, main coordinator,
    object history dict, and bluetooth_live advertisement cache.

    bluetooth_live subscription is intentionally left intact — BLE radios
    keep working and will repopulate naturally.
    """
    if msg["confirm"] != "FACTORY RESET":
        connection.send_error(
            msg["id"], "confirmation_failed",
            'You must pass confirm="FACTORY RESET" to proceed.'
        )
        return

    import asyncio as _aio
    from homeassistant.helpers.storage import Store as _St
    from .settings_store import DEFAULT_SETTINGS
    from .model_store import DEFAULT_DATA as _model_defaults

    def _adaptive_empty():
        return {
            "room_fingerprints": {},
            "transition_counts": {},
            "floor_pairs": {},
            "stats": {"total_observations": 0, "learning_since": None, "days_active": 0},
        }

    domain = hass.data.get(DOMAIN, {})
    cleared = 0
    errors = []

    # ── 1. SettingsStore — reset to DEFAULT_SETTINGS, NOT {} ─────────────
    # The purchased licence survives a factory reset. It is not configuration
    # the user is asking to clear — it is proof of payment, it cannot be read
    # back once gone, and wiping it turns "start clean" into a support ticket.
    try:
        _live_settings = domain.get(DATA_SETTINGS)
        _keep_licence = {
            k: (_live_settings.data if _live_settings else {}).get(k, "")
            for k in ("forensics_license_key", "forensics_license_expires", "license_is_trial", "license_tier")
        }
        # Vacation Mode's spans describe what is in HA's recorder, which a
        # PadSpan reset does not touch — a reset mid-vacation closes the span
        # so the next vacation's pattern still leaves it out.
        import time as _time
        from .vacation_mode import learned_pattern, switch_fields
        _live = _live_settings.data if _live_settings else {}
        _vac = {"vacation_mode_periods": _live.get("vacation_mode_periods") or [],
                "vacation_mode_pattern_prev": learned_pattern(_live),
                "vacation_mode_tracked_since": _live.get("vacation_mode_tracked_since") or 0,
                **switch_fields(_live, False, _time.time())}
        _vac.pop("vacation_mode_enabled_at", None)
        # A tester sign-up survives too: its id is the only way to reach the
        # server's copy, and "Stop being a tester" must keep working after a
        # reset (tester.carried_over).
        from .tester import carried_over as _tester_kept
        # And the trial milestone's answer and first sighting: a reset is not
        # a new install, so the card never comes back and its week never
        # restarts (settings_store.trial_state_kept).
        from .settings_store import trial_state_kept as _trial_kept
        st = _St(hass, 1, SETTINGS_STORE_KEY)
        _reset = {**dict(DEFAULT_SETTINGS), **{
            k: v for k, v in _keep_licence.items() if v
        }, **_vac, **_tester_kept(_live), **_trial_kept(_live)}
        # A Pro invite, open or answered, is this install's: a reset must not
        # forget a No thanks (pro_invite.py).
        from .pro_invite import SETTINGS_KEY as _INVITE_KEY
        if isinstance(_live, dict) and _live.get(_INVITE_KEY):
            _reset[_INVITE_KEY] = _live[_INVITE_KEY]
        # And the offers' server switches: an ended offer must not come back
        # until the next update check (or ever, with it turned off).
        if isinstance(_live, dict) and _live.get("server_offers"):
            _reset["server_offers"] = _live["server_offers"]
        await st.async_save(_reset)
        cleared += 1
        store_obj = domain.get(DATA_SETTINGS)
        if store_obj and hasattr(store_obj, "data"):
            store_obj.data = dict(_reset)
    except Exception as e:
        _LOGGER.warning("Factory reset: settings — %s", e)
        errors.append(SETTINGS_STORE_KEY)

    # ── 2. MapsStore — reset to {"maps": []} and delete map image files ──
    try:
        st = _St(hass, 1, MAPS_STORE_KEY)
        await st.async_save({"maps": []})
        cleared += 1
        maps_obj = domain.get(DATA_MAPS)
        if maps_obj and hasattr(maps_obj, "data"):
            maps_obj.data = {"maps": []}
        # Delete uploaded map images
        if maps_obj and hasattr(maps_obj, "maps_dir"):
            _mdir = maps_obj.maps_dir
        else:
            from .maps_store import maps_dir_for
            _mdir = maps_dir_for(hass)

        def _image_files() -> list:
            # is_dir / iterdir / is_file all touch the disk: not on the loop.
            if not _mdir.is_dir():
                return []
            return [f for f in _mdir.iterdir()
                    if f.is_file() and f.suffix.lower() in (".png", ".jpg", ".jpeg", ".webp")]

        for f in await _aio.to_thread(_image_files):
            try:
                await _aio.to_thread(f.unlink)
            except Exception:
                pass
    except Exception as e:
        _LOGGER.warning("Factory reset: maps — %s", e)
        errors.append(MAPS_STORE_KEY)

    # ── 3. CalibrationStore — reset to {"points": [], "model": {}} ───────
    try:
        st = _St(hass, 1, CALIBRATION_STORE_KEY)
        await st.async_save({"points": [], "model": {}})
        cleared += 1
        cal_obj = domain.get(DATA_CALIBRATION)
        if cal_obj and hasattr(cal_obj, "data"):
            cal_obj.data = {"points": [], "model": {}}
    except Exception as e:
        _LOGGER.warning("Factory reset: calibration — %s", e)
        errors.append(CALIBRATION_STORE_KEY)

    # ── 4. AdaptiveStore — reset to _empty_data() ────────────────────────
    try:
        st = _St(hass, 1, ADAPTIVE_STORE_KEY)
        await st.async_save(_adaptive_empty())
        cleared += 1
        ada_obj = domain.get(DATA_ADAPTIVE)
        if ada_obj and hasattr(ada_obj, "data"):
            ada_obj.data = _adaptive_empty()
    except Exception as e:
        _LOGGER.warning("Factory reset: adaptive — %s", e)
        errors.append(ADAPTIVE_STORE_KEY)

    # ── 5. ModelStore — reset to DEFAULT_DATA ─────────────────────────────
    try:
        st = _St(hass, 1, MODEL_STORE_KEY)
        await st.async_save(dict(_model_defaults))
        cleared += 1
        mod_obj = domain.get(DATA_MODEL)
        if mod_obj and hasattr(mod_obj, "data"):
            mod_obj.data = dict(_model_defaults)
    except Exception as e:
        _LOGGER.warning("Factory reset: model — %s", e)
        errors.append(MODEL_STORE_KEY)

    # ── 5b. FabricStore — reset room-geometry ground truth ────────────────
    # A factory reset is the one sanctioned full wipe: the "FACTORY RESET"
    # confirm latch above is the explicit user consent the fabric requires.
    try:
        st = _St(hass, 1, FABRIC_STORE_KEY)
        await st.async_save({"floors": {}, "history": []})
        cleared += 1
        fab_obj = domain.get(DATA_FABRIC)
        if fab_obj and hasattr(fab_obj, "data"):
            fab_obj.data = {"floors": {}, "history": []}
    except Exception as e:
        _LOGGER.warning("Factory reset: fabric — %s", e)
        errors.append(FABRIC_STORE_KEY)

    # ── 6. ObjectStore — reset ._data to {} ───────────────────────────────
    try:
        st = _St(hass, 1, OBJECT_STORE_KEY)
        await st.async_save({})
        cleared += 1
        obj_obj = domain.get(DATA_OBJECTS)
        if obj_obj:
            if hasattr(obj_obj, "_data"):
                obj_obj._data = {}
            elif hasattr(obj_obj, "data"):
                obj_obj.data = {}
    except Exception as e:
        _LOGGER.warning("Factory reset: objects — %s", e)
        errors.append(OBJECT_STORE_KEY)

    # ── 6b. Find My links — which address each known tag uses (findmy.py) ──
    try:
        # Through the live Store too: a delayed save it still holds (within
        # 5 s of a link) would otherwise write the old links back (round 8).
        _old_fm = domain.pop("findmy_bridge_store", None)
        if _old_fm is not None:
            await _old_fm.async_save({})
        st = _St(hass, 1, FINDMY_STORE_KEY)
        await st.async_save({})
        cleared += 1
        domain.pop("findmy_bridge", None)
    except Exception as e:
        _LOGGER.warning("Factory reset: Find My links — %s", e)
        errors.append(FINDMY_STORE_KEY)

    # ── 7. AlertStore — reset to {} ───────────────────────────────────────
    try:
        st = _St(hass, 1, ALERTS_STORE_KEY)
        await st.async_save({})
        cleared += 1
        alert_obj = domain.get(DATA_ALERTS)
        if alert_obj and hasattr(alert_obj, "data"):
            alert_obj.data = {}
    except Exception as e:
        _LOGGER.warning("Factory reset: alerts — %s", e)
        errors.append(ALERTS_STORE_KEY)

    # ── 8. MovementStore — reset .entries to [] ───────────────────────────
    try:
        st = _St(hass, 1, MOVEMENT_STORE_KEY)
        await st.async_save([])
        cleared += 1
        mov_obj = domain.get(DATA_MOVEMENT)
        if mov_obj and hasattr(mov_obj, "entries"):
            mov_obj.entries = []
        elif mov_obj and hasattr(mov_obj, "data"):
            mov_obj.data = []
    except Exception as e:
        _LOGGER.warning("Factory reset: movement — %s", e)
        errors.append(MOVEMENT_STORE_KEY)

    # ── 9. TracebackStore — the whole history, segment files included ────
    # It emptied only the old single file and the in-memory list: the daily
    # segment files (the real history) stayed, and every movement came back
    # on the next reload.
    try:
        tb_obj = domain.get(DATA_TRACEBACK)
        if tb_obj is not None and hasattr(tb_obj, "async_replace"):
            await tb_obj.async_replace([])
        else:
            await _St(hass, 1, TRACEBACK_STORE_KEY).async_save({"frames": []})
        cleared += 1
    except Exception as e:
        _LOGGER.warning("Factory reset: traceback — %s", e)
        errors.append(TRACEBACK_STORE_KEY)

    # ── 9a. Live Aboard, the 3D house (house3d_store.py) ──────────────────
    # Emptied like the rest, terms acceptance included, but only a file that
    # exists: an install that never turned the feature on gets no new file
    # out of a reset (a store merely loaded by a read is not a file). What
    # this house shared to the library survives, as a tester sign-up does:
    # its owner tokens are the only way to withdraw it, and "Withdraw my
    # shared furniture" must keep working after a reset
    # (house3d_library.carried_over). Under the store's own lock, as a
    # restore is (ws_backup._store_lock): a Save under way finishes first.
    try:
        from .const import DATA_HOUSE3D, HOUSE3D_STORE_KEY  # noqa: PLC0415
        from .house3d_store import ReadFailed as _house3d_unread  # noqa: PLC0415
        from .house3d_store import async_file_exists as _house3d_written  # noqa: PLC0415
        from .house3d_store import async_get_store as _house3d_store  # noqa: PLC0415
        from .house3d_store import empty as _house3d_empty  # noqa: PLC0415
        from .ws_backup import _store_lock  # noqa: PLC0415
        async with await _store_lock(hass, HOUSE3D_STORE_KEY):
            _h3_new = _house3d_empty()
            if await _house3d_written(hass):
                from .house3d_library import carried_over as _shared_kept  # noqa: PLC0415
                try:
                    _h3_new = _shared_kept((await _house3d_store(hass)).data, _h3_new)
                except _house3d_unread:
                    pass
                st = _St(hass, 1, HOUSE3D_STORE_KEY)
                await st.async_save(_h3_new)
                cleared += 1
            h3_obj = domain.get(DATA_HOUSE3D)
            if h3_obj is not None and hasattr(h3_obj, "data"):
                h3_obj.data = _h3_new
    except Exception as e:
        _LOGGER.warning("Factory reset: house3d — %s", e)
        errors.append("padspan_ha.house3d")

    # ── 9b. CaptureStore — manifest AND session files ─────────────────────
    # The only store whose payload is not in the blob, so clearing the manifest
    # alone would leave the .jsonl files on disk.  async_clear unlinks them.
    try:
        from .const import CAPTURE_STORE_KEY, DATA_CAPTURE

        st = _St(hass, 1, CAPTURE_STORE_KEY)
        await st.async_save({"sessions": []})
        cleared += 1
        cap_obj = domain.get(DATA_CAPTURE)
        if cap_obj is not None:
            await cap_obj.async_clear()
    except Exception as e:
        _LOGGER.warning("Factory reset: capture — %s", e)
        errors.append("padspan_ha.capture")

    # ── 9c-9e. Device registry, Lost & Found, Forensics ──────────────────
    # The screen promises "permanently delete ALL PadSpan data", "all BLE
    # object labels and tag names" — but these three were left: the device
    # registry put its labels straight back on every device after a reset
    # (snapshot_builder copies a registry label onto the object), Lost & Found
    # kept every last-seen room, and Forensics every session.
    from .const import (  # noqa: PLC0415
        DATA_DEVICE_REGISTRY, DATA_FORENSICS, DATA_LOST_AND_FOUND,
        FORENSICS_STORE_KEY, LOST_AND_FOUND_STORE_KEY,
    )
    from .device_registry import DEVICE_REGISTRY_STORE_KEY  # noqa: PLC0415
    for _key, _dkey, _empty, _reset in (
        (DEVICE_REGISTRY_STORE_KEY, DATA_DEVICE_REGISTRY, {"version": 1, "devices": {}},
         lambda o: (o._devices.clear(), o._index.clear(), o._ephemeral.clear())),
        (LOST_AND_FOUND_STORE_KEY, DATA_LOST_AND_FOUND, {},
         lambda o: o.records.clear()),
        (FORENSICS_STORE_KEY, DATA_FORENSICS, {"addrs": {}},
         lambda o: o.addrs.clear()),
    ):
        try:
            await _St(hass, 1, _key).async_save(_empty)
            cleared += 1
            _obj = domain.get(_dkey)
            if _obj is not None:
                _reset(_obj)
        except Exception as e:
            _LOGGER.warning("Factory reset: %s — %s", _key, e)
            errors.append(_key)

    # ── 10. Object history (plain dict, not a store class) ────────────────
    try:
        # Through the snapshot builder's own Store when it has one: a save on
        # that Store cancels its pending delayed save, which would otherwise
        # write the pre-reset history back moments later.
        st = domain.get("_obj_hist_store") or _St(hass, 1, OBJECT_HISTORY_STORE_KEY)
        await st.async_save({})
        cleared += 1
    except Exception as e:
        _LOGGER.warning("Factory reset: object_history — %s", e)
        errors.append(OBJECT_HISTORY_STORE_KEY)

    # ── 11. Backups store ─────────────────────────────────────────────────
    try:
        st = _St(hass, 1, BACKUPS_STORE_KEY)
        await st.async_save({})
        cleared += 1
    except Exception as e:
        _LOGGER.warning("Factory reset: backups — %s", e)
        errors.append(BACKUPS_STORE_KEY)

    # ── Clear ALL in-memory caches ────────────────────────────────────────

    # Object snapshot cache (used for fast re-renders)
    domain.pop(DATA_OBJECTS_CACHE, None)

    # One poll of beacon address memory. Stale across a reload — the addresses
    # a rotating device wore before are gone — and keeping it would have the
    # first poll after a reload compare against a world that no longer exists.
    domain.pop(DATA_BEACON_LAST_MACS, None)

    # Object history — set to None so the reload condition triggers fresh load
    domain.pop(DATA_OBJECT_HISTORY, None)
    domain.pop("_obj_hist_last_save", None)
    domain.pop("_obj_hist_store", None)

    # Presence coordinator caches
    try:
        _coord = domain.get("presence_coordinator")
        if _coord:
            for attr in ("_known_objs", "_last_seen", "_room_votes",
                         "_room_confidence", "_device_labels"):
                if hasattr(_coord, attr):
                    getattr(_coord, attr).clear()
    except Exception:
        pass

    # Main coordinator caches
    try:
        _main_coord = domain.get(DATA_COORDINATOR)
        if _main_coord:
            for attr in ("_known_objs", "_last_seen"):
                if hasattr(_main_coord, attr):
                    getattr(_main_coord, attr).clear()
    except Exception:
        pass

    # BluetoothLive advertisement cache — clear so old objects disappear.
    # The subscription stays active so new ads will repopulate naturally.
    try:
        _bl = get_bluetooth_live(hass)
        if _bl:
            _bl._seen_by_source.clear()
            _bl._radio_last_heard.clear()
            _bl._last_reseed = None
    except Exception:
        pass

    _LOGGER.warning(
        "FACTORY RESET executed by %s — cleared %d stores",
        connection.user.name if connection.user else "unknown",
        cleared,
    )

    _bump(hass, "factory_reset")
    # "total": 11 is a display figure for the UI's progress readout, not a
    # literal count of the try/except blocks above (there are 13, several
    # added after this constant was last touched) — it does not need to
    # track that count exactly, but if it drifts far enough to read as
    # "some stores silently skipped" to a user, bump it to match.
    connection.send_result(msg["id"], {
        "ok": len(errors) == 0,
        "cleared": cleared,
        "total": 11,
        "errors": errors,
    })
