# PadSpan HA — BLE Room-Presence Tracking for Home Assistant
# Copyright (C) 2026 Garry Broeckling
# Licensed under the GNU General Public License v3.0
# See LICENSE file or https://www.gnu.org/licenses/gpl-3.0.html
"""Live Bluetooth snapshot for PadSpan.

Goal: expose the same kind of scanner + advertisement feed you can see in
Home Assistant Settings → Devices & services → Bluetooth → Visualization.

We keep a light in-memory cache via bluetooth async callbacks, and we also
fall back to querying Home Assistant's discovered service-info list when
available.
"""

from __future__ import annotations

import datetime as dt
import logging
import re
import time
from collections import deque
from dataclasses import dataclass
from typing import Any, Callable, Dict, List, Optional

from homeassistant.core import HomeAssistant, callback

from .device_detail import scrub_apple_block
from .proxy_health import AdvertRateHealth

_LOGGER = logging.getLogger(__name__)


def _now() -> dt.datetime:
    return dt.datetime.now(dt.timezone.utc)


def _bytes_to_hex_list(b: bytes) -> str:
    # Match HA UI-ish style: "0x4A 0x17 ..."
    return " ".join(f"0x{v:02X}" for v in b)


def _manuf_hex(company: Any, payload: bytes) -> str:
    """A manufacturer block as stored, the hashes of a person's identifiers in
    Apple's taken out first (device_detail.scrub_apple_block)."""
    return _bytes_to_hex_list(scrub_apple_block(payload) if company == 76 else payload)


def _scanning_mode(obj: Any, attr: str) -> Optional[str]:
    """habluetooth's BluetoothScanningMode off a scanner, as a plain string.

    ACTIVE means the radio TRANSMITS — it sends SCAN_REQ and reads the SCAN_RSP
    that comes back, which is where a device puts its complete local name when
    it will not fit in the 31-byte advertisement. PASSIVE only listens. AUTO
    starts passive and is promoted to active on demand, so `current_mode`
    genuinely changes over time.

    Returns "active" / "passive" / "auto", or None when the attribute is absent
    (older habluetooth) or the scanner did not say. None means UNKNOWN and must
    never be presented as passive: not transmitting and not telling us are
    different facts.
    """
    m = getattr(obj, attr, None)
    if m is None:
        return None
    v = getattr(m, "value", None)          # Enum -> its value
    if isinstance(v, str) and v:
        return v.lower()
    try:
        return str(m).rsplit(".", 1)[-1].lower() or None
    except Exception:
        return None


def reseed_interval_s(settings: Optional[Dict[str, Any]]) -> int:
    """How often to reseed from HA's discovered-service-info, in seconds.

    ble_reseed_interval_s (Settings → Presence, 1–60, default 30) is always in
    the settings, since DEFAULT_SETTINGS is merged into every load. So "Enable
    aggressive BLE reseed (5s)" (Manage → HA Entities → BLE Proxy
    Compatibility, aggressive_ble_reseed) never ran: its branch only ran when
    the interval was missing, and the panel said 5 s while it stayed at 30. Now
    the checkbox caps the interval at 5 s, and a shorter interval stays.
    """
    s = settings or {}
    try:
        n = max(1, min(60, int(s.get("ble_reseed_interval_s", 30))))
    except (TypeError, ValueError):
        n = 30
    if s.get("aggressive_ble_reseed"):
        n = min(n, 5)
    return n


def _coerce_source(src: Any) -> str:
    # src may be a string, list/tuple/set of strings, or None.
    if src is None:
        return ""
    if isinstance(src, str):
        return src
    try:
        # iterable
        for s in src:
            if isinstance(s, str):
                return s
        return ""
    except Exception:
        return str(src)


def address_type_of(device: Any, esphome_ok: Optional[Callable[[str], bool]] = None) -> Optional[str]:
    """"public" or "random" when the radio says which, else None.

    ESPHome proxies put it in BLEDevice.details["address_type"] (bleak-esphome
    passes ESP-IDF's value on: 0 public, 1 random, 2 and 3 a resolvable private
    address, random on the air), and BlueZ in the D-Bus props ("AddressType").
    ESPHome's 0 is also protobuf's empty value: firmware before 2022.12 sends no
    type, so every address it hears, random ones too, arrives as 0. A 0 counts
    as public only when esphome_ok(details["source"]) says that proxy's firmware
    sends the type (BluetoothLive._esphome_public_ok); otherwise it says nothing.
    HA's mgmt channel and Shelly scanners don't report it.
    """
    details = getattr(device, "details", None)
    if not isinstance(details, dict):
        return None
    at = details.get("address_type")
    if at in (1, 2, 3) and not isinstance(at, bool):
        return "random"
    if at == 0 and not isinstance(at, bool):
        try:
            return "public" if esphome_ok is not None and esphome_ok(str(details.get("source") or "")) else None
        except Exception:
            return None
    props = details.get("props")
    if isinstance(props, dict):
        t = props.get("AddressType")
        if t in ("public", "random"):
            return t
    return None


def _tx_power_value(value: Any) -> Optional[int]:
    """A declared TX power in dBm, or None. habluetooth reports -127 for "none"."""
    if value is None:
        return None
    power = int(value)
    return None if power == -127 else power


def receiver_type(scanner: Any) -> str:
    """What kind of receiver a Home Assistant scanner is, by its class:
    bleak_esphome's ESPHomeScanner, aioshelly's ShellyBLEScanner, habluetooth's
    HaScanner and HaScannerMgmt (this machine's own adapter), HA's
    RuuviGatewayScanner. Fixed words for the opt-in report."""
    name = type(scanner).__name__.lower()
    for word, kind in (("esphome", "esphome"), ("shelly", "shelly"), ("hascanner", "ha_adapter"), ("ruuvi", "ruuvi")):
        if word in name:
            return kind
    return "other"


def _service_info_to_record(si: Any, seen: Optional[dt.datetime] = None,
                            esphome_ok: Optional[Callable[[str], bool]] = None) -> Dict[str, Any]:
    """Flatten a BluetoothServiceInfo(Bleak)-like object into a plain dict.

    Everything below is `getattr(..., None)` rather than direct attribute
    access because the shape of this object has genuinely varied across HA
    core / bleak versions (RSSI and manufacturer/service data sometimes sit
    directly on `si`, sometimes nested under `si.advertisement` instead) —
    the fallbacks exist to survive whichever shape the running HA actually
    hands us, not defensive padding against inputs that can't occur.
    """
    seen_dt = seen or getattr(si, "time", None) or getattr(si, "seen", None) or _now()
    if isinstance(seen_dt, (int, float)):
        # Some implementations may use unix seconds.
        seen_dt = dt.datetime.fromtimestamp(float(seen_dt), tz=dt.timezone.utc)
    if isinstance(seen_dt, dt.datetime) and seen_dt.tzinfo is None:
        seen_dt = seen_dt.replace(tzinfo=dt.timezone.utc)

    address = getattr(si, "address", "") or ""
    name = getattr(si, "name", None) or getattr(si, "local_name", None) or ""
    source = _coerce_source(getattr(si, "source", None))

    rssi = getattr(si, "rssi", None)
    if rssi is None:
        adv = getattr(si, "advertisement", None)
        rssi = getattr(adv, "rssi", None) if adv is not None else None

    service_uuids = getattr(si, "service_uuids", None) or getattr(si, "service_uuids", None) or []

    manuf = getattr(si, "manufacturer_data", None)
    if manuf is None:
        adv = getattr(si, "advertisement", None)
        manuf = getattr(adv, "manufacturer_data", None) if adv is not None else None
    if manuf is None:
        manuf = {}

    svcdata = getattr(si, "service_data", None)
    if svcdata is None:
        adv = getattr(si, "advertisement", None)
        svcdata = getattr(adv, "service_data", None) if adv is not None else None
    if svcdata is None:
        svcdata = {}

    manuf_out: Dict[str, str] = {}
    try:
        for k, v in dict(manuf).items():
            if isinstance(v, (bytes, bytearray)):
                manuf_out[str(k)] = _manuf_hex(k, bytes(v))
            else:
                manuf_out[str(k)] = str(v)
    except Exception:
        manuf_out = {}

    svc_out: Dict[str, str] = {}
    try:
        for k, v in dict(svcdata).items():
            if isinstance(v, (bytes, bytearray)):
                svc_out[str(k)] = _bytes_to_hex_list(bytes(v))
            else:
                svc_out[str(k)] = str(v)
    except Exception:
        svc_out = {}

    # TX Power Level AD type (0x0A) — device's declared transmit power at 1 m.
    # When present, use this instead of the static ref_power config to improve distance accuracy.
    # ESPresense uses the same approach for automatic per-device calibration.
    tx_power = getattr(si, "tx_power", None)
    if tx_power is None:
        adv = getattr(si, "advertisement", None)
        tx_power = getattr(adv, "tx_power", None) if adv is not None else None

    # Connectable flag — can this device accept BLE connections?
    connectable = getattr(si, "connectable", None)

    return {
        "address": address,
        "name": name or address,
        "source": source,
        "rssi": rssi,
        "tx_power": _tx_power_value(tx_power),
        "connectable": bool(connectable) if connectable is not None else None,
        "address_type": address_type_of(getattr(si, "device", None), esphome_ok),
        "last_seen": seen_dt.isoformat(),
        # age_s is filled in get_snapshot so it's relative to snapshot time
        "manufacturer_data": manuf_out,
        "service_data": svc_out,
        "service_uuids": list(service_uuids) if isinstance(service_uuids, (list, tuple, set)) else [],
    }


def _service_info_to_record_from_adv(
    addr: str, source: str, rssi: Any,
    ble_device: Any, adv_data: Any, seen: dt.datetime,
    esphome_ok: Optional[Callable[[str], bool]] = None,
) -> Dict[str, Any]:
    """Build a record dict from raw BLEDevice + AdvertisementData (per-scanner)."""
    name = getattr(ble_device, "name", None) or getattr(adv_data, "local_name", None) or ""

    manuf = getattr(adv_data, "manufacturer_data", None) or {}
    manuf_out: Dict[str, str] = {}
    try:
        for k, v in dict(manuf).items():
            if isinstance(v, (bytes, bytearray)):
                manuf_out[str(k)] = _manuf_hex(k, bytes(v))
            else:
                manuf_out[str(k)] = str(v)
    except Exception:
        pass

    svcdata = getattr(adv_data, "service_data", None) or {}
    svc_out: Dict[str, str] = {}
    try:
        for k, v in dict(svcdata).items():
            if isinstance(v, (bytes, bytearray)):
                svc_out[str(k)] = _bytes_to_hex_list(bytes(v))
            else:
                svc_out[str(k)] = str(v)
    except Exception:
        pass

    service_uuids = getattr(adv_data, "service_uuids", None) or []
    tx_power = getattr(adv_data, "tx_power", None)

    return {
        "address": str(addr),
        "name": str(name or addr),
        "source": _coerce_source(source),
        "rssi": int(rssi) if rssi is not None else None,
        "tx_power": _tx_power_value(tx_power),
        "connectable": None,
        "address_type": address_type_of(ble_device, esphome_ok),
        "last_seen": seen.isoformat(),
        "manufacturer_data": manuf_out,
        "service_data": svc_out,
        "service_uuids": list(service_uuids) if isinstance(service_uuids, (list, tuple, set)) else [],
    }


@dataclass
class _Adv:
    record: Dict[str, Any]
    seen: dt.datetime


class BluetoothLive:
    def __init__(self, hass: HomeAssistant) -> None:
        self.hass = hass
        # Keyed as {address: {source: _Adv}} so every radio's reading is kept independently.
        # Previously keyed only by address, which caused the second scanner callback to
        # overwrite the first — meaning only one radio's RSSI ever appeared per device.
        self._seen_by_source: Dict[str, Dict[str, _Adv]] = {}
        # {addr: {source: deque[(seen_dt, rssi)]}} — recent raw samples from
        # REAL callbacks (never the reseed path) for median-of-N filtering.
        self._rssi_samples: Dict[str, Dict[str, Any]] = {}
        # {addr: "random" | "public"}: what any radio reported for the address,
        # kept per address while it is cached (the maker list reads it,
        # known_type). Not per report: HA's own adapter reports no type
        # on its live adverts (habluetooth's mgmt side channel) while the reseed
        # reads BlueZ's for the same address, so in 0.38.207 each live advert
        # wiped the reseed's "random" until the next reseed. A report with no
        # type keeps the earlier one, "random" is never downgraded, and the entry
        # goes only when the address leaves the cache.
        self._address_types: Dict[str, str] = {}
        # {addr: unix time}: addresses a radio confirmed as public (ESPHome
        # address_type 0, BlueZ AddressType "public"), kept in .storage
        # (PUBLIC_ADDRESSES_STORE_KEY) through prunes and restarts: a public
        # address never changes type. The built-in maker list counts as fact for
        # these only (known_type). A "random" report removes one.
        self._public: Dict[str, int] = {}
        self._public_store: Any = None
        # {ESPHome scanner source: (its firmware sends the address type, until)}
        self._esphome_ok_cache: Dict[str, Any] = {}
        # How long the cache keeps an address, and how many it keeps at most
        # (0: no cap). Set by snapshot_builder from Settings → Presence: the
        # BLE Advertisement Timeout, and the low-memory switch's cap. Until
        # 0.38.106 the age was a fixed 4 h whatever the setting said, so
        # lowering the timeout saved no memory at all.
        self.cache_age_s: float = 14400.0
        self.cache_max_addrs: int = 0
        self._unsubs: List[Any] = []
        # Per-radio "last heard" timestamp — updated on every callback, independent of filtering.
        # Used by the frontend to show a radio as "listening" even when its ads are old/filtered.
        self._radio_last_heard: Dict[str, dt.datetime] = {}  # source → datetime
        self._last_reseed: Optional[dt.datetime] = None  # periodic reseed for proxy scanners
        # source → last observed scan mode, for counting transitions. Memory
        # only: it exists to answer "does the reported mode actually move?",
        # which cannot be answered from one reading.
        self._last_scan_mode: Dict[str, str] = {}
        # Diagnostics: last seed result
        self.seed_method: str = "none"  # "per_scanner", "deduplicated", "failed"
        self.seed_scanner_count: int = 0
        self.seed_device_readings: int = 0
        self.seed_error: str = ""
        # Addresses added to the cache since it was made (never decremented).
        # The opt-in report reads its rate per hour (perf_sampler.py): how
        # crowded the radio environment is, which sets how big the cache and
        # the object history grow.
        self.new_addresses: int = 0
        # Each scanner's advertisement rate against its own usual
        # (proxy_health.py): memory only, shown only while a drop is on.
        self.rate_health = AdvertRateHealth()

    def _note_scan_mode_flips(self, radios: List[Dict[str, Any]]) -> None:
        """Count radios whose live scan mode CHANGED since the last snapshot.

        One reading cannot tell a field that tracks the radio from one that
        echoes a stored setting. Movement can — and the two counters mean
        opposite things:

          auto    a scanner on AUTO is promoted to active in short windows, so
                  flips are expected. Seeing them proves the value is live.
          pinned  HA leaves an explicitly ACTIVE or PASSIVE scanner alone, so
                  flips should be ~0. A fleet where pinned radios keep changing
                  would mean the mode is not under the owner's control there,
                  which is the one result that makes the map indicator
                  dishonest — and it cannot be seen from a single install.

        Counts only, and only when the owner opted in. `bump` is a dict
        increment when on and one lookup when off, so this is safe on the
        snapshot path.
        """
        try:
            from .telemetry import bump  # noqa: PLC0415 - avoids an import cycle
        except Exception:
            return
        for r in radios:
            src = r.get("source") or ""
            mode = r.get("scan_mode")
            if not src or not mode:
                continue          # unknown is not a transition, and never a flip
            prev = self._last_scan_mode.get(src)
            self._last_scan_mode[src] = mode
            if prev is None or prev == mode:
                continue
            req = str(r.get("requested_scan_mode") or "").lower()
            if req == "auto":
                bump(self.hass, "scan_mode_flip_auto")
            else:
                bump(self.hass, "scan_mode_flip_pinned")

    def _rate_health_tick(self) -> set:
        """Close the advertisement-rate minute if one has passed; the
        scanners whose drop is on. Counts each drop that starts (opt-in
        report only)."""
        try:
            started = self.rate_health.tick(time.monotonic())
            if started:
                from .telemetry import bump  # noqa: PLC0415 - avoids an import cycle
                bump(self.hass, "proxy_rate_drop", len(started))
            return self.rate_health.low_sources()
        except Exception as e:  # noqa: BLE001 - never costs the snapshot
            _LOGGER.debug("Advert rate health skipped: %s", e)
            return set()

    def unload(self) -> None:
        for u in self._unsubs:
            try:
                u()
            except Exception:
                pass
        self._unsubs.clear()
        self._seen_by_source.clear()
        self._rssi_samples.clear()
        self._address_types.clear()

    def _note_address_type(self, addr: str, address_type: Optional[str]) -> None:
        """Keep what a report says about the address's type (_address_types,
        and _public for a confirmed public one)."""
        if address_type == "random":
            self._address_types[addr] = "random"
            if self._public.pop(addr, None) is not None:
                self._save_public(at_once=True)
        elif address_type == "public":
            self._address_types.setdefault(addr, "public")
            if self._address_types[addr] == "public":
                now = int(time.time())
                prev = self._public.get(addr)
                # Saved when new, and its time refreshed once a day: the oldest
                # go first when there are more than PUBLIC_MAX.
                if prev is None or now - prev > 86400:
                    self._public[addr] = now
                    self._save_public()

    def _save_public(self, at_once: bool = False) -> None:
        if len(self._public) > PUBLIC_MAX:
            keep = sorted(self._public, key=self._public.__getitem__, reverse=True)[:int(PUBLIC_MAX * 0.9)]
            self._public = {a: self._public[a] for a in keep}
        if self._public_store is None:
            return
        def _data() -> Dict[str, Any]:
            return {"rule": PUBLIC_STORE_RULE, "addresses": dict(self._public)}
        try:
            if at_once:
                # A removal is written now, not up to 60 s later: a power cut
                # must not bring back an address a radio has said is random.
                self.hass.async_create_task(self._public_store.async_save(_data()))
            else:
                self._public_store.async_delay_save(_data, 60)
        except Exception:
            try:
                self._public_store.async_delay_save(_data, 0 if at_once else 60)
            except Exception as e:  # noqa: BLE001
                _LOGGER.debug("public address save failed: %s", e)

    def _esphome_public_ok(self, source: str) -> bool:
        """Does this ESPHome proxy's firmware send the address type (2022.12 or
        newer)? An unknown version counts as no. Asked again after 60 s (no)
        or 10 min (yes), so a proxy that just connected, or was updated, is
        read again soon."""
        now = time.monotonic()
        hit = self._esphome_ok_cache.get(source)
        if hit is not None and now < hit[1]:
            return hit[0]
        ok = esphome_sends_address_type(esphome_version(self.hass, source))
        self._esphome_ok_cache[source] = (ok, now + (600.0 if ok else 60.0))
        return ok

    def known_type(self, address: str) -> Optional[str]:
        """"random" or "public" if a radio has said which (the second kept in
        .storage, so it lasts), else None. Dict lookups only: read per object,
        per build."""
        return self._address_types.get(address) or ("public" if address in self._public else None)

    async def async_load_public(self, store: Any) -> None:
        """Read the confirmed public addresses kept from earlier runs."""
        self._public_store = store
        try:
            data = await store.async_load()
        except Exception as e:  # noqa: BLE001
            _LOGGER.debug("public address load failed: %s", e)
            data = None
        # Only a file written under this rule: 0.38.211 also kept ESPHome's 0
        # from proxies too old to send a type.
        ok_rule = isinstance(data, dict) and data.get("rule") == PUBLIC_STORE_RULE
        addrs = data.get("addresses") if ok_rule else None
        if isinstance(addrs, dict):
            for a, t in addrs.items():
                if (isinstance(a, str) and len(a) == 17 and isinstance(t, (int, float))
                        and self._address_types.get(a.upper()) != "random"):
                    self._public.setdefault(a.upper(), int(t))

    @callback
    def _on_adv(self, service_info: Any, change: Any = None) -> None:
        # The live habluetooth callback registered in async_setup_bluetooth_live
        # (both ACTIVE and PASSIVE registrations point here) — HA calls this
        # synchronously on its event loop for every advertisement any scanner
        # hears, so the whole body is one try/except: raising here would
        # propagate into HA's bluetooth dispatch and could take scanning down
        # for every integration, not just ours, over a single malformed ad.
        # Store latest reading per {address, source} — preserves all radios' views of a device
        try:
            addr = getattr(service_info, "address", None) or ""
            if not addr:
                return
            seen = _now()
            # When the advertisement was actually received (service_info.time,
            # monotonic — the same clock the reseed's scanner stamps use).
            # Registering a callback makes HA replay its cached history into
            # it; stamped "now", a minutes-old address looked live again and
            # a Find My tag's correct link was undone on every restart
            # (review round 11).
            # A stamp from before this boot is NEGATIVE (habluetooth restores
            # its stored history as unix - (time() - monotonic())), and those
            # replay too — so any non-zero stamp counts (round 12).
            _t = getattr(service_info, "time", None)
            _age = 0.0
            if isinstance(_t, (int, float)) and _t != 0:
                _age = (time.time() if float(_t) > 1e9 else time.monotonic()) - float(_t)
                if _age > 0:
                    seen = seen - dt.timedelta(seconds=_age)
            rec = _service_info_to_record(service_info, seen=seen, esphome_ok=self._esphome_public_ok)
            src = rec.get("source") or "_unknown"
            if addr not in self._seen_by_source:
                self._seen_by_source[addr] = {}
                self.new_addresses += 1
            # Before the replay check: an old report's type is still true.
            self._note_address_type(addr, rec.get("address_type"))
            # A REPLAYED (old) report never replaces a newer one. A live advert
            # (age ~0) always lands: comparing wall-clock stamps alone froze
            # live readings for as long as a backward clock step (round 12).
            _prev_adv = self._seen_by_source[addr].get(src)
            if _age > 2.0 and _prev_adv is not None and _prev_adv.seen > seen:
                return
            self._seen_by_source[addr][src] = _Adv(record=rec, seen=seen)
            if _age <= 2.0 and src != "_unknown":
                self.rate_health.note(src, addr, time.monotonic())
            # Sample history for median-of-N (real callbacks only — the
            # reseed path replays cached readings and must not multiply them)
            _rs = rec.get("rssi")
            if _rs is not None:
                self._rssi_samples.setdefault(addr, {}).setdefault(
                    src, deque(maxlen=32)
                ).append((seen, float(_rs)))
            # Track when each radio last sent us anything (independent of age filtering)
            if src != "_unknown" and (src not in self._radio_last_heard or self._radio_last_heard[src] < seen):
                self._radio_last_heard[src] = seen
        except Exception as e:
            _LOGGER.debug("BLE adv parse failed: %s", e)

    def _seed_from_discovered(self) -> None:
        """Populate cache with per-scanner RSSI data from ALL scanners.

        HA's deduplicated APIs (async_discovered_service_info, async_register_callback)
        only return ONE scanner's reading per device.  For indoor positioning we need
        RSSI from EVERY scanner that sees each device.

        Primary method: iterate each scanner's own device cache via the habluetooth
        manager (same pattern Bermuda uses).  Each scanner maintains its own dict of
        discovered devices with per-scanner RSSI — no deduplication.

        Fallback: async_discovered_service_info (deduplicated, only 1 scanner per device).
        """
        try:
            _seeded_scanner = False
            _scanner_count = 0
            _total_ads = 0
            # ── Primary: per-scanner iteration (full RSSI matrix) ──
            try:
                from habluetooth import get_manager as _get_bt_manager  # type: ignore
                manager = _get_bt_manager()
                if manager:
                    seen = _now()
                    _mono_now = time.monotonic()
                    scanners_list = list(manager.async_current_scanners())
                    _scanner_count = len(scanners_list)
                    for scanner in scanners_list:
                        src = getattr(scanner, "source", None)
                        if not src:
                            continue
                        dev_adv = getattr(scanner, "discovered_devices_and_advertisement_data", None)
                        if dev_adv is None:
                            continue
                        # Per-device timestamps of when the scanner ACTUALLY
                        # last heard each device (monotonic, Bermuda-style).
                        # Without them, reseeding would stamp every cached
                        # entry as heard-now, laundering stale readings as
                        # fresh every 30 s for as long as the cache holds them.
                        _stamps = getattr(scanner, "discovered_device_timestamps", None) or {}
                        for ble_device, adv_data in dev_adv.values():
                            addr = getattr(ble_device, "address", None)
                            if not addr:
                                continue
                            rssi = getattr(adv_data, "rssi", None)
                            _stamp = _stamps.get(addr)
                            if _stamp is not None:
                                # Stamps are monotonic; > 1e9 means a unix-epoch
                                # implementation — handle both.
                                if float(_stamp) > 1e9:
                                    _age = max(0.0, time.time() - float(_stamp))
                                else:
                                    _age = max(0.0, _mono_now - float(_stamp))
                                dev_seen = seen - dt.timedelta(seconds=_age)
                            else:
                                # No stamp from this scanner — HA's own adapter
                                # keeps none when HA runs it through bleak
                                # (Bluetooth "degraded mode": no kernel mgmt
                                # socket), and HA passes an unchanged advert
                                # to no callback, so a steady device heard
                                # there aged from its first report while still
                                # advertising (review rounds 13-14). The
                                # manager's last advert for the address —
                                # overall, or among connectable scanners, where
                                # the host adapter still counts when a passive
                                # proxy holds the overall record — is updated
                                # on every one, unchanged or not: its time,
                                # when THIS scanner is the one it came from.
                                # Otherwise keep the existing record's age
                                # rather than refreshing it; only brand-new
                                # entries get stamped now.
                                _lt = None
                                for _conn in (False, True):
                                    try:
                                        _last = manager.async_last_service_info(addr, _conn)
                                    except Exception:  # noqa: BLE001
                                        _last = None
                                    if _last is not None and str(getattr(_last, "source", "")) == str(src):
                                        _lt = getattr(_last, "time", None)
                                        break
                                if isinstance(_lt, (int, float)) and _lt != 0:
                                    _age = max(0.0, (time.time() if float(_lt) > 1e9 else _mono_now) - float(_lt))
                                    dev_seen = seen - dt.timedelta(seconds=_age)
                                else:
                                    _prev = self._seen_by_source.get(addr, {}).get(str(src))
                                    dev_seen = _prev.seen if _prev else seen
                            rec = _service_info_to_record_from_adv(
                                addr, src, rssi, ble_device, adv_data, dev_seen,
                                esphome_ok=self._esphome_public_ok,
                            )
                            if addr not in self._seen_by_source:
                                self._seen_by_source[addr] = {}
                                self.new_addresses += 1
                            self._note_address_type(addr, rec.get("address_type"))
                            self._seen_by_source[addr][str(src)] = _Adv(record=rec, seen=dev_seen)
                            if str(src) != "_unknown":
                                self._radio_last_heard[str(src)] = seen
                            _total_ads += 1
                    _seeded_scanner = True
                    self.seed_method = "per_scanner"
                    self.seed_scanner_count = _scanner_count
                    self.seed_device_readings = _total_ads
                    self.seed_error = ""
                else:
                    self.seed_error = "get_manager() returned None"
            except ImportError as _imp_err:
                self.seed_error = f"habluetooth import: {_imp_err}"
            except Exception as _mgr_err:
                self.seed_error = f"scanner iteration: {_mgr_err}"

            # ── Fallback: deduplicated API (1 scanner per device) ──
            if not _seeded_scanner:
                self.seed_method = "deduplicated"
                from homeassistant.components import bluetooth  # type: ignore
                if hasattr(bluetooth, "async_discovered_service_info"):
                    infos = bluetooth.async_discovered_service_info(self.hass)
                    for si in infos:
                        self._on_adv(si)
                    try:
                        infos_nc = bluetooth.async_discovered_service_info(
                            self.hass, connectable=False
                        )
                        for si in infos_nc:
                            self._on_adv(si)
                    except TypeError:
                        pass

            self._last_reseed = _now()
        except Exception as e:
            _LOGGER.debug("BLE seed failed: %s", e)

    @property
    def callback_active(self) -> bool:
        """True if at least one BLE callback is registered."""
        return bool(self._unsubs)

    @property
    def unique_address_count(self) -> int:
        return len(self._seen_by_source)

    def clear_scanner(self, source: str) -> int:
        """Remove all cached advertisements from a specific scanner.

        Returns the number of address entries cleaned.
        """
        cleared = 0
        for addr in list(self._seen_by_source):
            if source in self._seen_by_source[addr]:
                del self._seen_by_source[addr][source]
                cleared += 1
                if not self._seen_by_source[addr]:
                    del self._seen_by_source[addr]
                    self._address_types.pop(addr, None)
        return cleared

    def _cap_addresses(self, now: dt.datetime) -> None:
        """Over cache_max_addrs: drop the addresses heard longest ago, down to
        90% of the cap so the sort is not paid again on the next build."""
        cap = self.cache_max_addrs
        if not cap or len(self._seen_by_source) <= cap:
            return
        def _last(addr: str) -> dt.datetime:
            return max((a.seen for a in self._seen_by_source[addr].values()), default=now)
        keep = int(cap * 0.9)
        for addr in sorted(self._seen_by_source, key=_last)[:len(self._seen_by_source) - keep]:
            del self._seen_by_source[addr]
            self._rssi_samples.pop(addr, None)
            self._address_types.pop(addr, None)

    def get_snapshot(self, max_ads: int = 1000, max_age_s: int = 900) -> Dict[str, Any]:
        """Return a lightweight BLE snapshot for the UI.

        radios: active scanners/adapters (local + remote proxies)
        advertisements: recently seen advertisements with RSSI + metadata

        We include a small diagnostics object so the UI can surface why BLE might look empty.
        """
        diag: Dict[str, Any] = {
            "ok": True,
            "seeded": False,
            "callback_active": self.callback_active,
            "adv_cache_size": sum(len(v) for v in self._seen_by_source.values()),
            "unique_cached": self.unique_address_count,
            "errors": [],
        }

        try:
            from homeassistant.components import bluetooth  # type: ignore

            now = _now()
            radios: List[Dict[str, Any]] = []
            _rate_low = self._rate_health_tick()
            try:
                scanners_fn = getattr(bluetooth, "async_current_scanners", None)
                if scanners_fn is not None:
                    scanners = scanners_fn(self.hass)

                    # Some HA versions return dict-like containers.
                    if isinstance(scanners, dict):
                        scanners = scanners.values()

                    for s in scanners:
                        src = getattr(s, "source", None)
                        name = getattr(s, "name", None)
                        connectable = getattr(s, "connectable", None)
                        scanning = getattr(s, "scanning", None)
                        adapter = getattr(s, "adapter", None)
                        # ACTIVE vs PASSIVE scanning — whether the radio
                        # TRANSMITS. An active scanner sends SCAN_REQ and reads
                        # the SCAN_RSP that comes back; a passive one only
                        # listens. This is habluetooth's BluetoothScanningMode
                        # and is NOT `connectable` (which is about opening GATT
                        # connections) and NOT `scanning` (which only says the
                        # scanner is running). Three separate facts.
                        #
                        # AUTO is a real third value: the scanner starts
                        # passive and the manager promotes it to active on
                        # demand, so `current_mode` genuinely changes over
                        # time. current_mode is what it is doing NOW;
                        # requested_mode is what was asked for.
                        cur_mode = _scanning_mode(s, "current_mode")
                        req_mode = _scanning_mode(s, "requested_mode")

                        _radio_src = _coerce_source(src) or ""
                        _lh = self._radio_last_heard.get(_radio_src)
                        _lh_s = round((now - _lh).total_seconds(), 1) if _lh else None
                        radios.append({
                            "source": _radio_src,
                            "name": str(name or ""),
                            "connectable": bool(connectable) if connectable is not None else None,
                            "scanning": bool(scanning) if scanning is not None else None,
                            "scan_mode": cur_mode,
                            "requested_scan_mode": req_mode,
                            "adapter": str(adapter or "") if adapter is not None else "",
                            "last_heard_s": _lh_s,
                            "receiver_type": receiver_type(s),
                        })
                        # Only while this scanner's drop is on: a healthy
                        # house's radios are exactly as before.
                        if _radio_src in _rate_low:
                            radios[-1]["adv_rate_low"] = True
                else:
                    # Older HA: we may not be able to list scanners individually.
                    count = None
                    count_fn = getattr(bluetooth, "async_scanner_count", None)
                    if count_fn is not None:
                        try:
                            count = count_fn(self.hass, connectable=True)
                        except TypeError:
                            count = count_fn(self.hass)
                    if isinstance(count, int):
                        radios.append(
                            {
                                "source": "",
                                "name": f"Scanners active: {count} (upgrade HA for per-scanner list)",
                                "connectable": None,
                                "scanning": None,
                                "scan_mode": None,
                                "requested_scan_mode": None,
                                "adapter": "",
                            }
                        )
            except Exception as e:
                diag["ok"] = False
                diag["errors"].append(f"scanner_list_failed: {e!s}")
                radios = []

            # Periodically reseed from HA's discovered-service-info API.
            # This is essential for proxy scanners (Shelly, etc.) whose
            # advertisements arrive via HA's scanner infrastructure but NOT
            # through async_register_callback.  Default 30s; aggressive mode
            # (5s) can be enabled in settings for HA 2026.4+ where habluetooth
            # dedup suppresses repeat callbacks from passive proxies.
            _RESEED_INTERVAL_S = 30
            try:
                from .const import DOMAIN, DATA_SETTINGS
                _st = self.hass.data.get(DOMAIN, {}).get(DATA_SETTINGS)
                if _st:
                    _RESEED_INTERVAL_S = reseed_interval_s(_st.data)
            except Exception:
                pass
            # How late a passive proxy's reports can arrive — the Find My
            # report's "late" (findmy.py _report_lag) reads it here.
            diag["reseed_interval_s"] = _RESEED_INTERVAL_S
            _needs_reseed = (
                not self._seen_by_source
                or self._last_reseed is None
                or (now - self._last_reseed).total_seconds() > _RESEED_INTERVAL_S
            )
            if _needs_reseed:
                try:
                    self._seed_from_discovered()
                    diag["seeded"] = True
                except Exception as e:
                    diag["ok"] = False
                    diag["errors"].append(f"seed_failed: {e!s}")

            ads: List[Dict[str, Any]] = []
            # Prune old entries from cache to prevent unbounded growth: past
            # cache_age_s (4 h unless the timeout setting says otherwise).
            # Previously a fixed 30 min — too aggressive, caused beacons/tags
            # to vanish from the objects list before users could find/tag them.
            _prune_age = self.cache_age_s
            _prune_addrs: List[str] = []
            for addr, src_map in self._seen_by_source.items():
                _dead = [s for s, a in src_map.items() if (now - a.seen).total_seconds() > _prune_age]
                for s in _dead:
                    del src_map[s]
                if not src_map:
                    _prune_addrs.append(addr)
            for addr in _prune_addrs:
                del self._seen_by_source[addr]
                self._rssi_samples.pop(addr, None)
                self._address_types.pop(addr, None)
            self._cap_addresses(now)

            # Collect per-address records, keeping ALL per-source readings for
            # each address.  The max_ads cap applies to unique *addresses* (not
            # total per-source records) so that multiple scanners don't crowd
            # out devices.
            addr_best_age: Dict[str, float] = {}  # addr → best (lowest) age_s
            addr_records: Dict[str, List[Dict[str, Any]]] = {}
            for addr, src_map in self._seen_by_source.items():
                for src, a in src_map.items():
                    age_s = (now - a.seen).total_seconds()
                    if max_age_s and age_s > max_age_s:
                        continue
                    rec = dict(a.record)
                    rec["age_s"] = age_s
                    # Median-of-N: a 1-2 Hz beacon emits many ads per poll
                    # window but the cache keeps only the newest per source.
                    # Report the median of the last 15 s of real samples —
                    # BLE noise is heavy-tailed and the median rejects
                    # multipath fade outliers the single latest ad can't.
                    _sd = self._rssi_samples.get(addr, {}).get(src)
                    if _sd:
                        _fresh = sorted(
                            r for (t, r) in _sd
                            if (now - t).total_seconds() <= 15.0
                        )
                        if len(_fresh) >= 3:
                            _m = len(_fresh) // 2
                            rec["rssi"] = round(
                                _fresh[_m] if len(_fresh) % 2
                                else (_fresh[_m - 1] + _fresh[_m]) / 2.0,
                                1,
                            )
                    addr_records.setdefault(addr, []).append(rec)
                    prev = addr_best_age.get(addr)
                    if prev is None or age_s < prev:
                        addr_best_age[addr] = age_s

            # Cap by unique address count (most recently seen first)
            sorted_addrs = sorted(addr_best_age, key=lambda a: addr_best_age[a])
            if max_ads and len(sorted_addrs) > max_ads:
                sorted_addrs = sorted_addrs[:max_ads]
            kept = set(sorted_addrs)
            for addr in kept:
                ads.extend(addr_records[addr])

            # Sort: most recently seen first
            ads.sort(key=lambda x: x.get("age_s", 1e9))

            # --- Synthetic radios for orphaned sources ---
            # Some scanners (e.g. Shelly BLE proxies) relay advertisements
            # through HA but don't appear in async_current_scanners().  If we
            # see a source in our advertisement cache that has no matching
            # radio entry, create a synthetic one so it shows up in the
            # scanner list, calibration UI, and everywhere else.
            known_sources = {r["source"] for r in radios if r.get("source")}
            orphan_sources: Dict[str, dt.datetime] = {}  # source → latest seen
            for src_map in self._seen_by_source.values():
                for src, adv_obj in src_map.items():
                    if src and src != "_unknown" and src not in known_sources:
                        prev = orphan_sources.get(src)
                        if prev is None or adv_obj.seen > prev:
                            orphan_sources[src] = adv_obj.seen
            for src, last_seen in orphan_sources.items():
                _lh_s = round((now - last_seen).total_seconds(), 1)
                radios.append({
                    "source": src,
                    "name": src,  # best-effort; enrichment in websocket.py adds device name
                    "connectable": False,
                    # HA dropped this scanner; only its cached readings
                    # remain (up to the BLE timeout, 4 h by default). It
                    # is listening only if it was heard just now.
                    "scanning": _lh_s < 120,
                    "scan_mode": None,
                    "requested_scan_mode": None,
                    "adapter": "",
                    "last_heard_s": _lh_s,
                })
            if orphan_sources:
                diag["synthetic_radios"] = len(orphan_sources)

            diag["adv_cache_size"] = sum(len(v) for v in self._seen_by_source.values())
            diag["unique_addresses"] = len(addr_best_age)
            diag["unique_after_cap"] = len(kept)
            self._note_scan_mode_flips(radios)

            return {
                "radios": radios,
                "advertisements": ads,
                "diag": diag,
            }
        except Exception as e:
            _LOGGER.debug("BLE snapshot failed: %s", e)
            return {"radios": [], "advertisements": [], "diag": {"ok": False, "errors": [str(e)]}}
DATA_KEY = "bluetooth_live"

# At most this many confirmed public addresses are kept (the oldest confirmed go first).
PUBLIC_MAX = 2000
# Written into the file; a file without it (0.38.211) is not read.
PUBLIC_STORE_RULE = 2
# ESPHome 2022.12.0 was the first to send the address type with its adverts
# (esphome#4115); before it the field is missing, and reads 0, "public".
ESPHOME_TYPE_SINCE = (2022, 12)


def esphome_sends_address_type(version: Any) -> bool:
    """True for an ESPHome firmware version that sends the address type."""
    m = re.match(r"\s*(\d{4})\.(\d{1,2})\b(.*)", str(version or ""))
    if not m:
        return False
    ym = (int(m.group(1)), int(m.group(2)))
    if ym != ESPHOME_TYPE_SINCE:
        return ym > ESPHOME_TYPE_SINCE
    return "dev" not in m.group(3)  # 2022.12.0-dev builds came before the change too


def esphome_version(hass: Any, source: str) -> Optional[str]:
    """The firmware version of the ESPHome proxy whose scanner this is, or None.

    bleak-esphome keeps the proxy's device info with its scanner's connector
    (connect_scanner: client=partial(ESPHomeClient, client_data=...)), and HA's
    ESPHome integration with its config entry (runtime_data.device_info); the
    scanner's source is device_info.bluetooth_mac_address or mac_address.
    """
    src = str(source or "").upper()
    if not src:
        return None
    try:
        from habluetooth import get_manager as _get_bt_manager  # type: ignore
        for sc in _get_bt_manager().async_current_scanners():
            if str(getattr(sc, "source", "")).upper() != src:
                continue
            client = getattr(getattr(sc, "connector", None), "client", None)
            cd = (getattr(client, "keywords", None) or {}).get("client_data")
            v = getattr(getattr(cd, "device_info", None), "esphome_version", None)
            if v:
                return str(v)
    except Exception:
        pass
    try:
        for entry in hass.config_entries.async_entries("esphome"):
            di = getattr(getattr(entry, "runtime_data", None), "device_info", None)
            if di is None:
                continue
            macs = {str(getattr(di, "bluetooth_mac_address", "") or "").upper(),
                    str(getattr(di, "mac_address", "") or "").upper()}
            v = getattr(di, "esphome_version", None)
            if src in macs and v:
                return str(v)
    except Exception:
        pass
    return None


async def async_setup_bluetooth_live(hass: HomeAssistant) -> BluetoothLive:
    """Create + register BLE callbacks."""
    bl = BluetoothLive(hass)
    try:
        from homeassistant.helpers.storage import Store  # noqa: PLC0415
        from .const import PUBLIC_ADDRESSES_STORE_KEY, VENDOR_CACHE_STORE_KEY  # noqa: PLC0415
        await bl.async_load_public(Store(hass, 1, PUBLIC_ADDRESSES_STORE_KEY))
        # The answers the online maker lookup kept. Nothing reads them any more.
        await Store(hass, 1, VENDOR_CACHE_STORE_KEY).async_remove()
    except Exception as e:  # noqa: BLE001
        _LOGGER.debug("public address store unavailable: %s", e)

    try:
        from homeassistant.components import bluetooth  # type: ignore

        # Register callbacks without filters to capture all advertisements.
        # We need BOTH ACTIVE (connectable scanners) and PASSIVE (non-connectable
        # scanners like Shelly BLE proxies) to see ads from all scanner types.
        mode_enum = getattr(bluetooth, "BluetoothScanningMode", None)
        active_mode = mode_enum.ACTIVE if mode_enum is not None else None
        passive_mode = getattr(mode_enum, "PASSIVE", None) if mode_enum is not None else None

        def _register_cb(mode):
            try:
                if mode is not None:
                    return bluetooth.async_register_callback(hass, bl._on_adv, {}, mode)
                else:
                    return bluetooth.async_register_callback(hass, bl._on_adv, {})
            except TypeError:
                try:
                    return bluetooth.async_register_callback(hass, bl._on_adv)
                except TypeError:
                    try:
                        return bluetooth.async_register_callback(hass, bl._on_adv, matcher={})
                    except Exception:
                        return None

        # Register for connectable (ACTIVE) scanner advertisements
        unsub = _register_cb(active_mode)
        if unsub:
            bl._unsubs.append(unsub)

        # Register for non-connectable (PASSIVE) scanner advertisements
        # (Shelly BLE proxies, other passive relay scanners)
        if passive_mode is not None:
            unsub2 = _register_cb(passive_mode)
            if unsub2:
                bl._unsubs.append(unsub2)

        # Seed once on startup so UI isn't empty while we wait for callbacks.
        bl._seed_from_discovered()

    except Exception as e:
        _LOGGER.debug("Bluetooth callbacks not available: %s", e)

    hass.data.setdefault("padspan_ha", {})[DATA_KEY] = bl
    return bl


def get_bluetooth_live(hass: HomeAssistant) -> Optional[BluetoothLive]:
    return hass.data.get("padspan_ha", {}).get(DATA_KEY)
